<?php
echo "Data do servidor: " . date('d-m-Y H:i:s P e T ') . "<br><br>";
require_once("includes/defines.inc");
if($_GET["key"] == '50245869000174' . date("dmY")) {
    echo "<p>Vers�o do Manager: <strong>" . $WEBERP_VERSAO . "</strong></p>";
    phpinfo();
}
die();
?>