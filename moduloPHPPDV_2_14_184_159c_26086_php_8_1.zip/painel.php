<?PHP
// ini_set('display_errors',1);
// ini_set('display_startup_erros',1);
// error_reporting(E_ALL);
	
	//$_INCLUIR					= true;
	$GLOBALS['_IS_MANAGER_PDV'] = 1;
	
	include_once("includes/defines.inc");
	include_once("includes/funcoes.fcn");
	registrarAutoload();	
   	include_once("classes/class_funcoesgerais.inc");
	include_once("classes/class_HTML.inc");
	require_once("includes/header.inc");

	if ($_GET['cad'] == '1'){
		$data  = date('YmdHis');
		$arq   = funcoesGerais::listarArquivos('plugin/painel/fila/','pdv');
		if (is_array($arq) && !empty($arq)) {
			sort($arq);
			foreach($arq as $arquivo) {
				$a = explode('-',$arquivo);
				if (($data - $a[0]) > 200) {
					unlink('plugin/painel/fila/'.$arquivo);
				}
			}
		}
		$arq = funcoesGerais::listarArquivos('plugin/painel/fila/','pdv');
        if (is_array($arq) && !empty($arq)) {
			sort($arq);		
			$fila 				= unserialize(file_get_contents('plugin/painel/fila/'.$arq[0]));
			$fila['arquivo'] 	= 'plugin/painel/fila/'.$arq[0];
			unlink($fila['arquivo']);
            $retorno = json_encode($fila);
		} else {
			$retorno = 'ND';
		}
        echo $retorno;
		die;
	}
		
	if ($_GET['cad'] == '3'){
		require_once("web_services/ws_painel/classes/class_webservice_painel.inc");
			
		$dados = json_decode($_POST['val']);
		$dados = (array)$dados;

		$_config_old = 'plugin/painel/parametros_old.config';
		$_config     = 'plugin/painel/parametros.config';

		unlink($_config_old);

		rename($_config,$_config_old);

		file_put_contents($_config, serialize($dados));

		$_wsPS = new webservice_painel();

		$retorno = $_wsPS->downloadArquivo();


		echo json_encode($retorno);
		die;
	}

	if ($_GET['cad'] == '4'){

		$tipo = $_POST['val'];

		if ($tipo == 'slide')
			$_lista = funcoesGerais::listarArquivos('plugin/painel/slide/','jpg');
		else if ($tipo == 'video')
			$_lista = funcoesGerais::listarArquivos('plugin/painel/mov/','mp4');

		echo json_encode((object)$_lista);

		die;
	}
	
	$_HTML = new HTML();
	
	$_ID["html"] = $_HTML->AddTag("HTML");
	
		$_ID["head"] = $_HTML->AddTag("HEAD");
			$_HTML->AddTag("META",Array("_"=>'charset="UTF-8"'),TRUE);

			$_HTML->AddTag("TITLE",NULL,TRUE,"Zanthus - Sistemas Integrados - Painel");
			$_HTML->AddTag("LINK",Array("REL"=>"SHORTCUT ICON","href"=>"imagens/Zanthus.ico"),TRUE);
			$_HTML->AddTag("LINK",Array("REL"=>"stylesheet","href"=>"{$_URL}css/plugins/bootstrap/css/bootstrap.min.css{$GLOBALS['_VERSAO_CACHE']}", TRUE));
			$_HTML->AddTag("LINK",Array("REL"=>"stylesheet","href"=>"{$_URL}css/plugins/painel/styles.css{$GLOBALS['_VERSAO_CACHE']}", TRUE));
			$_HTML->AddTag("LINK",Array("REL"=>"stylesheet","href"=>"{$_URL}css/plugins/painel/w3.css{$GLOBALS['_VERSAO_CACHE']}", TRUE));
			html::preencherJavaScriptPadrao($_HTML);
			$_HTML->AddTag("SCRIPT",Array("SRC"=>"JavaScript/plugins/painel/painel.js{$GLOBALS['_VERSAO_CACHE']}"),True);
			
		$_HTML->EndTag($_ID["head"]);
	
		$_ID["body"] = $_HTML->AddTag("BODY",'');
				$audio = $_HTML->AddTag("AUDIO",array('id'=>'audio_campainha'));
						$_HTML->AddTag("SOURCE",array('id'=>"source_campainha",'src'=>"",'type'=>"audio/ogg" ),true);
				$_HTML->EndTag($audio);

				$audio = $_HTML->AddTag("AUDIO",array('id'=>'audio_fala'));
						$_HTML->AddTag("SOURCE",array('id'=>"source_fala",'src'=>"",'type'=>"audio/ogg" ),true);
				$_HTML->EndTag($audio);
	
				$_div = $_HTML->AddTag("DIV",array('id'=>'header','class'=>"text-center"));
						$_HTML->AddTag("IMG",array('id'=>"source",'onclick'=>'getClassePainelGlobal().abrirConfig()','src'=>"plugin/painel/img/logo_painel.png"),true);
				$_HTML->EndTag($_div);
				
				$_div = $_HTML->AddTag("DIV",array('id'=>'noticia'));
					$_div2 = $_HTML->AddTag("DIV",array('id'=>'w3-content w3-section'));
						$_HTML->AddTag('IMG',array('id'=>'img_slide','style'=>"display: none;",'class'=>"mySlides w3-animate-zoom",'src'=>""),true);
						$img  =	$_HTML->AddTag("VIDEO",array('width'=>"100%",'id'=>'videoPlayer','style'=>"display: none;", 'autoplay'=>"", 'loop'=>""));
									$_HTML->AddTag('SOURCE',array('src'=>"",'type'=>"video/mp4"),true);
							$_HTML->EndTag($img);	

					$_HTML->EndTag($_div2);
				$_HTML->EndTag($_div);
				
				$_div = $_HTML->AddTag("DIV",array('id'=>'relogio'));
						$_div2 = $_HTML->AddTag("DIV",array('id'=>'data'));
							$_HTML->AddTag("DIV",array('id'=>'Clock'),true);
						$_HTML->EndTag($_div2);
				$_HTML->EndTag($_div);
			
				$_div = $_HTML->AddTag("DIV",array('id'=>'senha-grande'));
						$_HTML->AddTag("SPAN",'',true,'CAIXA');
						$_HTML->AddTag("DIV",array('id'=>"numero-0"),true,'0000');
				$_HTML->EndTag($_div);
				
				$_div = $_HTML->AddTag("DIV",array('id'=>'ultimas-senhas'));
						$_HTML->AddTag("DIV",array('id'=>"titulo-ultimas-senhas"),true,'�LTIMAS CHAMADAS');
						$_HTML->AddTag("DIV",array('id'=>"numero-1"),true,'0000');
						$_HTML->AddTag("DIV",array('id'=>"numero-2"),true,'0000');
						$_HTML->AddTag("DIV",array('id'=>"numero-3"),true,'0000');
				$_HTML->EndTag($_div);
				
				// MODAL DE CONFIG
				$_form = $_HTML->AddTag("FORM",array('id'=>'form-config','action'=>'#','method'=>'POST'));
					$_div = $_HTML->AddTag("DIV",array('id'=>'modal-config','class'=>'modal'));
						$_div2 = $_HTML->AddTag("DIV",array('class'=>'modal-content'));
							$_HTML->AddTag("H4",'',true,'Configuracoes');
							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-12'));
								$_HTML->AddTag("LABEL",'',true,'URL Manager');
							$_HTML->EndTag($_div3);
							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-12'));
								$_div4 = $_HTML->AddTag("DIV",array('class'=>'form-group'));
									$_HTML->AddTag("INPUT",array('id'=>"url_manager",'type'=>'text','class'=>'form-control'),true,'');
								$_HTML->EndTag($_div4);
							$_HTML->EndTag($_div3);

							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-6'));
								$_div4 = $_HTML->AddTag("DIV",array('class'=>'form-group'));
									$_HTML->AddTag("LABEL",'',true,'Cod. Loja');
									$_HTML->AddTag("INPUT",array('id'=>"cod_loja",'type'=>'number','class'=>'form-control'),true,'');
								$_HTML->EndTag($_div4);
							$_HTML->EndTag($_div3);
							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-6'));
								$_div4 = $_HTML->AddTag("DIV",array('class'=>'form-group'));
									$_HTML->AddTag("LABEL",'',true,'Cod. Chama Fila');
									$_HTML->AddTag("INPUT",array('id'=>"cod_painel",'type'=>'number','class'=>'form-control'),true,'');
								$_HTML->EndTag($_div4);
							$_HTML->EndTag($_div3);

							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-2'));
								$_HTML->AddTag("BUTTON",array('name'=>'Salvar','id'=>"bt_salvar",'onclick'=>'getClassePainelGlobal().salvaConfig();','type'=>'button','class'=>'btn btn-default btn btn-flat btn-success btn-action text-white'),true,'Salvar');
							$_HTML->EndTag($_div3);
							$_div3 = $_HTML->AddTag("DIV",array('class'=>'col-md-2'));
								$_HTML->AddTag("BUTTON",array('name'=>'Cancelar','id'=>"bt_cancelar",'onclick'=>'getClassePainelGlobal().fecharConfig();','type'=>'button','class'=>'btn btn-default btn btn-flat btn-danger btn-action text-white'),true,'Cancelar');
							$_HTML->EndTag($_div3);

						$_HTML->EndTag($_div2);
					$_HTML->EndTag($_div);
				$_HTML->EndTag($_form);

		$_HTML->EndTag($_ID["body"]);
		
		
		
	$_HTML->EndTag($_ID["html"]);
	echo $_HTML->getHTML5() . $_HTML->toHTML();

?>