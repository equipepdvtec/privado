<?php
	$_INTERNO		= True;
	$_EXIBE   		= False;
	$_FSCRIPTS  	= False;
	$_FGRAFICOS 	= False;
	$_MOSTRAFOOTER 	= False;
	$_SEMVALIDAR 	= True;
	$_NOTEST 		= True;
	$_lusuario 		= 99999; // Autorizador...
	$_FPEDIDO 		= true;
	$_max_execution_time = ini_get('max_execution_time');
	$_max_execution_time = (int)$_max_execution_time < 3600 ? 3600 : $_max_execution_time;
	$_TIMEOUT 		= $_max_execution_time;
	//$_TIMEOUT = 10800; //Por enquanto
	
	//Tratamento de WebService
	$_ACESSOWS      = true;

    $_origem = $_REQUEST["origem"];
    if($_origem == 'INTERFACE') {
        $GLOBALS['_IS_MANAGER_PDV'] = true;
    }

	//Se for uma chamada do redirecionador � interno logo � sem HTTPS.
	if($_SERVER["HTTP_REFERER"]==="saas_redirect") {
		$_SEMHTTPS = true;
	}
	
	require_once("includes/header.inc");
	require_once("classes/class_funcoesgerais.inc");

	$_url_manager = $_REQUEST["url_manager"];
	$_path_interface = $_REQUEST["path_interface"];
	$_sessao_saas = $_REQUEST["sessao_saas"];
	/*
	 * Nesse arquivo tratamos chamadas da Interface e do M�dulo
	 * Quando interface, significa que est� executando de dentro de um m�dulo
	 * Nesse caso temos que fazer comunica��o com o manager para baixar o template
	 */
	if($_origem == 'INTERFACE') {

        $_mensagem = base64_decode($_GET["mensagem"]);
        $_mensagem 	= JSON::decode($_mensagem);
        $_grupo_pdv = $_mensagem->grupo_pdv;
        $_fn = $_mensagem->fn;

        //Temos que tratar se for ambiente SAAS
        if($_sessao_saas == '') {
            $_url_manager = $_url_manager . '/interface_pdv.php';
        }else{
            $_url_manager = $_url_manager . '?service_saas=interface_pdv.php&service_sessao_saas='.$_sessao_saas;
        }

        //Chamamos aqui com a origem m�dulo para o manager tratar
        $_params = "&origem=MODULO&grupo_pdv={$_grupo_pdv}";

        if($_fn == 12821){
            $_mensagem->token = urlencode($_mensagem->token);
            $_params = "&origem=MODULO&token={$_mensagem->token}&lj={$_mensagem->loja}&pdv={$_mensagem->pdv}";
        }

        $_curl = curl_init();
        curl_setopt($_curl, CURLOPT_URL, $_url_manager);
        curl_setopt($_curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($_curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($_curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($_curl, CURLOPT_POST, count((array)$_params));
        curl_setopt($_curl, CURLOPT_POSTFIELDS, $_params);
        $_data = curl_exec ($_curl);
        $_erro = curl_error($_curl);
        $_status = curl_getinfo($_curl, CURLINFO_HTTP_CODE);
        curl_close($_curl);
        if ($_status != 200) {
            funcoesGerais::GravaLog("Pacote: " . var_export($_params, true), true);
            funcoesGerais::GravaLog("URL: " . $_url_manager, true);
            funcoesGerais::GravaLog("Resultado: " . var_export($_data, true), true);
            funcoesGerais::GravaLog("CURL Error: " . var_export($_erro, true), true);
            funcoesGerais::GravaLog("HTTP Code: " . $_status, true);
        }

        $_data = JSON::decode($_data);
        $_telas = base64_decode($_data->TELAS);
        $_css = base64_decode($_data->CSS);

        $_sucesso = 1;
        $_msg = 'Sem tela para atualizar';
        $_arquivo_interface = "telas_touch.js";
        $_arquivo_css = "telas_touch.css";

        if($_fn == 12821){
            $_msg = 'Falha ao recuperar dados do template';
            if($_data->erro && !empty($_data->msg)){
                $_msg = $_data->msg;
            }
        }
        //Se n�o tem telas � porque pode ter gerado um erro, ent�o n�o atualizamos
        if(!empty($_telas)) {
            $_param = "__telas_touch";
            if(!empty($_data->TIPO)){
                switch ($_data->TIPO) {
                    case 1:
                        $_param = "__telas_touch_mouse";
                        $_arquivo_interface = "telas_touch_config.js";
                        break;
                    case 2:
                        $_arquivo_interface = "telas_self.js";
                        $_param = "__telas_self";
                        break;
                    case 3:
                        $_arquivo_interface = "telas_cliente.js";
                        $_param = "__telas_cliente";
                        break;
                }
            }
            $_bf = fopen($_path_interface."/resources/js/{$_arquivo_interface}",'w+');
            $_string_save = "{$_param} = " . str_replace("\\","",$_telas).";";
            if($_fn == 12821 && !empty($_mensagem->loja) && !empty($_mensagem->pdv)){
                $_string_save .="\n__token_template = '{$_data->TOKEN}##{$_data->TIPO}##A';";
            }
            fputs($_bf,$_string_save);
            fclose($_bf);
            //Se houve atualiza��o mudamos para status 3 de sucesso
            $_sucesso = 3;
        }

        //Se n�o tem css � porque pode ter gerado um erro, ent�o n�o atualizamos.
        if(!empty($_css)) {
            if(!empty($_data->TIPO)){
                switch ($_data->TIPO) {
                    case 1:
                        $_arquivo_css = "telas_touch_config.css";
                        break;
                    case 2:
                        $_arquivo_css = "telas_self.css";
                        break;
                    case 3:
                        $_arquivo_css = "telas_cliente.css";
                        break;
                }
            }
            $_bf = fopen($_path_interface."/resources/css/{$_arquivo_css}",'w+');
            fputs($_bf,$_css);
            fclose($_bf);
            //Se houve atualiza��o mudamos para status 3 de sucesso
            $_sucesso = 3;
        }
        //vamos verificar se temos imagens
        if(!empty($_data->IMAGENS)){
            //gravando a imagem
            foreach ($_data->IMAGENS as $_cod_sit=>$_imagem) {
                $_file = "data://application/octet-stream;base64,{$_imagem}";
                $_info = getimagesize($_file);
                $_im = false;
                switch ($_info["mime"]) {
                    case "image/jpeg":
                        $_im = imagecreatefromjpeg($_file);
                        break;
                    case "image/gif":
                        $_im = imagecreatefromgif($_file);
                        break;
                    case "image/png":
                        $_im = imagecreatefrompng($_file);
                        break;
                }
                if ($_im == false) {
                    $_im = imagecreatefromstring(base64_decode($_imagem));
                }
                imagealphablending($_im, false);
                imagesavealpha($_im, true);
                imagecolortransparent($_im);
                $_cod_tela = ($_data->TIPO==2)?"1200":"200";
                imagepng($_im, $_path_interface."/resources/imagens/{$_cod_tela}/{$_cod_sit}.png");
            }
        }

        if($_sucesso == 3 && $_fn != 12821) {
            //Temos que editar o index.html pra fazer a chamada do telas_touch.js de forma din�mica
            //Se n�o o cache do navegador n�o atualiza o novo template
            $_conteudo = file_get_contents($_path_interface.'index.html');
            $_nome_arquivo = 'telas_touch.js';
            $_pos = Zstrpos($_conteudo,$_nome_arquivo);
            $_texto = substr($_conteudo,$_pos,35);
            $_texto_novo = $_nome_arquivo . '?' . funcoesGerais::str_alinha(uniqid(),20,DIREITA,false,'0');
            $_conteudo = str_replace($_texto,$_texto_novo,$_conteudo);

            //Agora escrevemos o index.html atualizado
            $_bf = fopen($_path_interface.'index.html','w+');
            fputs($_bf,$_conteudo);
            fclose($_bf);
        }


        $_retorno = array(
            'resultado' => $_sucesso,
            'msg'       => $_msg,
            'fn' 		=> $_fn
        );

        $_obj_json = JSON::encode((object)$_retorno);
        echo $_REQUEST['retorno'] . '(' .  $_obj_json . ')';

    }else{

        if($_REQUEST["token"]){
            $_tela = new interface_pdv($GLOBALS["_MASTER"]);
            $_retorno = $_tela->getTelasInterface($_REQUEST["token"],$_REQUEST["lj"],$_REQUEST["pdv"]);
            echo $_retorno;
            die();
        }

        $_grupo_pdv = $_REQUEST["grupo_pdv"];

	    $_tela = new tela_pdv($GLOBALS["_MASTER"]);
	    $_retorno = $_tela->gerarCargaTelaPDV($_grupo_pdv);
	    echo $_retorno;

    }

?>