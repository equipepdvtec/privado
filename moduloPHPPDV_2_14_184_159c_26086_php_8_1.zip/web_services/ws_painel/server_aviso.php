<?php
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
/*
    WebServices - Painel
    Rafael Ferreira
    2017-02-05
*/

$_INTERNO = True;
$_EXIBE = False;
$_FSCRIPTS = False;
$_FGRAFICOS = False;
$_MOSTRAFOOTER = False;
$_SEMVALIDAR = True;
$_NOTEST = True;
$_lusuario = 99999; // Autorizador...
$_FPEDIDO = true;
$_TIMEOUT = 3600;
$_ACESSOWS = true;
//$_INCLUIR = true;
$GLOBALS['_IS_MANAGER_PDV'] = true;
//$GLOBALS['_IS_MOBILE'] = true;

chdir("../../");
/*################## BLOCO VALIDA��O SAAS ###################*/
include_once("includes/defines.inc");

/*
 * Se for ambiente saas o m�todo acima faz a valida��o
* Tentei colocar essas vari�veis dentro do m�todo mas n�o rolou.
* Tem que ser aqui.
*/
if (AMBIENTE_SAAS) {
    $_SEMHTTPS = false;
}

include_once("classes/class_funcoesgerais.inc");
funcoesGerais::validarServidorSaas();
/*################## FIM BLOCO VALIDA��O SAAS ###################*/

if (($_POST['val'] != "") or ($_GET['val'] != "")) {
    unset($GLOBALS['_IS_MANAGER_PDV']);
    header('Access-Control-Allow-Origin: *');
    $_INCLUIR = true;
    $dados = json_decode($_POST['val']);

    if ($dados == '')
        $dados = json_decode($_GET['val']);

    require_once("includes/header.inc");
    require_once('classes/class_painel.inc');
    require_once('web_services/ws_painel/ws_painel.inc');

    if ($dados->metodo == 'consultaConfigAviso')
        $retorno = consultaConfigAviso($dados->cod_loja,$dados->cod_painel,$dados->url_manager);


    //funcoesGerais::GravaLog("json retornaConfigPainelAviso: ".json_encode($retorno), true);
   // funcoesGerais::GravaLog("array retornaConfigPainelAviso: ".serialize($retorno), true);

    echo json_encode($retorno);


} else {
    if (!empty($_SERVER["HTTP_SOAPACTION"])) {
        require_once("includes/nusoap.inc");
        require_once("includes/header.inc");
        require_once("web_services/ws_painel/classes/class_webservice_painel.inc");
        require_once('web_services/ws_painel/ws_painel.inc');
    } else {
        require_once("includes/nusoap.inc");
    }

    $server = new soap_server();
    $server->configureWSDL('manager', 'urn:manager');
    $server->wsdl->schemaTargetNamespace = 'urn:manager';


    //Chamada paonel do fiscal
    $server->register('AvisoPDV',
                array('ACodLoja' => 'xsd:integer', 'ANumPDV' => 'xsd:integer', 'AAviso' => 'xsd:integer', 'AValor' => 'xsd:string', 'ACodLojaTrans' => 'xsd:integer', 'ACodPDVTrans' => 'xsd:integer'),
                array('return' => 'xsd:string'),'urn:manager','urn:manager#AvisoPDV');

    /* Captura dos dados enviados*/
    if (version_compare(phpversion(), '7.2.0', '>=') === false) {
        $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
    } else {
        //Para o php 7.2 tem que ser assim
        $HTTP_RAW_POST_DATA = file_get_contents("php://input");
    }

    $server->service($HTTP_RAW_POST_DATA);
}
?>
