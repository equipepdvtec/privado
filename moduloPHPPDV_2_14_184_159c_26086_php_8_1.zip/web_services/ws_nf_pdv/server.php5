<?php
/*
    WebServices - Nota Eletr�nica
    �ber Lincoln
    22.12.2009
    Disponibiliza
*/

$_INTERNO		= True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;
$_SEMVALIDAR 	= True;
$_NOTEST 		= True;
$_lusuario 		= 99999; // Autorizador...
$_FPEDIDO 		= true;
/**
 * A regra aqui � nada demorar mais do que 40 segundos
 * por�m teremos exce��es como o efetivar que precisa ser executado a qualquer custo.
**/
$_TIMEOUT		= 40;
$_ACESSOWS	    = true;


chdir("../../");

/*################## BLOCO VALIDA��O SAAS ###################*/
include_once("includes/defines.inc");
/*
 * Se for ambiente saas o m�todo acima faz a valida��o
* Tentei colocar essas vari�veis dentro do m�todo mas n�o rolou.
* Tem que ser aqui.
*/
if(AMBIENTE_SAAS) {
    $_SEMHTTPS = TRUE;
}

include_once("classes/class_funcoesgerais.inc");
if (funcoesGerais::managerOFFLine()) {
    //Se for m�dulo vou colocar um M na frente
    $GLOBALS["WEBERP_VERSAO"] = "M" . $GLOBALS["WEBERP_VERSAO"];
}
funcoesGerais::validarServidorSaas();

/*################## FIM BLOCO VALIDA��O SAAS ###################*/
/* Captura dos dados enviados */
if (version_compare(phpversion(), '7.2.0', '>=') === false ) {
    $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
} else {
    //Para o php 7.2 tem que ser assim
    $HTTP_RAW_POST_DATA = file_get_contents("php://input");
}

//$_soap_action = $_SERVER["HTTP_SOAPACTION"];
$_soap_action = "";
$_h_ini = time();
/**
 * esse m�todo consumiu mta cpu, n�o foi eficiente, ent�o removi, talve um dia eu reveja.
 */
if (!empty($_soap_action)) {
    //Talvez no SAAS precise disso vamos testar.
    //require_once("includes/nusoap.inc");
    require_once("includes/header.inc");
    require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
    require_once("classes/class_memcache_provider.inc");
    require_once("web_services/ws_nf_pdv/classes/class_webservice_nfce.inc");
    require_once('web_services/ws_nf_pdv/ws_nf_pdv.inc');

    //funcoesGerais::GravaLog("o q veio do pdv [{$_SERVER["HTTP_SOAPACTION"]}] " . $HTTP_RAW_POST_DATA , true,true,false,'ENTRADA_TEMPO_EFETIVACAO.ZLG');
    //urn:manager#
    $_m_dado_soap_action = strpos($_SERVER["HTTP_SOAPACTION"],"#") +1;
    $_metodo = substr($_SERVER["HTTP_SOAPACTION"],$_m_dado_soap_action,-1);
    //$_pos_a_partir = 350;
    //Quando fa�o no soapui vem menos caracteres que o PDV ent�o vamos come�ar daqui.
    $_pos_a_partir = 313;

    $_xml_envio = funcoesGerais::retornarValorTagXML('<Axml_envio>','</Axml_envio>',$HTTP_RAW_POST_DATA,$_pos_a_partir);


    if (($_cod_loja_trans = funcoesGerais::retornarValorTagXML('<ACodLojaTrans>','</ACodLojaTrans>',$HTTP_RAW_POST_DATA,$_pos_a_partir)) === false) {
        $_cod_loja_trans = funcoesGerais::retornarValorTagXML('<ACodLojaTrans xsi:type="xsd:integer">','</ACodLojaTrans>',$HTTP_RAW_POST_DATA,$_pos_a_partir);
    }

    if (($_cod_pdv_trans = funcoesGerais::retornarValorTagXML('<ACodPDVTrans>','</ACodPDVTrans>',$HTTP_RAW_POST_DATA,$_pos_a_partir)) === false) {
        $_cod_pdv_trans = funcoesGerais::retornarValorTagXML('<ACodPDVTrans xsi:type="xsd:integer">','</ACodPDVTrans>',$HTTP_RAW_POST_DATA,$_pos_a_partir);
    }
    //A ideia � evitar isso
    if ($_xml_envio[0] === "&") {
        //$_xml_envio = html_entity_decode($_xml_envio);
        $_xml_envio = funcoesGerais::converterEntitiesToXML($_xml_envio);
    }


    $_ret = $_metodo($_xml_envio,$_cod_loja_trans,$_cod_pdv_trans);
    $_ret =  '<?xml version="1.0" encoding="ISO-8859-1"?><SOAP-ENV:Envelope SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"><SOAP-ENV:Body>' .
         '<ns1:' . $_metodo . 'Response xmlns:ns1="urn:manager"><return xsi:type="xsd:string">' .
         funcoesGerais::converterXMLToEntities($_ret) .
         '</return>'.
         '</ns1:' . $_metodo . 'Response>'.
         '</SOAP-ENV:Body></SOAP-ENV:Envelope>';
    //$_h_fim = time();
    //if ((int)$_cod_loja_trans == 5 && (int) $_cod_pdv_trans == 219) {
    //    funcoesGerais::GravaLog("[{$_cod_loja_trans} - {$_cod_pdv_trans}] tempo " . funcoesGerais::timeDiff($_h_ini, $_h_fim) . " o que veio {$HTTP_RAW_POST_DATA} " . " \n q saiu do pdv [{$_SERVER["HTTP_SOAPACTION"]}] " . $_ret, true, true, false, 'ENTRADA_TEMPO_EFETIVACAO.ZLG');
    //}
    echo $_ret;

    //funcoesGerais::GravaLog("saida {$_ret}",true,true);

} else {


    if (!empty($_SERVER["HTTP_SOAPACTION"])) {
        try {
            require_once("includes/nusoap.inc");
            //Aqui tem uma chamada no banco.
            require_once("includes/header.inc");
        } catch (Exception $_e) { //Aqui n�o vai mais parar na hora da conex�o, vai parar depois e espero que tenha tratamento n�.
        }
        //Aqui pra baixo n�o pode ter conex�o com o banco fora do m�todo principal.
        require_once("classes/class_memcache_provider.inc");
        require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
        require_once("web_services/ws_nf_pdv/classes/class_webservice_nfce.inc");
        require_once('web_services/ws_nf_pdv/ws_nf_pdv.inc');

    } else {
        require_once("includes/nusoap.inc");
    }
    $server = new soap_server;
    $server->configureWSDL('WSNfPDV', 'urn:managernfpdv');
    $server->wsdl->schemaTargetNamespace = 'urn:managernfpdv';
    $_arr_fixo = Array('ACodLojaTrans' => 'xsd:integer', 'ACodPDVTrans' => 'xsd:integer');
    //------------------------------------------------------------------------------
    //Valida clientes da nf
    $server->register('validarClienteNf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#validarClienteNf', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                            <br/><b>param</b> string  Axml_envio
                            <br/><b>return</b> string Axml_retorno"));

    $server->register('calcularTotalOperacaoNf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#calcularTotalOperacaoNf', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                            <br/><b>param</b> string  Axml_envio
                            <br/><b>return</b> string Axml_retorno"));

    $server->register('efetivarNf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:manager',
        'urn:manager#efetivarNf', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                            <br/><b>param</b> string  Axml_envio
                            <br/><b>return</b> string Axml_retorno"));

    $server->register('verificarStatusNf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:manager',
        'urn:manager#verificarStatusNf', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));

    $server->register('pegarPDFDANf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#pegarPDFDANf', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));
    $server->register('pegarNumeroSerieRPS',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#pegarNumeroSerieRPS', false, false,
        utf8_encode("<br/><b>Retorna dados WebService NF </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));
    $server->register('pegarDadosOFFLine',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#pegarDadosOFFLine', false, false,
        utf8_encode("<br/><b>Retorna dados que ser�o utilizados na NFCe OFFLine.<br/>
                            Este m�todo ser� chamado pelo PDV quando ele julgar necess�rio </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));
    $server->register('subirXMLNota',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#subirXMLNota', false, false,
        utf8_encode("<br/><b>Receberemos um XML no padr�o do SEFAZ e <br/>
                            adicionaremos a nota em nossas tabelas </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));
    $server->register('subirXMLCfeRecuperado',
        array('Axml_envio'=>'xsd:string') + $_arr_fixo,
        array('return'=>'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#subirXMLCfeRecuperado',
        false,false,
        utf8_encode("<br/><b>Receberemos um XML Cfe que foi recuperado do SAT </b>
					<br/><b>param</b> string  Axml_envio
					<br/><b>return</b> string Axml_retorno"));
    $server->register('extrairTributNf',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#extrairTributNf', false, false,
        utf8_encode("<br/><b>Monta um xml com todos os impostos <br/>
                            para gerar mapa resumo do CFe e NFCe </b>
                       <br/><b>param</b> string  Axml_envio
                       <br/><b>return</b> string Axml_retorno"));
    $server->register('tratarVersaoModulo',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#tratarVersaoModulo', false, false,
        utf8_encode("<br/><b>Retorna a vers�o atual do m�dulo <br/>
                        e procura por atualiza��o </b>
                   <br/><b>param</b> string  Axml_envio
                   <br/><b>return</b> string Axml_retorno"));
    $server->register('PermissaoCancelamento',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#PermissaoCancelamento', false, false,
        utf8_encode("<br/><b>Receberemos um XML no padr�o do SEFAZ e <br/>
                        informamos se tem permiss�o para efetuar o cancelamento do documento </b>
                        <br/><b>param</b> string  Axml_envio
                        <br/><b>return</b> string Axml_retorno"));
    $server->register('CancelarDocumento',
        array('Axml_envio' => 'xsd:string') + $_arr_fixo,
        array('return' => 'xsd:string'),
        'urn:managernfpdv',
        'urn:managernfpdv#CancelarDocumento', false, false,
        utf8_encode("<br/><b>Receberemos um XML no padr�o do SEFAZ e <br/>
                        realizamos o cancelamento do documento </b>
                        <br/><b>param</b> string  Axml_envio
                        <br/><b>return</b> string Axml_retorno"));
    /**
     * Colocado aqui por causa do bug do path forcado no 1260
     * Ele fica apontando pro ws de nota ao inv�s do conv�ncional.
     */
    $server->register('AtualizaDadosPDV',
        array('AXML'=>'xsd:string')+$_arr_fixo,
        array('return'=>'xsd:boolean'),
        'urn:managernfpdv',
        'urn:managernfpdv#AtualizaDadosPDV');



    $server->service($HTTP_RAW_POST_DATA);
}
$_h_fim = time();
//if ((int)$_cod_loja_trans == 5 && (int) $_cod_pdv_trans == 219) {
    //funcoesGerais::GravaLog("[{$_cod_loja_trans} - {$_cod_pdv_trans}] tempo " . funcoesGerais::timeDiff($_h_ini, $_h_fim) . " o que veio {$HTTP_RAW_POST_DATA} " . " \n q saiu do pdv [{$_SERVER["HTTP_SOAPACTION"]}] " . $_ret, true, true, false, 'ENTRADA_TEMPO_EFETIVACAO.ZLG');
//}
