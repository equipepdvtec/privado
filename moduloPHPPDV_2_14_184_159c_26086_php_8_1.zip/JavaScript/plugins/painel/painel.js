/*
	@description	Classe utilizada pelo programa painel.php
	@author			Rafael Ferreira
	@date			21/09/2017
	@module			Java Script da Classe ClassePainel
*/

$(document).ready(function () {
    //colocar if para quando sem licença
    if (localStorage["painel_config"] != null) {
        getClassePainelGlobal().consultaParametro();
        getClassePainelGlobal().atualizaRelogio()
        getClassePainelGlobal().buscaProximo();
    } else {
        getClassePainelGlobal().abrirConfig();
    }
})

GlobalClassePainel = null;

function getClassePainelGlobal() {
    if (GlobalClassePainel === null) {
        GlobalClassePainel = new ClassePainel();
    }
    return GlobalClassePainel;
};

function ClassePainel() {
    this.construct();
};
ClassePainel.prototype = {
    intervaloBusca: 1000,
    construct:
        function () {
        },
    tocarFala:
        function(retorno) {
            const audio = new Audio("plugin/painel/sound/fala/caixa_" + retorno.caixa + ".ogg");
            const promise = audio.play();
            if(promise !== undefined) {
                promise.then(() => {
                    console.log('fala '+retorno.caixa)
                    getClassePainelGlobal().buscaProximo();
                }).catch(error => {
                    console.log('erro fala caixa '+retorno.caixa+' erro:'+error);
                    getClassePainelGlobal().buscaProximo();
                });
            }
        },
    tocarCampainha:
        function(param, retorno) {
            const audio = new Audio("plugin/painel/sound/" + param.NUM_CAMPAINHA + ".ogg");
            audio.addEventListener("ended", function() {
                if (param.FLG_ATIVA_FALA == 'S') {
                    console.log('campainha '+param.NUM_CAMPAINHA)
                    audio.pause();
                    audio.currentTime = 0;
                    getClassePainelGlobal().tocarFala(retorno);
                } else {
                    console.log('desativada fala');
                    getClassePainelGlobal().buscaProximo();
                }
            });
            const promise = audio.play();
            if(promise !== undefined) {
                promise.then(() => {}).catch(error => {
                    console.log('erro campainha caixa '+param.NUM_CAMPAINHA+' erro:'+error);
                    if (param.FLG_ATIVA_FALA == 'S') {
                        getClassePainelGlobal().tocarFala(retorno);
                    } else {
                        console.log('desativada fala');
                        getClassePainelGlobal().buscaProximo();
                    }
                });
            }
        },
    buscaProximo:
        function () {
            $.ajax({
                crossDomain: true,
                type: 'POST',
                url: 'painel.php?cad=1',
                data: '236464302'
            }).done(function (res) {
                //Teste
                //res = '{"pdv":"0204","nome_oper":"SUELLEN APARECIDA MELAO FERRE","funcao":"1110","caixa":"0205","arquivo":"plugin\\/painel\\/fila\\/20221031173247-1667244767413.pdv"}';
                console.log('intervalo busca '+getClassePainelGlobal().intervaloBusca)
                if (res != 'ND') {
                    retorno = JSON.parse(res);
                    let tempoIntervalo = getClassePainelGlobal().intervaloBusca;
                    if (retorno.funcao == '1110' && typeof param !== 'undefined' && param.TEMPO_INTERVALO > 0) {
                        tempoIntervalo = parseInt(param.TEMPO_INTERVALO);
                    }
                    setTimeout(function() {
                        param = JSON.parse(localStorage["painel_parametro"]);
                        getClassePainelGlobal().tocarCampainha(param, retorno);
                        $("#numero-3").html($("#numero-2")[0].innerHTML);
                        $("#numero-2").html($("#numero-1")[0].innerHTML);
                        $("#numero-1").html($("#numero-0")[0].innerHTML);
                        $("#numero-0").html(retorno.caixa);
                        getClassePainelGlobal().mudaCor();
                    }, tempoIntervalo);
                } else {
                    setTimeout(function() {
                        getClassePainelGlobal().buscaProximo();
                    }, getClassePainelGlobal().intervaloBusca);
                }
            });
        },
    atualizaRelogio:
        function () {
            getClassePainelGlobal().ativarTipoMedia();

            setInterval(function () {
                var now = new Date();
                var mes = now.getMonth() + 1;
                var mes = ("0" + mes).slice(-2);
                var dName = now.getDay() + 1;
                var dia = now.getDate();
                var dia = ("0" + dia).slice(-2);
                var yearNr = now.getYear();

                if (dName == 1) {
                    Day = "Domingo";
                }
                if (dName == 2) {
                    Day = "Segunda-feira";
                }
                if (dName == 3) {
                    Day = "Terca-feira";
                }
                if (dName == 4) {
                    Day = "Quarta-feira";
                }
                if (dName == 5) {
                    Day = "Quinta-feira";
                }
                if (dName == 6) {
                    Day = "Sexta-feira";
                }
                if (dName == 7) {
                    Day = "Sabado";
                }

                if (yearNr < 2000) {
                    Year = 1900 + yearNr;
                }
                else {
                    Year = yearNr;
                }
                var todaysDate = (" " + Day + " " + dia + "/" + mes + "/" + Year);

                var Elem = document.getElementById('Clock');

                var Hoje = new Date();
                var Horas = Hoje.getHours();

                if (Horas < 10) {
                    Horas = "0" + Horas;
                }

                var Minutos = Hoje.getMinutes();
                if (Minutos < 10) {
                    Minutos = "0" + Minutos;
                }
                var Segundos = Hoje.getSeconds();
                if (Segundos < 10) {
                    Segundos = "0" + Segundos;
                }
                Elem.innerHTML = todaysDate + " - " + Horas + ":" + Minutos + ":" + Segundos;
            }, 1000);

            return true;

        },
    mudaCor:
        function () {
            intrvl = 0;
            for (nTimes = 0; nTimes < 5; nTimes++) {
                intrvl += 300;
                setTimeout(function () {
                    $("#senha-grande").css("background", "#1d325c");
                }, intrvl);
                intrvl += 300;
                setTimeout(function () {
                    $("#senha-grande").css("background", "#009933");
                }, intrvl);
            }
        },
    ativarTipoMedia:
        function () {
            if (typeof localStorage["painel_parametro"] !== 'undefined') {
                var slide = document.getElementById('img_slide');
                var video = document.getElementById('videoPlayer');
                param = JSON.parse(localStorage["painel_parametro"]);
                if (param.TIPO_MEDIA == 'slide') {
                    // Ocultando Video
                    video.muted = true;
                    video.style.display = 'none';
                    // Mostrando Slide
                    slide.style.display = 'block';
                    getClassePainelGlobal().carouselSlide(param);
                } else {
                    // Ocultando Slide
                    slide.style.display = 'none';
                    // Mostrando Video
                    video.style.display = 'block';
                    if(param.FLG_SOM_VIDEO == 'N') {
                        video.muted = true;
                    } else if(param.FLG_SOM_VIDEO == 'S') {
                        video.muted = false;
                    }
                    getClassePainelGlobal().carouselMovie(param);
                }
            }
        },
    carouselSlide:
        function (param) {
            var cont = 0;
            var slide = document.getElementById('img_slide');
            getClassePainelGlobal().consultaLista('slide');
            lista_slide = JSON.parse(localStorage["lista_slide"]);
            clearInterval(localStorage["id_carouselSlide"]);
            id = setInterval(function () {
                if (cont < Object.keys(lista_slide).length) {
                    slide.src = 'plugin/painel/slide/' + lista_slide[cont];
                } else {
                    cont = 0;
                    if(lista_slide[cont] != undefined) {
                        slide.src = 'plugin/painel/slide/' + lista_slide[cont];
                        getClassePainelGlobal().consultaLista('slide');
                        lista_slide = JSON.parse(localStorage["lista_slide"]);
                    }
                }
                ++cont;
            }, param.TEMPO_SLIDE);
            localStorage["id_carouselSlide"] = id;
        },
    carouselMovie:
        function (param) {
            var cont = 0;
            var video = document.getElementById('videoPlayer');
            getClassePainelGlobal().consultaLista('video');
            lista_video = JSON.parse(localStorage["lista_video"]);
            if(lista_video != undefined && video.src == "") {
                if (Object.keys(lista_video).length > 1) {
                    video.removeAttribute("loop");
                } else {
                    video.setAttribute("loop", true);
                }
                video.src = 'plugin/painel/mov/' + lista_video[cont];
            }
            video.onended = function () {
                ++cont;
                if (cont < Object.keys(lista_video).length) {
                    video.src = 'plugin/painel/mov/' + lista_video[cont];
                }
                else {
                    cont = 0;
                    if(lista_video[cont] != undefined) {
                        video.src = 'plugin/painel/mov/' + lista_video[cont];
                        getClassePainelGlobal().consultaLista('video');
                        lista_video = JSON.parse(localStorage["lista_video"]);
                    }
                }
            }
        },
    salvaConfig:
        function () {
            if (($.trim($("#url_manager").val()) === '') || ($.trim($("#cod_loja").val()) === '') || ($.trim($("#cod_painel").val()) === '')) {
                alert('Favor preencher todos os campos.');
            } else {
                var dados = {};
                dados.url_manager = $.trim($("#url_manager").val());
                dados.cod_loja = $.trim($("#cod_loja").val());
                dados.cod_painel = $.trim($("#cod_painel").val());
                dados.ult_carga = $.trim($("#ult_carga").val());
                dados.metodo = 'consultaConfig';
                localStorage["painel_config"] = JSON.stringify(dados);
                document.getElementById("modal-config").style.display = "none";
                delete localStorage["painel_parametro"]
                alert('Salvo com sucesso.');
                window.location.reload(true);
            }
        },
    fecharConfig:
        function () {
            document.getElementById("modal-config").style.display = "none";
        },
    abrirConfig:
        function () {
            var dados = {};
            if (localStorage["painel_config"] != null) {
                dados = JSON.parse(localStorage["painel_config"]);
                $("#url_manager").val(dados.url_manager);
                $("#cod_loja").val(dados.cod_loja)
                $("#cod_painel").val(dados.cod_painel);
                $("#ult_carga").val(dados.ult_carga);
            }
            document.getElementById("modal-config").style.display = "block";
        },
    validarReinicioPainel:
        function (data) {
            if (typeof localStorage["painel_parametro"] !== 'undefined') {
                param = JSON.parse(localStorage["painel_parametro"]);
                param_data = JSON.parse(data);
                delete param['DTH_CARGA'];
                delete param['IP_CARGA'];
                delete param_data['DTH_CARGA'];
                delete param_data['IP_CARGA'];
                param_valida = JSON.stringify(param);
                param_data_valida = JSON.stringify(param_data);
                if(param_valida != param_data_valida) {
                    localStorage["forca_reinicio"] = 1;
                }
            }
        },
    consultaParametro:
        function () {
            var consulta = setInterval(function () {
                if(localStorage["forca_reinicio"] == 1) {
                    clearInterval(consulta);
                    localStorage["forca_reinicio"] = 0;
                    window.location.reload(true);
                    return false;
                }

                var dados = {};
                dados = JSON.parse(localStorage["painel_config"]);
                json = localStorage["painel_config"];
                $.ajax({
                    crossDomain: true,
                    type: 'POST',
                    url: dados.url_manager,
                    data: {val: json},
                    async: false,
                    success: function (data) {
                        getClassePainelGlobal().validarReinicioPainel(data);
                        // Proteção caso não venha um json valido.
                        try {
                            JSON.parse(data);
                            localStorage["painel_parametro"] = data;
                        } catch (e) {
                            return false;
                        }
                    }
                });
                json = localStorage["painel_parametro"];
                $.ajax({
                    crossDomain: true,
                    type: 'POST',
                    url: 'painel.php?cad=3',
                    data: {val: json},
                    async: false,
                    success: function (data) {
                        if (data == '"OK"') {
                            localStorage["forca_reinicio"] = 1;
                        }
                    }
                });
            }, 10000);
        },
    consultaLista:
        function (tipo) {
            $.ajax({
                crossDomain: true,
                type: 'POST',
                url: 'painel.php?cad=4',
                data: {val: tipo},
                async: false
            }).done(function (res) {
                ret = JSON.parse(res);
                localStorage["lista_"+tipo] = res;
            });
        },
};