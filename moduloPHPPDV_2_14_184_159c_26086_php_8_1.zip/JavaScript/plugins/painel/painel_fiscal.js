/*
	@description	Classe utilizada pelo programa painel.php
	@author			Rafael Ferreira
	@date			21/09/2017
	@module			Java Script da Classe ClassePainel
*/

$(document).ready(function () {
    //colocar if para quando sem licença        

    //getClassePainelGlobalFiscal().consultaParametro();
    getClassePainelGlobalFiscal().buscaFiscal();
    getClassePainelGlobalFiscal().mudaCor();
    getClassePainelGlobalFiscal().consultaParametro();
    //getClassePainelGlobalFiscal().AtualizaLista();

})

GlobalClassePainelFiscal = null;

function getClassePainelGlobalFiscal() {
    if (GlobalClassePainelFiscal === null) {
        GlobalClassePainelFiscal = new ClassePainelFiscal();
    }
    ;
    return GlobalClassePainelFiscal;
};

function ClassePainelFiscal() {
    this.construct();
};
ClassePainelFiscal.prototype = {

    construct:
        function () {
        },
    salvaConfig:
        function () {
            if (($.trim($("#url_manager").val()) === '') || ($.trim($("#cod_loja").val()) === '')) {
                alert('Favor preencher todos os campos.');
            }
            else {
                var dados = {};

                dados.url_manager = $.trim($("#url_manager").val());
                dados.cod_loja = $.trim($("#cod_loja").val());
                dados.cod_painel = $.trim($("#cod_painel").val());
                dados.ult_carga = $.trim($("#ult_carga").val());
                dados.metodo = 'consultaConfigAviso';

                localStorage["painel_aviso_config"] = JSON.stringify(dados);
                document.getElementById("modal-config").style.display = "none";

                alert('Salvo com sucesso.');
            }
        },
    fecharConfig:
        function () {
            document.getElementById("modal-config").style.display = "none";
        },
    abrirConfig:
        function () {
            var dados = {};

            if (localStorage["painel_aviso_config"] != null) {
                dados = JSON.parse(localStorage["painel_aviso_config"]);

                $("#url_manager").val(dados.url_manager);
                $("#cod_loja").val(dados.cod_loja)
                $("#cod_painel").val(dados.cod_painel);
                $("#ult_carga").val(dados.ult_carga);
            }

            document.getElementById("modal-config").style.display = "block";
        },
    buscaFiscal:
        function () {

            setInterval(function () {
                $.ajax({
                    type: 'POST',
                    url: 'painel_fiscal.php?cad=1',
                    data: '236464302'
                })
                    .done(function (res) {
                        if (res != 'false') {

                            retorno = JSON.parse(res);
                            lista = JSON.parse(localStorage["painel_fiscal_parametro"]);
                            var codAviso = parseInt(retorno.AAviso);
                            //console.log(lista);
                            if (codAviso >= 1 && codAviso <= 9) {
                                $.each(lista, function (i, item) {
                                    if (retorno.ANumPDV == item.COD_PDV) {
                                        if ($('#pdv-' + retorno.ANumPDV).length == 0) {
                                            $('#lista-fiscal').append('<div class="col-md-4" id="pdv-' + retorno.ANumPDV + '"></div>');
                                            $('#pdv-' + retorno.ANumPDV).append('<div class="pdv-fiscal chamando" id="pdv-conteudo-' + retorno.ANumPDV + '"></div>');
                                            $('#pdv-conteudo-' + retorno.ANumPDV).append('<span id="pdv-desc-' + retorno.ANumPDV + '">' + item.PDV_DESC + '</span><BR>');
                                            $('#pdv-conteudo-' + retorno.ANumPDV).append('<span class="msg" id="pdv-msg-' + retorno.ANumPDV + '">' + retorno.AMensagem +'</span><HR>');
                                            $('#pdv-conteudo-' + retorno.ANumPDV).append('<span class="oper" id="pdv-oper-' + retorno.ANumPDV + '">' + item.NOME + '</span>');

                                            $("#chamada-fiscal-6").html($("#chamada-fiscal-5").html());
                                            $("#chamada-fiscal-5").html($("#chamada-fiscal-4").html());
                                            $("#chamada-fiscal-4").html($("#chamada-fiscal-3").html());
                                            $("#chamada-fiscal-3").html($("#chamada-fiscal-2").html());
                                            $("#chamada-fiscal-2").html($("#chamada-fiscal-1").html());

                                            $('#chamada-fiscal-1').html(' ');
                                            $('#chamada-fiscal-1').append('<div id="pdv-fiscal-chamda-1" class="pdv-fiscal-chamada"></div>');
                                            $('#pdv-fiscal-chamda-1').append('<span id="pdv-chamda-desc-' + retorno.ANumPDV + '">' + item.PDV_DESC + '</span><BR>');
                                            $('#pdv-fiscal-chamda-1').append('<span class="msg" id="pdv-chamda-msg-' + retorno.ANumPDV + '">' + retorno.AMensagem +'</span><BR>');
                                            $('#pdv-fiscal-chamda-1').append('<span class="oper" id="pdv-chamda-oper-' + retorno.ANumPDV + '">' + item.NOME + '</span>');

                                            var playPromise = audio_campainha.play();

                                        }
                                    }
                                });
                            }
                            else if (codAviso == 0) {
                                $('#pdv-' + retorno.ANumPDV).remove();
                            }
                        }
                    });
            }, 5000);
        },
    mudaCor:
        function () {
            intrvl = 0;
            setInterval(function () {
                intrvl += 500;
                setTimeout(function () {
                    $(".chamando").css("background", "#1d325c");
                }, intrvl);
                intrvl += 500;
                setTimeout(function () {
                    $(".chamando").css("background", "#b32d00");
                }, intrvl);
            }, 100);
        },

    consultaParametro:
        function () {
            setInterval(function () {
                var dados = {};
                console.log('Carga de parametros');

                dados = JSON.parse(localStorage["painel_aviso_config"]);
                json = localStorage["painel_aviso_config"];

                $.ajax({
                    crossDomain: true,
                    type: 'POST',
                    url: dados.url_manager,
                    data: {val: json},
                    async: false,
                    success: function (data) {

                        if ((data != '') && (data != 'false')) {
                            localStorage["painel_fiscal_parametro"] = data;
                            //getClassePainelGlobalFiscal().AtualizaLista();
                            console.log('Carga OK');
                        }
                        else {
                            console.log('Carga ERRO');
                            console.log(data);

                        }

                    }
                });

            }, 60000);
        },
};