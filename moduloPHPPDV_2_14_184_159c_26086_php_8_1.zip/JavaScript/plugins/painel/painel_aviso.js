/*
	@description	Classe utilizada pelo programa painel.php
	@author			Rafael Ferreira
	@date			21/09/2017
	@module			Java Script da Classe ClassePainel
*/

$(document).ready(function () {
    //colocar if para quando sem licença        

    getClassePainelGlobalFiscal().consultaParametro();
    getClassePainelGlobalFiscal().AtualizaLista();
    getClassePainelGlobalFiscal().buscaAviso();
    getClassePainelGlobalFiscal().mudaCor();

})

GlobalClassePainelFiscal = null;

function getClassePainelGlobalFiscal() {
    if (GlobalClassePainelFiscal === null) {
        GlobalClassePainelFiscal = new ClassePainelFiscal();
    }
    ;
    return GlobalClassePainelFiscal;
};

function ClassePainelFiscal() {
    this.construct();
};
ClassePainelFiscal.prototype = {

    construct:
        function () {
        },
    salvaConfig:
        function () {
            if (($.trim($("#url_manager").val()) === '') || ($.trim($("#cod_loja").val()) === '')) {
                alert('Favor preencher todos os campos.');
            }
            else {
                var dados = {};

                dados.url_manager = $.trim($("#url_manager").val());
                dados.cod_loja = $.trim($("#cod_loja").val());
                dados.cod_painel = $.trim($("#cod_painel").val());
                dados.ult_carga = $.trim($("#ult_carga").val());
                dados.url_interface = $.trim($("#url_interface").val());
                dados.metodo = 'consultaConfigAviso';

                localStorage["painel_aviso_config"] = JSON.stringify(dados);
                document.getElementById("modal-config").style.display = "none";

                alert('Salvo com sucesso.');
            }
        },
    fecharConfig:
        function () {
            document.getElementById("modal-config").style.display = "none";
        },
    abrirConfig:
        function () {
            var dados = {};

            if (localStorage["painel_aviso_config"] != null) {
                dados = JSON.parse(localStorage["painel_aviso_config"]);

                $("#url_manager").val(dados.url_manager);
                $("#cod_loja").val(dados.cod_loja)
                $("#cod_painel").val(dados.cod_painel);
                $("#ult_carga").val(dados.ult_carga);
                $("#url_interface").val(dados.url_interface);
            }

            document.getElementById("modal-config").style.display = "block";
        },
    consultaParametro:
        function () {
            setInterval(function () {
                var dados = {};
                console.log('Carga de parametros');

                dados = JSON.parse(localStorage["painel_aviso_config"]);
                json = localStorage["painel_aviso_config"];

                $.ajax({
                    crossDomain: true,
                    type: 'POST',
                    url: dados.url_manager,
                    data: {val: json},
                    async: false,
                    success: function (data) {

                        if ((data != '') && (data != 'false')) {
                            localStorage["painel_aviso_parametro"] = data;
                            getClassePainelGlobalFiscal().AtualizaLista();
                            console.log('Carga OK');
                        }
                        else {
                            console.log('Carga ERRO');
                            console.log(data);

                        }

                    }
                });

                console.log('Enviando para storage');
                json = localStorage["painel_aviso_parametro"];
                $.ajax({
                    type: 'POST',
                    url: 'painel_aviso.php?cad=3',
                    data: {val: json},
                    async: false,
                    success: function (data) {
                        //console.log(data);

                    }
                });

            }, 60000);

        },
    AbrirInterface:
        function (ip) {


            if (confirm('Deseja abrir a interface Mouse ?')) {

                var dados = {};
                localStorage["zanlink-counter"] = 1;
                localStorage["zanlink"] = 1;
                dados.ip = ip;
                dados.porta = "8899";
                dados.ativo = "true";
                dados.tentativa = "0";
                localStorage["zanlink-1"] = JSON.stringify(dados);

                dados = JSON.parse(localStorage["painel_aviso_config"]);
                window.open(dados.url_interface, '_blank');
            }

            /*
            getClasseMensagensOrig().mostrarConfirmacao('Deseja abrir a interface Mouse ?','',function (ret) {
                if (ret) {
                    Alert('sim');
                }
                return false;
            });
            */


        },

    AtualizaLista:
        function () {
            var lista = {};

            lista = JSON.parse(localStorage["painel_aviso_parametro"]);

            $.each(lista, function (i, item) {
                //console.log(item.COD_PDV);
                if ($('#pdv-' + item.COD_PDV).length == 0) {
                    $('#lista-aviso').append('<div class="col-md-2" id="pdv-' + item.COD_PDV + '" ondblclick="getClassePainelGlobalFiscal().AbrirInterface(\''+item.IP_PDV+'\')"></div>');
                    $('#pdv-' + item.COD_PDV).append('<div class="pdv" id="pdv-conteudo-' + item.COD_PDV + '"></div>');
                    $('#pdv-conteudo-' + item.COD_PDV).append('<span class="desc" id="pdv-desc-' + item.COD_PDV + '">' + item.PDV_DESC + '</span><BR>');
                    $('#pdv-conteudo-' + item.COD_PDV).append('<span id="pdv-status-' + item.COD_PDV + '">' + item.STATUS_PDV + '</span><BR>');
                    $('#pdv-conteudo-' + item.COD_PDV).append('<span id="pdv-oper-' + item.COD_PDV + '">' + item.NOME + '</span><BR>');
                    $('#pdv-conteudo-' + item.COD_PDV).append('<span id="pdv-mov-' + item.COD_PDV + '">MOVIMENTO ' + item.DATA_MOV + '</span><BR>');
                    $('#pdv-conteudo-' + item.COD_PDV).append('<span class="msg" id="pdv-msg-' + item.COD_PDV + '"></span>');
                }
                else {
                    $('#pdv-desc-' + item.COD_PDV).html(item.PDV_DESC);
                    $('#pdv-status-' + item.COD_PDV).html(item.STATUS_PDV);
                    $('#pdv-oper-' + item.COD_PDV).html(item.NOME);
                    $('#pdv-mov-' + item.COD_PDV).html('MOVIMENTO ' + item.DATA_MOV);
                }
            });

        },
    mudaCor:
        function () {
            intrvl = 0;
            setInterval(function () {
                intrvl += 500;
                setTimeout(function () {
                    $(".chamando").css("background", "#1d325c");
                }, intrvl);
                intrvl += 500;
                setTimeout(function () {
                    $(".chamando").css("background", "#b32d00");
                }, intrvl);
            }, 100);
        },
    buscaAviso:
        function () {

            setInterval(function () {
                $.ajax({
                    type: 'POST',
                    url: 'painel_aviso.php?cad=1',
                    data: '236464302'
                })
                    .done(function (res) {
                        if (res != 'false') {

                            retorno = JSON.parse(res);

                            if (parseInt(retorno.AAviso) >= 1 && parseInt(retorno.AAviso) <= 9) {
                                $('#pdv-msg-' + retorno.ANumPDV).html(retorno.AMensagem);
                                $('#pdv-conteudo-' + retorno.ANumPDV).addClass('chamando');

                                var playPromise = audio_campainha.play();
                            }
                            else if (parseInt(retorno.AAviso) >= 12) {
                                $('#pdv-msg-' + retorno.ANumPDV).html(retorno.AMensagem);
                                $('#pdv-conteudo-' + retorno.ANumPDV).addClass('chamando');

                                var playPromise = audio_campainha.play();
                            }
                            else if (retorno.AAviso == '0') {
                                $('#pdv-conteudo-' + retorno.ANumPDV).removeClass('chamando');
                                $('#pdv-conteudo-' + retorno.ANumPDV).css("background", "#1d325c");
                                $('#pdv-msg-' + retorno.ANumPDV).html("");
                            }
                        }
                    });
            }, 5000);
        },

};