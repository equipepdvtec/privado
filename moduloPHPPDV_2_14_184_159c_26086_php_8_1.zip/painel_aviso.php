<?PHP
// ini_set('display_errors',1);
// ini_set('display_startup_erros',1);
// error_reporting(E_ALL);

//$_INCLUIR = true;
$GLOBALS['_IS_MANAGER_PDV'] = 1;
$_INTERNO		= True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;
$_SEMVALIDAR 	= True;
$_NOTEST 		= True;
$_lusuario 		= 99999; // Autorizador...
$_FPEDIDO 		= true;
$_TIMEOUT		= 300;
$_ACESSOWS	    = true;

include_once("includes/defines.inc");
include_once("includes/funcoes.fcn");
registrarAutoload();
include_once("classes/class_funcoesgerais.inc");
include_once("classes/class_HTML.inc");


if ($_GET['cad'] == '1') {
    unset($GLOBALS['_IS_MANAGER_PDV']);
    require_once("includes/header.inc");
    require_once('classes/class_painel.inc');
    require_once('web_services/ws_painel/ws_painel.inc');
    $retorno = listarAvisos('aviso');

    echo json_encode($retorno);
    die;
}

require_once("includes/header.inc");
if ($_GET['cad'] == '3') {
    require_once("web_services/ws_painel/classes/class_webservice_painel.inc");

    $dados = json_decode($_POST['val']);
    $dados = (array)$dados;

    $_config_old = 'plugin/painel/parametros_aviso_old.config';
    $_config = 'plugin/painel/parametros_aviso.config';

    unlink($_config_old);

    rename($_config, $_config_old);

    file_put_contents($_config, serialize($dados));

    echo json_encode($retorno);
    die;
}

$_HTML = new HTML();

$_ID["html"] = $_HTML->AddTag("HTML");

$_ID["head"] = $_HTML->AddTag("HEAD");
$_HTML->AddTag("META", Array("_" => 'charset="UTF-8"'), TRUE);

$_HTML->AddTag("TITLE", NULL, TRUE, "Zanthus - Sistemas Integrados - Painel");
$_HTML->AddTag("LINK", Array("REL" => "SHORTCUT ICON", "href" => "imagens/Zanthus.ico"), TRUE);
$_HTML->AddTag("LINK", Array("REL" => "stylesheet", "href" => "{$_URL}css/plugins/bootstrap/css/bootstrap.min.css{$GLOBALS['_VERSAO_CACHE']}"), TRUE);
$_HTML->AddTag("LINK", Array("REL" => "stylesheet", "href" => "{$_URL}css/plugins/adminlte/css/AdminLTE.min.css{$GLOBALS['_VERSAO_CACHE']}"), TRUE);
$_HTML->AddTag("LINK", Array("REL" => "stylesheet", "href" => "{$_URL}css/manager.css{$GLOBALS['_VERSAO_CACHE']}"), TRUE);
$_HTML->AddTag("LINK", Array("REL" => "stylesheet", "href" => "{$_URL}css/plugins/painel/styles.css{$GLOBALS['_VERSAO_CACHE']}"), TRUE);
$_HTML->AddTag("LINK", Array("REL" => "stylesheet", "href" => "{$_URL}css/plugins/painel/w3.css{$GLOBALS['_VERSAO_CACHE']}"), TRUE);
html::preencherJavaScriptPadrao($_HTML);
$_HTML->AddTag("SCRIPT", Array("SRC" => "JavaScript/plugins/painel/painel_aviso.js{$GLOBALS['_VERSAO_CACHE']}"), TRUE);

$_HTML->EndTag($_ID["head"]);

$_ID["body"] = $_HTML->AddTag("BODY", '');

$audio = $_HTML->AddTag("AUDIO", array('id' => 'audio_campainha'));
$_HTML->AddTag("SOURCE", array('id' => "source_campainha", 'src' => "plugin/painel/sound/1.ogg", 'type' => "audio/ogg"), true);
$_HTML->EndTag($audio);


$_div = $_HTML->AddTag("DIV", array('id' => 'header-fiscal', 'class' => "col-md-12", 'align' => "center"));
$_HTML->AddTag("IMG", array('id' => "source", 'onclick' => 'getClassePainelGlobalFiscal().abrirConfig()', 'src' => "plugin/painel/img/logo_painel.png"), true);
$_HTML->EndTag($_div);
/*
$_div = $_HTML->AddTag("DIV", array('id' => 'chamada-aviso', 'class' => "col-md-12", 'align' => "center"));
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-1",'class' => "col-md-2"),true);
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-2",'class' => "col-md-2"),true);
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-3",'class' => "col-md-2"),true);
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-4",'class' => "col-md-2"),true);
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-5",'class' => "col-md-2"),true);
$_HTML->AddTag("DIV", array('id'=>"chamada-aviso-6",'class' => "col-md-2"),true);


$_div3 = $_HTML->AddTag("DIV", array('class' => "pdv-chamada"));
$_HTML->AddTag("SPAN", '', true, 'CAIXA: 5');
$_HTML->AddTag("BR", '', true);
$_HTML->AddTag("SPAN", '', true, 'Mariana Oliveira');
$_HTML->AddTag("BR", '', true);
$_HTML->AddTag("SPAN", '', true, 'CHAMANDO FISCAL');
$_HTML->EndTag($_div3);
$_HTML->EndTag($_div2);
*/
$_HTML->EndTag($_div);

$_div = $_HTML->AddTag("DIV", array('id' => 'lista-aviso', 'align' => "center", 'class' => "col-md-12"), true);

// MODAL DE CONFIG
$_form = $_HTML->AddTag("FORM", array('id' => 'form-config', 'action' => '#', 'method' => 'POST'));
$_div = $_HTML->AddTag("DIV", array('id' => 'modal-config', 'class' => 'modal'));
$_div2 = $_HTML->AddTag("DIV", array('class' => 'modal-content'));
$_HTML->AddTag("H4", '', true, 'Configuracoes');
$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-12'));
$_HTML->AddTag("LABEL", '', true, 'URL Manager');
$_HTML->EndTag($_div3);
$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-12'));
$_div4 = $_HTML->AddTag("DIV", array('class' => 'form-group'));
$_HTML->AddTag("INPUT", array('id' => "url_manager", 'type' => 'text', 'class' => 'form-control'), true, '');
$_HTML->EndTag($_div4);
$_HTML->EndTag($_div3);

$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-12'));
$_HTML->AddTag("LABEL", '', true, 'URL Interface');
$_HTML->EndTag($_div3);
$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-12'));
$_div4 = $_HTML->AddTag("DIV", array('class' => 'form-group'));
$_HTML->AddTag("INPUT", array('id' => "url_interface", 'type' => 'text', 'class' => 'form-control'), true, '');
$_HTML->EndTag($_div4);
$_HTML->EndTag($_div3);

$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-6'));
$_div4 = $_HTML->AddTag("DIV", array('class' => 'form-group'));
$_HTML->AddTag("LABEL", '', true, 'Cod. Loja');
$_HTML->AddTag("INPUT", array('id' => "cod_loja", 'type' => 'number', 'class' => 'form-control'), true, '');
$_HTML->EndTag($_div4);
$_HTML->EndTag($_div3);
$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-6'));
//$_div4 = $_HTML->AddTag("DIV", array('class' => 'form-group'));
//$_HTML->AddTag("LABEL", '', true, 'Cod. Chama Fila');
//$_HTML->AddTag("INPUT", array('id' => "cod_painel", 'type' => 'number', 'class' => 'form-control'), true, '');
//$_HTML->EndTag($_div4);
$_HTML->EndTag($_div3);

$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-2'));
$_HTML->AddTag("BUTTON", array('name' => 'Salvar', 'id' => "bt_salvar", 'onclick' => 'getClassePainelGlobalFiscal().salvaConfig();', 'type' => 'button', 'class' => 'btn btn-default btn btn-flat btn-success btn-action text-white'), true, 'Salvar');
$_HTML->EndTag($_div3);
$_div3 = $_HTML->AddTag("DIV", array('class' => 'col-md-2'));
$_HTML->AddTag("BUTTON", array('name' => 'Cancelar', 'id' => "bt_cancelar", 'onclick' => 'getClassePainelGlobalFiscal().fecharConfig();', 'type' => 'button', 'class' => 'btn btn-default btn btn-flat btn-danger btn-action text-white'), true, 'Cancelar');
$_HTML->EndTag($_div3);

$_HTML->EndTag($_div2);
$_HTML->EndTag($_div);
$_HTML->EndTag($_form);
$_HTML->EndTag($_ID["body"]);

$_HTML->EndTag($_ID["html"]);
echo $_HTML->getHTML5() . $_HTML->toHTML();

?>