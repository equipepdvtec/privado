<?php
/**
 * Created by PhpStorm.
 * User: Rafael Ferreira
 * Desenvolvido para comunicar com a Interface Unificada
 *
 * Date: 15/03/2018
 * Time: 15:01
 */

$_mensagem		= $_GET["mensagem"];

if ($_mensagem <> ''){

    $_mensagemObj 	= json_decode(base64_decode($_mensagem));

    $_retorno = array(
        'resultado' => '',
        'mensagem'  => '',
        'cod_loja'  => $_mensagemObj->cod_loja,
        'cod_pdv'   => $_mensagemObj->cod_pdv,
        'dados'     => $_mensagemObj->dados,
        'fn' 		=> $_mensagemObj->fn
    );

    try {
        switch ($_mensagemObj->tipo) {
            /**
             * Consulta aa configura��o local no disco
             * mesta estrutura para n�o precisar remontar a consulta
             */
            case 'ConsultaConfigInterface':


                $_dados = $_mensagemObj->dados;

                $config = unserialize(file_get_contents("config_interface_{$_dados->loja}_{$_dados->cod_pdv}.conf"));

                if ($config <> false){
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'Configuracao restaurada';
                    $_retorno['dados'] = $config;
                }
                else{
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Problema ao restaurar config';
                }


                break;
            case 'GravaConfigInterface':

                $_dados = $_mensagemObj->dados;

                if (file_put_contents("config_interface_{$_dados->loja}_{$_dados->cod_pdv}.conf", serialize($_dados))){
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'Configuracao Salva';
                }
                else{
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Problema ao gravar config';
                }

                break;
            default:
                $_retorno['resultado'] = '1';
                $_retorno['mensagem'] = 'Nenhum tipo encontrado';
                break;
        }
    }
    catch(Exception $e) {
        $_erro = $e->getCode();

        // Tratando Retorno
        if($_retorno['resultado'] == "") {
            $_retorno['resultado'] = '1';
            $_retorno['mensagem'] = "Erro: {$e->getMessage()}";
        }

    }

}
else{
    die;
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

echo $_GET['retorno'] . '(' .  json_encode($_retorno) . ')';

?>