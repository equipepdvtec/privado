<?php

/**
 * set_error()
 * Voc� pode definir sua fun��o para tratamento de erros
 */
if (!function_exists('set_error')) {
    //$_ERROR = array();
    /**
     * @param $err_msg
     */
    function set_error($err_msg) {
        funcoesGerais::GravaLog($err_msg,true,true,false);//,"nfe_log.zlg");
        //global $_ERROR;
        //return $_ERROR[] = $err_msg;
    }
}
//chdir('./tags/pre-review/');
include_once('nfephp/tags/pre-review/libs/nfe.class.php');

/* NIVEL 0 ********************************************************************/


class situacaoZanthus extends situacao {
    //Sobrescrevendo a conex�o.
    function __construct() {
    }

    // todo:: revisar (php 8.1)
    function fetch($_con, $situacao) {
        $this->situacao_id = $situacao['situacao_id'];
        $this->descricao   = $situacao['descricao'];
    }
}

class NFeZanthus extends NFe {

    /**
     * Se for devolu��o sem cupom, por hora n�o montaremos a
     * tag da Anvisa, pois n�o temos essas informa��es e qdo for com cupom essas informa��es estar�o no cupom.
     * @var bool
     */
    public static $_devolucao_sem_cupom = false;
    //Pensar nisso depois.
    protected $_fileXSD;
    protected $_variaveisCarregadas;
    protected $_urlcarregada;
    protected $_logo;
    protected $_nome_certificado;
    protected $_senha_certificado;
    protected $_via_unica_nfe;
    protected $_id_nota_temp;
    public $_chave_ref_nf = null;
    protected $_valor_max_nfce_end = 0;
    protected $_cod_loja;

    /**
     * Permite limpar as vari�veis sempre que chamado.
     *
     * @var unknown_type
     */
    protected $_nao_limpar_mais = false;

    public $_codigo_token_nfce;
    /**
     * @var basebd
     */
    protected $_qry;

    protected $_qrcode_nfce = array();

    protected $_dados_pagamentos = [];

    public function setDadosPagamentos(Array $_dados) {
        $this->_dados_pagamentos = $_dados;
    }

    public function getDadosPagamentos() {
        return $this->_dados_pagamentos ?: [];
    }

    /**
     * Indica se deve negar ou n�o limpar as vari�veis.
     * @param boolean $_value
     */
    public function set_negar_limpeza($_value) {
        $this->_nao_limpar_mais = $_value;
    }
    /**
     * @return String
     */
    public function get_nome_certificado() {
        return $this->_nome_certificado;
    }

    /**
     * @return String
     */
    public function get_senha_certificado() {
        return funcoesGerais::descriptografarSenha($this->_senha_certificado);
    }


    public function getNameCert() {
        return $this->nameCert;
    }

    public function getPassKey() {
        return $this->passKey;
    }
    /**
     * @return String
     */
    public function getLogotipo() {
        return $this->_logotipo;
    }

    public function setLogotipo($nm){
        if($nm !== ''){
            $this->_logotipo = $nm;
        }
    }

    public function getViaUnicaNfe(){
        return $this->_via_unica_nfe;
    }

    public function setViaUnicaNfe($_qtd){
        if($_qtd !== ''){
            $this->_via_unica_nfe = $_qtd;
        }
    }

    public function getCodLoja() {
        return $this->_cod_loja;
    }

    public function setCodLoja($_cl){
        $this->_cod_loja = $_cl;
    }

    /**
     * Montar IPI somente quando for Ind�stria e NFE
     * @return bool
     */
    public function getMontarIPI() {
        return $GLOBALS["_TIPO_LOJA"] == 4 && $this->modelo == 55;
    }

    /**
     * Tipo de ambiente da NFe
     * @param string $_tipo_ambiente
     */
    public function set_flg_tipo_ambiente_nfe($_tipo_ambiente) {
        //N�o muda pra Zero se n�o estava.
        if ((int) $_tipo_ambiente !== 0) {
            $this->ambiente = (int) $_tipo_ambiente;
        }
    }

    /**
     * Retorna o tipo de ambiente NFe.
     * @return string
     */
    public function get_flg_tipo_ambiente_nfe() {
        return (int) $this->ambiente;
    }

    /**
     * @param String $_nome_certificado
     */
    public function set_nome_certificado($_nome_certificado) {
        $this->_nome_certificado = trim($_nome_certificado);
        if((String)$_nome_certificado!=="") {
            $this->nameCert      =  trim($_nome_certificado);
        }
    }

    /**
     * @param String $_senha_certificado
     */
    public function set_senha_certificado($_senha_certificado) {
        $this->_senha_certificado = funcoesGerais::descriptografarSenha(trim($_senha_certificado));
        if((String) $_senha_certificado!=="") {
            $this->passKey       =   funcoesGerais::descriptografarSenha(trim($_senha_certificado));
            $this->passPhrase    =   funcoesGerais::descriptografarSenha(trim($_senha_certificado));
        }

    }

    /**
     * M�todo para set o id_nota_temp ser� usado no InfCpl do CFe
     */
    public function set_id_nota_temp($_id_nota_temp) {
        $this->_id_nota_temp = $_id_nota_temp;
    }

    function __construct($_connection = null) {
        $this->_qry                 = $_connection;
        $this->_urlcarregada 		= false;
        $this->_variaveisCarregadas = false;
        $this->infNFe   			= new infNFe;
        $this->situacao 			= new situacaoZanthus();
        $this->ambiente				= 0;
        $this->_valor_max_nfce_end  = 0;

        /*
         * Aqui testamos se a classe nusoap_client j� est� carregada.
         * Se n�o estiver carregamos.
         */
        if(class_exists("nusoap_client",false)==false) {
            include_once(funcoesGerais::retornarCaminhoAbsolutoManager() . "includes/nusoap.inc");
        }
        return true;
    }

    /**
     * No final chamaremos esse m�todo pra preencher com os dados fiscais.
     */
    function preencherInfoAdicComTotaisImpostos($_CSTs = []) {
        //N�o pode ser new toda hora.
        if (!isset($this->infNFe->infAdic)) {
            $this->infNFe->add_infAdic(new infAdic);
        }

        if($this->infNFe->total->ICMSTot->vFCP > 0) {
            $this->infNFe->infAdic->infAdFisco .= "FECP B.C. R$ {$this->infNFe->total->ICMSTot->vFCP}";
        }

        if($this->infNFe->total->ICMSTot->vFCPST > 0) {
            $this->infNFe->infAdic->infAdFisco .= "FECP B.C. ST R$ {$this->infNFe->total->ICMSTot->vFCPST}";
        }

        if($this->infNFe->total->ICMSTot->vFCPSTRet > 0) {
            $this->infNFe->infAdic->infAdFisco .= "FECP B.C. ST Ret R$ {$this->infNFe->total->ICMSTot->vFCPSTRet}";
        }

        if($this->infNFe->total->ICMSTot->vFCPUFDest > 0){
            $this->infNFe->infAdic->infAdFisco .= "FECP B.C. Dest R$ " . number_format($this->infNFe->total->ICMSTot->vFCPUFDest,2,',','.');
        }

        //NT2023001-1 - Inserindo textos para determinados CSTs que surgirem na nota, depois precisamos ajustar os valores que est�o XXXX!
        $_infCplAdRem = false;
        foreach($_CSTs as $_key => $_aliquota){
            switch($_key){
                case 2:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico pr�prio:";
                    foreach($_aliquota as $_conteudo){
                        $this->infNFe->infAdic->infCpl .= " Al�quota: R$ {$_conteudo['adRemICMS']} BC: {$_conteudo['qBCMono']} (em litros) ICMS mono: R$ {$_conteudo['vICMSMono']},";
                    }
                    $_infCplAdRem = true;
                    break;
                case 15:
                    //Fazendo isso pois � o mesmo texto do CST 2
                    if(empty($_CSTs[2])) $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico pr�prio:";
                    foreach($_aliquota as $_conteudo){
                        $this->infNFe->infAdic->infCpl .= " Al�quota: R$ {$_conteudo['adRemICMS']} BC: {$_conteudo['qBCMono']} (em litros) ICMS mono: R$ {$_conteudo['vICMSMono']},";
                    }
                    $_passouCST15 = false;
                    foreach($_aliquota as $_conteudo){
                        if(!$_passouCST15) $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sujeito a reten��o:";
                        $this->infNFe->infAdic->infCpl .= " Al�quota: R$ {$_conteudo['adRemICMSReten']} BC: {$_conteudo['qBCMonoReten']} (em litros) ICMS mono: R$ {$_conteudo['vICMSMonoReten']},";
                        $_passouCST15 = true;
                    }
                    $_infCplAdRem = true;
                    break;
                case 53:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sobre combust�veis diferido conforme Conv�nio ICMS 199/2022";
                    $_infCplAdRem = true;
                    break;
                case 61:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sobre combust�veis cobrado anteriormente conforme Conv�nio ICMS 199/2022";
                    $_infCplAdRem = true;
                    break;
            }
        }
        $this->infNFe->infAdic->infCpl .= ($_infCplAdRem) ? ";" : "";
        //Vamos limpar o campo, pra evitar erro na hora de subir.
        $this->infNFe->infAdic->infCpl = funcoesGerais::limparCampoNotaEletronica($this->infNFe->infAdic->infCpl);

        $_ocultaTagsDest = false;
        if ((int) $this->modelo === 65 && $this->infNFe->dest->enderDest->UF != 'EX') {
            // Parametro para informar os dados do destinat�rio
            $_opcoes_dest_xml = $GLOBALS['_MONTAGEM_XML']['opcoes_dest_xml'];
            $_opcoes_dest_xml = !empty($_opcoes_dest_xml) ? $_opcoes_dest_xml : 1;
            $_ocultaTagsDest = $_opcoes_dest_xml == 1;

            // � obrigat�rio informar os dados do destinat�rio
            $_valNF = funcoesGerais::ConverterParaNumero($this->infNFe->total->ICMSTot->vNF,2);
            $_valMax = $this->_valor_max_nfce_end;
            if(is_numeric($_valMax) && $_valMax > 0) {
                if($_valNF > $_valMax) {
                    $_ocultaTagsDest = false;
                }
            }

            // � obrigat�rio informar os dados do destinat�rio
            if((int)$this->infNFe->ide->indPres == 4 && (int)$this->infNFe->transp->modFrete != 9 && !empty($this->infNFe->transp->transporta)) {
                $_ocultaTagsDest = false;
            }
        }

        //Vamos ocultar estas tags do XML e mandar apenas os campos obrigat�rios.
        if($_ocultaTagsDest) {
            unset($this->infNFe->dest->enderDest);
            $this->infNFe->dest->enderDest = new enderDest;

            unset( $this->infNFe->dest->IE, $this->infNFe->dest->ISUF, $this->infNFe->dest->IM, $this->infNFe->dest->email );
            if ((int)$this->tpAmb!==2) {
                unset($this->infNFe->dest->xNome);
            }
        }
    }
    /**
     * Pegaremos o objeto os dados do banco e valoraremos o objeto para transformarmos depois.
     * @param $_dados
     * @param $_nitem
     */
    function valorarObjeto($_dados,$_nitem) {

        $_imprimiu_issqn    = false;
        //Se for o primeiro item faz tudo isso.
        if ($_nitem === 0) {
            if (!isset($this->infNFe)) {
                //$this->carregarVariaveis();
                $this->infNFe = new infNFe();
            }
            //f minusculo usa o locale da m�quina e aparentemente em nosso container esta como Portugues.
            $this->infNFe->versao = sprintf("%01.2F", $_dados["a01_versao"]);
            $this->_versao_nfe = (float) $this->infNFe->versao;
            $this->infNFe->Id = $_dados["a01_id"];
            $this->Id = substr($_dados["a01_id"], 3);

            $this->_valor_max_nfce_end = funcoesGerais::ConverterParaNumero($_dados["e01_vlrmaxnfceend"],2);


            $this->infNFe->ide->cUF = $_dados["b01_cuf"];
            $this->codigo_token_nfce = $_dados["codigo_token_nfce"];
            /*
            $this->certificado_digital = $_dados["nome_certificado_digital"];
            $this->certificado_digital = $_dados["senha_certificado_digital"];
            */
            $_ocultaTagsDest = false; // Define se devo ocultar tags n�o obrigat�rias do destinat�rio


            $this->tpAmb = $_dados["flg_tipo_ambiente_nfe"];
            $this->ambiente = (int)$this->tpAmb;
            $this->infNFe->ide->tpAmb = $this->ambiente;
            $this->infNFe->ide->natOp =  funcoesGerais::limparCampoNotaEletronica($_dados["b01_natop"]);
            $this->infNFe->ide->indPag = $_dados["b01_indpag"];
            $this->infNFe->ide->mod = $_dados["b01_modelo"];

            NFe::$_tipo_nota = (int)$this->infNFe->ide->mod;
            $this->modelo = NFe::$_tipo_nota;

            $this->infNFe->ide->serie = $_dados["b01_serie"];
            $this->infNFe->ide->cNF = $_dados["b01_cnf"];
            $this->infNFe->ide->nNF = $_dados["b01_nnf"];

            if (!funcoesGerais::managerOFFLine()) {
                $_tipo_bd = $GLOBALS['_MASTER']->getBDType();
            } else {
                $_tipo_bd = "padrao";
            }

            /*$this->nfe_anterior = $_dados["id_nfe_anterior"];
            $this->calculo = $_dados["dt_calculo"];*/

            $_uf_nf = $_dados["c05_uf"];


            $this->infNFe->ide->dEmi = funcoesGerais::converte_data($_dados["b01_demi"], $_tipo_bd, 'utc', false, true, false, $_uf_nf, true);
            $this->infNFe->ide->dSaiEnt = funcoesGerais::converte_data($_dados["b01_dsaient"], $_tipo_bd, 'utc', false, true, false, $_uf_nf, true);

            $this->infNFe->ide->dhCont = funcoesGerais::converte_data($_dados["b01_dhcont"], $_tipo_bd, 'utc', false, true, false, $_uf_nf, true);
            $this->infNFe->emit->CRT = $_dados["c01_crt"];

            $this->infNFe->ide->xJust = $_dados["b01_xjust"];

            //Se for revenda o indFinal tem que ser zero
            $_cnpj = funcoesGerais::retornarNumeros($_dados["e01_cnpj"]);
            if($_dados["e05_uf"] == 'EX'){
                $_cnpj = funcoesGerais::removerCaracteresCpfCnpj($_dados["e01_cnpj"]);
            }
            if($_dados['flg_revenda'] != 'S' && ($GLOBALS["_VERSAO_NT"] & 16384 ) > 0) {
                $this->infNFe->ide->indFinal = 1;
            }else{
                if ($_dados['e01_ie'] != 'ISENTO' && (int)$this->modelo === 55 && !empty($_cnpj)
                    //Quando for emitida uma NF-e de Opera��o Estadual (idDest = 1), sendo essa Opera��o com Consumidor Normal (indFinal = 0) e a UF do Destinat�rio for diferente da UF do Emitente, ser� retornado a rejei��o 773
                    && !($_dados["b01_iddest"] == 1 &&  $_dados["e05_uf"] != $_dados["c05_uf"])) {
                    $this->infNFe->ide->indFinal = 0;
                } else{
                    $this->infNFe->ide->indFinal = $_dados["b01_indfinal"];
                }
            }

            /**
             * Se no b01_tipointeg estiver algum numero preenchido, esse campo que dever� ser utilizado,
             * caso contr�rio o que vale � o b01_indpres.
             */
            $this->infNFe->ide->indPres = funcoesGerais::retornarNumeros($_dados['b01_tipointeg']) != '' ? $_dados['b01_tipointeg'] : $_dados["b01_indpres"];
            $this->infNFe->ide->indIntermed = $_dados["b01_indintermed"] > 0 ? 1 : 0;

            if ($_dados["b01_indintermed"] > 0) {
                $this->infNFe->infIntermed->CNPJ = $_dados['b01_cnpjintermed'];
                if (strlen($_dados["b01_idintermed"]) == 1) {
                    $_dados["b01_idintermed"] = '0' . $_dados["b01_idintermed"];
                }
                $this->infNFe->infIntermed->idCadIntTran = $_dados["b01_idintermed"];
            } else {
                unset($this->infNFe->infIntermed);
            }

            $this->infNFe->ide->tpNF = $_dados["b01_tpnf"];
            $this->infNFe->ide->cMunFG = $_dados["b01_cmunfg"];
            $this->infNFe->ide->tpImp = $_dados["b01_tpimp"];
            $this->infNFe->ide->tpEmis = $_dados["b01_tpemis"];
            $this->infNFe->ide->cDV = $_dados['b01_cdv'];
            $this->infNFe->ide->finNFe = $_dados["b01_finnfe"];
            $this->infNFe->ide->procEmi = $_dados["b01_procemi"];
            $this->infNFe->ide->verProc = $_dados["b01_verproc"];

            //Se esses camposestiverem preenchidos
            //O tipo 4 o sistema j� faz a refer�ncia por outro ponto.
            if ((int) $this->infNFe->ide->finNFe !== 4) {
                if (isset($_dados["b20j_mod"]) && isset($_dados["b20j_necf"]) && isset($_dados["b20j_ncoo"])) {
                    $_chave = "{$_dados["b20j_mod"]}|{$_dados["b20j_necf"]}|{$_dados["b20j_ncoo"]}";
                    if (!isset($this->_chave_ref_nf[$_chave])) {
                        $this->_chave_ref_nf[$_chave] = '1';
                        $this->infNFe->ide->add_NFref(new NFref('CUPOM'));
                        $_j = sizeof((array)$this->infNFe->ide->NFref) - 1;
                        $this->infNFe->ide->NFref[$_j]->refNF->mod = $_dados["b20j_mod"];
                        $this->infNFe->ide->NFref[$_j]->refNF->nECF = (int)$_dados["b20j_necf"];
                        $this->infNFe->ide->NFref[$_j]->refNF->nCOO = (int)substr($_dados["b20j_ncoo"], -6);
                    }

                }
            }


            $this->infNFe->emit->CNPJ = funcoesGerais::retornarNumeros($_dados["c01_cnpj"]);
            if (!isset($this->infNFe->emit->xNome)) {
                $this->infNFe->emit->xNome = trim(funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["c01_xnome"])));
            }
            if (!isset($this->infNFe->emit->xFant)) {
                $this->infNFe->emit->xFant = strtoupper(trim((funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["c01_xfant"])))));
            }

            $this->infNFe->emit->IE = $_dados["c01_ie"];
            if ((int) $this->modelo === 55) {
                $this->infNFe->emit->IEST = $_dados['c01_iest'];
            }
            $this->infNFe->emit->IM = $_dados["c01_im"];
            $this->infNFe->emit->CNAE = $_dados["c01_cnae"];

            $this->infNFe->emit->enderEmit->xLgr = funcoesGerais::limparCampoNotaEletronica($_dados["c05_xlgr"]);
            $this->infNFe->emit->enderEmit->nro = trim($_dados["c05_nro"]);
            $this->infNFe->emit->enderEmit->xCpl = funcoesGerais::limparCampoNotaEletronica($_dados["c05_xcpl"]);
            $this->infNFe->emit->enderEmit->xBairro = funcoesGerais::limparCampoNotaEletronica($_dados["c05_xbairro"]);
            $this->infNFe->emit->enderEmit->cMun = $_dados["c05_cmun"];
            $this->infNFe->emit->enderEmit->xMun = funcoesGerais::limparCampoNotaEletronica($_dados["c05_xmun"]);
            $this->infNFe->emit->enderEmit->UF = $_dados["c05_uf"];

            $this->infNFe->ide->idDest = $_dados["b01_iddest"];
            $this->infNFe->emit->enderEmit->CEP = $_dados["c05_cep"];
            $this->infNFe->emit->enderEmit->cPais = $_dados["c05_cpais"];
            $this->infNFe->emit->enderEmit->xPais = strtoupper($_dados["c05_xpais"]);

            $_tamanho_fone_emit = strlen(preg_replace('/\D/', '', $_dados["c05_fone"]));
            if ($_tamanho_fone_emit >= 6 && $_tamanho_fone_emit <= 14) {
                $this->infNFe->emit->enderEmit->fone = $_dados["c05_fone"];
            } elseif ($GLOBALS["_DEBUG"]) {
                funcoesGerais::GravaLog("Telefone do emitente inv�lido: " . $_dados["c05_fone"], true, true);
            }

            $this->infNFe->dest->CPF = funcoesGerais::retornarNumeros($_dados["e01_cpf"]);
            if($_dados["e05_uf"] == 'EX'){
                $this->infNFe->dest->CPF = funcoesGerais::removerCaracteresCpfCnpj($_dados["e01_cpf"]);
            }
            $this->infNFe->dest->CNPJ = $_cnpj;
            if (!isset($this->infNFe->dest->xNome)) {
                $this->infNFe->dest->xNome = funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["e01_xnome"]));
            }
            $this->infNFe->dest->IE = $_dados['e01_ie'];
            $this->infNFe->dest->IM = $_dados["e01_im"];
            $this->infNFe->dest->ISUF = $_dados["e01_isuf"];
            $this->infNFe->dest->email = trim($_dados["e01_email"]);
            $this->infNFe->dest->indIEDest = $_dados["e01_indiedest"];

            if (isset($_dados["e05_xlgr"])) {
                $this->infNFe->dest->enderDest->xLgr = strtoupper(funcoesGerais::removerCaracteresCadrastroCLI($_dados["e05_xlgr"]));
            }
            $this->infNFe->dest->enderDest->nro = trim($_dados["e05_nro"]);
            $this->infNFe->dest->enderDest->xCpl = funcoesGerais::removerCaracteresCadrastroCLI($_dados["e05_xcpl"]);
            $this->infNFe->dest->enderDest->xBairro = funcoesGerais::removerCaracteresCadrastroCLI($_dados["e05_xbairro"]);
            $this->infNFe->dest->enderDest->cMun = $_dados["e05_cmun"];
            if (isset($_dados["e05_xmun"])) {
                $this->infNFe->dest->enderDest->xMun = strtoupper(funcoesGerais::removerCaracteresCadrastroCLI($_dados["e05_xmun"]));
            }
            $this->infNFe->dest->enderDest->UF = $_dados["e05_uf"];
            $this->infNFe->dest->enderDest->CEP = $_dados["e05_cep"];
            $this->infNFe->dest->enderDest->cPais = $_dados["e05_cpais"];
            $this->infNFe->dest->enderDest->xPais = strtoupper(funcoesGerais::removerCaracteresCadrastroCLI($_dados["e05_xpais"]));
            $this->infNFe->dest->enderDest->fone = $_dados["e05_fone"];

            //BL-6727 => Se for venda exterior, presencial e opera��o interna, n�o pode conter as tags do pais
            if ((int) $this->modelo === 55 &&
                $this->infNFe->dest->enderDest->xMun ==  'EXTERIOR' &&
                (int)$this->infNFe->ide->idDest == 1 &&
                (int)$this->infNFe->ide->indPres == 1){
                unset($this->infNFe->dest->enderDest->cPais);
                unset($this->infNFe->dest->enderDest->xPais);
            }

            /*
             * BL-4197 - No Ambiente de Homologa��o alterar o valor da tag <CNPJ>99999999000191</CNPJ> para
             * valor real encontrado no campo num_cgc da tab_nota_header, quando o cliente for PJ, contribuinte
             * do ICMS e IE v�lida.
             */
            if ((int)$this->tpAmb == 2 && empty($_dados['e01_cnpj']) && empty($_dados["e01_cpf"])) {
                $this->infNFe->dest->CNPJ = '99999999000191';

            }
            //$this->infNFe->dest->CNPJ       = ($res_dest['enderdest']['uf'] !== 'EX') ? "99999999000191" : null;
            if ((int)$this->tpAmb === 2) {
                $this->infNFe->dest->xNome = "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL";
            }

            $_operacao_presencial = false;
            //ML-237 - Se atender todos esses casos, significa que foi opera��o presencial
            if ($this->infNFe->ide->idDest == "1" &&
                $this->infNFe->dest->indIEDest == "9" &&
                $this->infNFe->ide->indPres == "1" &&
                $this->infNFe->ide->indFinal == "1" &&
                !empty($_dados["flg_ind_pres"])) {
                $_operacao_presencial = true;
            }
            $_ie_temp = $_dados['e01_ie'];
            if ((int)$this->modelo !== 65) {

                /*
                 * BL-4197 - Altera��o solicitada pela Val�ria no dia 15/03/16.
                 * Crie um IF para cada tipo de indiedest
                 */
                //Contribuinte pessoa juridica
                if ($this->infNFe->dest->IE != 'ISENTO' && (int)$this->modelo === 55 && !empty($this->infNFe->dest->CNPJ) && empty($_operacao_presencial)) {
                    $this->infNFe->dest->IE = $_ie_temp;
                    $this->infNFe->dest->indIEDest = 1;
                }
                //contribuinte pessoa juridica isento de inscri��o estadual(IE) ou cpf nos estados da UF.
                if ((int)$this->modelo === 55
                    && ($this->verificarUFNotaTecnica($_uf_nf) == true
                        || $this->verificarUFNotaTecnica($_dados["e05_uf"]) == true)
                    && (($this->infNFe->dest->IE == 'ISENTO'
                            && !empty($this->infNFe->dest->CNPJ))
                        || !empty($this->infNFe->dest->CPF))) {
                    //Atividade ALTNFENFCE-19, pede para por o 9 quando for modelo 55 e UF (AM, BA, CE, GO, MG, MS, MT,PE, RN, SP)

                    $this->infNFe->dest->indIEDest = 9;

                    /**
                     * @Auhtor   : Filipe Barros
                     * BL-4696
                     * @Descr    : Sempre que for um Produtor Rural setamos o indiedest como 1 e passamos a inscri��o estadual
                     *             No array $res_dest os campos cpf e cnpj sempre vem com o mesmo valor.
                     *             Produtor Rural � uma Pessoa F�sica, por isso entra na condi��o acima.
                     *             Segundo a Val�ria, caso n�o houver IE, sempre mandamos o indiedest como 9.
                     */
                    if ($GLOBALS["_FLG_EMPRESA"] == 'R') {
                        $this->infNFe->dest->IE = $_ie_temp;
                        $this->infNFe->dest->indIEDest = 1;
                    }


                }
                //N�o contribuinte pessoa juridica ou pessoa f�sica n�o sendo dos estados da UF
                if ((int)$this->modelo === 55
                    && $this->verificarUFNotaTecnica($_uf_nf) == false
                    && $this->verificarUFNotaTecnica($_dados["e05_uf"]) == false
                    && (($this->infNFe->dest->IE == 'ISENTO'
                            && !empty($this->infNFe->dest->CNPJ))
                        || !empty($this->infNFe->dest->CPF))) {

                    /**
                     * @Auhtor   : Filipe Barros
                     * BL-4696
                     * @Descr    : Sempre que for um Produtor Rural setamos o indiedest como 1 e passamos a inscri��o estadual
                     *             No array $res_dest os campos cpf e cnpj sempre vem com o mesmo valor.
                     *             Produtor Rural � uma Pessoa F�sica, por isso entra na condi��o acima.
                     *             Segundo a Val�ria, caso n�o houver IE, sempre mandamos o indiedest como 9.
                     */
                    if ($GLOBALS["_FLG_EMPRESA"] == 'R') {
                        $this->infNFe->dest->IE = $_ie_temp;
                        $this->infNFe->dest->indIEDest = 1;
                    }
                }

                //Atividade NOTATECNOV-1, Se for venda exterior deve for�ar o valor 9 para o indIEDest
                if ((int)$this->modelo === 55 && $_dados["e05_uf"] == 'EX') {
                    $this->infNFe->dest->IE = "";
                    $this->infNFe->dest->indIEDest = 9;
                }

            }

            //Para o ambiente de teste deve for�ar 9 segundo a Val�ria.
            if ((int)$this->tpAmb === 2 && (int)$this->modelo === 65) {
                $this->infNFe->dest->indIEDest = 9;
            }
            if($_dados['cfop_nao_contribuinte'] == 'S'){
                $this->infNFe->dest->indIEDest = 9;
            }

            /**
             * BL-5473
             * BIT Software
             * 28.05.2018
             * Se for SC e estiver 2 for�amos para 9
             */
            if ((int)$this->modelo===55&& $this->infNFe->dest->enderDest->UF=='SC'&&$this->infNFe->dest->indIEDest==2) {
                $this->infNFe->dest->indIEDest  = 9;
            }
            if (!empty($_dados["za01_ufsaidapais"])) {
                $this->infNFe->add_exporta(new exporta);
                $this->infNFe->exporta->ufsaidapais = $_dados["za01_ufsaidapais"];
                $this->infNFe->exporta->xlocexporta = $_dados["za01_xlocexporta"];
            }

            $this->infNFe->transp->modFrete = $_dados["x01_modfrete"];
            if ((isset($_dados["x03_cnpj"]) || isset($_dados["x03_cpf"]))  && (int)$this->infNFe->transp->modFrete != 9) {
                if (empty($this->infNFe->transp->transporta)) {
                    $this->infNFe->transp->add_transporta(new transporta);
                }
                $this->infNFe->transp->transporta->CNPJ   = $_dados["x03_cnpj"];
                $this->infNFe->transp->transporta->CPF    = $_dados["x03_cpf"];
                if (!isset($this->infNFe->transp->transporta->xNome)) {
                    $this->infNFe->transp->transporta->xNome = funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["x03_xnome"])); //diego 11
                }
                $this->infNFe->transp->transporta->IE     = $_dados["x03_ie"];
                $this->infNFe->transp->transporta->xEnder = $_dados["x03_xender"];
                $this->infNFe->transp->transporta->xMun   = funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["x03_xmun"]));
                $this->infNFe->transp->transporta->UF     = $_dados["x03_uf"];

                if ((int)$this->modelo !== 65 && (($this->_versao_nfe < 4) ||
                    ((int)$this->infNFe->ide->idDest === 1 && $this->infNFe->dest->enderDest->UF == $this->infNFe->emit->enderEmit->UF))) {
                    //veicTransp
                    if (isset($_dados["x18_placa"])) {
                        if (!isset($this->infNFe->transp->veicTransp)) {
                            $this->infNFe->transp->add_veicTransp(new veicTransp);
                        }
                        $this->infNFe->transp->veicTransp->placa = $_dados["x18_placa"];
                        $this->infNFe->transp->veicTransp->UF = $_dados["x18_uf"];
                        $this->infNFe->transp->veicTransp->RNTC = $_dados["x18_rntc"];
                    }

                    //reboque
                    if (isset($_dados["x22_placa"])) {
                        if (empty($this->infNFe->transp->reboque)) {
                            $this->infNFe->transp->add_reboque(new reboque);
                        }
                        $this->infNFe->transp->reboque[0]->placa = $_dados["x22_placa"];
                        $this->infNFe->transp->reboque[0]->UF = $_dados["x22_uf"];
                        $this->infNFe->transp->reboque[0]->RNTC = $_dados["x22_rntc"];
                    }
                }

            }

            /**
             * BL-6130
             * O grupo de volume (x26) pode ter N ocorr�ncias. Mas no momento inserimos uma s�.
             * Se for um pedido os dados ir�o vir da tab_nota_transp, caso contr�rio usaremos
             * apenas PESO_BRUTO e PESO_LIQUIDO da tab_mercadoria.
             */
            if (isset($_dados["x26_marca"]) || isset($_dados["x26_pesob"])) {
                if (empty($this->infNFe->transp->vol)) {
                    $this->infNFe->transp->add_vol(new vol);
                }
                $this->infNFe->transp->vol->qVol    = $_dados["x26_qvol"];
                $this->infNFe->transp->vol->esp     = $_dados["x26_esp"];
                $this->infNFe->transp->vol->marca   = $_dados["x26_marca"];
                $this->infNFe->transp->vol->nVol    = $_dados["x26_nvol"];
                $this->infNFe->transp->vol->pesoL   = $_dados["x26_pesol"];
                $this->infNFe->transp->vol->pesoB   = $_dados["x26_pesob"];
            }

            if(empty($this->infNFe->infAdic)) {
                $this->infNFe->add_infAdic(new infAdic());
            }

            $this->infNFe->infAdic->infCpl = $_dados["z01_infcpl"];
            $this->infNFe->autXML->CNPJ = $_dados["a01_cnpj"] ;
            $this->infNFe->autXML->CPF = $_dados["a01_cpf"] ;

            // Respons�vel Tecnico
            if (($GLOBALS["_VERSAO_NT"] & 1) > 0) {
                $this->infNFe->infRespTec->CNPJ = '50245869000174';
                $this->infNFe->infRespTec->xContato = 'Zanthus Comercio e Servicos Ltda';
                $this->infNFe->infRespTec->fone = '1137507000';
                $this->infNFe->infRespTec->email = 'fiscal@zanthus.com.br';

                // SQA-3962 verifica o bit para inclus�o do hashCSRT
                if (($this->infNFe->ide->mod == 65 && ($GLOBALS['_UF_FLAGS'] & 8192) > 0)
                    || ($this->infNFe->ide->mod == 55 && ($GLOBALS['_UF_FLAGS'] & 16384) > 0)) {
                    $chNFe = str_replace('NFe', '', $this->infNFe->Id);
                    $_dados_csrt = funcoesGerais::obterDadosCSRT($_uf_nf);
                    $_arr_csrt = funcoesGerais::montarHashCSRT($chNFe, $this->tpAmb, $_dados_csrt['DADOS_CSRT']);
                    $this->infNFe->infRespTec->idCSRT = str_pad((int)$_arr_csrt['idCSRT'],2, '0', STR_PAD_LEFT);
                    $this->infNFe->infRespTec->hashCSRT = $_arr_csrt['hashCSRT'];
                }
            }
        }
        //Fim da primeira vez.

        if ($this->modelo === 65 && ($GLOBALS['_UF_FLAGS'] & 2048) > 0) {
            $nBico = (!empty($_dados["nbico"])) ? $_dados["nbico"] : 0;
            $nBomba = (!empty($_dados["nbomba"])) ? $_dados["nbomba"] : 0;
            $nTanque = (!empty($_dados["ntanque"])) ? $_dados["ntanque"] : 0;
            $vEncIni = (!empty($_dados["vencini"])) ? $_dados["vencini"] : 0;
            $vEncFim = (!empty($_dados["vencfin"])) ? $_dados["vencfin"] : 0;
            $_encerrantes_nota = [
                ['xCampo' => 'nBico', 'xTexto' => $nBico],
                ['xCampo' => 'nBomba', 'xTexto' => $nBomba],
                ['xCampo' => 'nTanque', 'xTexto' => $nTanque],
                ['xCampo' => 'vEncIni', 'xTexto' => $vEncIni],
                ['xCampo' => 'vEncFim', 'xTexto' => $vEncFim]
            ];
            foreach ($_encerrantes_nota as $ct) {
                $obsCont = new obsCont;
                $obsCont->xCampo = $ct['xCampo'];
                $obsCont->xTexto = $ct['xTexto'];
                $this->infNFe->infAdic->obsCont[] = $obsCont;
            }
        }

        /**
         * SQM-4049
         * Adicionado os novos campos da NT 2024.003 no XML
         */
         if (!empty($_dados["nreceituario"]) || !empty($_dados["cpfresptec"])) {
            if(empty($this->infNFe->agropecuario)) {
                $this->infNFe->add_agropecuario(new agropecuario());
            }
            $defensivo = new defensivo();
            $defensivo->nReceituario = (string)$_dados["nreceituario"];
            $defensivo->CPFRespTec = (string)$_dados["cpfresptec"];
            $this->infNFe->agropecuario->add_defensivo($defensivo);
        }

        if (!empty($_dados["h01_nitem"])) {
            $this->infNFe->add_det(new det);
            $this->infNFe->det[$_nitem]->nItem = $_dados["h01_nitem"];
            $this->infNFe->det[$_nitem]->prod->vFrete = $_dados["i01_vfrete"];
            $this->infNFe->det[$_nitem]->prod->vSeg = $_dados["i01_vseg"];
            $this->infNFe->det[$_nitem]->prod->vOutro = $_dados["i01_voutro"];

            /**
             * SQM-103
             * Ajustando para n�o montar a tag de desconto nos itens com indicador de dedu��o do icms desonerado.
             * Essa informa��o pode gerar duplicidade de descontos.
             */
            if($_dados["n01_inddeduzdeson"] == "1"){
                $_dados["i01_vdesc"] = 0;
            }
            $this->infNFe->det[$_nitem]->prod->vDesc = $_dados["i01_vdesc"];
            $this->infNFe->det[$_nitem]->prod->cEAN = $_dados["i01_cean"];
            $this->infNFe->det[$_nitem]->prod->cProd = $_dados["i01_cprod"];

            //em modo de homologa��o mandar o primeiro produto com essa descricao
            if ((int)$this->tpAmb === 2 && $_nitem === 0 && (int)$this->modelo === 65) {
                $this->infNFe->det[$_nitem]->prod->xProd = "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL";
            } else {
                // Dever� ser identificado se o pdv est� mandando uma descri��o promocional no item, para que seja retirado do XML
                // Ex: COCA-COLA 600ML De 3,50 por 3,00
                $_desc = explode(' ', funcoesGerais::limparCampoNotaEletronica($_dados["i01_xprod"]));
                $de_por='';
                $new_desc='';
                foreach ($_desc as $itens) {
                    switch ($itens) {
                        case 'De':
                        case '_De':
                            $de_por .= '|DE';
                            break;
                        case 'por':
                            $de_por .= '|POR';
                            break;
                        default:
                            $isString = preg_replace("/[^A-Za-z-]/", "", $itens);
                            empty($isString) ? $de_por .= '|NUMBER' : $new_desc .= $itens.' ';
                    }
                }
                if($de_por == '|DE|NUMBER|POR|NUMBER') {
                    $this->infNFe->det[$_nitem]->prod->xProd = funcoesGerais::limparCampoNotaEletronica($new_desc);
                    $this->infNFe->det[$_nitem]->add_infAdProd(new infAdProd);
                    // A descri��o promocional ser� armazenada no campo complementar, pois ser� impressa na Danfe.
                    // N�o alterar descritivo pois ser� usado como palavra chave de busca e tem separadores pois nesse campo pode ir outras mensagens
                    $_desc_promo = str_replace($new_desc, "", $_dados["i01_xprod"]);
                    $this->infNFe->det[$_nitem]->infAdProd->infAdProd  = '|DESC_PROMO: '.funcoesGerais::limparCampoNotaEletronica($_desc_promo).'|';
                } else {
                    $this->infNFe->det[$_nitem]->prod->xProd = funcoesGerais::limparCampoNotaEletronica($_dados["i01_xprod"]);
                }
            }

            $this->infNFe->det[$_nitem]->prod->CFOP = $_dados["i01_cfop"];
            $this->infNFe->det[$_nitem]->prod->uCom = funcoesGerais::limparCampoNotaEletronica($_dados["i01_ucom"]);
            $this->infNFe->det[$_nitem]->prod->qCom = $_dados["i01_qcom"];
            $this->infNFe->det[$_nitem]->prod->vUnCom = $_dados["i01_vuncom"];
            $this->infNFe->det[$_nitem]->prod->vProd = $_dados["i01_vprod"];
            //$this->infNFe->det[$_nitem]->prod->vnf = $_dados["i01_vnf"];
            $this->infNFe->det[$_nitem]->prod->NCM = $_dados["i01_ncm"];
            $this->infNFe->det[$_nitem]->prod->CEST = $_dados["i01_cest"];
            $this->infNFe->det[$_nitem]->prod->indEscala = $_dados["i01_indescala"];
            $this->infNFe->det[$_nitem]->prod->qTrib = $_dados["i01_qtrib"];
            $this->infNFe->det[$_nitem]->prod->vUnTrib = $_dados["i01_vuntrib"];
            /**
             * Nosso VUnTrib vem subtraindo o desconto.
             * Por�m a nota t�cnica NT 2011/004
             * GI14a  campo I14a diz que se a multiplica��o for diferente
             * dar� o erro 630.
             */
            if (!empty($_dados["i01_vuntrib"])) {
                $this->infNFe->det[$_nitem]->prod->vUnTrib   = $_dados["i01_vuntrib"];
            } else {//Se estiver vazio pega o da pr�pria vuncom
                $this->infNFe->det[$_nitem]->prod->vUnTrib   = $_dados["i01_vuncom"];
            }


            $this->infNFe->det[$_nitem]->prod->indTot = $_dados["i01_indtot"];
            $this->infNFe->det[$_nitem]->prod->uTrib = funcoesGerais::limparCampoNotaEletronica($_dados["i01_utrib"]);
            $this->infNFe->det[$_nitem]->prod->EXTIPI = $_dados["i01_extipi"];

            if (strlen($_dados["n01_cst"]) == 2) {
                $_n01_cst = $_dados["n01_cst"];
            }else{
                $_n01_cst = substr($_dados["n01_cst"],1,2);
            }

            $this->infNFe->det[$_nitem]->prod->cBenef = trim($_dados["i01_cbenef"]);

            $this->infNFe->det[$_nitem]->prod->cEANTrib = $_dados["i01_ceantrib"];

            //Atributo do produto
            if (intval($_dados["i01_tipoimposto"])===0) {
                if (isset($_dados["l101_cprodanp"]) && !empty($_dados["l101_cprodanp"]) && ($this->infNFe->ide->mod == '55') && ($GLOBALS['_VERSAO_NT']&2097152)>0) {
                    $this->infNFe->det[$_nitem]->imposto->add_ICMS(new ICMS(true));
                }
                else {
                    $this->infNFe->det[$_nitem]->imposto->add_ICMS(new ICMS());
                }
                if(($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) && !funcoesGerais::managerOFFLine()) {
                    $this->infNFe->det[$_nitem]->imposto->ICMS->orig      = $_dados["n01_orig_simples"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->CST       = $_dados["n01_cst_simples"];
                }else{
                    $this->infNFe->det[$_nitem]->imposto->ICMS->orig      = $_dados["n01_orig"];
                    if ($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->CST = $_dados["n01_cst"];
                    } else {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->CST       = $_n01_cst;
                    }
                }
                $this->infNFe->det[$_nitem]->imposto->ICMS->modBC     = $_dados["n01_modbc"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pRedBC    = $_dados["n01_predbc"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vBC       = $_dados["n01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pICMS     = $_dados["n01_picms"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vICMS     = $_dados["n01_vicms"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->modBCST   = $_dados["n01_modbcst"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pMVAST    = $_dados["n01_pmvast"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pRedBCST  = $_dados["n01_predbcst"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vBCST     = $_dados["n01_vbcst"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pICMSST   = $_dados["n01_picmsst"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSST   = $_dados["n01_vicmsst"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSOp   = $_dados["n01_vicmsop"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->pDif      = $_dados["n01_pdif"];
                $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSDif  = $_dados["n01_vicmsdif"];


                // ML-1203 -> 25-11-19 -> Eduardo Esteves
                if(($GLOBALS['_VERSAO_NT'] & 2048) != 0
                && $this->infNFe->ide->indFinal == 0
                && ($this->infNFe->ide->mod == '55' || $this->infNFe->ide->mod == '65')
                && ($this->infNFe->det[$_nitem]->imposto->ICMS->CST == '60' || $this->infNFe->det[$_nitem]->imposto->ICMS->CST == '500')) {

                    $this->infNFe->det[$_nitem]->imposto->ICMS->vBCSTRet = $_dados["n26_vbcstret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pST = $_dados["n26_pst"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSubstituto = $_dados["n26_vicmssubstituto"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSTRet = $_dados["n27_vicmsstret"];

                    $this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST   = $_dados["n26_vbcstret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST     = $_dados["n01_pfcpst"];
                    $_dados["n01_vfcpst"] = ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST * ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST / 100) - (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP);
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST     = $_dados["n01_vfcpst"];

                    if (isset($_dados["l101_cprodanp"]) && !empty($_dados["l101_cprodanp"]) && ($this->infNFe->ide->mod == '55') && ($GLOBALS['_VERSAO_NT']&2097152)>0) {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vBCSTDest = $_dados["n31_vbcstdest"];
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSTDest = $_dados["n32_vicmsstdest"];
                    }
                }

                /**
                 * ML-1624
                 * Inserido para consumidor final MS
                 */
                if(($GLOBALS['_VERSAO_NT'] & 8192) != 0
                    && $this->infNFe->ide->indFinal == 1
                    && ($this->infNFe->ide->mod == '55' || $this->infNFe->ide->mod == '65')
                    && ($this->infNFe->det[$_nitem]->imposto->ICMS->CST == '60' || $this->infNFe->det[$_nitem]->imposto->ICMS->CST == '500')) {

                    $this->infNFe->det[$_nitem]->imposto->ICMS->vBCSTRet = $_dados["n26_vbcstret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pST = $_dados["n26_pst"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSubstituto = $_dados["n26_vicmssubstituto"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSTRet = $_dados["n27_vicmsstret"];

                    $this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST   = $_dados["n26_vbcstret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST     = $_dados["n01_pfcpst"];
                    $_dados["n01_vfcpst"] = ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST * ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST / 100) - (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP);
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST     = $_dados["n01_vfcpst"];
                }

                /**
                 * ML-1124
                 * Segundo a nota t�cnica NT2018 005_v1_30 o ICMS efetivo se torna obrigat�rio
                 * em opera��es para consumidor final (indFinal=1) e CST 60 ou CSSON 500
                 * caso contr�rio iremos zerar os valores
                 */
                if(($GLOBALS['_VERSAO_NT'] & 2) != 0
                && $this->infNFe->ide->indFinal == 1
                && ($this->infNFe->ide->mod == '55' || $this->infNFe->ide->mod == '65')
                && ($this->infNFe->det[$_nitem]->imposto->ICMS->CST == '60' || $this->infNFe->det[$_nitem]->imposto->ICMS->CST == '500')) {

                    //Por causa da regra de icms checo tamb�m o percentual do efetivo
                    if($this->infNFe->det[$_nitem]->imposto->ICMS->pICMS > 0 || $_dados["n36_picmsefet"] > 0) {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->pRedBCEfet = $_dados["n34_predbcefet"];
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vBCEfet = $_dados["n35_vbcefet"];
                        $this->infNFe->det[$_nitem]->imposto->ICMS->pICMSEfet = $_dados["n36_picmsefet"];
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSEfet = $_dados["n37_vicmsefet"];
                    } else if($this->infNFe->dest->enderDest->UF == 'SP' || $this->infNFe->dest->enderDest->UF == 'RS' || $this->infNFe->dest->enderDest->UF == 'SC') {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->pRedBCEfet = 0.00;
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vBCEfet = 0.00;
                        $this->infNFe->det[$_nitem]->imposto->ICMS->pICMSEfet = 0.00;
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSEfet = 0.00;
                    }
                }

                if ($this->_versao_nfe >= 4 && $_dados["b01_iddest"] != "2") {
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCP   = $_dados["n01_vbcfcp"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pFCP     = $_dados["n01_pfcp"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vFCP     = $_dados["n01_vfcp"];
                    if (empty($this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST) && $_dados["n01_vbcfcpst"] > 0) {
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST   = $_dados["n01_vbcfcpst"];
                        $this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST     = $_dados["n01_pfcpst"];
                        $_dados["n01_vfcpst"] = ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCPST * ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->pFCPST / 100) - (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP);
                        $this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST     = $_dados["n01_vfcpst"];
                    }
                    if($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) {
                        if(($this->infNFe->det[$_nitem]->imposto->ICMS->CST == 500) && $this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST > 0) {
                            $this->infNFe->total->ICMSTot->vFCPSTRet += number_format((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST, 2, ".", "");
                        }
                        if(($this->infNFe->det[$_nitem]->imposto->ICMS->CST != 500) && $this->infNFe->det[$_nitem]->imposto->ICMS->vFCP > 0) {
                            $this->infNFe->total->ICMSTot->vFCP += (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP;
                        }
                    }else{
                        if(($this->infNFe->det[$_nitem]->imposto->ICMS->CST == 10 ||
                                $this->infNFe->det[$_nitem]->imposto->ICMS->CST == 30 ||
                                $this->infNFe->det[$_nitem]->imposto->ICMS->CST == 60 ||
                                $this->infNFe->det[$_nitem]->imposto->ICMS->CST == 70 ||
                                $this->infNFe->det[$_nitem]->imposto->ICMS->CST == 90) && $this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST > 0) {
                            //Segundo a j�ssica e tamb�m pela fonte: https://blog.oobj.com.br/fundo-de-combate-pobreza-fcp-nfe-4-0/, o vFCPSTRet � apenas no 60 e 500
                            if($this->infNFe->det[$_nitem]->imposto->ICMS->CST == 60 || $this->infNFe->det[$_nitem]->imposto->ICMS->CST == 500){
                                if ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP > 0) {
                                    $this->infNFe->total->ICMSTot->vFCPSTRet += number_format((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP, 2, ".", "");
                                } elseif ((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST > 0) {
                                    $this->infNFe->total->ICMSTot->vFCPSTRet += number_format((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST, 2, ".", "");
                                }
                                // $this->infNFe->total->ICMSTot->vFCP = 0;
                            } else {
                                $this->infNFe->total->ICMSTot->vFCPST += (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST;
                                $this->infNFe->total->ICMSTot->vNF += (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCPST;
                            }
                        }
                        if(!empty($this->infNFe->total->ICMSTot->vFCPSTRet)) {
                            $this->infNFe->total->ICMSTot->vBCST = 0;
                        }
                        if($this->infNFe->det[$_nitem]->imposto->ICMS->vFCP>0&&$this->infNFe->det[$_nitem]->imposto->ICMS->CST!=60&&$this->infNFe->det[$_nitem]->imposto->ICMS->CST!=500) {
                            $this->infNFe->total->ICMSTot->vFCP += (float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP;
                        }
                    }

                    if($this->infNFe->det[$_nitem]->imposto->ICMS->vFCP > 0) {
                        $this->infNFe->det[$_nitem]->add_infAdProd(new infAdProd);
                        $_valor_base = $this->infNFe->det[$_nitem]->imposto->ICMS->vBCFCP;
                        if(funcoesGerais::CSTValido($this->infNFe->det[$_nitem]->imposto->ICMS->CST, [60], $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"])) {
                            $_valor_base = $this->infNFe->det[$_nitem]->imposto->ICMS->vBCSTRet;
                        }
                        $_percentual = number_format((float)$this->infNFe->det[$_nitem]->imposto->ICMS->pFCP, 2, ".", "");
                        $_valor_base = number_format((float)$_valor_base, 2, ".", "");
                        $_valor = number_format((float)$this->infNFe->det[$_nitem]->imposto->ICMS->vFCP, 2, ".", "");
                        $this->infNFe->det[$_nitem]->infAdProd->infAdProd .= "FECP B.C. R$ {$_valor_base} {$_percentual}% Valor R$ {$_valor}";
                    }
                }

                /**
                 * Autor: Tairo Miguel
                 * BL-3302
                 * OBS:Tag de desonera��o de icms
                 */
                if(floatval($_dados["n01_vicmsdeson"]) > 0){
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSDeson     = $_dados["n01_vicmsdeson"];
                    //Segundo a Val�ria, restringir o motdesicms apenas para CST 40 e 41, ent�o diferente disso eu volto para 9
                    if ($this->infNFe->det[$_nitem]->imposto->ICMS->CST != 40 && $this->infNFe->det[$_nitem]->imposto->ICMS->CST != 41 && $_dados["n01_motdesicms"] == 8) {
                        $_dados["n01_motdesicms"] = 9;
                    }
                    $this->infNFe->det[$_nitem]->imposto->ICMS->motDesICMS     = $_dados["n01_motdesicms"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->indDeduzDeson = $_dados["n01_inddeduzdeson"];
                }

                /**
                 * NT20005110-5
                 * BIT
                 * Jun.2021
                 */
                if(floatval($_dados["n33_vicmsstdeson"]) > 0){
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSSTDeson = $_dados["n33_vicmsstdeson"];
                    $_dados["n33_motdesicmsst"] = 9;
                    $this->infNFe->det[$_nitem]->imposto->ICMS->motDesICMSST = $_dados["n33_motdesicmsst"];
                }
                /**
                 * NT20005110-23
                 * Bit
                 * Jun.2021
                 */
                if(($GLOBALS['_VERSAO_NT']&524288)!=0) {
                    $this->infNFe->det[$_nitem]->imposto->ICMS->pDifFCP = $_dados["n33_pdiffcp"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSFCPDif = $_dados["n33_vicmsfcpdif"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSEfFCPDif = $_dados["n33_vicmseffcpdif"];
                }

                if(in_array((int)$this->infNFe->det[$_nitem]->imposto->ICMS->CST,[2,15,53,61])) {
                    $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMono = $_dados["n37a_qbcmono"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMonoReten = $_dados["n39a_qbcmonoreten"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMonoRet = $_dados["n43a_qbcmonoret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->adRemICMS = $_dados["n38_adremicms"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->adRemICMSReten = $_dados["n40_adremicmsreten"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->adRemICMSRet = $_dados["n44_adremicmsret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMono = $_dados["n39_vicmsmono"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoReten = $_dados["n41_vicmsmonoreten"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoRet = $_dados["n45_vicmsmonoret"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoOp = $_dados["n41a_vicmsmonoop"];
                    $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoDif = $_dados["n43_vicmsmonodif"];

                    //Esses n�o temos no banco ent�o a soma est� sendo feita pelos itens
                    $this->infNFe->total->ICMSTot->qBCMono += $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMono;
                    $this->infNFe->total->ICMSTot->qBCMonoReten += $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMonoReten;
                    $this->infNFe->total->ICMSTot->qBCMonoRet += $this->infNFe->det[$_nitem]->imposto->ICMS->qBCMonoRet;
                }
            }

            //IPI
            if ($this->getMontarIPI() && !empty($_dados["o01_cst"]) && !empty($_dados["o01_cenq"])) {
                $this->infNFe->det[$_nitem]->imposto->add_IPI(new IPI);
                if($_dados["o01_cst"]== '05' && $GLOBALS['_CODIGO_REGIME_TRIBUTARIO'] == 1){
                    $_dados["o01_cst"] = '99';
                }
                $this->infNFe->det[$_nitem]->imposto->IPI->cEnq      = $_dados["o01_cenq"];
                $this->infNFe->det[$_nitem]->imposto->IPI->CST       = $_dados["o01_cst"];
                $this->infNFe->det[$_nitem]->imposto->IPI->vBC       = $_dados["o01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->IPI->pIPI      = $_dados["o01_pipi"];
                $this->infNFe->det[$_nitem]->imposto->IPI->vIPI      = $_dados["o01_vipi"];
            }

            //PIS
            if (!empty($_dados["q01_cst"])) {//Esse deve aparecer sempre
                $this->infNFe->det[$_nitem]->imposto->add_PIS(new PIS);
                // BL-5324 Quando for simplis nacional convertemos para 99
                if($_dados["q01_cst"]== '05' && $GLOBALS['_CODIGO_REGIME_TRIBUTARIO'] == 1){
                    $_dados["q01_cst"] = '99';
                }
                $this->infNFe->det[$_nitem]->imposto->PIS->CST       = $_dados["q01_cst"];
                $this->infNFe->det[$_nitem]->imposto->PIS->vBC       = $_dados["q01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->PIS->pPIS      = $_dados["q01_ppis"];
                $this->infNFe->det[$_nitem]->imposto->PIS->vPIS      = $_dados["q01_vpis"];
                $this->infNFe->det[$_nitem]->imposto->PIS->qBCProd   = $_dados["q01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->PIS->vAliqProd = $_dados["q01_valiqprod"];
            }

            /* N�o tratamos at� 18/10/2018
             * //PISST
            $res_PISST = $res_imposto['pisst'];
            if (count((array)$res_PISST)) {
                if(floatval($res_PISST['vbc'])>0) {
                    $this->infNFe->det[$_nitem]->imposto->add_PISST(new PISST);
                    $this->infNFe->det[$_nitem]->imposto->PISST->vBC       = $res_PISST['vbc'];
                    $this->infNFe->det[$_nitem]->imposto->PISST->pPIS      = $res_PISST['ppis'];
                    $this->infNFe->det[$_nitem]->imposto->PISST->qBCProd   = $res_PISST['qbcprod'];
                    $this->infNFe->det[$_nitem]->imposto->PISST->vAliqProd = $res_PISST['valiqprod'];
                    $this->infNFe->det[$_nitem]->imposto->PISST->vPIS      = $res_PISST['vpis'];
                }
            }*/

            //COFINS
            if (!empty($_dados["s01_cst"])) {//Esse dever� aparecer sempre
                $this->infNFe->det[$_nitem]->imposto->add_COFINS(new COFINS);
                // BL-5324 Quando for simplis nacional convertemos para 99
                if($_dados["s01_cst"] == '05' && $GLOBALS['_CODIGO_REGIME_TRIBUTARIO'] == 1){
                    $_dados["s01_cst"] = '99';
                }
                $this->infNFe->det[$_nitem]->imposto->COFINS->CST       = $_dados["s01_cst"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vBC       = $_dados["s01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->pCOFINS   = $_dados["s01_pcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->qBCProd   = $_dados["s01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vAliqProd = $_dados["s01_valiqprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vCOFINS   = $_dados["s01_vcofins"];
            }

            //COFINSST
            if(floatval($_dados["t01_vbc"])>0) {
                $this->infNFe->det[$_nitem]->imposto->add_COFINSST(new COFINSST);
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vBC       = $_dados["t01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->pCOFINS   = $_dados["t01_pcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->qBCProd   = $_dados["t01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vAliqProd = $_dados["t01_valiqprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vCOFINS   = $_dados["t01_vcofins"];
            }

            /**
             * SQM-1831
             * IBS | CBS | IS
             */
            $_ub02_cstis = trim($_dados["ub02_cstis"]);
            if(!empty($_ub02_cstis)){
                $this->infNFe->det[$_nitem]->imposto->add_IS(new IS);
                $_dados["ub02_cstis"] = trim($_dados["ub02_cstis"]);
                $this->infNFe->det[$_nitem]->imposto->IS->CSTIS          = str_pad($_dados["ub02_cstis"],3, '0',STR_PAD_LEFT);
                $this->infNFe->det[$_nitem]->imposto->IS->cClassTribIS   = str_pad($_dados["ub03_cclasstribis"],6, '0',STR_PAD_LEFT);
                $this->infNFe->det[$_nitem]->imposto->IS->vBCIS          = $_dados["ub05_vbcis"];
                $this->infNFe->det[$_nitem]->imposto->IS->pIS            = $_dados["ub06_pis"];
                if(!empty($_dados["ub07_pisespec"]) && $_dados["ub07_pisespec"]>0){
                    $this->infNFe->det[$_nitem]->imposto->IS->pISEspec       = $_dados["ub07_pisespec"];
                    $this->infNFe->det[$_nitem]->imposto->IS->uTrib          = $_dados["i01_utrib"];
                    $this->infNFe->det[$_nitem]->imposto->IS->qTrib          = number_format((float)$_dados["i01_qtrib"],4);
                }
                $this->infNFe->det[$_nitem]->imposto->IS->vIS            = $_dados["ub11_vis"];
            }

            $_ub13_cst = trim($_dados["ub13_cst"]);
            if(!empty($_ub13_cst)){
                $this->infNFe->det[$_nitem]->imposto->add_IBSCBS(new IBSCBS);
                $_dados["ub13_cst"] = trim($_dados["ub13_cst"]);
                $this->infNFe->det[$_nitem]->imposto->IBSCBS->CST  = str_pad($_dados["ub13_cst"],3, '0',STR_PAD_LEFT);
                $this->infNFe->det[$_nitem]->imposto->IBSCBS->cClassTrib  = str_pad($_dados["ub14_cclasstrib"],6, '0',STR_PAD_LEFT);
                if(!in_array($this->infNFe->det[$_nitem]->imposto->IBSCBS->CST, ['410','620'])){
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vBC                   = $_dados["ub16_vbc"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pIBSUF                = $_dados["ub18_pibsuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pDifUF                = $_dados["ub22_pdifuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vDifUF                = $_dados["ub23_vdifuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pRedAliqUF            = $_dados["ub27_predaliquf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetUF           = $_dados["ub28_paliqefetuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vIBSUF                = $_dados["ub35_vibsuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pIBSMun               = $_dados["ub37_pibsmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pDifMun               = $_dados["ub41_pdifmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vDifMun               = $_dados["ub42_vdifmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pRedAliqMun           = $_dados["ub46_predaliqmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetMun          = $_dados["ub47_paliqefetmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vIBSMun               = $_dados["ub54_vibsmun"];
                    $_item_vIBS = $_dados["ub35_vibsuf"] + $_dados["ub54_vibsmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vIBS                  = funcoesGerais::ConverterParaNumero($_item_vIBS, 2);
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pCBS                  = $_dados["ub56_pcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pDifCBS               = $_dados["ub60_pdifcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vDifCBS               = $_dados["ub61_vdifcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pRedAliqCBS           = $_dados["ub65_predaliqcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetCBS          = $_dados["ub66_paliqefetcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vCBS                  = $_dados["ub67_vcbs"];
                }

                if($this->infNFe->det[$_nitem]->imposto->IBSCBS->CST == '550'){
                    $_dados["ub69_cstreg"] = trim($_dados["ub69_cstreg"]);
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->CSTReg = str_pad($_dados["ub69_cstreg"],3, '0',STR_PAD_LEFT);
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->cClassTribReg = str_pad($_dados["ub70_cclasstribreg"],6, '0',STR_PAD_LEFT);
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetRegIBSUF     = $_dados["ub71_paliqefetregibsuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vTribRegIBSUF         = $_dados["ub72_vtribregibsuf"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetRegIBSMun    = $_dados["ub72a_paliqefetregibsmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vTribRegIBSMun        = $_dados["ub72b_vtribregibsmun"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->pAliqEfetRegCBS       = $_dados["ub72c_paliqefetregcbs"];
                    $this->infNFe->det[$_nitem]->imposto->IBSCBS->vTribRegCBS           = $_dados["ub72d_vtribregcbs"];
                }
            }

            if(($GLOBALS['_REGRA_ESPECIAL_ICMS'] & 131072)>0 || ($GLOBALS['_REGRA_ESPECIAL_ICMS'] & 262144)>0) {
                if (!isset($this->infNFe->det[$_nitem]->vItem)) {
                    $this->infNFe->det[$_nitem]->add_vItem(new vItem);
                }
                $this->infNFe->det[$_nitem]->vItem = funcoesGerais::ConverterParaNumero($_dados['w02_vnf'], 2);

                if (!isset($this->infNFe->total->vNFTot)) {
                    $this->infNFe->total->add_vNFTot(new vNFTot());
                    $this->infNFe->total->vNFTot = 0.00;
                }

                $this->infNFe->total->vNFTot += (float)$this->infNFe->det[$_nitem]->vItem;
                $this->infNFe->total->vNFTot = funcoesGerais::ConverterParaNumero($this->infNFe->total->vNFTot, 2);
            }

            //Mesmo que coloque aliquota zero dever� mostrar o ISSQNTOT.
            //ISSQN
            //Atributo do produto
            if (intval($_dados["i01_tipoimposto"])===1) {
                $_imprimiu_issqn = true;
                $this->infNFe->det[$_nitem]->imposto->add_ISSQN(new ISSQN);
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vBC       = $_dados["u01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vAliq     = $_dados["u01_valiq"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vISSQN    = $_dados["u01_vissqn"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cMunFG    = $_dados["u01_cmunfg"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cListServ = $_dados["u01_clistserv"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cSitTrib  = $_dados["u01_csittrib"];
                //*Vers�o 3.10*//
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vDeducao  	 = $_dados["u01_vdeducao"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vOutro  	 = $_dados["u01_voutro"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vDescIncond = $_dados["u01_vdescincond"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vISSRet   	 = $_dados["u01_vissret"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->indISS		= $_dados["u01_indiss"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cServico	= $_dados["u01_cservico"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cMun		= $_dados["u01_cmun"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cPais		= $_dados["u01_cpais"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->nProcesso	= $_dados["u01_nprocesso"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->indIncentivo= $_dados["u01_indincentivo"];
            }



            //ICMSUFDest - nova tag para icms de partilha (ALTNFENFE-1)
            if ($_dados["na01_vicmsufdest"] > 0 && $this->infNFe->ide->mod == 55 && $_dados["b01_iddest"] == "2"
                && ($this->infNFe->ide->indFinal !== 0 && ((int)$this->infNFe->dest->indIEDest !== 1 || (int)$this->infNFe->dest->indIEDest !== 2))) {
                //Atributo do produto
                $this->infNFe->det[$_nitem]->imposto->add_ICMSUFDest(new ICMSUFDest);
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vBCUFDest = $_dados["na01_vbcufdest"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->pFCPUFDest = $_dados["na01_pfcpufdest"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->pICMSUFDest = $_dados["na01_picmsufdest"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->pICMSInter = $_dados["na01_picmsinter"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->pICMSInterPart = $_dados["na01_picmsinterpart"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vFCPUFDest = $_dados["na01_vfcpufdest"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vICMSUFDest = $_dados["na01_vicmsufdest"];
                $this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vICMSUFRemet = $_dados["na01_vicmsufremet"];
                // BL-7219 -> 09-10-20 -> Eduardo Esteves
                if($this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vFCPUFDest > 0 && ($GLOBALS['_VERSAO_NT'] & 256) > 0) {
                    $this->infNFe->det[$_nitem]->add_infAdProd(new infAdProd);
                    $this->infNFe->det[$_nitem]->infAdProd->infAdProd .= "FECP B.C. R$ {$this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vBCUFDest} {$this->infNFe->det[$_nitem]->imposto->ICMSUFDest->pFCPUFDest}% Valor R$ {$this->infNFe->det[$_nitem]->imposto->ICMSUFDest->vFCPUFDest}";
                }

            }



            //Se tem combust�vel
            if (isset($_dados["l101_cprodanp"]) && !empty($_dados["l101_cprodanp"])) {
                $this->infNFe->det[$_nitem]->prod->add_comb(new comb);
                $this->infNFe->det[$_nitem]->prod->comb->cProdANP = $_dados["l101_cprodanp"];
                $this->infNFe->det[$_nitem]->prod->comb->descANP = funcoesGerais::limparCampoNotaEletronica($_dados["l101_descanp"]);
                $this->infNFe->det[$_nitem]->prod->comb->pGLP = $_dados['la03a_pglp'];
                $this->infNFe->det[$_nitem]->prod->comb->pGNn = $_dados['la03b_pgnn'];
                $this->infNFe->det[$_nitem]->prod->comb->pGNi = $_dados['la03c_pgni'];
                $this->infNFe->det[$_nitem]->prod->comb->qTemp = $_dados["l101_qtemp"];
                $this->infNFe->det[$_nitem]->prod->comb->UFCons = $_dados["l101_ufcons"];

                //CFOPs utilizados para combust�vel/GLP
                $_CFOPSCombustivel = [5650,5656,5667,6650,6656,6667];
                //Poss�veis CFOPs para devolu��o de combust�vel/GLP
                $_CFOPSCombustivel = array_merge($_CFOPSCombustivel,[1202, 2202, 1949, 2949, 1661, 2661, 1662,2662]);

                if(!empty($_dados['nbico']) && in_array($this->infNFe->det[$_nitem]->prod->CFOP, $_CFOPSCombustivel)) {
                    $this->infNFe->det[$_nitem]->prod->comb->add_encerrante(new encerrante_nota());
                    $this->infNFe->det[$_nitem]->prod->comb->encerrante->nBico = $_dados["nbico"];
                    $this->infNFe->det[$_nitem]->prod->comb->encerrante->nTanque = $_dados["ntanque"];
                    $this->infNFe->det[$_nitem]->prod->comb->encerrante->nBomba = $_dados['nbomba'];
                    $this->infNFe->det[$_nitem]->prod->comb->encerrante->vEncIni = $_dados['vencini'];
                    $this->infNFe->det[$_nitem]->prod->comb->encerrante->vEncFin = $_dados["vencfin"];
                }

                //J�ssica disse que n�o podemos montar essa tag com zero.
                if($_dados["la17_pbio"] > 0 && in_array($this->infNFe->det[$_nitem]->prod->CFOP, $_CFOPSCombustivel)) {
                    $this->infNFe->det[$_nitem]->prod->comb->pBio = $_dados["la17_pbio"];
                }

                if((!empty($_dados['la19_indimport']) || !empty($_dados['la20_cuforig']) || (float)$_dados['la21_porig']>0) && in_array($this->infNFe->det[$_nitem]->prod->CFOP, $_CFOPSCombustivel)){
                    $this->infNFe->det[$_nitem]->prod->comb->add_origComb(new origComb());
                    $this->infNFe->det[$_nitem]->prod->comb->origComb->indImport = $_dados["la19_indimport"];
                    $this->infNFe->det[$_nitem]->prod->comb->origComb->cUFOrig = $_dados["la20_cuforig"];
                    $this->infNFe->det[$_nitem]->prod->comb->origComb->pOrig = $_dados['la21_porig'];
                }
            }

            //S� insere o medicamento se for 55 e 65, mas n�o insere qdo estiver offline pq n�o tem a info no pdv.
            //Sendo devolu��o n�o informaremos que � um medicamento, pois exige rastreio
            //Logo se voc� estiver fazendo uma devolu��o, sub entendemos que o documento original tem as
            //informa��es da Anvisa e o rastreio.
            //E quando for TROCA sem cupom tamb�m n�o temos essa informa��o

            /**
             * Dado que a Nota T�cnica 2021.004 introduziu a obrigatoriedade de emiss�o de NF-e modelo 55,
             * com a obrigatoriedade da tag med nos medicamentos classificados nos NCMs que come�am com:
             * 3001, 3002, 3003, 3004, 3005 e 3006
             */
            $_dados["k01_cprodanvisa"] = trim($_dados["k01_cprodanvisa"]);
            if (!empty($_dados["k01_cprodanvisa"]) && ((int)$this->modelo === 55 || ((int)$this->infNFe->ide->finNFe !== 4 && NFeZanthus::$_devolucao_sem_cupom === false && (int)$this->modelo === 65))) {
                if ((strlen(str_replace(' ','',trim($_dados["k01_cprodanvisa"]))) === 13 ) || $_dados["k01_cprodanvisa"] == 'ISENTO' ) {
                    $this->infNFe->det[$_nitem]->prod->add_med(new med);
                    //A RMS envia um monte de espa�os vazios.
                    $this->infNFe->det[$_nitem]->prod->med->cProdANVISA = str_replace(' ','',trim($_dados["k01_cprodanvisa"]));
                    $this->infNFe->det[$_nitem]->prod->med->xMotivoIsencao = trim($_dados["k01b_xmotivoisencao"]);
                    $this->infNFe->det[$_nitem]->prod->med->vPMC = $_dados["k01_vpmc"];
                }
            }
            $this->infNFe->det[$_nitem]->imposto->vTotTrib = (float) $_dados["m01_vtottrib"];

            /*
            //PIS
            if (!empty($_dados["q01_cst"])) {//Esse deve aparecer sempre
                $this->infNFe->det[$_nitem]->imposto->PIS->CST = $_dados["q01_cst"];
                $this->infNFe->det[$_nitem]->imposto->PIS->vBC = $_dados["q01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->PIS->pPIS = $_dados["q01_ppis"];
                $this->infNFe->det[$_nitem]->imposto->PIS->vPIS = $_dados["q01_vpis"];
                $this->infNFe->det[$_nitem]->imposto->PIS->qBCProd = $_dados["q01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->PIS->qBCProd = $_dados["q01_valiqprod"];
            }

            //COFINS
            if (!empty($_dados["s01_cst"])) {//Esse dever� aparecer sempre
                $this->infNFe->det[$_nitem]->imposto->COFINS->CST = $_dados["s01_cst"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vBC = $_dados["s01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->pCOFINS = $_dados["s01_pcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vCOFINS = $_dados["s01_vcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->qBCProd = $_dados["s01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINS->vAliqProd = $_dados["s01_valiqprod"];
            }

            //COFINSST
            if(floatval($_dados["t01_vbc"])>0) {
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vBC = $_dados["t01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->pCOFINS = $_dados["t01_pcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vCOFINS = $_dados["t01_vcofins"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->qBCProd = $_dados["t01_qbcprod"];
                $this->infNFe->det[$_nitem]->imposto->COFINSST->vAliqProd = $_dados["t01_valiqprod"];
            }

            if (intval($_dados["i01_tipoimposto"])===1) {
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vprodiss = $_dados["u01_vprodiss"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vBC = $_dados["u01_vbc"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vAliq = $_dados["u01_valiq"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vISSQN = $_dados["u01_vissqn"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cMunFG = $_dados["u01_cmunfg"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cListServ = $_dados["u01_clistserv"];
                //$this->infNFe->det[$_nitem]->imposto->issqn->csittrib = $_dados["u01_csittrib"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vDeducao = $_dados["u01_vdeducao"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vOutro = $_dados["u01_voutro"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vDescIncond = $_dados["u01_vdescincond"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->vISSRet = $_dados["u01_vissret"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->indISS = $_dados["u01_indiss"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cServico = $_dados["u01_cservico"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cMun = $_dados["u01_cmun"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->cPais = $_dados["u01_cpais"];
                $this->infNFe->det[$_nitem]->imposto->ISSQN->indIncentivo = $_dados["u01_indincentivo"];
            }
            */

            if ($this->_versao_nfe >= 4) {
                if (isset($_dados["i80_nlote"]) && !empty($_dados["i80_nlote"])) {
                    $this->infNFe->det[$_nitem]->prod->add_rastro(new rastro);
                    $this->infNFe->det[$_nitem]->prod->rastro->nLote = $_dados["i80_nlote"];
                    $this->infNFe->det[$_nitem]->prod->rastro->qLote = $_dados["i80_qlote"];
                    $this->infNFe->det[$_nitem]->prod->rastro->dFab = funcoesGerais::converte_data($_dados["i80_dfab"], $_tipo_bd, 'y-m-d', false, true, false, $_uf_nf, true);//substr($_dados["i80_dfab"], 0, 10);
                    $this->infNFe->det[$_nitem]->prod->rastro->dVal = funcoesGerais::converte_data($_dados["i80_dval"], $_tipo_bd, 'y-m-d', false, true, false, $_uf_nf, true); //substr($_dados["i80_dval"], 0, 10);
                    $this->infNFe->det[$_nitem]->prod->rastro->cAgreg = $_dados["i80_cagreg"];

                }
            }

        }



        /*$this->infNFe->total->icmstot->vprod = $_dados["w02_vprod"];
               $this->infNFe->total->icmstot->vnf = $_dados["w02_vnf"];
               $this->infNFe->total->icmstot->vtottrib = $_dados["w02_vtottrib"];
               $this->infNFe->total->icmstot->vdesc = $_dados["w02_vdesc"];
               $this->infNFe->total->icmstot->vfrete = $_dados["w02_vfrete"];
               $this->infNFe->total->icmstot->vseg = $_dados["w02_vseg"];
               $this->infNFe->total->icmstot->vfcpufdest = $_dados["w02_vfcpufdest"];
               $this->infNFe->total->icmstot->vicmsufdest = $_dados["w02_vicmsufdest"];
               $this->infNFe->total->icmstot->vicmsufremet = $_dados["w02_vicmsufremet"];
               $this->infNFe->total->icmstot->vicmsdeson = $_dados["w02_vicmsdeson"];*/

        if (isset($_dados["n01_vbc"]) && funcoesGerais::CSTTributado($_n01_cst)) {
            $this->infNFe->total->ICMSTot->vBC += (float)$_dados["n01_vbc"];
        }
        if (isset($_dados["n01_vicms"]) && funcoesGerais::CSTTributado($_n01_cst)) {
            $this->infNFe->total->ICMSTot->vICMS += (float)$_dados["n01_vicms"];
        }


        /**
         * Autor: Tairo Miguel
         * BL-3302
         * OBS: Tag de desonera��o de icms
         */
        if (isset($_dados["w02_vicmsdeson"])) {
            $this->infNFe->total->ICMSTot->vICMSDeson += (float)$_dados["w02_vicmsdeson"];
        }




        //Na opera��o estadual n�o montamos o valores
        if ((int) $this->infNFe->ide->idDest == 1 || ((int)$this->infNFe->ide->indFinal == 0 &&
            ((int)$this->infNFe->dest->indIEDest == 1 || (int)$this->infNFe->dest->indIEDest == 2))) {
            $this->infNFe->total->ICMSTot->vFCPUFDest   = 0;
            $this->infNFe->total->ICMSTot->vICMSUFDest  = 0;
            $this->infNFe->total->ICMSTot->vICMSUFRemet = 0;
        } else {
            if (isset($_dados["w02_vfcpufdest"]))	$this->infNFe->total->ICMSTot->vFCPUFDest    = $_dados["w02_vfcpufdest"];
            if (isset($_dados["w02_vicmsufdest"]))	$this->infNFe->total->ICMSTot->vICMSUFDest   = $_dados["w02_vicmsufdest"];
            if (isset($_dados["w02_vicmsufremet"]))	$this->infNFe->total->ICMSTot->vICMSUFRemet  = $_dados["w02_vicmsufremet"];
        }

        if(empty($this->infNFe->total->ICMSTot->vFCPSTRet)) {
            if (isset($_dados["n01_vbcst"])) $this->infNFe->total->ICMSTot->vBCST += (float)$_dados["n01_vbcst"];
        }

        //NT2023001-1 - ICMS Monof�sico (Combust�vel)
        if(isset($_dados["w06e_vicmsmonoret"]) || isset($_dados["w06c_vicmsmono"]) || isset($_dados["w06d_vicmsmonoreten"])){
            $this->infNFe->total->ICMSTot->vICMSMono = (float)$_dados["w06c_vicmsmono"];
            $this->infNFe->total->ICMSTot->vICMSMonoReten = (float)$_dados["w06d_vicmsmonoreten"];
            $this->infNFe->total->ICMSTot->vICMSMonoRet = (float)$_dados["w06e_vicmsmonoret"];

            //Esses n�o temos no banco ent�o a soma est� sendo feita pelo itens
            $this->infNFe->total->ICMSTot->qBCMono;
            $this->infNFe->total->ICMSTot->qBCMonoReten;
            $this->infNFe->total->ICMSTot->qBCMonoRet;
        }


        if (isset($_dados["n01_vst"]))			$this->infNFe->total->ICMSTot->vST     		   += (float)$_dados["n01_vst"];
        $this->infNFe->total->ICMSTot->vProd    += ($_imprimiu_issqn !== true) ? (float) $this->infNFe->det[$_nitem]->prod->vProd : 0;
        if (isset($_dados["i01_vfrete"]))		$this->infNFe->total->ICMSTot->vFrete     	   += (float)$_dados["i01_vfrete"];
        if (isset($_dados["i01_vseg"]))			$this->infNFe->total->ICMSTot->vSeg   		   += (float)$_dados["i01_vseg"];
        if (isset($_dados["i01_vdesc"]))		$this->infNFe->total->ICMSTot->vDesc    	   += (float)$_dados["i01_vdesc"];
        //$this->infNFe->total->ICMSTot->vII     = $res_ICMSTot['vii'];
        $this->infNFe->total->ICMSTot->vOutro   += (float)$_dados["i01_voutro"];
        $this->infNFe->total->ICMSTot->vPIS     += ($_imprimiu_issqn !== true) ? (float) $this->infNFe->det[$_nitem]->imposto->PIS->vPIS : 0;
        $this->infNFe->total->ICMSTot->vCOFINS  += ($_imprimiu_issqn !== true) ?(float) $this->infNFe->det[$_nitem]->imposto->COFINS->vCOFINS : 0;
        if($this->getMontarIPI()) {
            $this->infNFe->total->ICMSTot->vIPI += ($_imprimiu_issqn !== true) ? (float) $this->infNFe->det[$_nitem]->imposto->IPI->vIPI : 0;
        }

        if (isset($_dados["w02_vnf"]))      $this->infNFe->total->ICMSTot->vNF  += (float)$_dados["w02_vnf"] + $_dados["i01_vfrete"];
        //NT2023001 - Se houver ICMS Mono reten��o precisamos somar no total da nota
        if(!empty($this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoReten)) $this->infNFe->total->ICMSTot->vNF += $this->infNFe->det[$_nitem]->imposto->ICMS->vICMSMonoReten;

        /*if ((int)$this->infNFe->ide->idDest != 2) {
            $this->infNFe->total->ICMSTot->vFCP = $_total_vfcp;
        }*/
        //Valor aproximado total de tributos federais, estaduais e municipais
        if (isset($_dados["m01_vtottrib"]))		$this->infNFe->total->ICMSTot->vTotTrib  += (float) $_dados["m01_vtottrib"];
        //if (isset($_dados["w02_vtottrib"]))		$this->infNFe->total->ICMSTot->vTotTrib   = $_dados["w02_vtottrib"];

        //ISSQNtot
        if($_imprimiu_issqn===true) {
            if (!isset($this->infNFe->total->ISSQNtot)) {
                $this->infNFe->total->add_ISSQNtot(new ISSQNtot());
            }
            if (isset($_dados["u01_vprodiss"])) 	$this->infNFe->total->ISSQNtot->vServ           += (float)$_dados["u01_vprodiss"] * $_dados['i01_qcom'];
            if (isset($_dados["u01_vbc"])) 	    	$this->infNFe->total->ISSQNtot->vBC      	    += (float)$_dados["u01_vbc"];
            if (isset($_dados["u01_vissqn"]))  		$this->infNFe->total->ISSQNtot->vISS 	   	    += (float)$_dados["u01_vissqn"];
            if (isset($_dados["w01_vpis"]))			$this->infNFe->total->ISSQNtot->vPIS     		 = $_dados["w01_vpis"];
            if (isset($_dados["w01_vcofins"]))		$this->infNFe->total->ISSQNtot->vCOFINS    	     = $_dados["w01_vcofins"];
            if($this->getMontarIPI()) {
                if (isset($_dados["w01_vipi"]))		$this->infNFe->total->ISSQNtot->vIPI     		 = $_dados["w01_vipi"];
            }

            //*Vers�o 3.10*//
            if (isset($_dados["w01_dcompet"]))		$this->infNFe->total->ISSQNtot->dCompet  	   	 = $_dados["w01_dcompet"];
            if (isset($_dados["u01_vdeducao"]))  	$this->infNFe->total->ISSQNtot->vDeducao 	   	+= (float)$_dados["u01_vdeducao"];
            if (isset($_dados["u01_voutro"]))  		$this->infNFe->total->ISSQNtot->vOutro  	   	+= (float)$_dados["u01_voutro"];
            if (isset($_dados["u01_vdescincond"]))  $this->infNFe->total->ISSQNtot->vDescIncond  	+= (float)$_dados["u01_vdescincond"];
            if (isset($_dados["u01_vissret"]))  	$this->infNFe->total->ISSQNtot->vISSRet  	  	+= (float)$_dados["u01_vissret"];
            if (isset($_dados["w01_cregtrib"]))		$this->infNFe->total->ISSQNtot->cRegTrib  	   	 = $_dados["w01_cregtrib"];
        }

        /**
         * SQM-1831
         * IBS | CBS | IS
         */
        if(isset($this->infNFe->det[$_nitem]->imposto->IS)){
            if (!isset($this->infNFe->total->ISTot)) {
                $this->infNFe->total->add_ISTot(new ISTot());
            }
            $this->infNFe->total->ISTot->vIS = $_dados["w33_vis"];
        }

        if(isset($this->infNFe->det[$_nitem]->imposto->IBSCBS)){
            if (!isset($this->infNFe->total->IBSCBSTot)) {
                $this->infNFe->total->add_IBSCBSTot(new IBSCBSTot());
            }

            $this->infNFe->total->IBSCBSTot->vBCIBSCBS = !empty($_dados["w35_vbcibscbs"]) ? $_dados["w35_vbcibscbs"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vDifUF = !empty($_dados["w38_vdifuf"]) ? $_dados["w38_vdifuf"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vDevTribUF = '0.00';
            $this->infNFe->total->IBSCBSTot->vIBSUF = !empty($_dados["w41_vibsuf"]) ? $_dados["w41_vibsuf"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vDifMun = !empty($_dados["w43_vdifmun"]) ? $_dados["w43_vdifmun"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vDevTribMun = '0.00';
            $this->infNFe->total->IBSCBSTot->vIBSMun = !empty($_dados["w46_vibsmun"]) ? $_dados["w46_vibsmun"] : '0.00';
            $_vIBS = $_dados["w41_vibsuf"] + $_dados["w46_vibsmun"];
            $this->infNFe->total->IBSCBSTot->vIBS = !empty($_vIBS) ? funcoesGerais::ConverterParaNumero($_vIBS,2) : '0.00';
            $this->infNFe->total->IBSCBSTot->vCredPresIBS = '0.00';
            $this->infNFe->total->IBSCBSTot->vCredPresCondSusIBS = '0.00';
            $this->infNFe->total->IBSCBSTot->vDifCBS = !empty($_dados["w53_vdifcbs"]) ? $_dados["w53_vdifcbs"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vDevTribCBS = '0.00';
            $this->infNFe->total->IBSCBSTot->vCBS = !empty($_dados["w56_vcbs"]) ? $_dados["w56_vcbs"] : '0.00';
            $this->infNFe->total->IBSCBSTot->vCredPresCBS = '0.00';
            $this->infNFe->total->IBSCBSTot->vCredPresCondSusCBS = '0.00';
        }

        /*        $this->observacao_fiscal = $_dados["cod_observacao_fiscal"];
                $this->obs_fiscal = $_dados["cod_obs_fiscal"];
                $this->icms = $_dados["obs_icms"];
                $this->icms_merc = $_dados["obs_icms_merc"];
                $this->empresa = $_dados["flg_empresa"];
                $this->numerico_nfe = $_dados["cod_numerico_nfe"];
                $this->nfe_subiu_offline = $_dados["id_nfe_subiu_offline"];
                $this->tiponota = $_dados["tiponota"];
                $this->numnota = $_dados["numnota"];
                $this->nf = $_dados["serie_nf"];
                $this->modelo_nf = $_dados["tipo_modelo_nf"];
                $this->numcupom = $_dados["numcupom"];
                $this->numpdv = $_dados["numpdv"];
                $this->datacupom = $_dados["datacupom"];
                $this->ind_pres = $_dados["flg_ind_pres"];
                $this->indiedest = $_dados["forcar_indiedest"];
                $this->TIPONOTA = $_dados["TIPONOTA"];*/
    }

    /**
     * ESTE FETCH N�O SER� USADO MAIS, MANTEREMOS ELE AQUI PARA ANALISE, CASO NECESS�RIO
     * @param $_arr_nfe
     * @return bool
     * @throws Exception
     * todo:: revisar (php 8.1)
     */
    function fetch($_con,$_arr_nfe) {
        return true;
    }

    /**
     * Gera arquivo pdf para impressao de NF-e
     * @param	string   $_xml
     * @param   string   $_formato P=portrait L=landscape
     * @param   string   $_path_logomarca caminho imagem.
     * @param   boolean  $_gerar_pdf_retorno Se gera como arquivo ou retorna o pr�prio PDF.
     * @param   boolean  $_issqn Se deve ou n�o gerar o ISSQN.
     * @param 	int	     $_tipo_modelo Se � NFe 55 ou NFCe 65, pois isso muda a totalmente a forma de imprimir.
     * @param   int		 $_qtd_colunas Quantidade de colunas para envio do texto da NFCe.
     * @param   boolean  $_completo Na NFCe indicar� se o
     * @return  PDF/String
     * @access  public
     * @author  Djalma Fadel Junior (Original)
     *
     * Zanthus (�ber Lincoln)
     *
     * Sobrescrevi este m�todo pois est�o faltando alguns dados importantes.
     * Como o n�mero do protocolo.
     *
     **/
    public function imprimeNF($_xml, $_formato="P",$_path_logomarca="",$_gerar_pdf_retorno=false,
                              $_issqn=false,$_tipo_modelo=55,$_qtd_colunas = 0,
                              $_completo = false, $_id_token = '000001',$_id_nfe="",
                              $_info_impressao=null, $_somar_desc_nfce = null, $_desc_marca_dagua_danfe_nfe = null,
                              $_grava_cod_lido_cfe = null, $_grava_cod_lido_nfce = null, $_tipo_papel = 'JT', $_dados_offline = null) {
        if (empty($this->UF) && (is_numeric($this->cUF))) {
            $_arr     = array_keys(funcoesGerais::$_cod_uf_sefaz,$this->cUF);
            $this->UF = $_arr[0];
        }


        if ((int) $_tipo_modelo != 59) {
            $this->carregarUrlSEFAZ($this->UF);
        }
        if(file_exists($this->_logo)) {
            $_logo = $this->_logo;
        }

        //Se for NFCe 65 ou SAT 59 mostramos apenas o QRCode.
        if ((int) $_tipo_modelo === 65 || (int) $_tipo_modelo === 59) {
            if ($_qtd_colunas > 0) {
                include_once('nfephp/tags/pre-review/libs/DanfeTextoNFCeNFePHP.class.php');
                if((int) $_tipo_modelo === 59) {
                    $_danfe = new DanfeTextoSATCFePHP($_xml,"", 0 );
                }else{
                    $_danfe = new DanfeTextoNFCeNFePHP($_xml,"", 0 );
                }
                $_danfe->setURLChave($this->aURLwsdl);
                //Preciso de algumas informa��es do objetoi pai.
                $_danfe->setObjNFeZanthus($this);
                $_danfe->_qtd_caracteres = $_qtd_colunas;
                $_danfe->idToken = $_id_token;
                $_danfe->_imprimir_cod_lido = $this->imprimirCodLido($this->getCodLoja(), $_tipo_modelo, $_info_impressao);
                $_danfe->monta("P", array(80,'one-page'),"C",$_completo,$_info_impressao,$_somar_desc_nfce, $_dados_offline);
                $_arr = funcoesGerais::destrincharIDNFE($_id_nfe);
                if((int) $_tipo_modelo != 59 && $this->getViaUnicaNfe() != 1) {
                    if (funcoesGerais::managerOFFLine() || ((int)$_arr["TIPO_EMISSAO"] === 9)) {
                        $_danfe->_via_estabelecimento = true;
                        $_danfe->monta("P", array(80,'one-page'),"C",$_completo,$_info_impressao,$_somar_desc_nfce);
                    }
                }
                return $_danfe->printDANFE('',funcoesGerais::retornarCaminhoAbsolutoManager() . "danfe.pdf",'I',$_completo);
            } else {
                include_once('nfephp/tags/pre-review/libs/DanfeNFCeNFePHP.class.php');
                if((int) $_tipo_modelo === 59) {
                    $_danfe = new DanfeSATPHP($_xml,$_logo,0);
                }else{
                    $_danfe = new DanfeNFCeNFePHP($_xml,$_logo,0,$_id_token);
                }
                $_danfe->_imprimir_cod_lido = $this->imprimirCodLido($this->getCodLoja(), $_tipo_modelo, $_info_impressao);
                $_danfe->setURLChave($this->aURLwsdl);
                $_danfe->setObjNFeZanthus($this);
                $_danfe->idToken  = $_id_token;
                //Se quiser imprimr html basta colocar essa vari�vel como false e tirar o pdf do printDANFE.
                $_danfe->_eh_pdf = true;
                $_danfe->monta("P", array(80,'one-page'),"C",$_completo,$_info_impressao ,$_somar_desc_nfce);
                if($_gerar_pdf_retorno===false) {
                    return $_danfe->printDANFE('pdf',funcoesGerais::retornarCaminhoAbsolutoManager() . "danfe.pdf",'I', $_tipo_papel);
                } else {
                    return $_danfe->printDANFE('pdf',funcoesGerais::retornarCaminhoAbsolutoManager() . "danfe.pdf",'S', $_tipo_papel);
                }
            }
        } else { //Se for NFe 55 mostramos o DANFE.
            if (!defined('FPDF_FONTPATH') && !funcoesGerais::managerOFFLine()) {
                define('FPDF_FONTPATH',funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/font/');
            }

            include_once('nfephp/tags/pre-review/libs/danfe.class.paisagem.php');
            $_danfe = new danfe_paisagem($_xml, $_formato, $this->nProt, $_logo, $_issqn,$_info_impressao);
            $_danfe->_imprimir_cod_lido = $this->imprimirCodLido($this->getCodLoja(), $_tipo_modelo, $_info_impressao);
            //se true, imprime campos do canhoto
            $_danfe->canhoto = true;
            // path para logomarca
            //protocolo de autorizacao deve sair em infCpl
            $_danfe->protocolo = $this->nProt;
            $_danfe->cUF	   = $this->cUF;
            $_danfe->_desc_marca_dagua_danfe_nfe = $_desc_marca_dagua_danfe_nfe;
            //data e hora de autorizacao devem sair em infCpl
            $_logotipo = $this->getLogotipo();
            if (!empty($_logotipo)) {
                $_danfe->logomarca = $_logotipo;
            } else if (!empty($_path_logomarca)) {
                $_danfe->logomarca = $_path_logomarca;
            }
            return $_danfe->gera($_gerar_pdf_retorno);
        }

    }

    /**
     * @param $xml
     * @return $1|false|SimpleXMLElement
     */
    private function novoStringToObjectXML($xml)
    {
        // Remove tags com fechamento em branco, ex <valor />
        $xml = preg_replace('%<[^>]*\/>%', '', $xml);
        // Romove alguns caracteres que d�o problema
        $xml = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $xml);

        $xml = str_replace('&lt;', '<', $xml);
        $xml = str_replace('&gt;', '>', $xml);
        $xml = str_replace('&quot;', '"', $xml);

        $xml = preg_replace('/xmlns[^=]*="[^"]*"/i', '', $xml);
        $xml = preg_replace('/[a-zA-Z]+:([a-zA-Z]+[=>])/', '$1', $xml);

        $xml = str_replace("<![CDATA[","",$xml);
        $xml = str_replace("]]>","",$xml);

        $xml = str_ireplace('<?xml version="1.0" encoding="UTF-8"?>','',$xml);
        $xml = str_ireplace('<?xml version="1.0" encoding=\'UTF-8\'?>','',$xml);
        $xml = str_ireplace('<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?>','',$xml);
        $xml = trim($xml);

        $xml = funcoesGerais::removerLatinCharacters(utf8_decode(funcoesGerais::removerAcentuacao($xml)));

//        if(false !== strpos($xml,'outputXML'))
//        {
//            $xml  = end(explode("<outputXML>",$xml));
//            $xml = reset(explode("</outputXML>",$xml));
//        }

        if (isset($xml) and is_string($xml))
        {
            $objXml = simplexml_load_string($xml);

            if ($objXml === false)
                $objXml = simplexml_load_string(utf8_decode($xml));

            if ($objXml === false)
                $objXml = simplexml_load_string($xml);

            if ($objXml === false)
                $objXml = simplexml_load_string($xml);

            return $objXml;

        } else {
            return false;
        }
    }

    /**
     * Transforma o xml recebido pelo pdv em objeto para a montagem do xml de retorno da Danfe Simplificada
     * @param $_xml
     * @return object
     */
    public function objetoDanfeSimplificada ($_xml, $_dados_offline = null){
        $_obj = (Object) $this->novoStringToObjectXML($_xml)->infNFe;
        $_dadosDanfe = (Object) [
            'protocolo' =>(Object) [
                'chave' => (String)$_obj->nfeProc->protNFe->infProt->chNFe,
                'chave1' => str_split((String)$_obj->nfeProc->protNFe->infProt->chNFe,22)[0],
                'chave2' => str_split((String)$_obj->nfeProc->protNFe->infProt->chNFe,22)[1],
                'numero' => (String)$_obj->nfeProc->protNFe->infProt->nProt,
                'data' => date("d/m/Y H:i:s", strtotime((String)$_obj->nfeProc->protNFe->infProt->dhRecbto)),
            ],
            'ide'=>(Object) [
                'tipo' => (String)$_obj->ide->tpNF == "1" ? "1 - Sa�da" : "0 - Entrada",
                'numero' => (String)$_obj->ide->nNF,
                'serie' => (String)$_obj->ide->serie,
                'data' => date("d/m/Y H:i:s", strtotime((String)$_obj->ide->dhEmi)),
            ],
            'emitente' => (Object) [
                'nome' => (String)$_obj->emit->xNome,
                'tipocpfcnpj' => (String)$_obj->emit->CNPJ ? 'CNPJ' : 'CPF',
                'cpfcnpj' => funcoesGerais::formatarDado('CNPJCPF',(String)$_obj->emit->CNPJ ? (String)$_obj->emit->CNPJ : (String)$_obj->emit->CPF),
                'endereco' => (String)$_obj->emit->enderEmit->xLgr,
                'numero' => (String)$_obj->emit->enderEmit->nro,
                'bairro' => (String)$_obj->emit->enderEmit->xBairro,
                'cidade' => (String)$_obj->emit->enderEmit->xMun,
                'uf' => (String)$_obj->emit->enderEmit->UF,
                'cep' => funcoesGerais::formatarDado('CEP',(String)$_obj->emit->enderEmit->CEP),
            ],
            'destinatario' => (Object) [
                'nome' => funcoesGerais::str_alinha((String)$_obj->dest->xNome,56,ESQUERDA,true,' '),
                'tipocpfcnpj' => (String)$_obj->dest->CNPJ ? 'CNPJ' : 'CPF',
                'cpfcnpj' => funcoesGerais::formatarDado('CNPJCPF',(String)$_obj->dest->CNPJ ? (String)$_obj->dest->CNPJ : (String)$_obj->dest->CPF),
                'endereco' => (String)$_obj->dest->enderDest->xLgr,
                'numero' => (String)$_obj->dest->enderDest->nro,
                'bairro' => (String)$_obj->dest->enderDest->xBairro,
                'cidade' => (String)$_obj->dest->enderDest->xMun,
                'uf' => (String)$_obj->dest->enderDest->UF,
                'cep' => funcoesGerais::formatarDado('CEP',(String)$_obj->dest->enderDest->CEP),
            ],
            'adicional' =>(Object) [
                'complementar' => (String)$_obj->infAdic->infCpl,
                'federal' => explode(' ESTADUAL ',explode('- FEDERAL ',(String)$_obj->infAdic->infCpl)[1])[0],
                'estadual' => explode(' MUNICIPAL ',explode(' ESTADUAL ',(String)$_obj->infAdic->infCpl)[1])[0],
                'municipal' => 'R$ '.explode(' ',explode(' MUNICIPAL ',(String)$_obj->infAdic->infCpl)[1])[1],
            ],
            'items' => (Array)[],
            'total'=>(Object) [
                'quantidade' => 0,
                'totalItens' =>funcoesGerais::str_alinha("R$ ". number_format((float)$_obj->total->ICMSTot->vProd,2,",",""),17,DIREITA,true,' '),
                'descontos' =>funcoesGerais::str_alinha("R$ ". number_format((float)$_obj->total->ICMSTot->vDesc,2,",",""),19,DIREITA,true,' '),
                'total' =>funcoesGerais::str_alinha("R$ ". number_format((float)$_obj->total->ICMSTot->vNF,2,",",""),23,DIREITA,true,' '),
            ],
            'textoProdutos' => '',
            'homologacao' => ''
        ];

        foreach ($_obj->det as $item){
            $_item = (Object) [
                'codProduto' => (String)$item->prod->cProd,
                'nomeProduto' => (String)$item->prod->xProd,
                'cfop' => (String)$item->prod->CFOP,
                'cst' => array_keys((array)$item->imposto->ICMS)[0] ? str_replace("ICMS","",array_keys((array)$item->imposto->ICMS)[0]) : "0",
                'quantidade' => (String)$item->prod->qCom,
                'unidade' => (String)$item->prod->uCom,
                'valorUnitario' => (String)$item->prod->vUnCom,
                'valorTotal' => (String)$item->prod->vProd,
            ];
            array_push($_dadosDanfe->items, $_item);
        }

        foreach ($_dadosDanfe->items as $key => $item){
            $_dadosDanfe->total->quantidade++;
            $textoFormatado = (Object)[
                'ordem' => funcoesGerais::str_alinha($key+1,4,DIREITA,true,0),
                'codProduto' => funcoesGerais::str_alinha($item->codProduto,18,DIREITA,true,' '),
                'nomeProduto' => funcoesGerais::str_alinha($item->nomeProduto,34,DIREITA,true,' '),
                'cfop' => funcoesGerais::str_alinha($item->cfop,9,DIREITA,true,' '),
                'cst' => funcoesGerais::str_alinha(funcoesGerais::str_alinha($item->cst,3,DIREITA,false,'0'),6,DIREITA,true,' '),
                'quantidade' => funcoesGerais::str_alinha(number_format($item->quantidade,3,",",""),11,DIREITA,true,' '),
                'unidade' => funcoesGerais::str_alinha($item->unidade,4,DIREITA,true,' '),
                'valorUnitario' => funcoesGerais::str_alinha(number_format($item->valorUnitario,2,",",""),13,DIREITA,true,' '),
                'valorTotal' =>funcoesGerais::str_alinha(number_format($item->valorTotal,2,",",""),13,DIREITA,true,' '),
            ];
            $_dadosDanfe->textoProdutos.=
                "\n{$textoFormatado->ordem}{$textoFormatado->codProduto}{$textoFormatado->nomeProduto}".
                "\n{$textoFormatado->cfop}{$textoFormatado->cst}{$textoFormatado->quantidade}{$textoFormatado->unidade}{$textoFormatado->valorUnitario}{$textoFormatado->valorTotal}";
        }

        if (!funcoesGerais::managerOFFLine()){
            $_empresa = new Empresa($GLOBALS['_MASTER']);
            $_dados_loja = $_empresa->retornarInformacoesEmpresa($this->_cod_loja, array("FLG_TIPO_AMBIENTE_NFE"));
            $_ambiente = $_dados_loja['FLG_TIPO_AMBIENTE_NFE'];
        }else{
            $_empresa = simplexml_load_string($_dados_offline);
            if($_empresa===false) {
                $_xml_aux = utf8_encode($_dados_offline);
                $_empresa = simplexml_load_string($_xml_aux);
            }
        }

        $_ambiente = $_empresa->flg_tipo_ambiente_nfe;
        $_dadosDanfe->homologacao = $_ambiente == "2" ? "NF-e sem valor fiscal - HOMOLOGA��O": "";
        $_dadosDanfe->total->quantidade = funcoesGerais::str_alinha($_dadosDanfe->total->quantidade,11,DIREITA,true,' ');

        return $_dadosDanfe;
    }

    /**
     * Retorna xml formatado para a impress�o na impressora Sweda
     * @param $_dadosDanfe
     * @param $_pathlogo
     * @return string
     */
    public function xmlSweda($_dadosDanfe, $_pathlogo, $bytes_bloco){
        $_xml1 = "<cespl>38</cespl><c><ce>--------------------------------------------------------".
            "\n--------------------------------------------------------".
            "\n<da>DANFE Simplificado</da>".
            "\n--------------------------------------------------------".
            "\n<da>CHAVE DE ACESSO</da></ce></c>";

        $_xml2 = "<cespl>38</cespl><c><ce>{$_dadosDanfe->protocolo->chave}".
            "\n<b>{$_dadosDanfe->homologacao}</b>".
            "\n--------------------------------------------------------".
            "\n<da>PROTOCOLO DE AUTORIZA��O</da>".
            "\n{$_dadosDanfe->protocolo->numero} {$_dadosDanfe->protocolo->data}".
            "\n--------------------------------------------------------".
            "\n<ibmp>{$_pathlogo}/5/1.bmp</ibmp>".
            "\n {$_dadosDanfe->emitente->nome}".
            "\n{$_dadosDanfe->emitente->tipocpfcnpj}: {$_dadosDanfe->emitente->cpfcnpj}".
            "\n{$_dadosDanfe->emitente->endereco}, {$_dadosDanfe->emitente->numero}".
            "\n{$_dadosDanfe->emitente->bairro} - {$_dadosDanfe->emitente->cidade} - {$_dadosDanfe->emitente->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\n<da>EMISS�O NORMAL</da>".
            "\n<b>Tipo de opera��o:</b> {$_dadosDanfe->ide->tipo}".
            "\n<b>N�mero:</b> {$_dadosDanfe->ide->numero} - <b>S�rie:</b> {$_dadosDanfe->ide->serie}".
            "\n<b>Emiss�o:</b> {$_dadosDanfe->ide->data}".
            "\n--------------------------------------------------------".
            "\n<da>DESTINAT�RIO</da>".
            "\n<b>{$_dadosDanfe->homologacao}</b>".
            "\n".
            "\n{$_dadosDanfe->destinatario->nome}".
            "\n{$_dadosDanfe->destinatario->tipocpfcnpj}: {$_dadosDanfe->destinatario->cpfcnpj}".
            "\n{$_dadosDanfe->destinatario->endereco}, {$_dadosDanfe->destinatario->numero}".
            "\n{$_dadosDanfe->destinatario->bairro} - {$_dadosDanfe->destinatario->cidade} - {$_dadosDanfe->destinatario->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\nItem            C�digo              Descri��o do produto".
            "\n     CFOP   CST        QTD  UN  V.Unit.(R$)  V.Item (R$)".
            "\n--------------------------------------------------------".
            "{$_dadosDanfe->textoProdutos}".
            "\n--------------------------------------------------------".
            "\n<e>Qtde Total itens{$_dadosDanfe->total->quantidade}</e>".
            "\n".
            "\n<e>Total itens{$_dadosDanfe->total->totalItens}</e>".
            "\n<e>Descontos{$_dadosDanfe->total->descontos}</e>".
            "\n<e>Total{$_dadosDanfe->total->total}</e>".
            "\n--------------------------------------------------------".
            "\nTRIBUTOS TOTAIS INCIDENTES (LEI FEDERAL 12.741/2012)".
            "\nFEDERAL {$_dadosDanfe->adicional->federal} ESTADUAL {$_dadosDanfe->adicional->estadual} MUNICIPAL {$_dadosDanfe->adicional->municipal}".
            "\n--------------------------------------------------------".
            "\n--------------------------------------------------------</ce></c>".
            "\n<gui></gui>";
        $_xmlBarras =
            "<blocoBarras><code128>{$_dadosDanfe->protocolo->chave}</code128></blocoBarras>";

        $_retorno = $this->divideXMLemBlocos($_xml1, $bytes_bloco).$_xmlBarras.$this->divideXMLemBlocos($_xml2, $bytes_bloco);
        return $_retorno;
    }

    /**
     * Retorna xml formatado para a impress�o na impressora Epson
     * @param $_dadosDanfe
     * @param $_pathlogo
     * @return string
     */
    public function xmlEpson($_dadosDanfe, $_pathlogo, $bytes_bloco){
        $_xml1 = "<cespl>38</cespl><c><ce>--------------------------------------------------------".
            "\n--------------------------------------------------------".
            "\n<da>DANFE Simplificado</da>".
            "\n--------------------------------------------------------".
            "\n<da>CHAVE DE ACESSO</da></ce></c>";

        $_xml2 = "<c><ce>{$_dadosDanfe->protocolo->chave}".
            "\n<b>{$_dadosDanfe->homologacao}</b>".
            "\n--------------------------------------------------------".
            "\n<da>PROTOCOLO DE AUTORIZA��O</da>".
            "\n{$_dadosDanfe->protocolo->numero} {$_dadosDanfe->protocolo->data}".
            "\n--------------------------------------------------------".
            "\n<ibmp>{$_pathlogo}/5/1.bmp</ibmp>".
            "\n {$_dadosDanfe->emitente->nome}".
            "\n{$_dadosDanfe->emitente->tipocpfcnpj}: {$_dadosDanfe->emitente->cpfcnpj}".
            "\n{$_dadosDanfe->emitente->endereco}, {$_dadosDanfe->emitente->numero}".
            "\n{$_dadosDanfe->emitente->bairro} - {$_dadosDanfe->emitente->cidade} - {$_dadosDanfe->emitente->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\n<da>EMISS�O NORMAL</da>".
            "\n<b>Tipo de opera��o:</b> {$_dadosDanfe->ide->tipo}".
            "\n<b>N�mero:</b> {$_dadosDanfe->ide->numero} - <b>S�rie:</b> {$_dadosDanfe->ide->serie}".
            "\n<b>Emiss�o:</b> {$_dadosDanfe->ide->data}".
            "\n--------------------------------------------------------".
            "\n<da>DESTINAT�RIO</da>".
            "\n<b>{$_dadosDanfe->homologacao}</b>".
            "\n".
            "\n{$_dadosDanfe->destinatario->nome}".
            "\n{$_dadosDanfe->destinatario->tipocpfcnpj}: {$_dadosDanfe->destinatario->cpfcnpj}".
            "\n{$_dadosDanfe->destinatario->endereco}, {$_dadosDanfe->destinatario->numero}".
            "\n{$_dadosDanfe->destinatario->bairro} - {$_dadosDanfe->destinatario->cidade} - {$_dadosDanfe->destinatario->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\nItem            C�digo              Descri��o do produto".
            "\n     CFOP   CST        QTD  UN  V.Unit.(R$)  V.Item (R$)".
            "\n--------------------------------------------------------".
            "{$_dadosDanfe->textoProdutos}".
            "\n--------------------------------------------------------".
            "\n<e>Qtde Total itens{$_dadosDanfe->total->quantidade}</e>".
            "\n".
            "\n<e>Total itens{$_dadosDanfe->total->totalItens}</e>".
            "\n<e>Descontos{$_dadosDanfe->total->descontos}</e>".
            "\n<e>Total{$_dadosDanfe->total->total}</e>".
            "\n--------------------------------------------------------".
            "\nTRIBUTOS TOTAIS INCIDENTES (LEI FEDERAL 12.741/2012)".
            "\nFEDERAL {$_dadosDanfe->adicional->federal} ESTADUAL {$_dadosDanfe->adicional->estadual} MUNICIPAL {$_dadosDanfe->adicional->municipal}".
            "\n--------------------------------------------------------".
            "\n--------------------------------------------------------</ce></c>".
            "\n<gui></gui>";
        $_xmlBarras =
            "<blocoBarras><code128>{$_dadosDanfe->protocolo->chave}</code128></blocoBarras>";

        $_retorno = $this->divideXMLemBlocos($_xml1, $bytes_bloco).$_xmlBarras.$this->divideXMLemBlocos($_xml2, $bytes_bloco);

        return funcoesGerais::removerLatinCharacters($_retorno);
    }

    /**
     * Retorna xml sem tags de formata��o
     * @param $_dadosDanfe
     * @param $_pathlogo
     * @return string
     */
    public function xmlDefault($_dadosDanfe, $_pathlogo, $bytes_bloco){
        $_xml1 = "--------------------------------------------------------".
            "\n--------------------------------------------------------".
            "\nDANFE Simplificado".
            "\n--------------------------------------------------------".
            "\nCHAVE DE ACESSO";
        $_xml2 = "{$_dadosDanfe->protocolo->chave}".
            "\n{$_dadosDanfe->homologacao}".
            "\n--------------------------------------------------------".
            "\nPROTOCOLO DE AUTORIZA��O".
            "\n{$_dadosDanfe->protocolo->numero} {$_dadosDanfe->protocolo->data}".
            "\n--------------------------------------------------------".
            "\n<ibmp>{$_pathlogo}/5/1.bmp</ibmp>".
            "\n {$_dadosDanfe->emitente->nome}".
            "\n{$_dadosDanfe->emitente->tipocpfcnpj}: {$_dadosDanfe->emitente->cpfcnpj}".
            "\n{$_dadosDanfe->emitente->endereco}, {$_dadosDanfe->emitente->numero}".
            "\n{$_dadosDanfe->emitente->bairro} - {$_dadosDanfe->emitente->cidade} - {$_dadosDanfe->emitente->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\nEMISS�O NORMAL".
            "\nTipo de opera��o: {$_dadosDanfe->ide->tipo}".
            "\nN�mero: {$_dadosDanfe->ide->numero} - S�rie: {$_dadosDanfe->ide->serie}".
            "\nEmiss�o: {$_dadosDanfe->ide->data}".
            "\n--------------------------------------------------------".
            "\nDESTINAT�RIO".
            "\n{$_dadosDanfe->homologacao}".
            "\n".
            "\n{$_dadosDanfe->destinatario->nome}".
            "\n{$_dadosDanfe->destinatario->tipocpfcnpj}: {$_dadosDanfe->destinatario->cpfcnpj}".
            "\n{$_dadosDanfe->destinatario->endereco}, {$_dadosDanfe->destinatario->numero}".
            "\n{$_dadosDanfe->destinatario->bairro} - {$_dadosDanfe->destinatario->cidade} - {$_dadosDanfe->destinatario->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n--------------------------------------------------------".
            "\nItem            C�digo              Descri��o do produto".
            "\n     CFOP   CST        QTD  UN  V.Unit.(R$)  V.Item (R$)".
            "\n--------------------------------------------------------".
            "{$_dadosDanfe->textoProdutos}".
            "\n--------------------------------------------------------".
            "\nQtde Total itens{$_dadosDanfe->total->quantidade}".
            "\n".
            "\nTotal itens{$_dadosDanfe->total->totalItens}".
            "\nDescontos{$_dadosDanfe->total->descontos}".
            "\nTotal{$_dadosDanfe->total->total}".
            "\n--------------------------------------------------------".
            "\nTRIBUTOS TOTAIS INCIDENTES (LEI FEDERAL 12.741/2012)".
            "\nFEDERAL {$_dadosDanfe->adicional->federal} ESTADUAL {$_dadosDanfe->adicional->estadual} MUNICIPAL {$_dadosDanfe->adicional->municipal}".
            "\n--------------------------------------------------------".
            "\n--------------------------------------------------------".
            "\n<gui></gui>";

        $_xmlBarras =
            "<blocoBarras><code128>{$_dadosDanfe->protocolo->chave}</code128></blocoBarras>";

        $_retorno = $this->divideXMLemBlocos($_xml1, $bytes_bloco).$_xmlBarras.$this->divideXMLemBlocos($_xml2, $bytes_bloco);

        return funcoesGerais::removerLatinCharacters($_retorno);
    }

    /**
     * Retorna xml sem tags de formata��o
     * @param $_dadosDanfe
     * @param $bytes_bloco
     * @return string
     */
    public function textoFormatado($_dadosDanfe, $bytes_bloco){
        $_xml1 = str_repeat("-",$bytes_bloco-2).
            "\n" . str_repeat("-",$bytes_bloco-2) ."\n".
            funcoesGerais::str_alinha("DANFE Simplificado",$bytes_bloco,CENTRO).
            "\n". str_repeat("-",$bytes_bloco-2) ."\n".
            funcoesGerais::str_alinha("CHAVE DE ACESSO",$bytes_bloco,CENTRO);
        $_xml2 = "{$_dadosDanfe->protocolo->chave}".
            "\n{$_dadosDanfe->homologacao}".
            "\n" . str_repeat("-",$bytes_bloco-2) . "\n".
            funcoesGerais::str_alinha("PROTOCOLO DE AUTORIZA��O",$bytes_bloco,CENTRO).
            "\n" . funcoesGerais::str_alinha("{$_dadosDanfe->protocolo->numero} {$_dadosDanfe->protocolo->data}",$bytes_bloco,CENTRO).
            "\n" . str_repeat("-",$bytes_bloco-2) .
            "\n{$_dadosDanfe->emitente->nome}".
            "\n{$_dadosDanfe->emitente->tipocpfcnpj}: {$_dadosDanfe->emitente->cpfcnpj}".
            "\n{$_dadosDanfe->emitente->endereco}, {$_dadosDanfe->emitente->numero}".
            "\n{$_dadosDanfe->emitente->bairro} - {$_dadosDanfe->emitente->cidade} - {$_dadosDanfe->emitente->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n". str_repeat("-",$bytes_bloco-2) .
            "\n" . funcoesGerais::str_alinha("EMISS�O NORMAL",$bytes_bloco,CENTRO).
            "\n" . funcoesGerais::str_alinha("Tipo de opera��o: {$_dadosDanfe->ide->tipo}",$bytes_bloco,CENTRO).
            "\n" . funcoesGerais::str_alinha("N�mero: {$_dadosDanfe->ide->numero} - S�rie: {$_dadosDanfe->ide->serie}",$bytes_bloco,CENTRO).
            "\n" . funcoesGerais::str_alinha("Emiss�o: {$_dadosDanfe->ide->data}",$bytes_bloco,CENTRO).
            "\n". str_repeat("-",$bytes_bloco-2) .
            "\n" . funcoesGerais::str_alinha("DESTINAT�RIO",$bytes_bloco,CENTRO).
            "\n{$_dadosDanfe->homologacao}".
            "\n".
            "\n{$_dadosDanfe->destinatario->nome}".
            "\n{$_dadosDanfe->destinatario->tipocpfcnpj}: {$_dadosDanfe->destinatario->cpfcnpj}".
            "\n{$_dadosDanfe->destinatario->endereco}, {$_dadosDanfe->destinatario->numero}".
            "\n{$_dadosDanfe->destinatario->bairro} - {$_dadosDanfe->destinatario->cidade} - {$_dadosDanfe->destinatario->uf} - CEP: {$_dadosDanfe->emitente->cep}".
            "\n".str_repeat("-",$bytes_bloco-2) .
            "\nItem            C�digo              Descri��o do produto".
            "\n     CFOP   CST        QTD  UN  V.Unit.(R$)  V.Item (R$)".
            "\n--------------------------------------------------------".
            "{$_dadosDanfe->textoProdutos}".
            "\n--------------------------------------------------------".
            "\nQtde Total itens{$_dadosDanfe->total->quantidade}".
            "\n".
            "\nTotal itens{$_dadosDanfe->total->totalItens}".
            "\nDescontos{$_dadosDanfe->total->descontos}".
            "\nTotal{$_dadosDanfe->total->total}".
            "\n".str_repeat("-",$bytes_bloco-2).
            "\nTRIBUTOS TOTAIS INCIDENTES (LEI FEDERAL 12.741/2012)".
            "\nFEDERAL {$_dadosDanfe->adicional->federal} ESTADUAL {$_dadosDanfe->adicional->estadual} MUNICIPAL {$_dadosDanfe->adicional->municipal}".
            "\n".str_repeat("-",$bytes_bloco-2).
            "\n".str_repeat("-",$bytes_bloco-2);

        $_xmlBarras =
            "<BARCODE BLOCO=\"44\"><![CDATA[{$_dadosDanfe->protocolo->chave}]]></BARCODE>";


        $_retorno = "<XML><TEXTO_ANTES><![CDATA[".$this->divideEmLinhas($_xml1, $bytes_bloco)."]]></TEXTO_ANTES>".
            $_xmlBarras. "<TEXTO_DEPOIS><![CDATA[".$this->divideEmLinhas($_xml2, $bytes_bloco)."]]></TEXTO_DEPOIS></XML>";

        return funcoesGerais::removerLatinCharacters($_retorno);
    }

    /**
     * Dividindo o texto em linhas
    */
    public function divideEmLinhas($_xml, $_tamanho){
        $_arrayXML = explode ("\n", $_xml);
        $_contador = 0;
        $_xmlRetorno= "";

        foreach ($_arrayXML as $chave => $_linha){
            $_contador += strlen($_linha)+2; //numero de caracteres da linha com o \n
            if ($_contador>=($_tamanho-2)){
                $_xmlRetorno .="\n";
                $_xmlRetorno .=$_linha;
                $_contador = strlen($_linha)+2;
            }else if ($chave === 0){
                $_xmlRetorno .= $_linha;
            }else{
                $_xmlRetorno .= "\n".$_linha;
            }
        }
        $_xmlRetorno .= "\n";
        return $_xmlRetorno;
    }

    /**
     * Retorna o xml formatado e dividido em blocos conforme indicado pelo PDV
     * @param $_xml
     * @param string $_formato
     * @param string $_dirImg
     * @param string $bytes_bloco
     * @return string
     */
    public function xmlDanfeSimplificada($_xml, $_formato="3", $_dirImg='', $bytes_bloco='4000', $_dados_offline = null) {
        $_dadosDanfe = $this->objetoDanfeSimplificada($_xml, $_dados_offline);
        switch ($_formato){
            case 1:
                $_xmlFormatado = $this->xmlSweda($_dadosDanfe, $_dirImg, $bytes_bloco);
                break;
            case 2:
                $_xmlFormatado = $this->xmlEpson($_dadosDanfe, $_dirImg, $bytes_bloco);
                break;
            case 99:
                $_xmlFormatado = $this->textoFormatado($_dadosDanfe, $bytes_bloco);
                break;
            default:
                $_xmlFormatado = $this->xmlDefault($_dadosDanfe, $_dirImg, $bytes_bloco);
                break;
        }

        //$_retorno = $this->divideXMLemBlocos($_xmlFormatado, $bytes_bloco);
        return $_xmlFormatado;
    }

    /**
     * Divide o xml em blocos de acordo com o tamanho indicado pelo PDV
     * @param $_xml
     * @param $_tamanho
     * @return string
     */
    public function divideXMLemBlocos($_xml, $_tamanho){
        $_arrayXML = explode ("\n", $_xml);
        $_contador = 0;
        $_xmlRetorno= "<bloco><![CDATA[";

        foreach ($_arrayXML as $chave => $_linha){
            $_contador += strlen($_linha)+2; //numero de caracteres da linha com o \n
            if ($_contador>=($_tamanho-2)){
                $_xmlRetorno .="\n]]></bloco><bloco><![CDATA[";
                $_xmlRetorno .="\n".$_linha;
                $_contador = strlen($_linha)+2;
            }else if ($chave === 0){
                $_xmlRetorno .= $_linha;
            }else{
                $_xmlRetorno .= "\n".$_linha;
            }
        }
        $_xmlRetorno .= "\n]]></bloco>";
        return $_xmlRetorno;
    }

    /**
     * Sobreposi��a do m�todo carregaCert.
     */
    public function carregaCert($_force=false) {
        //Se n�o carregou as vari�veis for�o o carregamento antes de qualquer coisa.
        if($this->_variaveisCarregadas===false) {
            return $this->carregarVariaveis();
        } else {
            //O pr�prio m�todo carregar chamar� novamente aqui com a vari�vel igual a true.
            return parent::carregaCert();
        }

    }


    /**
     * M�todo Respons�vel por carregar as vari�veis de caminho do
     * config_inc.php
     */
    public function carregarVariaveis() {

        if ((int) $this->_versao_nfe === 0) {
            $this->_versao_nfe = funcoesGerais::retornarVersaoNFe(0,$this->cUF,$this->modelo);
        }
        if($this->_variaveisCarregadas===true) {
            //Testo o certificado, se carregar blz. Como o certificado pode ficar mudando n�o pode ficar com o mesmo.
            if( $this->carregaCert()!==true) {
                funcoesGerais::GravaLog("N�o foi poss�vel carregar o certificado 1. {$this->errorMsg}",true,true);
                return false;
            }
            return true;
        }
        $this->_variaveisCarregadas = true;

        //O XSD precisa ser carregado antes.
        $this->pathXSD       =   $GLOBALS['_doc_root'] . "nfephp/tags/pre-review/xsd/";
        if($this->_versao_nfe == 2) {
            $this->_fileXSD      =   $this->pathXSD.'nfe_v2.00.xsd';
        } else {
            $this->_fileXSD      =   $this->pathXSD."nfe_v".  number_format($this->_versao_nfe,2) .".xsd";
        }


        //Se for o manager OFFLine o nome dos arquivos ser�o fixos n�o precisaremos de nada disso.
        if (funcoesGerais::managerOFFLine()) {
            //Vamos alertar caso o Ambiente n�o venha
            if ((int) $this->ambiente <= 0 ) {
                $this->errorMsg  = "Ambiente da NFe incorreto (1- Produ��o/2- Homologa��o). Processo abortado.";
                funcoesGerais::GravaLog($this->errorMsg,true,true);
                return false;//throw new Exception($_msg);
            } else {
                $this->carregaCert();
                return true;
            }
        }
        $_path 		  				= funcoesGerais::retornarCaminhoAbsolutoManager();
        $_achou_o_novo 			    = false;

        //Se encontrou o nome do certificado digital
        if((String) $this->get_nome_certificado() !== "") {

            //Vamos definir uma regra aqui...

            //Pega o caminhod do Novo CERTIFICADO que no SaaS � diferente.
            $this->pathCerts     = certificado_digital::retornarCaminhoCertificado();
            //Nome do arquivo certificado
            $_novo_caminho_cert =  $this->pathCerts . $this->get_nome_certificado();

            //Se existe o caminho vamos em frente.
            if (file_exists($_novo_caminho_cert)) {
                $_achou_o_novo = true;
            }
            //Se o Ambiente n�o foi configurado deve
            if ($_achou_o_novo && (int) $this->ambiente <= 0 ) {
                $this->errorMsg  = "Ambiente da NFe incorreto (1- Produ��o/2- Homologa��o). Processo abortado.";
                funcoesGerais::GravaLog($this->errorMsg,true,true);
                return false;//throw new Exception($_msg);
            }
        }

        //Se n�o achou o novo trabalha com o antigo.
        if (!$_achou_o_novo) {
            ///Isso n�o deve mais ser considerado a partir da pr�xima vers�o.
            if(file_exists("{$_path}nfephp/tags/pre-review/config_inc.php")) {

                //para cada elemento da matriz assinar e gravar dados na base
                //Carrego o Config aqui.

                include($GLOBALS['_doc_root'] . 'nfephp/tags/pre-review/config_inc.php');

                $this->ambiente = $ambiente;
                $this->pathCerts = $certDir;
            } else { // A �ltima op��o ser� pegar os arquivos .pem da base de dados
                // N�o podemos forcar a gera��o quando for pela tela de certificado digital.
                if (!$this->_forcar_releitura ) {
                    if ($this->forcarGeracaoCertificadosTemporario() === false) {
                        $this->errorMsg = "N�o foi possivel importar o certificado digital da base da dados";
                        funcoesGerais::GravaLog($this->errorMsg,true,true);
                        //throw new Exception($_msg);
                        return false;
                    }
                }
            }
        }

        /**
         * Se vier o nome nesta vari�vel significa que foi estipulado no banco.
         * N�o checo o caminho pois sen�o existir dever� dar erro.
         * Sempre troco o nome do certificado caso mude n�o imorta o que ocorra.
         */
        if((String) $this->get_nome_certificado()==="") {
            $this->nameCert      =  $certName;
        } else {
            $this->nameCert      =  $this->get_nome_certificado();
        }
        if((String) $this->get_senha_certificado()==="") {
            $this->passKey       =   $keyPass;
            $this->passPhrase    =   $passPhrase;
        } else {
            $this->passKey       =   $this->get_senha_certificado();
            $this->passPhrase    =   $this->get_senha_certificado();
        }


        $_logotipo 		= $this->getLogotipo();
        $this->_logo  	=  ($_logotipo != '' && file_exists($nfeRoot.'/'.$_logotipo)) ? $nfeRoot.'/'.$_logotipo : $logodanfe;


        //Testo o certificado, se carregar blz. Como o certificado pode ficar mudando n�o pode ficar com o mesmo.
        if( $this->carregaCert()!==true) {
            funcoesGerais::GravaLog("N�o foi poss�vel carregar o certificado 2. {$this->errorMsg}",true,true);
            return false;
        }

        return true;
    }

    /**
     * Arrumando problema de conex�o introduzido pelo certificado.
     *
     * @return basebd|mixed|null
     */
    private function getConnection() {
        if (!isset($this->_qry)) {
            $this->_qry = $GLOBALS["_MASTER"];
        }
        return $this->_qry;
    }

    /**
     * For�a da gera��o dos arquivo do certificado digital buscando no banco de dados e gerando o conte�do na pasta cert_temp_pem
     * @return bool
     */
    private function forcarGeracaoCertificadosTemporario() {
        $_con = $this->getConnection()->cloneconnection(__METHOD__);
        $_certificado_digital = new certificado_digital($_con);

        // pego o nome correto e formatado
        $_cert_gerado_pem = certificado_digital::retonarNomeCertificadoFormatadoPEM($this->get_nome_certificado(), certificado_digital::cert_gerado_pem);
        $_private_pem = certificado_digital::retonarNomeCertificadoFormatadoPEM($this->get_nome_certificado(), certificado_digital::private_pem);
        $_public_pem = certificado_digital::retonarNomeCertificadoFormatadoPEM($this->get_nome_certificado(), certificado_digital::public_pem);
        $_public_limpo_pem = certificado_digital::retonarNomeCertificadoFormatadoPEM($this->get_nome_certificado(), certificado_digital::public_limpo_pem);

        // pego o path completo
        $_cert_gerado_pem = certificado_digital::retornarCaminhoCertificadoTemp() . $_cert_gerado_pem;
        $_private_pem = certificado_digital::retornarCaminhoCertificadoTemp() . $_private_pem;
        $_public_pem = certificado_digital::retornarCaminhoCertificadoTemp() . $_public_pem;
        $_public_limpo_pem = certificado_digital::retornarCaminhoCertificadoTemp() . $_public_limpo_pem;

        /*
            N�o for�aremos a gera��o se os arquivos existirem no servidor e se n�o tiver nenhuma atualiza��o no certificado.
            Retornamos true abaixo, pois indica que os arquivos j� est�o no servidor e est�o com as ultimas atualiza��es.
         */
        if ((file_exists($_cert_gerado_pem) && file_exists($_private_pem) && file_exists($_public_pem) && file_exists($_public_limpo_pem)) &&
            $_certificado_digital->forcarImportacaoDaBase($this->get_nome_certificado()) === false) {
            $_con->close();
            return true;
        }

        if ($this->setarDiretorioPem()) {

            if ($_certificado_digital->buscarInformacoesPemCertificadoDigital($this->get_nome_certificado()) !== false) {  // pego no nome de todos os arquivos j� formatados
                $_cert_gerado_pem_content = $_certificado_digital->getCert_gerado();
                $_private_pem_content = $_certificado_digital->getPrivate_key();
                $_public_pem_content = $_certificado_digital->getPublic_key();
                $_public_limpo_pem_content = $_certificado_digital->getPublic_key_limpo();

                if (!empty($_cert_gerado_pem_content) && !empty($_private_pem_content) && !empty($_public_pem_content) && !empty($_public_limpo_pem_content)) {
                    $_file_cert = file_put_contents($_cert_gerado_pem, $_cert_gerado_pem_content);
                    $_file_private = file_put_contents($_private_pem, $_private_pem_content);
                    $_file_public = file_put_contents($_public_pem, $_public_pem_content);
                    $_file_public_limpo = file_put_contents($_public_limpo_pem, $_public_limpo_pem_content);
                    if ($_file_cert !== false && $_file_private !== false && $_file_public !== false && $_file_public_limpo !== false) {
                        /*if ($GLOBALS['_debug']) {
                            funcoesGerais::GravaLog("forcarGeracaoCertificadosTemporario: arquivos de certificados importados do banco de dados com sucesso.",true,true);
                        }*/
                        $_certificado_digital->atualizarDataUltimaImportacao();
                        $_con->close();
                        return true;
                    }
                    // em caso de falha apago todos
                    unlink($_cert_gerado_pem);
                    unlink($_private_pem);
                    unlink($_public_pem);
                    unlink($_public_limpo_pem);
                }
            }
        }
        if ($GLOBALS['_debug']) {
            funcoesGerais::GravaLog("forcarGeracaoCertificadosTemporario: ocorreu algum problema no momento de gerar os escrever os arquivos do certificado no path ". certificado_digital::retornarCaminhoCertificadoTemp(),true,true);
        }
        $_con->close();
        return false;
    }

    /*
     * Insira o XML de uma NFe e grava na tabela de Controle NFe.,
     * A transa��o dever� ser controlada por fora, pois se n�o gravar aqui n�o grava a tab_nota_header tamb�m.
     * @oaram $_xml_nota
     * @param $_cod_loja
     * @param $_tipo_nfe
     * @param $_motivo_contingencia
     * @param $_tipo_modelo_nf Se 55 ou 65.
     * @param $_arr_nfe Dados para gerar o QRCode
     */
    public function gravarNFeNormal($_xml_nota,$_cod_loja,$_tipo_nfe='1',$_motivo_contingencia="",$_tipo_modelo_nf = 55, $_arr_nfe= null, $_assinado = false) {
        //Assinamos a Nota Fiscal eletr�nica.
        if(!$_assinado) {
            //Testo o certificado, se carregar.
            if( $this->carregaCert()!==true) {
                funcoesGerais::GravaLog("N�o foi poss�vel carregar o certificado 3 . {$this->errorMsg}",true,true);
                return false;
            }

            $_xml_nota = $this->assina($_xml_nota, 'infNFe');
            //Validamos o SCHEMA da NFe
            if(($_ret = $this->validaXML($_xml_nota, $this->_fileXSD))===false) {
                funcoesGerais::GravaLog("[1-gravarNFeNormal-{$_tipo_emissao}] Schema inv�lido . {$this->errorMsg}",true,true);
                //BL-6561 Se for modelo 55 vamos for�ar mostrar erro para o usu�rio
                if ((int) $_tipo_modelo_nf === 55) {
                    return false;
                }
                //Se for o tipo 9, vamos deixar vender e depois arrumamos a rejei��o
                /*if ((int) $_tipo_emissao!=9) {
                    return false;
                }*/

            }
        }


        $_controle_nfe = new controle_nfe($this->getConnection());
        $_achou  = false;
        if ($_controle_nfe->encontrarNota($_cod_loja,$this->Id)) {
            $_achou = true;
            return true;
        }


        $_controle_nfe->setid_nfe($this->Id);
        $_controle_nfe->setCodSituacaoEnvioNfe("PE");
        //A principio aqui � normal depois tudo pode mudar.
        $_controle_nfe->setcod_tipo_emissao_nfe($_tipo_nfe);
        $_controle_nfe->settipo_modelo_nf($_tipo_modelo_nf);
        //Aqui a nota � normal
        $_controle_nfe->setcod_finalidade_nfe("NN");
        $_controle_nfe->setdes_just($_motivo_contingencia);
        //Situa��o 1= Assinada
        $_controle_nfe->setcod_situacao_nfe(1);
        //$_controle_nfe->num_protocolo_nfe			= '';
        $_controle_nfe->setid_versao_layout_nfe($this->infNFe->versao);
        $_controle_nfe->setdsc_xml_nfe($_xml_nota);
        //Software do contribuinte.
        $_controle_nfe->setid_processo_emissor(0);
        $_controle_nfe->setcod_empresa($_cod_loja);
        $_controle_nfe->setcod_unidade($_cod_loja);
        if (!$_achou) {
            return $_controle_nfe->Incluir(true);
        } else {
            //Se j� achou n�o faz nada..
            return true;
        }
    }

    private function obterInfoURLSEFAZ($_ambiente, $_siglaUF) {
        //Aqui decidimos qual arquivo devemos carregar.
        if($this->_versao_nfe == 2) {//N�o coloque 3 iguais pois vem como double.
            $_infoSEFAZ 	= $this->carregaSEFAZ("nfephp/urlWebServicesNFe2.xml",$_ambiente,$_siglaUF);
        } else {
            //Se for o modelo NFCe abriremos outro arquivo.
            if ((int) $this->modelo === 65) {
                //ALTNFE-15
                if ($this->_versao_nfe < 4) {
                    $_infoSEFAZ 	= $this->carregaSEFAZ("nfephp/urlWebServicesNFCe310.xml",$_ambiente,$_siglaUF);
                } else {
                    $_infoSEFAZ = $this->carregaSEFAZ("nfephp/urlWebServicesNFCe400.xml", $_ambiente, $_siglaUF);
                }
            } else {
                if ($this->_versao_nfe < 4) {
                    $_infoSEFAZ 	= $this->carregaSEFAZ("nfephp/urlWebServicesNFe310.xml",$_ambiente,$_siglaUF);
                }else{
                    $_infoSEFAZ 	= $this->carregaSEFAZ("nfephp/urlWebServicesNFe400.xml",$_ambiente,$_siglaUF);
                }
            }
        }

        //Este veremos depois pois tenho que ter os arquivos.
        //$this->aFxsd
        $this->aURLwsdl 	 = null;
        //$this->aVerxsd  	 = null;//N�o posso mexer pq tem o cabe�alho do xsd aqui tb.
        //$this->aFunctionWdsl = null;

        //Se por algum motivo vier vazio vamos setar.
        if (empty($this->_comp_vers) && $this->_versao_nfe > 3.1) {
            $this->setVersaoNFe($this->_versao_nfe);
        }


        $this->aFxsd= array(
            "ConsultaCadastro{$this->_comp_vers}"=>'consCad_v2.00.xsd',
            "CadConsultaCadastro{$this->_comp_vers}"=>'consCad_v2.00.xsd',//'consCad_v%%VERSAO%%.xsd',
            "NfeAutorizacao"=>'enviNFe_v%%VERSAO%%.xsd',
            "NfeRecepcao{$this->_comp_vers}"=>'enviNFe_v%%VERSAO%%.xsd',
            "NFeRetAutorizacao"=>'retEnviNFe_v%%VERSAO%%.xsd',
            "NfeRetRecepcao{$this->_comp_vers}"=>'retEnviNFe_v%%VERSAO%%.xsd',
            //Este n�o evoluiu a vers�o e j� podemos regirar
            //"NfeCancelamento{$this->_comp_vers}"=>'cancNFe_v2.00.xsd',
            "NfeInutilizacao{$this->_comp_vers}"=>'inutNFe_v%%VERSAO%%.xsd',
            "NfeStatusServico{$this->_comp_vers}"=>'consStatServ_v%%VERSAO%%.xsd',
            "NfeConsultaNF{$this->_comp_vers}"=>'consSitNFe_v%%VERSAO%%.xsd',
            //Por causa do SEFAZ da Bahia n�o funciona se for NfeConsultaNF2 BL-5101 e BL-5110
            "NfeConsultaNF"=>'consSitNFe_v%%VERSAO%%.xsd',
            //Essa � a consulta at�mica da NFCe
            "NfeConsultaNFe"=>'consSitNFe_v%%VERSAO%%.xsd',
            //"RecepcaoEvento"=>'retEnvCCe_v%%VERSAO%%.xsd',
            //O maior � 2.0 ent�o n�o vamos mais carregar os outros.
            "RecepcaoEvento"=>'retEnvCCe_v2.00.xsd',
            //'CabecMsg'=>'cabecMsg_v%%VERSAO%%.xsd',
            "CabecMsg{$this->_comp_vers}"=>'cabecMsg_v1.02.xsd',
            "NfeRecepcaoDPEC{$this->_comp_vers}"=>'envDPEC_v%%VERSAO%%.xsd',
            "ConsultaDPEC{$this->_comp_vers}"=>'consDPEC_v%%VERSAO%%.xsd',
            "NfeRecepcaoEPEC{$this->_comp_vers}"=>'enventoEPEC_v%%VERSAO%%.xsd'
        );

        foreach ($_infoSEFAZ as $_chave=>$_value) {
            switch ($_chave) {
                //Tem lugar q esta com 4.00 na frente e outros n�o, pra n�o dar problema no resto mudo apenas aqui.
                case
                "NfeInutilizacao" :
                    $_key = "NfeInutilizacao" . $this->_comp_vers;
                    break;
                case
                "NfeConsulta" :
                    $_key = "NfeConsulta" . $this->_comp_vers;
                    break;
                case
                "CadConsultaCadastro":
                    $_key = "CadConsultaCadastro" . $this->_comp_vers;
                    break;
                default:
                    $_key = $_chave;
            }
            if($_key == 'IncluirQRCodeXMLNFCe') {
                $this->aURLwsdl[$_key] 		 = $_value["ativo"];

                $this->aURLwsdl[$_chave] 	 = $this->aURLwsdl[$_key];


                if(($GLOBALS["_VERSAO_NT"] & 134217728) > 0) {
                    $this->aVerxsd[$_key] = 3;
                } else if (isset($_value["versao"])) {
                    //Se estivermos lento o arquivo 3.1 n�o haver� essa informa��o.
                    $this->aVerxsd[$_key] = $_value["versao"];
                } else {
                    $this->aVerxsd[$_key] = 1;
                }

                $this->aVerxsd[$_chave] = $this->aVerxsd[$_key];

                /**
                 * A nota tecnica inicial que saiu referesse
                 * a impress�o do QRCode, os ambientes ainda n�o est�o prontos
                 * para a tag nova do qrcode
                 */
                if (isset($_value["ver_imp"])) {
                    $this->aVerImpressao[$_key] = $_value["ver_imp"];
                } else {
                    $this->aVerImpressao[$_key] = 1;
                }
                $this->aVerImpressao[$_chave] = $this->aVerImpressao[$_key];

            }else{
                //Alguns estados vem com esta informa��o vazia ent�o for�o uma op��o.
                if($_value["versao"]=="") {
                    $_value["versao"] = "2.00";
                }

                $this->aURLwsdl[$_key] 		    = $_value["URL"];
                $this->aVerxsd[$_key]  		    = $_value["versao"];
                $this->aFunctionWdsl[$_key]     = $_value["service"];
                $this->aSoaActionWdsl[$_key]    = $_value["soap_action"];
                $this->aMetodoWdsl[$_key]       = $_value["metodo"];

                $this->aURLwsdl[$_chave] 		 = $this->aURLwsdl[$_key];
                $this->aVerxsd[$_chave]  		 = $this->aVerxsd[$_key] ;
                $this->aFunctionWdsl[$_chave]    = $this->aFunctionWdsl[$_key];
                $this->aSoaActionWdsl[$_chave]   = $this->aSoaActionWdsl[$_key];
                $this->aMetodoWdsl[$_chave]      = $this->aMetodoWdsl[$_key];

                if(!empty($_value["peer"])){
                    if($GLOBALS["_DEBUG_SEFAZ"]) {
                        funcoesGerais::GravaLog("SSL PEER esta ativo no arquivo de url para o metodo: " . $_value["metodo"] . "Estado: " . $_siglaUF, true,true);
                    }
                    $this->aPeer[$_key]             = $_value["peer"];
                    $this->aPeer[$_chave]            = $this->aPeer[$_key];
                }

            }


            //Se n�o tem o tipo que esta procurando vamos colocar o tipo que estamos trabalhando.
            if (isset($this->aFxsd[$_key])) {
                if (Zstrpos($this->aFxsd[$_key], "%%VERSAO%%") !== false) {
                    $this->aFxsd[$_key] = str_replace("%%VERSAO%%", $_value["versao"], $this->aFxsd[$_key]);
                }
            }

            if(!file_exists($this->pathXSD . $this->aFxsd[$_key])) {
                funcoesGerais::GravaLog("N�o foi poss�vel encontrar o arquivo especificado {$this->pathXSD}/{$this->aFxsd[$_key]}",true,true);
            }
        }
        return ($_infoSEFAZ===false ? false : true);
    }

    /*
     * Como reutilizamos a classe, limpamos as vari�veis que devem vir valoradas.
     */
    private function limparVariaveisRetorno() {
        //Na impress�o estava chamando isso duas vezes, ent�o criei isso e for�o o valor apenas antes de imprimir
        if ($this->_nao_limpar_mais === true) {
            return true;
        }
        $this->respostaXML = '';
        $this->cStat 	   = '';
        $this->tpAmb 	   = '';
        $this->verAplic    = '';
        $this->xMotivo     = '';
        // tempo medio de processamento
        $this->tMed 	   = '';
        // data e hora da mensagem
        $this->dhRecbto    = '';
        // numero do recibo, se o lote foi aceito
        // guardar o numero do recibo na base de dados pois devera ser usado
        // para verificar o estatus dos Lotes enviados
        $this->nRec 	  	= '';
        $this->errorStatus  = false;
        $this->aCad			= Array();
        $this->aNFe			= Array();
        $this->errorMsg 	= '';
        $this->nProt 		= '';
        /*
        $this->UF			= '';
        $this->IE			= '';
        $this->CNPJ			= '';
        $this->CPF			= '';
        $this->dhCons		= '';
     	$this->nNFIni 		= '';
	    $this->nNFFin 		= '';
	    $this->modelo		= '';
	    $this->serie 		= '';
	    $this->ano 		    = '';
	    $this->CNPJ 		= '';
	    $this->CPF   		= '';
	    $this->IE    		= '';
	    $this->chNFe 		= '';
	    $this->digVal		= '';
	    $this->dhCons 		= '';
		*/
    }
    /*
     * Carrega as vari�vei que ser�o utilzadas na conex�o com a SEFAZ de cada estado.
     */
    public function carregarUrlSEFAZ($_siglaUF) {
        if (is_numeric($_siglaUF)) {
            $this->cUF = $_siglaUF;
        } else {
            $this->cUF = funcoesGerais::$_cod_uf_sefaz[$_siglaUF];
            if ($this->getSituacaoEPEC() === true) {
                $_siglaUF = "EPEC";
            }
        }

        //Vai chamar novamente o ObterInfoURLSefaz com sigla de UF para SVC
        if($this->_situacao_SVC){
            $this->_urlcarregada = false;
            $_siglaUF = funcoesGerais::retornarTipoSVC($this->cUF);
        }

        /**
         * Como o certificado pode ser trocado por loja temos que ficarm chamando isso toda vez.
         */
        if($this->carregarVariaveis()===false) {
            funcoesGerais::GravaLog("N�o foi poss�vel carregar as variaveis de ambiente.",true,true);
            return false;
        }
        $this->limparVariaveisRetorno();
        if(($_siglaUF==="DPEC"&&($this->aURLwsdl["ConsultaDPEC"]===null))||
            ($_siglaUF!=="DPEC"&&($this->aURLwsdl["ConsultaDPEC"]!==null))) {
            $this->_urlcarregada = false;
        }

        if($this->_urlcarregada===false) {
            $this->UF = $_siglaUF;
            /*Aqui devemos preencher o Array de acordo com o estado que vamos utilizar.
             *Este m�todo � mto importante.
             */
            if((int) $this->ambiente === 2) {
                $_ambiente = "homologacao";
            } else {
                $_ambiente = "producao";
            }
            //Ajusto as bibliotecas para cada estado.
            if($this->obterInfoURLSEFAZ($_ambiente,$_siglaUF)===false) {
                funcoesGerais::GravaLog("N�o foi poss�vel obter informa��es sobre a URL de conex�o com a SEFAZ",true,true);
                return false;
            }
            $this->_urlcarregada = true;
        }
        if($this->_situacao_SVC){
            $this->_urlcarregada = false;
        }
        return true;
    }

    /**********************************************
     * Envia lote de Notas Fiscais
     *
     * @param	array   $_NFe notas fiscais em xml uma em cada campo de uma string
     * @param   integer $_lote o id do lote e um numero que deve ser gerado pelo sistema
     *                          a cada envio mesmo que seja de apenas uma NFe usar banco
     *                          de dados
     * @param   string  $_siglaUF Indica o estado que a url dever� ser processada. (�ber Lincoln)
     * @return	boolean	True se aceito o lote ou False de rejeitado
     * @return	boolean	True se aceito o lote ou False de rejeitado
     * @access  public
     ************************************************/
    // todo:: revisar (php 8.1)
    public function enviaNF($_NFe=array(),$_lote='1',$lote_sinc=false,$_siglaUF=null) {
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::enviaNF($_NFe,$_lote,$lote_sinc);
        } else {
            return false;
        }
    }

    /**********************************************
     * Solicita resposta do lote de Notas Fiscais
     * FUNCIONAL!!
     * Caso $this->cStat == 105 Tentar novamente mais tarde
     * @param	string   $_recibo numero do recibo do envio do lote
     * @param   string   $_siglaUF Indica o estado que a url dever� ser processada. (�ber Lincoln)
     * @return	boolean  True se sucesso false se falha
     * @access  public
     ************************************************/
    // todo:: revisar (php 8.1)
    public function retornoNF($_recibo, $bSave=TRUE,$_siglaUF=null) {
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::retornoNF($_recibo,false);
        } else {
            return false;
        }
    }

    /**
     * Solicita dados de situaçao de NF
     * FUNCIONAL !!
     * @param	string   $_idNFe numerico com 44 digitos
     * @param   string   $_siglaUF Indica o estado que a url dever� ser processada. (�ber Lincoln)
     * @return	mixed	response from SOAP call
     * @access  public
     **/
    // todo:: revisar (php 8.1)
    public function consultaNF($_idNFe, $bSave=true, $_esperar_menos = false,$_siglaUF=null){
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::consultaNF($_idNFe,false, $_esperar_menos);
        } else {
            return false;
        }
    }

    /**********************************************
     * Solicita o cancelamento de NF enviada
     *
     * @param	string  $idNFe ID da NFe com 44 digitos (sem o NFe na frente dos numeros)
     * @param   string  $protId Numero do protocolo de aceitaçao da NFe enviado anteriormente pelo SEFAZ
     * @param   boolean $bSave
     * @return	boolean TRUE se sucesso ou FALSE se falha
     * FUNCIONAL !!!
     * @access  public
     ************************************************/
    // todo:: revisar (php 8.1)
    public function cancelaNF($idNFe,$protId, $xJust,$bSave=true,$_siglaUF=null,$_codloja=null) {
        //Sempre deve estar configurado o config_inc.php pois ele define o tipo do
        //ambiente por exemplo 1 para produ��o e 2 para homologa��o.
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            //Se o tipo de integra��o for igual a false N�O � NFE.
            if(nfe_integracao::checarTipoIntegracao()===false) {
                if(($_classe_integrador = nfe_integracao::decidirIntegrador($_codloja))!==null) {
                    $_classe_integrador->_NFeZanthus = $this;
                    $_ret = $_classe_integrador->cancelarNFe($idNFe,$protId,$xJust,$_siglaUF,$_codloja,$this->ambiente);

                    if($_ret!==false) {
                        $this->versao   = $_ret["versao"];
                        $this->tpAmb    = $_ret["tpAmb"];
                        $this->verAplic = $_ret["verAplic"];
                        $this->cStat    = $_ret["cStat"];
                        $this->xMotivo  = $_ret["xMotivo"];
                        $this->cUF      = $_ret["cUF"];

                        if ($this->cStat==='101' ) {
                            $this->chNFe    = $_ret["chNFe"];
                            $this->dhRecbto = $_ret["dhRecbto"];
                            $this->nProt    = $_ret["nProt"];
                        }
                    } else {
                        $this->errorStatus = true;
                        return false;
                    }
                } else {
                    $this->errorStatus = true;
                    return false;
                }
            } else {
                return parent::cancelaNF($idNFe,$protId,$xJust,false,$_codloja);
            }
        }
        return false;
    }

    /**********************************************
     * Solicita inutiliza��o de uma serie de numeros de NFe (55) ou NFCe (65)
     *
     *
     * @param	string  $ano
     * @param   string  $nfSerie
     * @param   integer $modelo
     * @param   integer $numIni
     * @param   integer $numFim
     * @param   String  $xJust
     * @param   string  $_siglaUF
     * @param 	string  $_cnpj
     * @param   integer $_coduf
     * @param   integer  $_codloja

     * @access  public
     ************************************************/
    // todo:: revisar (php 8.1)
    public function inutilizaNF($ano,$nfSerie,$modelo,$numIni,$numFim,$xJust,$bSave=true,$_siglaUF=null,$_cnpj=null,$_coduf=null,$_codloja=null) {
        //Sempre deve estar configurado o config_inc.php pois ele define o tipo do
        //ambiente por exemplo 1 para produ��o e 2 para homologa��o.
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            $this->UFcod = $_coduf;
            $this->CNPJ  = $_cnpj;

            //Se o tipo de integra��o for igual a false N�O � NFE.
            if(nfe_integracao::checarTipoIntegracao()===false) {
                if(($_classe_integrador = nfe_integracao::decidirIntegrador($_codloja))!==null) {
                    $_classe_integrador->UFcod 		 = $this->UFcod;
                    $_classe_integrador->CNPJ  		 = $this->CNPJ;
                    $_classe_integrador->_NFeZanthus = $this;

                    $_ret = $_classe_integrador->inutilizarNFe($ano,$nfSerie,$modelo,$numIni,$numFim,$xJust,$_codloja,$this->ambiente);
                    if($_ret!==false) {
                        $this->versao   = $_ret["versao"];
                        $this->tpAmb    = $_ret["tpAmb"];
                        $this->verAplic = $_ret["verAplic"];
                        $this->cStat    = $_ret["cStat"];
                        $this->xMotivo  = $_ret["xMotivo"];
                        $this->cUF      = $_ret["cUF"];

                        if ($this->cStat=== '102') {
                            $this->ano      = $_ret["ano"];
                            $this->CNPJ     = $_ret["CNPJ"];
                            $this->modelo   = $_ret["modelo"];
                            $this->serie    = $_ret["serie"];
                            $this->nNFIni   = $_ret["nNFIni"];
                            $this->nNFFin   = $_ret["nNFFin"];
                            $this->dhRecbto = $_ret["dhRecbto"];
                            $this->nProt    = $_ret["nProt"];
                        }
                    } else {
                        $this->errorStatus = true;
                        return false;
                    }
                } else {
                    $this->errorStatus = true;
                    return false;
                }
            } else {
                return parent::inutilizaNF($ano,$nfSerie,$modelo,$numIni,$numFim,$xJust,false);
            }
        }
        return false;


    }

    /**
     * Envia DPEC
     */
    public function enviaDPEC($chNFe,$IE,$verProc,$destCNPJ,$destCPF,$vNF,$vICMS,$vST,$_siglaUF){

        if(!$this->carregarUrlSEFAZ($_siglaUF)) {
            return false;
        }

        $envDPEC = new NFeTools_envDPEC();
        if($this->_versao_nfe == 2) {
            $envDPEC->versao = "2.00";
        } else {
            $envDPEC->versao = $this->_versao_nfe;
        }
        $envDPEC->chNFe;      // id da NFe emitida em contingência DPEC - esta contido no xml da NFe 44 digitos
        $envDPEC->IE;         // IE do emitente
        $envDPEC->verProc;    //vers�o do programa que gera a NFe - esta dento do xml da NFe
        $envDPEC->destCNPJ;   //CNPJ do destinatario
        $envDPEC->destCPF;    // CFP do destinatario
        $envDPEC->destUF;     // sigla da UF do destinatario
        $envDPEC->vNF;        // valor da NF
        $envDPEC->vICMS;      //valor do ICMS
        $envDPEC->vST;         // valor total do ICMS retido com Substituicao tributaria

        //$envDPEC->tpAmb;      //
        //$envDPEC->id;         // ID = DPEC + CNPJ
        //$envDPEC->CNPJ;       // CNPJ do emitente OBITIDO DO chNFe
        //$envDPEC->cUF;        //codigo numerico da UF do emitente OBITIDO DO chNFe

        $envDPEC->sendSOAP();

        return $envDPEC;
    }
    /**
     * M�todo que sobrescreve o ValidaXML da NFETolls apenas para que n�o precise descobrir aonde esta o XSD de valida��o.
     *
     * @param 	string 	$docxml		XML da NFe.
     * @param 	string 	$xsdfile	Path do arquivo XSD de valida��o.
     * @return 	boolean
     */
    public function validaXML($docxml,$xsdfile='', $_limpar_buffer = false) {
        return parent::validaXML($docxml,($xsdfile==''?$this->_fileXSD:$xsdfile));
    }

    /**
     * Tentando traduzir alguns erros no XSD da SEFAZ.
     *
     * Para os casos em que n�o conseguimos tratar antes.
     * Colocar algumas tradu��es aqui
     *
     */
    public function traduzirErrosXsd($_texto) {
        $_chIni = "%I%";
        $_chFim = "%F%";
        $_arr = explode("\n", $_texto);
        $_erros_conhecidos = Array(
            '{http://www.portalfiscal.inf.br/nfe}nro',
            '{http://www.portalfiscal.inf.br/nfe}xLgr',
            '{http://www.portalfiscal.inf.br/nfe}xBairro',
            '{http://www.portalfiscal.inf.br/nfe}CEP',
            '{http://www.portalfiscal.inf.br/nfe}ICMS',
            '{http://www.portalfiscal.inf.br/nfe}PIS',
            '{http://www.portalfiscal.inf.br/nfe}COFINS',
            '{http://www.portalfiscal.inf.br/nfe}fone'
        );
        $_erros_traducao   = Array(
            //N�o modificar os textos '(TAG:***)' pois est�o sendo usados para valida��o no JS
            "{$_chIni}� necess�rio informar um n�mero v�lido para o endere�o do destinat�rio (TAG:nro){$_chFim}",
            "{$_chIni}� necess�rio informar um logradouro do destinat�rio (TAG:xLgr){$_chFim}",
            "{$_chIni}� necess�rio informar bairro do destinat�rio (TAG:xBairro){$_chFim}",
            "{$_chIni}� necess�rio informar CEP do destinat�rio (TAG:CEP){$_chFim}",
            "{$_chIni}Verifique o CST da mercadoria, n�o foi encontrado o ICMS para o item (TAG:ICMS){$_chFim}",
            "{$_chIni}Verifique o CST da mercadoria, n�o foi encontrado o PIS para o item (TAG:PIS){$_chFim}",
            "{$_chIni}Verifique o CST da mercadoria, n�o foi encontrado o COFINS para o item (TAG:COFINS){$_chFim}",
            "{$_chIni}Encontrado alguma inconsist�ncia no n�mero do telefone, favor ajustar e refazer o processo (TAG:fone){$_chFim}");
        //Os erros ser�o armazenados aqui.
        $_erro  = Array();
        $_ret  = "";
        foreach ($_arr as $_value) {
            $_novo_texto = str_replace($_erros_conhecidos, $_erros_traducao, $_value);
            $_pos_controle = $this->retornaPosCaractereControle($_novo_texto);
            if ($_novo_texto !== $_value && $_pos_controle !== false) {
                $_novo_texto = substr($_novo_texto, $_pos_controle[0], $_pos_controle[1]);

                if (in_array($_novo_texto, $_erro)===false) {
                    $_erro[] = $_novo_texto;
                    $_ret   .= $_novo_texto;
                }
            } else {
                $_ret .= $this->formataMsgValidacaoGenerica($_value) . "\n";
            }
        }
        return $_ret;
    }

    private function retornaPosCaractereControle($_novo_texto) {
        $_chIni = "%I%";
        $_chFim = "%F%";
        $_pos_ini = stripos($_novo_texto, $_chIni);
        $_pos_ini2 = ($_pos_ini !== false) ? stripos($_novo_texto, $_chIni, $_pos_ini + strlen($_chIni)) : false;
        if ($_pos_ini2 !== false) {
            $_pos_ini = $_pos_ini2;
        }
        if ($_pos_ini !== false) {
            $_pos_ini += strlen($_chIni);
        }
        $_pos_fim = stripos($_novo_texto, $_chFim);
        $_pos_fim2 = ($_pos_fim !== false) ? stripos($_novo_texto, $_chFim, $_pos_fim + strlen($_chFim)) : false;
        if ($_pos_fim2 !== false) {
            $_pos_fim = $_pos_fim2;
        }
        if ($_pos_ini !== false && $_pos_fim !== false && $_pos_fim > $_pos_ini) {
            return array($_pos_ini, $_pos_fim - $_pos_ini);
        } else {
            return false;
        }
    }

    private function formataMsgValidacaoGenerica($_erro_generico) {
        $_de = array(
            "{http://www.portalfiscal.inf.br/nfe}",
            "[facet 'pattern']",
            "The value",
            "is not accepted by the pattern",
            "has a length of",
            "[facet 'minLength']",
            "this underruns the allowed minimum length of",
            "[facet 'maxLength']",
            "this exceeds the allowed maximum length of",
            "Element",
            "attribute",
            "is not a valid value of the local atomic type",
            "is not a valid value of the atomic type",
            "Missing child element(s). Expected is",
            "The document has no document element",
            "[facet 'enumeration']",
            "one of",
            "failed to load external entity",
            "Failed to locate the main schema resource at",
            "This element is not expected. Expected is",
            "is not an element of the set"
        );
        $_para = array(
            "",
            "[Erro 'Layout']",
            "O valor",
            "n�o � aceito para o padr�o.",
            "tem o tamanho",
            "[Erro 'Tam. Min']",
            "deve ter o tamanho m�nimo de",
            "[Erro 'Tam. Max']",
            "Tamanho m�ximo permitido",
            "Elemento",
            "Atributo",
            "n�o � um valor v�lido",
            "n�o � um valor v�lido",
            "Elemento filho faltando. Era esperado",
            "Falta uma tag no documento",
            "[Erro 'Conte�do']",
            "um de",
            "falha ao carregar entidade externa",
            "Falha ao tentar localizar o schema principal em",
            "Este elemento n�o � esperado. Esperado �",
            "n�o � um dos seguintes possiveis"
        );
        return trim(str_replace($_de, $_para, $_erro_generico));
    }

    /**********************************************
     * Verifica o status do servico da SEFAZ
     *
     * Este metodo carrega a variavel
     * $this->cStat = 107 OK
     *        cStat = 108 sitema paralizado momentaneamente, aguardar retorno
     *        cStat = 109 sistema parado sem previsao de retorno, verificar status SCAN
     * se SCAN estiver ativado usar, caso caontrario aguardar pacientemente.
     *
     *
     * FUNCIONAL !!
     * @param	string $_siglaUF Estado
     * @return	boolean True se operacional e False se nao
     * @access  public
     ***********************************************/
    // todo:: revisar (php 8.1)
    public function statusServico($bSave=true,$_siglaUF=null) {
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::statusServico(false);
        } else {
            return false;
        }
    }

    /**
     * Solicita dados de situa��ao de Cadastro
     * @param	string  $UF
     * @param   string  $IE
     * @param   string  $CNPJ
     * @param   string  $CPF
     * @return	boolean TRUE se sucesso ou FALSE se falha
     * @access  public
     *
     **/
    public function consultaCadastro($_siglaUF,$_IE='',$_CNPJ='',$_CPF='',$bSave=TRUE) {
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::consultaCadastro($_siglaUF, $_IE, $_CNPJ, $_CPF, false);
        } else {
            $this->errorMsg = 'Problemas ao carregar a URL Sefaz.';
            $this->errorStatus = true;
            return false;
        }
    }

    /**********************************************
     * Envia lote de eventos
     *
     * @param	array  $_Evto Eventos em xml uma em cada campo de uma string
     * @param   integer $_lote o id do lote e um numero que deve ser gerado pelo sistema
     *                          a cada envio mesmo que seja de apenas um evento usar banco
     *                          de dados
     * @param   string  $_siglaUF Indica o estado que a url dever� ser processada. (�ber Lincoln)
     * @returnboolean   True se aceito o lote ou False de rejeitado
     * @access  public
     ************************************************/
    public function enviarEvento($_Evto=array(),$_lote='1',$_siglaUF=null) {
        if($this->carregarUrlSEFAZ($_siglaUF)) {
            return parent::enviarEvento($_Evto,$_lote,false);
        } else {
            return false;
        }
    }

    public function inserirQrcode(){
        $_siglaUF = $this->infNFe->emit->enderEmit->UF;
        $this->carregarUrlSEFAZ($_siglaUF);
        if($this->aURLwsdl['IncluirQRCodeXMLNFCe'] != 1) {
            return false;
        }

        $_url = $this->aURLwsdl['URLQRCodeAcesso'];
        $_qrcode2 = '';
        if(($GLOBALS["_VERSAO_NT"] & 8) > 0) {
            $_qrcode2 = '2';
        }
        $_url_chave = $this->aURLwsdl["URLAcesso{$_qrcode2}"];
        $_dest = '';
        if(empty($this->infNFe->dest->CNPJ) && empty($this->infNFe->dest->CPF)){
            $_dest = '';
        }else if(empty($this->infNFe->dest->CNPJ)){
            $_dest = $this->infNFe->dest->CPF;
        }else{
            $_dest = $this->infNFe->dest->CNPJ;
        }

        $_timezone = funcoesGerais::retornarTimeZone($_siglaUF,false,true);

        $_id_nfe = substr($this->infNFe->Id, 3);
        $_ambiente = $this->ambiente;
        //Para alguns estados esse CNPJ precisa estar no QRCODE
        if($_ambiente == 2 && $_dest == '') {
            $_dest = '99999999000191';
        }
        $_dhemi = $this->infNFe->ide->dEmi.$_timezone;
        $_vnf = $this->infNFe->total->ICMSTot->vNF;
        $_vnf = number_format($_vnf,2,'.','');
        $_vicms = $this->infNFe->total->ICMSTot->vICMS;
        $_vicms = number_format($_vicms,2,'.','');
        $_id_token = $this->_codigo_token_nfce;// $_arr_nfe[0]["infnfe"]['codigo_token_nfce'];

        $this->_qrcode_nfce = array(
            "ID_NFE"	            =>	$_id_nfe,
            "URL"		            =>	$_url,
            "AMBIENTE"	            =>	(int) $_ambiente,
            "DEST"		            =>	$_dest,
            "DHEMI"		            =>	$_dhemi,
            "VNF"		            =>	$_vnf,
            "VICMS"		            =>	$_vicms,
            "DIG"		            =>	null,
            "TOKEN"		            =>	$_id_token,
            "URL_CHAVE"		        =>	$_url_chave,
        );

        return true;

    }

    /**
     * Adivinhando o que o m�todo faz, j� que n�o havia coment�rio.
     * Acredito que este m�todo cheque o estado e retorne se est� dentro da condi��o
     * daquele estado para algum fim....(???)
     * @param string $_uf
     * @return boolean
     */
    public function verificarUFNotaTecnica ($_uf) {
        switch ($_uf) {
            case 'AM':
            case 'BA':
            case 'CE':
            case 'GO':
            case 'MG':
            case 'MS':
            case 'MT':
            case 'PE':
            case 'RN':
            case 'SP':
            case 'SE': //Solicitado no BL-5455
            case 'PA': //Solicitado no ML-268
            case 'AL': //Solicitado no ML-268
            case 'PB': //Solicitado pelo Eduardo e Val�ria
            case 'DF': //Solicitado pelo Fernando e Rodrigo Silveira
            case 'RJ': //Solicitado pelo Fernando e Rodrigo Silveira
            case 'PR': //Solicitado no BL-6611 08-08-2019
            case 'RS':
                $_ret = true;
                break;
            default:
                $_ret = false;
                break;
        }

        return $_ret;
    }

    /**
     * Na NF-e dever� respeitar o par�metro para imprimir o c�digo do produto (cEAN) ou c�digo lido (cEANTrib)
     * @param $_cod_loja
     * @param $_modelo
     * @param $_info_impressao
     * @return array|null
     */
    public function imprimirCodLido($_cod_loja, $_modelo, $_info_impressao) {
        $_imprimir_cod_lido = false;
        if(funcoesGerais::managerOFFLine()) {
            switch ((int)$_modelo) {
                case 65: //NFC-e
                    $_bit_ean_cod_interno = 16;
                    $_imprimir_cod_lido = $_info_impressao["grava_cod_lido_nfce"] == 'S';
                    break;
                case 59: //CF-e
                    $_bit_ean_cod_interno = 32;
                    $_imprimir_cod_lido = $_info_impressao["grava_cod_lido_cfe"] == 'S';
                    break;
                default:
                    return false;
                    break;
            }
            $_utiliza_cod_identidade = ((int)$_info_impressao["A00FIADC"] & 2) > 0;
            if($_utiliza_cod_identidade) {
                $_imprimir_cod_lido = ($_info_impressao["opcoes_impressao_nota"] & $_bit_ean_cod_interno) > 0;
                return $_imprimir_cod_lido;
            } else {
                return $_imprimir_cod_lido;
            }
        } else {
            switch ((int)$_modelo) {
                case 65: //NFC-e
                    $_param_cod_alternativo = "A00KKA";
                    $_bit_cod_alternativo = 4096;
                    $_bit_ean_cod_interno = 16;
                    break;
                case 59: //CF-e
                    $_param_cod_alternativo = "A00KNA";
                    $_bit_cod_alternativo = 1024;
                    $_bit_ean_cod_interno = 32;
                    break;
                case 55: //NF-e
                    $_param_cod_alternativo = "A00KOA";
                    $_bit_cod_alternativo = 32;
                    $_bit_ean_cod_interno = 8;
                    break;
                default:
                    return false;
                    break;
            }
            $_vp = new VALORESPARAMETRO($GLOBALS["_MASTER"]);
            $_params = $_vp->retornarVariosValoresParametros([87,30], [$_param_cod_alternativo, "A00FIADC"], $_cod_loja, true);
            $_utiliza_cod_identidade = ($_params["A00FIADC"] & 2) > 0;
            if($_utiliza_cod_identidade) {
                $_imprimir_cod_lido = ($_info_impressao["opcoes_impressao_nota"] & $_bit_ean_cod_interno) > 0;
                return $_imprimir_cod_lido;
            } else {
                $_imprimir_cod_lido = ($_params[$_param_cod_alternativo] & $_bit_cod_alternativo) > 0;
                return $_imprimir_cod_lido;
            }
        }
    }
}

/**
 * Classe respons�vel por tratar o xml do CFe do SAT
 * extend da NFeZanthus pois muita coisa � reaproveitada.
 * @author Fernando Silva
 */

class CFeZanthus extends NFeZanthus {

    function __construct($_connection) {
        $this->infCFe   			= new infCFe;
        return parent::__construct($_connection);
    }

    /**
     * No final chamaremos esse m�todo pra preencher com os dados fiscais.
     */
    function preencherInfoAdicComTotaisImpostos($_CSTs = []) {
        //N�o pode ser new toda hora.
        if (!isset($this->infCFe->infAdic)) {
            $this->infCFe->add_infAdic(new infAdic);
        }

        //NT2023001-1 - Inserindo textos para determinados CSTs que surgirem na nota, depois precisamos ajustar os valores que est�o XXXX!
        foreach($_CSTs as $_key => $_cst){
            switch($_key){
                case 2:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico pr�prio: BC {$_cst['qBCMonoRet']} (em litros); Al�quota: % {$_cst['adRemICMSRet']}; ICMS mono: R$ {$_cst['vICMSMonoRet']}";
                    break;
                case 15:
                    //Fazendo isso pois � o mesmo texto do CST 2
                    if(empty($_CSTs[2])) $this->infNFe->infAdic->infAdFisco .= ";ICMS monof�sico pr�prio: BC {$_cst['qBCMonoRet']} (em litros); Al�quota: % {$_cst['adRemICMSRet']}; ICMS mono: R$ {$_cst['vICMSMonoRet']};";
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sujeito a reten��o: BC {$_cst['qBCMonoRet']} (em litros); Al�quota: % {$_cst['adRemICMSRet']}; ICMS mono: R$ {$_cst['vICMSMonoRet']};";
                    break;
                case 53:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sobre combust�veis diferido conforme Conv�nio ICMS 199/2022;";
                    break;
                case 61:
                    $this->infNFe->infAdic->infCpl .= ";ICMS monof�sico sobre combust�veis cobrado anteriormente conforme Conv�nio ICMS 199/2022;";
                    break;
            }
        }


        $_chave_cfe = $this->infCFe->emit->CNPJ . '#CHAVE_ZANTHUS#' . $this->infCFe->total->ICMSTot->vNF . '@' . $this->_id_nota_temp;
        $_chave_cfe = base64_encode(funcoesGerais::criptografaInformacaoPDV($_chave_cfe));

        $this->infCFe->infAdic->infCpl .= ' ' . $_chave_cfe;

    }
    /**
     * @param $_arr_nfe
     * @return bool
     */
    function valorarObjeto($_dados, $_nitem) {
        $_imprimiu_issqn = false;
        if ($_nitem === 0) {
            if (!isset($this->infCFe)) {
                //$this->carregarVariaveis();
                $this->infCFe = new infCFe();
            }
            $this->_versao_nfe = (float)sprintf("%01.2F", $_dados["a01_versao"]);

            $this->infCFe->versaoDadosEnt = sprintf("%01.2F", $this->infCFe->versao);

            $this->infCFe->Id = $_dados["a01_id"];
            $this->Id = substr($_dados["a01_id"], 3);


            $this->infCFe->ide->cUF = $_dados["b01_cuf"];
            $this->codigo_token_nfce = $_dados["codigo_token_nfce"];
            /*
            $this->certificado_digital = $_dados["nome_certificado_digital"];
            $this->certificado_digital = $_dados["senha_certificado_digital"];
            */
            $_ocultaTagsDest = false; // Define se devo ocultar tags n�o obrigat�rias do destinat�rio


            $this->tpAmb = $_dados["flg_tipo_ambiente_nfe"];
            $this->ambiente = (int)$this->tpAmb;
            $this->infCFe->ide->tpAmb = $this->ambiente;
            $this->infCFe->ide->natOp = $_dados["b01_natop"];
            $this->infCFe->ide->indPag = $_dados["b01_indpag"];
            $this->infCFe->ide->mod = $_dados["b01_modelo"];

            NFe::$_tipo_nota = (int)$this->infCFe->ide->mod;
            $this->modelo = NFe::$_tipo_nota;

            //infCFe
            $this->infCFe->versaoDadosEnt = sprintf("%01.2F", $this->infCFe->versao);

            //ide
            $this->infCFe->ide->numeroCaixa = funcoesGerais::str_alinha($_dados["numpdv"], 3, DIREITA, false, 0);
            $this->infCFe->ide->CNPJ = $_dados["c01_cnpj"];
            $this->infCFe->ide->signAC = 'SGR-SAT SISTEMA DE GESTAO E RETAGUARDA DO SAT';//Parece que quando tem espa�o no final n�o � aceito.


            //emit
            $res_emit = $res_infCFe['emit'];
            $this->infCFe->emit->CNPJ = $_dados["c01_cnpj"];
            $this->infCFe->emit->IE = $_dados["c01_ie"];
            $this->infCFe->emit->IM = $_dados["c01_im"];

            //dest

            $this->infCFe->dest->CNPJ = $_dados["e01_cnpj"];
            $this->infCFe->dest->CPF = $_dados["e01_cpf"];
            if (!isset($this->infCFe->dest->xNome)) {
                $this->infCFe->dest->xNome = funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($_dados["e01_xnome"]));
            }
            //total
            $this->infCFe->total->ICMSTot->vNF = $_dados['w02_vnf'];
        }

        if (!empty($_dados["h01_nitem"])) {
            $this->infCFe->add_det(new detCF);
            $this->infCFe->det[$_nitem]->nItem = $_dados["h01_nitem"];
            $this->infCFe->det[$_nitem]->prod->vFrete = $_dados["i01_vfrete"];
            $this->infCFe->det[$_nitem]->prod->vSeg = $_dados["i01_vseg"];
            $this->infCFe->det[$_nitem]->prod->vOutro = $_dados["i01_voutro"];
            $this->infCFe->det[$_nitem]->prod->vDesc = $_dados["i01_vdesc"];
            $this->infCFe->det[$_nitem]->prod->cEAN = $_dados["i01_cean"];
            $this->infCFe->det[$_nitem]->prod->cProd = $_dados["i01_cprod"];
            $this->infCFe->det[$_nitem]->prod->xProd = funcoesGerais::limparCampoNotaEletronica($_dados["i01_xprod"]);
            $this->infCFe->det[$_nitem]->prod->CFOP = $_dados["i01_cfop"];
            $this->infCFe->det[$_nitem]->prod->uCom = trim($_dados["i01_ucom"]);
            $this->infCFe->det[$_nitem]->prod->qCom = $_dados["i01_qcom"];
            $this->infCFe->det[$_nitem]->prod->vUnCom = $_dados["i01_vuncom"];
            $this->infCFe->det[$_nitem]->prod->vProd = $_dados["i01_vprod"];
            //$this->infNFe->det[$_nitem]->prod->vnf = $_dados["i01_vnf"];
            $this->infCFe->det[$_nitem]->prod->NCM = $_dados["i01_ncm"];
            $this->infCFe->det[$_nitem]->prod->CEST = $_dados["i01_cest"];
            if ($this->infCFe->ide->mod == '59' && $this->infCFe->versao == '0.08'){
                unset($this->infCFe->det[$_nitem]->prod->indEscala);
            }else{
                $this->infCFe->det[$_nitem]->prod->indEscala = $_dados["i01_indescala"];
            }
            $this->infCFe->det[$_nitem]->prod->qTrib = $_dados["i01_qtrib"];
            $this->infCFe->det[$_nitem]->prod->vUnTrib = $_dados["i01_vuntrib"];
            if (!empty($_dados["i01_vuntrib"])) {
                $this->infCFe->det[$_nitem]->prod->vUnTrib = $_dados["i01_vuntrib"];
            } else {//Se estiver vazio pega o da pr�pria vuncom
                $this->infCFe->det[$_nitem]->prod->vUnTrib = $_dados["i01_vuncom"];
            }
            $this->infCFe->det[$_nitem]->prod->indTot = $_dados["i01_indtot"];
            $this->infCFe->det[$_nitem]->prod->uTrib = trim($_dados["i01_utrib"]);
            $this->infCFe->det[$_nitem]->prod->EXTIPI = $_dados["i01_extipi"];

            //N�o esta sendo enviado
            //$this->infCFe->det[$_nitem]->prod->genero    = $res_prod['genero'];

            if (isset($_dados["l101_cprodanp"]) && !empty($_dados["l101_cprodanp"])) {
                $this->infCFe->det[$_nitem]->prod->codanp = $_dados["l101_cprodanp"];
            }

            $this->infCFe->det[$_nitem]->imposto->vTotTrib = (float)$_dados["m01_vtottrib"];

            //ICMS
            //Atributo do produto
            if (intval($_dados["i01_tipoimposto"]) === 0) {
                $this->infCFe->det[$_nitem]->imposto->add_ICMS(new ICMSCF);
                if (($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) && !funcoesGerais::managerOFFLine()) {
                    $this->infCFe->det[$_nitem]->imposto->ICMS->Orig = $_dados["n01_orig_simples"];
                    $this->infCFe->det[$_nitem]->imposto->ICMS->CST = $_dados["n01_cst_simples"];
                } else {
                    $this->infCFe->det[$_nitem]->imposto->ICMS->Orig = $_dados["n01_orig"];

                    if ($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) {
                        $this->infCFe->det[$_nitem]->imposto->ICMS->CST = $_dados["n01_cst"];
                    } else {
                        if (strlen($_dados["n01_cst"]) == 2) {
                            $this->infCFe->det[$_nitem]->imposto->ICMS->CST = $_dados["n01_cst"];
                        } else {
                            $this->infCFe->det[$_nitem]->imposto->ICMS->CST = substr($_dados["n01_cst"], 1, 2);
                        }
                    }
                }
                $this->infCFe->det[$_nitem]->imposto->ICMS->pICMS = $_dados["n01_picms"];
            }

            //PIS
            if (!empty($_dados["q01_cst"])) {//Esse deve aparecer sempre
                $this->infCFe->det[$_nitem]->imposto->add_PIS(new PISCF);
                $this->infCFe->det[$_nitem]->imposto->PIS->CST = $_dados["q01_cst"];
                $this->infCFe->det[$_nitem]->imposto->PIS->vBC = $_dados["q01_vbc"];
                $this->infCFe->det[$_nitem]->imposto->PIS->pPIS = $_dados["q01_ppis"];
                $this->infCFe->det[$_nitem]->imposto->PIS->vPIS = $_dados["q01_vpis"];
                $this->infCFe->det[$_nitem]->imposto->PIS->qBCProd = $_dados["q01_qbcprod"];
                $this->infCFe->det[$_nitem]->imposto->PIS->vAliqProd = $_dados["q01_valiqprod"];
            }

            //PISST
            /*$res_PISST = $res_imposto['pisst'];
            if (count((array)$res_PISST)) {
                if(floatval($res_PISST['vbc'])>0) {
                    $this->infCFe->det[$i]->imposto->add_PISST(new PISSTCF);
                    $this->infCFe->det[$i]->imposto->PISST->vBC       = $res_PISST['vbc'];
                    $this->infCFe->det[$i]->imposto->PISST->pPIS      = $res_PISST['ppis'];
                    $this->infCFe->det[$i]->imposto->PISST->qBCProd   = $res_PISST['qbcprod'];
                    $this->infCFe->det[$i]->imposto->PISST->vAliqProd = $res_PISST['valiqprod'];
                    $this->infCFe->det[$i]->imposto->PISST->vPIS      = $res_PISST['vpis'];
                }
            }*/


            //COFINS
            if (!empty($_dados["s01_cst"])) {//Esse dever� aparecer sempre
                $this->infCFe->det[$_nitem]->imposto->add_COFINS(new COFINSCF);
                $this->infCFe->det[$_nitem]->imposto->COFINS->CST = $_dados["s01_cst"];
                $this->infCFe->det[$_nitem]->imposto->COFINS->vBC = $_dados["s01_vbc"];
                $this->infCFe->det[$_nitem]->imposto->COFINS->pCOFINS = $_dados["s01_pcofins"];
                $this->infCFe->det[$_nitem]->imposto->COFINS->qBCProd = $_dados["s01_qbcprod"];
                $this->infCFe->det[$_nitem]->imposto->COFINS->vAliqProd = $_dados["s01_valiqprod"];
                $this->infCFe->det[$_nitem]->imposto->COFINS->vCOFINS = $_dados["s01_vcofins"];
            }

            //COFINSST
            $res_COFINSST = $res_imposto['cofinsst'];
            if (floatval($_dados["t01_vbc"]) > 0) {
                $this->infCFe->det[$_nitem]->imposto->add_COFINSST(new COFINSSTCF);
                $this->infCFe->det[$_nitem]->imposto->COFINSST->vBC = $_dados["t01_vbc"];
                $this->infCFe->det[$_nitem]->imposto->COFINSST->pCOFINS = $_dados["t01_pcofins"];
                $this->infCFe->det[$_nitem]->imposto->COFINSST->qBCProd = $_dados["t01_qbcprod"];
                $this->infCFe->det[$_nitem]->imposto->COFINSST->vAliqProd = $_dados["t01_valiqprod"];
                $this->infCFe->det[$_nitem]->imposto->COFINSST->vCOFINS = $_dados["t01_vcofins"];
            }


            //Mesmo que coloque aliquota zero dever� mostrar o ISSQNTOT.
            //ISSQN
            //Atributo do produto
            if (intval($_dados["i01_tipoimposto"]) === 1) {
                $_imprimiu_issqn = true;
                $this->infCFe->det[$_nitem]->imposto->add_ISSQN(new ISSQN);
                $this->infCFe->det[$_nitem]->imposto->ISSQN->vBC = $_dados["u01_vbc"];
                $this->infCFe->det[$_nitem]->imposto->ISSQN->vAliq = $_dados["u01_valiq"];
                $this->infCFe->det[$_nitem]->imposto->ISSQN->vISSQN = $_dados["u01_vissqn"];
                $this->infCFe->det[$_nitem]->imposto->ISSQN->cMunFG = $_dados["u01_cmunfg"];
                $this->infCFe->det[$_nitem]->imposto->ISSQN->cListServ = $_dados["u01_clistserv"];
                $this->infCFe->det[$_nitem]->imposto->ISSQN->cSitTrib = $_dados["u01_csittrib"];
            }
        }

    }

    // todo:: revisar (php 8.1)
    function fetch($_con,$_arr_nfe) {
        return true;
        if($_arr_nfe===null) {
            return false;
        }
        $_imprimiu_issqn = false;
        $res_NFe     = $_arr_nfe;
        if (count((array)$res_NFe)) {
            //NFe
            if($res_NFe[0]['situacao']!==null) {
                $this->situacao->fetch($_con,$res_NFe[0]['situacao']);
            }

            //infCFe
            $res_infCFe = $res_NFe[0]["infnfe"];
            if (count((array)$res_infCFe)) {
                $this->infCFe->versaoDadosEnt = sprintf("%01.2F",$this->infCFe->versao);
            }

            //ide
            $res_ide = $res_infCFe["ide"];
            if (count((array)$res_ide)) {
                $this->infCFe->ide->numeroCaixa = funcoesGerais::str_alinha($res_NFe[0][""]["numpdv"],3,DIREITA,false,0);
                $this->infCFe->ide->CNPJ          = $res_infCFe['emit']['cnpj'];
                $this->infCFe->ide->signAC        = 'SGR-SAT SISTEMA DE GESTAO E RETAGUARDA DO SAT';//Parece que quando tem espa�o no final n�o � aceito.
            }

            //emit
            $res_emit = $res_infCFe['emit'];
            if (count((array)$res_emit)) {
                $this->infCFe->emit->CNPJ      = $res_emit['cnpj'];
                if ( (int) $GLOBALS["_VERSAO_CFE"] >= 8 && !empty($res_emit['ie'])) { // LAYOUTCFE-2 tratando IE para o novo layout 0.08
                    $this->infCFe->emit->IE = funcoesGerais::str_alinha($res_emit['ie'], 14, ESQUERDA, false, ' ');
                }else{
                    $this->infCFe->emit->IE        = $res_emit['ie'];
                }
                $this->infCFe->emit->IM        = $res_emit['im'];
            }

            //avulsa
            if (count((array)$res_avulsa)) {
                $this->infCFe->add_avulsa (new avulsa);
                $this->infCFe->avulsa->CNPJ      = $res_avulsa['cnpj'];
                $this->infCFe->avulsa->xOrgao    = $res_avulsa['xorgao'];
                $this->infCFe->avulsa->matr      = $res_avulsa['matr'];
                $this->infCFe->avulsa->xAgente   = $res_avulsa['xagente'];
                //NFE 2.0 Fone passou a ser obrigat�rio
                $this->infCFe->avulsa->fone      = $res_avulsa['fone'];
                $this->infCFe->avulsa->UF        = $res_avulsa['uf'];
                $this->infCFe->avulsa->nDAR      = $res_avulsa['ndar'];
                $this->infCFe->avulsa->dEmi      = $res_avulsa['demi'];
                $this->infCFe->avulsa->vDAR      = $res_avulsa['vdar'];
                $this->infCFe->avulsa->repEmi    = $res_avulsa['repemi'];
                $this->infCFe->avulsa->dPag      = $res_avulsa['dpag'];
            }

            //dest
            $res_dest = $res_infCFe['dest'];
            if (count((array)$res_dest)) {

                $this->infCFe->dest->CNPJ       = $res_dest['cnpj'];
                if ( (int) $GLOBALS["_VERSAO_CFE"] >= 8 && !empty($res_dest['cpf'])) { // LAYOUTCFE-2 tratando CPF para o novo layout 0.08
                    $this->infCFe->dest->CPF        = funcoesGerais::str_alinha($res_dest['cpf'], 11, DIREITA, false, "0");
                } else {
                    $this->infCFe->dest->CPF        = $res_dest['cpf'];
                }

                $this->infCFe->dest->xNome      = funcoesGerais::limparCampoNotaEletronica(htmlspecialchars_decode($res_dest['xnome'])); //diego 11
            }

            //entrega
            $res_entrega = $res_infCFe['entrega'];
            if (count((array)$res_entrega)) {
                $this->infCFe->add_entrega (new entregaCF);
                $this->infCFe->entrega->CNPJ    = $res_entrega['cnpj'];
                $this->infCFe->entrega->CPF     = $res_retirada['cpf']; //VERS�O 2.0
                $this->infCFe->entrega->xLgr    = $res_entrega['xlgr'];
                $this->infCFe->entrega->nro     = $res_entrega['nro'];
                $this->infCFe->entrega->xCpl    = $res_entrega['xcpl'];
                $this->infCFe->entrega->xBairro = $res_entrega['xbairro'];
                $this->infCFe->entrega->cMun    = $res_entrega['cmun'];
                $this->infCFe->entrega->xMun    = $res_entrega['xmun'];
                $this->infCFe->entrega->UF      = $res_entrega['uf'];
            }

            //det
            $res_det = $res_infCFe['det'];
            if (count((array)$res_det)) {
                for ($i=0; $i<count((array)$res_det); $i++) {
                    //Por algum motivo fica vazio, se estiver vazio cai fora.
                    if (empty($res_det[$i]['nitem'])) {
                        continue;
                    }
                    $this->infCFe->add_det(new detCF);
                    $this->infCFe->det[$i]->nItem     = $res_det[$i]['nitem'];

                    // prod
                    $res_prod = $res_det[$i]['prod'];
                    if (count((array)$res_prod)) {
                        $this->infCFe->det[$i]->prod->cProd     = $res_prod['cprod'];
                        $this->infCFe->det[$i]->prod->cEAN      = $res_prod['cean'];
                        $this->infCFe->det[$i]->prod->cEANTrib  = $res_prod['ceantrib'];
                        $this->infCFe->det[$i]->prod->xProd     = $res_prod['xprod'];
                        //VERS�O 2.0  A regra do NCM mudou ver manual
                        $this->infCFe->det[$i]->prod->NCM       = $res_prod['ncm'];
                        $this->infCFe->det[$i]->prod->CEST      = $res_prod['cest'];
                        $this->infCFe->det[$i]->prod->indEscala = $res_prod['indescala'];
                        $this->infCFe->det[$i]->prod->EXTIPI    = $res_prod['extipi'];
                        $this->infCFe->det[$i]->prod->genero    = $res_prod['genero'];
                        $this->infCFe->det[$i]->prod->CFOP      = $res_prod['cfop'];
                        $this->infCFe->det[$i]->prod->uCom      = $res_prod['ucom'];
                        $this->infCFe->det[$i]->prod->qCom      = $res_prod['qcom'];
                        $this->infCFe->det[$i]->prod->vUnCom    = $res_prod['vuncom'];
                        $this->infCFe->det[$i]->prod->vProd     = $res_prod['vprod'];
                        $this->infCFe->det[$i]->prod->uTrib     = $res_prod['utrib'];
                        $this->infCFe->det[$i]->prod->qTrib     = $res_prod['qtrib'];
                        $res_comb = (!is_null($res_prod['comb']['cprodanp'])) ? $res_prod['comb'] : null;
                        $this->infCFe->det[$i]->prod->codanp = $res_comb['cprodanp'];

                        /**
                         * Nosso VUnTrib vem subtraindo o desconto.
                         * Por�m a nota t�cnica NT 2011/004
                         * GI14a  campo I14a diz que se a multiplica��o for diferente
                         * dar� o erro 630.
                         */
                        if (!empty($res_prod['vuntrib'])) {
                            $this->infCFe->det[$i]->prod->vUnTrib   = $res_prod['vuntrib'];
                        } else {//Se estiver vazio pega o da pr�pria vuncom
                            $this->infCFe->det[$i]->prod->vUnTrib   = $res_prod['vuncom'];
                        }

                        $this->infCFe->det[$i]->prod->vFrete    = $res_prod['vfrete'];
                        $this->infCFe->det[$i]->prod->vSeg      = $res_prod['vseg'];
                        $this->infCFe->det[$i]->prod->vDesc     = $res_prod['vdesc'];
                        //NOTA FISCAL 2.0
                        $this->infCFe->det[$i]->prod->vOutro    = $res_prod['voutro'];
                        $this->infCFe->det[$i]->prod->indTot    = $res_prod['indtot'];

                    } // fim prod


                    //imposto
                    $res_imposto = $res_det[$i]['imposto'];

                    //Valor aproximado total de tributos federais, estaduais e municipais
                    if (!empty($res_det[$i]['imposto']['vtottrib'])) {
                        $this->infCFe->det[$i]->imposto->vTotTrib = $res_imposto['vtottrib'];
                    }
                    //ICMS
                    $res_ICMS    = $res_imposto['icms'];
                    if (count((array)$res_ICMS)) {
                        //Atributo do produto
                        if (intval($res_prod["i01_tipoimposto"])===0 || $this->_versao_nfe <= 2) {
                            $this->infCFe->det[$i]->imposto->add_ICMS(new ICMSCF);
                            if(($GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 1 || $GLOBALS["_CODIGO_REGIME_TRIBUTARIO"] == 2) && !funcoesGerais::managerOFFLine()) {
                                $this->infCFe->det[$i]->imposto->ICMS->Orig      = $res_ICMS['orig_simples'];
                                $this->infCFe->det[$i]->imposto->ICMS->CST       = $res_ICMS['cst_simples'];
                            }else{
                                $this->infCFe->det[$i]->imposto->ICMS->Orig      = $res_ICMS['orig'];
                                $this->infCFe->det[$i]->imposto->ICMS->CST       = $res_ICMS['cst'];
                            }
                            $this->infCFe->det[$i]->imposto->ICMS->pICMS     = $res_ICMS['picms'];
                        }
                    }

                    //PIS
                    $res_PIS = $res_imposto['pis'];
                    if (count((array)$res_PIS)) {//Esse deve aparecer sempre
                        $this->infCFe->det[$i]->imposto->add_PIS(new PISCF);
                        $this->infCFe->det[$i]->imposto->PIS->CST       = $res_PIS['cst'];
                        $this->infCFe->det[$i]->imposto->PIS->vBC       = $res_PIS['vbc'];
                        $this->infCFe->det[$i]->imposto->PIS->pPIS      = $res_PIS['ppis'];
                        $this->infCFe->det[$i]->imposto->PIS->vPIS      = $res_PIS['vpis'];
                        $this->infCFe->det[$i]->imposto->PIS->qBCProd   = $res_PIS['qbcprod'];
                        $this->infCFe->det[$i]->imposto->PIS->vAliqProd = $res_PIS['valiqprod'];
                    }

                    //PISST
                    $res_PISST = $res_imposto['pisst'];
                    if (count((array)$res_PISST)) {
                        if(floatval($res_PISST['vbc'])>0) {
                            $this->infCFe->det[$i]->imposto->add_PISST(new PISSTCF);
                            $this->infCFe->det[$i]->imposto->PISST->vBC       = $res_PISST['vbc'];
                            $this->infCFe->det[$i]->imposto->PISST->pPIS      = $res_PISST['ppis'];
                            $this->infCFe->det[$i]->imposto->PISST->qBCProd   = $res_PISST['qbcprod'];
                            $this->infCFe->det[$i]->imposto->PISST->vAliqProd = $res_PISST['valiqprod'];
                            $this->infCFe->det[$i]->imposto->PISST->vPIS      = $res_PISST['vpis'];
                        }
                    }

                    //COFINS
                    $res_COFINS = $res_imposto['cofins'];
                    if (count((array)$res_COFINS)) {//Esse dever� aparecer sempre
                        $this->infCFe->det[$i]->imposto->add_COFINS(new COFINSCF);
                        $this->infCFe->det[$i]->imposto->COFINS->CST       = $res_COFINS['cst'];
                        $this->infCFe->det[$i]->imposto->COFINS->vBC       = $res_COFINS['vbc'];
                        $this->infCFe->det[$i]->imposto->COFINS->pCOFINS   = $res_COFINS['pcofins'];
                        $this->infCFe->det[$i]->imposto->COFINS->qBCProd   = $res_COFINS['qbcprod'];
                        $this->infCFe->det[$i]->imposto->COFINS->vAliqProd = $res_COFINS['valiqprod'];
                        $this->infCFe->det[$i]->imposto->COFINS->vCOFINS   = $res_COFINS['vcofins'];
                    }

                    //COFINSST
                    $res_COFINSST = $res_imposto['cofinsst'];
                    if (count((array)$res_COFINSST)) {
                        if(floatval($res_COFINSST['vbc'])>0) {
                            $this->infCFe->det[$i]->imposto->add_COFINSST(new COFINSSTCF);
                            $this->infCFe->det[$i]->imposto->COFINSST->vBC       = $res_COFINSST['vbc'];
                            $this->infCFe->det[$i]->imposto->COFINSST->pCOFINS   = $res_COFINSST['pcofins'];
                            $this->infCFe->det[$i]->imposto->COFINSST->qBCProd   = $res_COFINSST['qbcprod'];
                            $this->infCFe->det[$i]->imposto->COFINSST->vAliqProd = $res_COFINSST['valiqprod'];
                            $this->infCFe->det[$i]->imposto->COFINSST->vCOFINS   = $res_COFINSST['vcofins'];
                        }
                    }
                    //Mesmo que coloque aliquota zero dever� mostrar o ISSQNTOT.
                    //ISSQN
                    $res_ISSQN = $res_imposto['issqn'];
                    if (count((array)$res_ISSQN)) {
                        //if(floatval($res_ISSQN['vbc'])>0) {
                        //Atributo do produto
                        if(intval($res_prod["i01_tipoimposto"])===1) {
                            $_imprimiu_issqn = true;
                            $this->infCFe->det[$i]->imposto->add_ISSQN(new ISSQN);
                            $this->infCFe->det[$i]->imposto->ISSQN->vBC       = $res_ISSQN['vbc'];
                            $this->infCFe->det[$i]->imposto->ISSQN->vAliq     = $res_ISSQN['valiq'];
                            $this->infCFe->det[$i]->imposto->ISSQN->vISSQN    = $res_ISSQN['vissqn'];
                            $this->infCFe->det[$i]->imposto->ISSQN->cMunFG    = $res_ISSQN['cmunfg'];
                            $this->infCFe->det[$i]->imposto->ISSQN->cListServ = $res_ISSQN['clistserv'];
                            $this->infCFe->det[$i]->imposto->ISSQN->cSitTrib  = $res_ISSQN['csittrib'];
                        }
                    }

                    //infAdProd
                    $res_infAdProd = $res_det[$i]['infadprod'];
                    if (count((array)$res_infAdProd)) {
                        $this->infCFe->det[$i]->add_infAdProd(new infAdProd);
                        $this->infCFe->det[$i]->infAdProd->infAdProd = $res_infAdProd['infadprod'];
                    }
                }
            }

            //Formas de Pagamentos
            $res_pag = $res_infCFe['pag'];
            if (count((array)$res_pag)) {
                for ($_cont_pag=0; $_cont_pag<count((array)$res_pag); $_cont_pag++) {
                    //Se a tag de valor estiver vazia o sistema dever� pular.
                    if (empty($res_pag[$_cont_pag]['vpag'])) {
                        continue;
                    }
                    $this->infCFe->add_pag(new pagCF);
                    $this->infCFe->pag[$_cont_pag]->tPag     = $res_pag[$_cont_pag]['tpag'];
                    $this->infCFe->pag[$_cont_pag]->vPag     = $res_pag[$_cont_pag]['vpag'];

                    //SAT N�o deve montar essas tags conforme Celso e Val�ria essas tags s�o apenas para NFCe
                    /*$res_pag_card = $res_pag[$_cont_pag]['card'];
                    if (count((array)$res_pag_card)) {
                        $this->infCFe->pag[$_cont_pag]->card->CNPJ     = $res_pag_card['cnpj'];
                        $this->infCFe->pag[$_cont_pag]->card->tBand    = $res_pag_card['tband'];
                        $this->infCFe->pag[$_cont_pag]->card->tpIntegra    = $res_pag_card['tpintegra'];
                        $this->infCFe->pag[$_cont_pag]->card->cAut     = $res_pag_card['caut'];
                    }*/
                }
            }

            //total
            $res_total = $res_infCFe['total'];

            $_chave_cfe = $res_infCFe['emit']['cnpj'] . '#CHAVE_ZANTHUS#' . $res_total . '@' . $this->_id_nota_temp;
            $_chave_cfe = base64_encode(funcoesGerais::criptografaInformacaoPDV($_chave_cfe));

            //infAdic
            $res_infAdic = $res_infCFe['infadic'];
            if($res_infAdic['infcpl'] != '') {
                $res_infAdic['infcpl'] .= ' ' . $_chave_cfe;
            }else{
                $res_infAdic['infcpl'] = ' ' . $_chave_cfe;
            }
            if (count((array)$res_infAdic)) {
                $this->infCFe->add_infAdic (new infAdic);
                $this->infCFe->infAdic->infAdFisco = $res_infAdic['infadfisco'];
                $this->infCFe->infAdic->infCpl     = $res_infAdic['infcpl'];
            }

        } else {
            return false;
        }
        return true;
    }


    /**
     * Retorna o XML ou objeto DOM
     * @param boolean $_formatar Define se formata ou n�o
     * @param boolean $_passar_dom Define se passa o Dom ou n�o
     * @return string
     */
    function get_xml($_formatar=false, $_passar_dom = false) {
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->formatOutput = $_formatar;

        $raiz = $dom->appendChild($dom->createElement('CFe'));

        $raiz->appendChild($this->infCFe->get_xml($dom));
        if ($_passar_dom) {
            return $dom;
        } else {
            $_xml = $dom->saveXML();
            //Se existir algum destes caracteres ser� rejeitado.
            $_xml = str_replace(array("\r","\n","\t"),' ',$_xml);
            return $_xml;
        }
    }

    function assina($_xml, $_tag='', $outDir='') {
        return $_xml;
    }

}
