<?php
/**
 * chkStatus.php
 *
 * Verifica o status do servi�o.
 * O retorno desta chamada sera utilizada para estabelercer se devemos 
 * entrar em contingencia.
 *
 * Este processo deve ser invocado periodicamente (ex. atraves do cron)
 * Ou antes do envio dos arquivos em lote
 *
 * Caso a resposta nao seja "On Line" as outras opera�oes estao suspensas
 * cancelamento, inutuliza�ao, etc..
 *
 * @author   Roberto L. Machado <roberto.machado@superig.com.br>
 * @version  1.0
 * @access   public
**/
/**
require_once('./libs/classNFEtools.php');
require_once('./config_inc.php');
require_once('./libs/basicFunctions.php');
include_once('../../../includes/nusoap.inc');
*/

	$_EXIBE   	   = False;
	$_FSCRIPTS     = true;
	$_FGRAFICOS    = False;
	$_MOSTRAFOOTER = False;
	$_INTERNO 	   = True;
	$_SEMVALIDAR   = True;
	
	echo "Iniciando o processo <br><br>";
	
	chdir("../../../");
	echo "Entrando <br> no diret�rio: " . getcwd() . " <br>" ;
	include_once("includes/header.inc");
	$_objetoNFe 	   = new NFeZanthus();  
	echo "Carregou o objeto.<br><b> Tentando checar status do SEFAZ (isso pode demorar um minuto)</b><br>";
	$_objetoNFe->setVersaoNFe(4);
	
	$_cod_loja = 1;
	
	$_con = $GLOBALS["_MASTER"];
	$_sql = "SELECT L.DES_SIGLA " .
				 	" ,(CASE WHEN (CRT.CODIGO_TOKEN_NFCE IS NOT NULL) THEN
							CRT.CODIGO_TOKEN_NFCE
					   ELSE L.CODIGO_TOKEN_NFCE
					   END) AS CODIGO_TOKEN_NFCE

					   ,(CASE WHEN (CRT.NOME_CERTIFICADO_DIGITAL IS NOT NULL) THEN
							CRT.NOME_CERTIFICADO_DIGITAL
					   ELSE L.NOME_CERTIFICADO_DIGITAL
					   END) AS NOME_CERTIFICADO_DIGITAL

					   ,(CASE WHEN (CRT.SENHA_CERTIFICADO_DIGITAL IS NOT NULL) THEN
							CRT.SENHA_CERTIFICADO_DIGITAL
					   ELSE L.SENHA_CERTIFICADO_DIGITAL
					   END) AS SENHA_CERTIFICADO_DIGITAL
					   ,L.FLG_TIPO_AMBIENTE_NFE  " .
		 			" FROM tab_loja L  " . $_con->noLock() .
					" LEFT JOIN TAB_CERTIFICADO_DIGITAL CRT " . $_con->noLock() .
					" ON (L.COD_CERTIFICADO_DIGITAL = CRT.COD_CERTIFICADO) " .
		 			" WHERE  (L.COD_LOJA= {$_cod_loja}) " ;
					
	$_con->executa($_sql);
	$_dados = $_con->retornarApenasUmRegistro();
 	$_objetoNFe->set_nome_certificado($_dados["NOME_CERTIFICADO_DIGITAL"]);
	$_objetoNFe->set_senha_certificado($_dados["SENHA_CERTIFICADO_DIGITAL"]);
 	$_objetoNFe->set_flg_tipo_ambiente_nfe($_dados["FLG_TIPO_AMBIENTE_NFE"]);


	$_siglaUF = $_dados["DES_SIGLA"];

	$_objetoNFe->modelo   = 65;
	$_objetoNFe->cUF	  = funcoesGerais::$_cod_uf_sefaz[$_siglaUF];	
	//if ( $_objetoNFe->carregarVariaveis()){
		/**
		 * Para saber qual o c�digo do estado que deseja pesquisar. 
		 * site abaixo.
		 * 
		 * 
		 * http://www.ibge.gov.br/home/geociencias/areaterritorial/principal.shtm
		 * 
		 */
		$_objetoNFe->UFcod = $_objetoNFe->cUF;
		$_estado		   = $_siglaUF;
		
		echo "<br><h1>Testando o estado <strong>{$_objetoNFe->UFcod} - {$_estado} </strong></h1><br><br>";
		$_objetoNFe->cUF   = $_objetoNFe->UFcod;

	    $retorno = $_objetoNFe->statusServico(true,$_estado);
	    if ($retorno) {
	        echo "Servi�o ON line <BR>";
	        echo "Tempo M�dio de Resposta : ".$_objetoNFe->tMed.' s<BR>';
	        echo "Verificado em : ".date('d/m/Y H:i:s',$_objetoNFe->dhRecbto).'<BR>';
	    } else {
	        echo "OFF LINE .... Servi�o PARADO!!!<BR>";
	        echo "Verificado em : ".date('d/m/Y H:i:s',$_objetoNFe->dhRecbto).'<BR>';
	        echo "Codigo  : ".$_objetoNFe->cStat.'<BR>';
	        echo "Motivo : ".$_objetoNFe->xMotivo.'<BR>';
	        echo "Obs : ".$_objetoNFe->xObs.'<BR>';
	        echo '<pre>' . htmlspecialchars( $_objetoNFe->debug_str ,null,"ISO-8859-1") . '</pre>';
	    }
	    echo "</BR>------------------------------------" . 
	    	 "</BR>Analise: </br><pre>" . var_export($_objetoNFe,true) . "</pre>";
	/*} else {
	    //houve erro com o certificado
	    echo $_objetoNFe->errorCod.' :  '.$_objetoNFe->errorMsg.'<BR>';
	}*/

?>
