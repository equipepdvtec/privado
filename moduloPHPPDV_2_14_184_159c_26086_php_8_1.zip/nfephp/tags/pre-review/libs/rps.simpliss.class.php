<?php
/**
 * @author: Filipe Barros
 * @data: 27/06/2016
 */
		
include_once('nfephp/tags/pre-review/libs/danfe.class.paisagem.php');

class rps_simpliss extends danfe_paisagem{
	private $_obj_integrador = null;
	//Dados da nota
	private $_numero_nota;
	private $_data_emissa;
	private $_cod_verificacao;
	
	//Dados Prestador
	private $_cpfcnpj_prestador;
	private $_nome_prestador;
	private $_nome_fantasia_prestador;
	private $_end_prestador;
	private $_complemento_prestador;
	private $_bairro_prestador;
	private $_mun_prestador;
	private $_sigla_prestador;
	private $_cep_prestador;
	private $_tel_prestador;
	private $_email_prestador;
	private $_insc_mun;
	
	//Dados Tomador
	private $_nome_tomador;
	private $_cpfcnpj_tomador;
	private $_end_tomador;
	private $_tel_tomador;
	private $_emailtomador;
	private $_complemento_tomador;
	private $_bairro_tomador;
	private $_mun_tomador;
	private $_sigla_tomador;
	private $_cep_tomador;
	private $_regime_especial; 	    
	private $_simples_nacional; 	    
	private $_incentivo_cultura;
	private $_competencia;
	private $_naturezaoperacao;
	
	//Info adicionais
	private $_discriminacao;
	private $_info_adicionais;
	
	//Atividade
	private $_num_atividade;
	private $_desc_atividade;
	
	//Impostos
	private $_valor_pis;
	private $_valor_cofins;
	private $_valor_inss;
	private $_valor_ir;
	private $_valor_csll;
	
	private $_valor_servicos;
	private $_desc_incondicionado;
	private $_retencoes_federais;
	private $_issqn_retido;
	private $_valor_liquido;
	//private $_local_prestado;
	private $_local_imposto;
	private $_valor_nota;
	private $_deducoes;
	private $_base_calculo;
	private $_aliquota;
	private $_impostos_issqn;
	private $_desconto_total;
	private $_desconto_condicionado;
	private $_num_rps;
	private $_info_importante;
	private $_link_nota;
    private $_array_municipio = null;
    
    private $_tamanho_itens = 62;
    private $_altura = 0;
    private $_url = "sem url";
	
	function __construct($_dados, $formato="P", $protocolo="",$logo="",$_issqn=false, $_info_adicionais = null, $_obj_integrador = null) {
		$this->setObjIntegrador($_obj_integrador);
		//Removo pra conseguir ler.
		$_dados["DSC_XML_NFS"]  = str_replace("tipos:", "", $_dados["DSC_XML_NFS"]);

		$_obj   = simplexml_load_string($_dados["DSC_XML_RETORNO_NFS"]);


		//CPF/CNPJ
		$_cpf_cnpj_prestador 	= funcoesGerais::AplicaMascara($_obj->CompNfse->Nfse->InfNfse->PrestadorServico->IdentificacaoPrestador->Cnpj,"99.999.999/9999-99");
		$_cpf_cnpj_tomador 		= (!empty($_obj->CompNfse->Nfse->InfNfse->TomadorServico->IdentificacaoTomador->CpfCnpj->Cpf) ? funcoesGerais::AplicaMascara($_obj->CompNfse->Nfse->InfNfse->TomadorServico->IdentificacaoTomador->CpfCnpj->Cpf,"999.999.999-99") : funcoesGerais::AplicaMascara($_obj->CompNfse->Nfse->InfNfse->TomadorServico->IdentificacaoTomador->CpfCnpj->Cnpj,"99.999.999/9999-99"));
		
		//Data emissao
		$_data_emissao = explode("T", $_obj->CompNfse->Nfse->InfNfse->DataEmissaoRps); //Separa hor�rio
		$_data_emissao = str_replace("-", "/", $_data_emissao[0]);
		
		$_dados["UF"] . $_dados["IBGE_LOJA"];

		//Munic�pio Prestado
		$_mun_prestador = $_dados["MUNICIPIOPRESTACAODESCRICAO"];
		$_mun_incidencia = $_mun_prestador; 
		
		//Munic�pio Prestador
		$_mun_tomador 	= $_dados["CIDACLIENTE"];
		$this->_url     = $this->getObjIntegrador()->getURLNFe();
		
		
		//Pegando os dados do XML
		$this->_numero_nota				= $_dados["NUM_NFSE"];
		$this->_data_emissa				= $_data_emissao;
		$this->_cod_verificacao			= $_dados["COD_VERIFICACAO"];
		$this->_cpfcnpj_prestador		= $_cpf_cnpj_prestador;
		$this->_nome_prestador			= $_dados["DES_LOJA"];
		$this->_nome_fantasia_prestador = $_dados["DES_FANTASIA"];
		$this->_end_prestador			= $_dados["DES_ENDERECO"].", ".$_dados["NUMERO"];
		$this->_bairro_prestador		= $_dados["DES_BAIRRO"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Bairro;
		$this->_complemento_prestador	= $_obj->CompNfse->Nfse->InfNfse->PrestadorServico->Endereco->Complemento;		
		$this->_mun_prestador			= $_mun_prestador;//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->CodigoMunicipio;
		$this->_sigla_prestador			= $_dados["DES_SIGLA"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Uf;
		$this->_cep_prestador			= funcoesGerais::AplicaMascara($_dados["NUM_CEP"],'99.999-999');//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Cep;
		$this->_insc_mun				= $_obj->CompNfse->Nfse->InfNfse->PrestadorServico->IdentificacaoPrestador->InscricaoMunicipal;
		$this->_tel_prestador			= funcoesGerais::retornarNumeros($_dados["NUM_FONE"]);
		$this->_nome_tomador			= $_dados["NOMECLIENTE"];
		$this->_email_prestador         = $_dados["EMAIL_PRESTADOR"];
		$this->_cpfcnpj_tomador			= $_cpf_cnpj_tomador;
		$this->_end_tomador				= $_obj->CompNfse->Nfse->InfNfse->TomadorServico->Endereco->Endereco;
		$this->_tel_tomador 			= $_dados["TELCLIENTE"];
		$this->_emailtomador		    = strtolower($_dados["DES_EMAIL"]);
		$this->_bairro_tomador			= $_obj->CompNfse->Nfse->InfNfse->TomadorServico->Endereco->Bairro;
		$this->_mun_tomador				= $_mun_tomador;//$_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->CodigoMunicipio;
		$this->_complemento_tomador	    = $_obj->CompNfse->Nfse->InfNfse->TomadorServico->Endereco->Complemento;		
		$this->_sigla_tomador			= $_obj->CompNfse->Nfse->InfNfse->TomadorServico->Endereco->Uf;
		$this->_cep_tomador				= funcoesGerais::AplicaMascara($_obj->CompNfse->Nfse->InfNfse->TomadorServico->Endereco->Cep,'99.999-999');
		$this->_discriminacao			= str_replace(array("\\n","\s"),"",$_obj->CompNfse->Nfse->InfNfse->Servico->Discriminacao);
		$this->_discriminacao			= str_replace("\\n","",$this->_discriminacao);
		$this->_discriminacao			= str_replace(array("\\","\n","\s"),"",$this->_discriminacao);
        if ($_dados["MSG_DADOS_ADICIONAIS_NF"] != NULL){
            $this->_discriminacao .= "\n" . $_dados["MSG_DADOS_ADICIONAIS_NF"];
        }
        $this->_discriminacao = substr($this->_discriminacao, 0, 1999);
		//$this->_info_adicionais			= $_obj->OutrasInformacoes;
		$this->_num_atividade			= $_obj->CompNfse->Nfse->InfNfse->Servico->CodigoTributacaoMunicipio;
		$this->_desc_atividade			= $_obj->CompNfse->Nfse->InfNfse->Servico->Discriminacao;
		$this->_valor_pis				= 0.00;
		$this->_valor_cofins			= 0.00;
		$this->_valor_inss				= 0.00;
		$this->_valor_ir				= 0.00;
		$this->_valor_csll				= 0.00;
		$this->_valor_servicos			= funcoesGerais::ConverterParaNumero($_obj->CompNfse->Nfse->InfNfse->Servico->Valores->ValorServicos,2);
		$this->_desc_incondicionado		= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->DescontoIncondicionado,2);
		$this->_retencoes_federais		= funcoesGerais::ConverterParaNumero($this->_valor_pis + $this->_valor_cofins + $this->_valor_inss + $this->_valor_ir + $this->_valor_csll, 2);
		$this->_issqn_retido			= funcoesGerais::ConverterParaNumero(0, 2);
		$this->_valor_liquido			= funcoesGerais::ConverterParaNumero($_obj->CompNfse->Nfse->InfNfse->Servico->Valores->ValorLiquidoNfse, 2);
		//$this->_local_prestado			= $_mun_prestado;
		$this->_local_imposto			= $_mun_incidencia;
		$this->_regime_especial 	    = $_obj->CompNfse->Nfse->InfNfse->RegimeEspecialTributacao;
		$this->_simples_nacional 	    = $_obj->CompNfse->Nfse->InfNfse->OptanteSimplesNacional;		
		$this->_incentivo_cultura	    = $_obj->CompNfse->Nfse->InfNfse->IncentivadorCultural;
		$this->_competencia				= $_obj->CompNfse->Nfse->InfNfse->Competencia;
		$this->_naturezaoperacao        = $_obj->CompNfse->Nfse->InfNfse->NaturezaOperacao;

		
		$this->_valor_nota				= funcoesGerais::ConverterParaNumero($this->_valor_servicos - $this->_desc_incondicionado, 2);
		$this->_deducoes				= funcoesGerais::ConverterParaNumero($_obj->CompNfse->Nfse->InfNfse->Servico->Valores->ValorDeducoes, 2);
		$this->_base_calculo			= funcoesGerais::ConverterParaNumero($_obj->CompNfse->Nfse->InfNfse->Servico->Valores->BaseCalculo, 2);
		$_codigo_Municipio = $_obj->CompNfse->Nfse->InfNfse->PrestadorServico->Endereco->CodigoMunicipio;
		if (($_codigo_Municipio == 3541406 ) || ($_codigo_Municipio == 3538709) || ($_codigo_Municipio == 4202008)){
            $this->_aliquota				= (string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->Aliquota;
            $this->_impostos_issqn			= funcoesGerais::ConverterParaNumero(((string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->Aliquota * (string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->IssRetido) / 100 , 2);
        }else{
            $this->_aliquota				= (string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->Aliquota * 100;
            $this->_impostos_issqn			= funcoesGerais::ConverterParaNumero((string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->Aliquota * (string)$_obj->CompNfse->Nfse->InfNfse->Servico->Valores->IssRetido , 2);
        }

		$this->_desconto_total			= funcoesGerais::ConverterParaNumero($this->_desc_incondicionado, 2);
		$this->_desconto_condicionado   = 0.00;
		$this->_num_rps					= $_obj->CompNfse->Nfse->InfNfse->IdentificacaoRps->Numero;
		/*$this->_info_importante 		= Array("- Nota fiscal referente o RPS N� ". $_obj_retorno->IdentificacaoRps->Numero,
										  "- A autenticidade desta Nota Fiscal pode ser verificada na p�gina da Prefeitura em www.goiania.go.gov.br.");*/
		/*$this->_link_nota 				= "http://www2.goiania.go.gov.br/sistemas/snfse/asp/snfse00200w0.asp?nota=";*/

        $xml = null;
		parent::__construct($xml, $formato, $protocolo, $logo, $_issqn);
    }
    
    /**
     * Setamos o objeto integrador.
     * @param oject $_value
     */
    public function setObjIntegrador($_value) {
    	$this->_obj_integrador = $_value;
    }
    
    /**
     * Objeto integrador
     * @param obje $_value
     */
    public function getObjIntegrador() {
    	return $this->_obj_integrador;
    }
    /**
     * Gera o PDF se a vari�vel retornar_buffer estiver como true
     * retorna o buffer do pdf sen�o tenta mandar por download o arquivo.
     *
     * @param unknown_type $_retonar_buffer
     * @return unknown
     */
    function gerarRPS($_retonar_buffer=false){
    	$this->AddPage();
    	
    	$this->montarDadosPrestador();
    	$this->montarDadosTomador();
    	
    	$this->montarDadosDiscriminacao();
    	$this->montarDadosTributosFederais();
    	$this->montarDadosValores();
    	
    	/**
    	 * PARA TESTE
    	 */
    	//$_retonar_buffer = false;
    	
    	if($_retonar_buffer===false) {
    		$this->Output("danfe.pdf","I");
    	} else {
    		return $this->Output("danfe.pdf","D");
    	}
    }
    
    /**
     * Cabe�alho da nota, m�todo herdado
     * (non-PHPdoc)
     * @see danfe_paisagem::Header()
     */
    function Header(){
    	$this->montarCabecalho();
    }
    
    /**
     * Rodap� da nota, m�todo heradado
     * @see danfe_paisagem::Footer()
     */
    function Footer(){
    	$this->montarRodape();
    }
    
    /**
     * Todo o conte�do daqui deve ir no cabe�alho da nota.
     */
    private function montarCabecalho(){

		$_altura_cabecalho = 23;
    	//Padr�o busco logo direto do portal
   		$this->linha($_altura_cabecalho, 37,  10.0,  10, "TBRL", "", "Arial,B,12,C");    	
    	if (empty($this->logomarca)) {
    		//$this->logomarca = 'http://www.goiania.go.gov.br/Imagem/Brasaogyn_cor.gif';
    		//$this->logomarca = "C:/SandBoxes/manager_1_11_38_1/plugin/nfse/integradores/GISS/guarulhos.gif";
    		$_mun_image = funcoesGerais::removerLatinCharacters($this->_mun_prestador);
    		$_mun_image = strtolower($_mun_image);
    		$_mun_image = str_replace(" ", "_", $_mun_image);
    		
    		$this->logomarca = "plugin/nfse/integradores/PTA/" . $_mun_image. ".gif";
    		//funcoesGerais::GravaLog("nome imagem {$this->logomarca}",true,true);
    		if (file_exists($this->logomarca)) {
	    		$this->Image($this->logomarca, $this->getMargemEsquerda(18), $this->getMargemTop(11), 0, 18, 'gif');
    		}
    	} else {
    		//Base 64
    		$_decode_img 		= base64_decode($this->logomarca);
    		if(isset($this->logomarca)) {
    			$this->Image($this->logomarca, $this->getMargemEsquerda(18), $this->getMargemTop(11), 0, 18);
    		} else {
    			new Exception("Erro ao gerar arquivo tempor�rio(logo).");
    		}
    	}
    	
    	//Esquerda
    	$this->linha($_altura_cabecalho, 155,  10.0,  10, "TBRL", "", "Arial,B,12,C");
    	$this->linha(20.0, 130.0,  40.0,  11, "", "PREFEITURA MUNICIPAL DE {$this->_mun_prestador}", "Arial,,10,C");
    	$this->linha(7.5,  130.0,  40.0,  16,     "", "SECRETARIA DE FAZENDA","Arial,,10,C");
    	$this->linha(7.5,  130.0,  40.0,  21,     "", "NOTA FISCAL ELETR�NICA DE SERVI�OS - NFS-e","Arial,,10,C");

    
    	//Direita
    	$this->linha($_altura_cabecalho, 190.0, 10, 10, "TBRL", "", "Arial,B,14,L");
  	    $this->linha(15, 23, 171, 8,"", "", "", "N�mero da",   "Arial,,14,C");
  	    $this->linha(15, 23, 171, 13.5,"", "", "", "NFS-e",   "Arial,,14,C");  	    
    	$this->linha(15, 23, 171,  20.7, "", "", "", $this->_numero_nota,   "Arial,B,16,C");
		//$this->SetFillColor(230,230,230);
    	//$this->setXY(37, 10);
		
		///////////////////////////////////////////////////////////////////////////////////////////////////

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(10, 33);
		//Largura, Altura
    	$this->Cell(37, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 37, 10,  33, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 37, 10,  34, "", "Data e Hora da Emiss�o",   "Arial,,8.5,C");

     	$this->linha(6, 30, 47,  33, "TBRL", "", "", "",   "Arial,,8.5,C");     	
     	$this->linha(6, 30, 47,  34, "", $this->_data_emissa,   "Arial,,8.5,C");

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(77, 33);
		//Largura, Altura
    	$this->Cell(27, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 27, 77,  33, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 27, 77,  34, "", "Compet�ncia",   "Arial,,8.5,C");

     	$this->linha(6, 27, 104,  33, "TBRL", "", "", "",   "Arial,,8.5,C");     	
     	$this->linha(6, 27, 104,  34, "", substr($this->_data_emissa,0,10),   "Arial,,8.5,C");
     	

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(131, 33);
		//Largura, Altura
    	$this->Cell(37, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 37, 131,  33, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 37, 131,  34, "", "C�digo de Verifica��o",   "Arial,,8.5,C");

     	$this->linha(6, 32, 168,  33, "TBRL", "", "", "",   "Arial,,8.5,C");     	
     	$this->linha(6, 32, 168,  34, "", $this->_cod_verificacao,   "Arial,,8.5,C");     	
     	
     	
		///////////////////////////////////////////////////////////////////////////////////////////////////

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(10, 39);
		//Largura, Altura
    	$this->Cell(37, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 37, 10,  39, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 37, 10,  40.5, "", "N�mero do RPS",   "Arial,,8.5,C");

     	$this->linha(6, 30, 47,  39, "TBRL", "", "", "",   "Arial,,8.5,C");     	
     	$this->linha(6, 30, 47,  40.5, "", $this->_num_rps,   "Arial,,8.5,C");

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(77, 39);
		//Largura, Altura
    	$this->Cell(27, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 27, 77,  39, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 27, 77,  40.5, "", "No. da NFS-e substitu�da",   "Arial,,6,C");

     	$this->linha(6, 27, 104,  39, "TBRL", "", "", "",   "Arial,,8.5,C");     	
     	$this->linha(6, 27, 104,  40.5, "", "",   "Arial,,8.5,C");
     	

		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY(131, 39);
		//Largura, Altura
    	$this->Cell(37, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 37, 131,  39, "TBRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha(6, 37, 131,  40.5, "", "Local de Presta��o",   "Arial,,8.5,C");

     	$this->linha(6, 32, 168,  39, "TBRL", "", "", "",   "Arial,,8.5,C");     
     	$this->linha(6, 32, 168,  40.5, "", $this->_mun_prestador . " - " . $this->_sigla_prestador,   "Arial,,5,C");
     	
		$this->_altura += 6;



    	/*$this->setXY(146, 22);
    	$this->Cell(15, 0, "Data Emiss�o");
    	$this->setXY(146, 27);
    	$this->Cell(15, 0, "C�digo Verifica��o");*

    	/*$this->linha($this->altura_padrao, 20, 175, 16.9, "", "", "", $this->_data_emissa, "Arial,B,9,L");
    	$this->linha($this->altura_padrao, 20, 175, 21.9, "", "", "", $this->_cod_verificacao, "Arial,B,9,L");
    	*/
    }
    
    /**
     * Monta os dados do prestador no PDF
     * Informa��es da empresa que est� emitindo a nota
     */
    private function montarDadosPrestador(){
    	$this->_altura = 45;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "Prestador de Servi�o", "Arial,,12,C");    	

    	$this->_altura += 6;
    	
    	
    	//////////////////////////////////////////////////////Prestador...
    	//Caixa..
		$this->SetFillColor(255,255,255);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(30, 27,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	
    	
    	$_pos_esquerda = 37;
    	$_largura 	   = 37;
    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Raz�o Social/Nome", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 126,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 126,  $_pos_esquerda +2,  $this->_altura+1, "", $this->_nome_prestador, "Arial,,8.5,L");    	

		
		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 37;
    	$_largura 	   = 37;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Nome Fantasia", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 126,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 126,  $_pos_esquerda +2,  $this->_altura+1, "", $this->_nome_fantasia_prestador, "Arial,,8.5,L");    			
		
		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 37;
    	$_largura 	   = 20;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "CNPJ/CPF", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 30,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura+1, "", $this->_cpfcnpj_prestador, "Arial,,8.5,C");    			
		    	
	   	
    	$_pos_esquerda += 30;
    	$_largura 	   = 30;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Inscri��o Municipal", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 18,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 18,  $_pos_esquerda,  $this->_altura+1, "", $this->_insc_mun, "Arial,,8.5,C");    	 

   		$_pos_esquerda += 18;
   		$_largura 	   = 16;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Munic�pio", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 49,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 49,  $_pos_esquerda,  $this->_altura+1.5, "", $this->_mun_prestador ." - " . $this->_sigla_prestador, "Arial,,7,C");
	   	
    	///////////////////////////////////
    	
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 37;
    	$_largura 	   = 27;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Endere�o e CEP", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 136,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 136,  $_pos_esquerda,  $this->_altura+1, "", $this->_end_prestador . " - " . $this->_bairro_prestador . " CEP: " . $this->_cep_prestador, "Arial,,8,L");    			

	   	///////////////////    	
		
	   	$this->_altura 	  += 6;   
    	$_pos_esquerda = 37;
    	$_largura 	   = 27;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Complemento", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 30,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura-.5, "", substr($this->_complemento_prestador,  0,10), "Arial,,7.5,C");    			
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura+2.5, "",substr($this->_complemento_prestador, 11,10) , "Arial,,7.5,C");	   	
		    	
	   	
    	$_pos_esquerda += 30;
    	$_largura 	   = 20;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Telefone", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 18,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 18,  $_pos_esquerda,  $this->_altura+1, "", $this->_tel_prestador, "Arial,,7,C");    	 

   		$_pos_esquerda += 18;
   		$_largura 	   = 16;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "e-mail", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 52,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 52,  $_pos_esquerda,  $this->_altura+1, "", $this->_email_prestador, "Arial,,8.5,C");
	   		   	
	   	
	   	
    	
    }
    
    /**
     * Monta os dados do tomador no PDF
     * Informa��es do cliente
     */
    private function montarDadosTomador(){
    	/*
    	$this->linha(30, 190,  10.0,  60, "TBRL", "TOMADOR DOS SERVI�OS", "Arial,B,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	//$this->linha(30, 37.5, 10.0,  60, "TBRL", "", "Arial,B,8.5,L");
    	$this->linha(5, 20, 11.0,  65, "", "Nome/Raz�o Social", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  70, "", "CPF/CNPJ", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  75, "", "Endere�o", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  80, "", "Bairro","Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  85, "", "Munic�pio", "Arial,,9.5,L");
    
    	//S� para utilizar como base os itens do centro
    	//$this->linha(30, 105,   47.5,  30, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(5, 105,   47.5,  65, "", $this->_nome_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  70, "", $this->_cpfcnpj_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  75, "", $this->_end_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  80, "", $this->_bairro_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  85, "", "{$this->_mun_tomador}�{$this->_sigla_tomador}   CEP {$this->_cep_tomador}", "Arial,,9.5,L");
    	*/
    	$this->_altura += 6;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "Tomador de Servi�o", "Arial,,12,C");    	

    	$this->_altura += 6;
    	
    	
    	//////////////////////////////////////////////////////Tomador...
    	
    	
    	$_pos_esquerda = 10;
    	$_largura 	   = 37;
    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Raz�o Social/Nome", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 153,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 153,  $_pos_esquerda,  $this->_altura+1, "", $this->_nome_tomador, "Arial,,8.5,L");    	

		
		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 37;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Nome Fantasia", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 153,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 153,  $_pos_esquerda,  $this->_altura+1, "", "", "Arial,,8.5,L");
		
		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 20;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "CNPJ/CPF", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 30,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura+1, "", $this->_cpfcnpj_tomador, "Arial,,8.5,C");    			
		    	
	   	
    	$_pos_esquerda += 30;
    	$_largura 	   = 30;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Inscri��o Municipal", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 18,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 18,  $_pos_esquerda,  $this->_altura+1, "", "", "Arial,,8.5,C");    	 

   		$_pos_esquerda += 18;
   		$_largura 	   = 16;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Munic�pio", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 76,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 76,  $_pos_esquerda,  $this->_altura+1.5, "", $this->_mun_tomador . " - " . $this->_sigla_tomador, "Arial,,7,C");
	   	
    	///////////////////////////////////
    	
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 27;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Endere�o e CEP", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 163,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 163,  $_pos_esquerda,  $this->_altura+1, "", $this->_end_tomador . " - " . $this->_bairro_tomador . "CEP: " .  $this->_cep_tomador, "Arial,,8,L");    			

	   	///////////////////    	
		
	   	$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 27;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Complemento", "Arial,,8.5,L");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 30,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura-.5, "", substr($this->_complemento_tomador,  0,10), "Arial,,7.5,C");    			
	   	$this->linha(6, 30,  $_pos_esquerda,  $this->_altura+2.5, "",substr($this->_complemento_tomador, 11,10) , "Arial,,7.5,C");	
	   	
		    	
	   	
    	$_pos_esquerda += 30;
    	$_largura 	   = 20;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Telefone", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 18,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 18,  $_pos_esquerda,  $this->_altura+1, "", $this->_tel_tomador, "Arial,,8.5,C");    	 

   		$_pos_esquerda += 18;
   		$_largura 	   = 16;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "e-mail", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 79,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 79,  $_pos_esquerda,  $this->_altura+1, "", $this->_emailtomador, "Arial,,8.5,C");    	
		$this->_altura 	  += 6;  	   	
		
    }
    
    
    /**
     * Dados de tributa��o federal
     */
    private function montarDadosTributosFederais() {
    	$this->_altura += 0;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "Tributos Federais", "Arial,,12,C");    	

		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 19;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "PIS (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_pis, "Arial,,7.5,C");    			

    	$_pos_esquerda += $_largura;
    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "COFINS (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_cofins, "Arial,,7.5,C");    			    	
    	
    	$_pos_esquerda += $_largura;	   	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "IR (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_ir, "Arial,,7.5,C");

	    $_pos_esquerda += $_largura;
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "INSS (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_inss, "Arial,,7.5,C");

	   	$_pos_esquerda += $_largura;
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "CSLL (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_csll, "Arial,,7.5,C");    				   	
	   	
		$this->_altura 	  += 6; 
	   	
    }
    
    
    /**
     * Monta os dados Discrimina��o no PDF
     */
    private function montarDadosDiscriminacao(){
    	//$this->_altura = 117;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "Discrimina��o do Servi�o", "Arial,,12,C");    	

    	$this->_altura += 6;    	

    	$this->linha($this->_tamanho_itens, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
    	
    	//$this->linha(30, 37.5, 10.0,  60, "TBRL", "", "Arial,B,8.5,L");
    	$_texto = wordwrap($this->_discriminacao,90,"\n");

    	$_linhas = explode("\n", $_texto);
    	$_pos = $this->_altura;
    	foreach ($_linhas as $_valor) {
	    	$this->linha(5, 20, 11.0,  $_pos, "", $_valor, "Arial,,9.5,L");
	    	$_pos = $_pos + 5;
	    	if ($_pos >= $this->_tamanho_itens + $this->_altura) {
	    		break;
	    	}
	    }
	    
	    ///////////////////////////
    	$this->_altura = $this->_tamanho_itens + $this->_altura;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "C�digo do Servi�o / Atividade", "Arial,,12,C");    	

    	$this->_altura += 6;    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
    	//$this->linha(6, 190,  10.0,  $this->_altura + 1, "", "5.02 / 3340090 - CLINICA VETERINARIA", "Arial,,8.5,C");    	
    	$this->linha(6, 190,  10.0,  $this->_altura + 1, "", $this->_num_atividade . " - " /*. $this->_desc_atividade*/, "Arial,,8.5,C");    	


	    ///////////////////////////
    	$this->_altura += 6;   
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);
		//Largura, Altura
    	$this->Cell(190, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  10.0,  $this->_altura, "", "Detalhamento Espec�fico da Constru��o C�vil", "Arial,,12,C");    	

    	$this->_altura += 6;   
		
    	////////////////
        //$_pos_esquerda += 10;
        $_pos_esquerda  = 10;
    	$_largura 	    = 30;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "C�digo da Obra", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 60,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 60,  $_pos_esquerda,  $this->_altura+1, "", "", "Arial,,8.5,C");    	 	

	   	
    	$_pos_esquerda += 60;
    	$_largura 	    = 30;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "C�digo ART", "Arial,,8.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, 70,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 70,  $_pos_esquerda,  $this->_altura+1, "", "", "Arial,,8.5,C");    	 	
	   	
		$this->_altura += 6; 	    	
	    
    }
    
    
    /**
     * Valores e impostos
     */
    public function montarDadosValores(){
    	$this->_altura += 0;    	
    	$this->SetFillColor(147,147,147);
    	//Horizontal, Vertical
		$this->setXY(10, $this->_altura);

		$_pos_esquerda  = 10;
    	$_largura 	    = 83.33;
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1.5, "", "Detalhamento de Valores - Prestador do Servi�o", "Arial,,7,C");    	

    	$this->SetFillColor(147,147,147);
		$_pos_esquerda  += $_largura ;
    	$_largura 	     = 30.7;    	
    	
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1.5, "", "Outras Informa��es", "Arial,,7,C");    



		$_pos_esquerda  += $_largura ;
    	$_largura 	     = 76;    		
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);    	
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1.5, "", "C�lculo do ISSQN devido no Munic�pio", "Arial,,7,C");     	
    	
    	$this->_altura += 6;
    	
    	///////////////////////////////////////////////////////
    	
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Valor do Servi�o R$", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_servicos, "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Natureza Opera��o", "Arial,,6,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Valor do Servi�o R$", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_valor_servicos, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;
		
		/////////////////////////// linha 2
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,L");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Desconto Incondicionado", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_desc_incondicionado, "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(255,255,255);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,6,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_naturezaoperacao . "-Tributa��o no munic�pio", "Arial,,7,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Dedu��es Permitidas em Lei", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_deducoes, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;

		////////////////////////////////////// Linha 3
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Desconto Condicionado", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_desconto_condicionado, "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Regime Especial Tributa��o", "Arial,,6,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Desconto Incondicionado", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_desc_incondicionado, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;		
		
		////////////////////////////////////// Linha 4
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Reten��es Federais", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
		//Essa informa��o n�o vem 
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_retencoes_federais, "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(255,255,255);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_regime_especial, "Arial,,6,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Base de C�lculo", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", $this->_base_calculo, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;
    	
		
		////////////////////////////////////// Linha 5
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) Outras Reten��es", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
		//Esse dado n�o vem no retorno
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "0,00", "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Op��o Simples Nacional", "Arial,,6,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(x) Aliquota %", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "",$this->_aliquota, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;
		
		
		////////////////////////////////////// Linha 6
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "(-) ISSQN Retido", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "0,00", "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(255,255,255);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", ((int) $this->_simples_nacional === 2) ? "{$this->_simples_nacional} - N�o " : $this->_simples_nacional, "Arial,,6,C");


	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "ISSQN a Reter", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "() Sim (X) N�o", "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 6;

		////////////////////////////////////// Linha 7
		
		$_pos_esquerda  = 10;
    	$_largura 	    = 50;
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 12, "", 0, 0, "", true);    	
    	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura+3, "", "(=) Valor Liquido R$", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
    	$_largura		= 33.33;
		$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura+3, "", $this->_valor_liquido, "Arial,,7,C");    	 	
	   	
	   	
    	$_pos_esquerda += $_largura;
    	$_largura       = 30.7;
		$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);       	
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "Incentivador Cultural ", "Arial,,7,C");

		$this->SetFillColor(255,255,255);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura+6);
    	$this->Cell($_largura, 6, "", 0, 0, "", true);  		
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+6, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+7, "", ((int) $this->_incentivo_cultura === 2) ? "{$this->_incentivo_cultura} - N�o " : $this->_incentivo_cultura, "Arial,,7,C");

	   	$_pos_esquerda += $_largura;
	   	$_largura 	    = 42.7;
    	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 12, "", 0, 0, "", true);    	
    	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura+3, "", "(=) Valor do ISSQN R$", "Arial,,7,L");

    	$_pos_esquerda += $_largura;
	   	$_largura 	    = 33.33;    	
		$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7,C");    	
	   	$this->linha(12, $_largura,  $_pos_esquerda,  $this->_altura+3, "", $this->_impostos_issqn, "Arial,,7,C"); 	   	
	   	
	   	
	   	
		$this->_altura += 12;		
    	
    	//Horizontal, Vertical
		/*$this->setXY(73.33, $this->_altura);
		//Largura, Altura
    	$this->Cell(63.33, 6, "", 0, 0, "", true);    	
    	$this->linha(6, 63.33,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 63.33,  10.0,  $this->_altura, "", "Outras Informa��es", "Arial,,12,C");    	
*/
    	/*
    	
		////////////////////
		$this->_altura 	  += 6;   
    	$_pos_esquerda = 10;
    	$_largura 	   = 19;		 	
    	    	    	
    	$this->SetFillColor(204,204,204);
    	//Horizontal, Vertical
		$this->setXY($_pos_esquerda, $this->_altura);
		//Largura, Altura
    	$this->Cell($_largura, 6, "", 0, 0, "", true);    	
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");
    	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "PIS (R$)", "Arial,,7.5,C");

    	$_pos_esquerda += $_largura;
		$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,7.5,C");    	
	   	$this->linha(6, $_largura,  $_pos_esquerda,  $this->_altura+1, "", "0,00", "Arial,,7.5,C");        	
	   	*/
    	/*
    	//Reten��es Federais
     	$this->linha(10, 31.666,  	10.0,  		198, "TBRL", "", "Arial,,8.5,C"); //coluna1
     	$this->linha(10, 31.666,  	10.0,  		199, "", "Reten��es", "Arial,,8.5,C");
     	$this->linha(10, 31.666,  	10.0,  		202, "", "Federais", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	41.666,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna2
    	$this->linha(10, 31.666,  	41.666,  	199, "", "PIS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	41.666,  	202, "", "R$ ".$this->_valor_pis, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	73.3,  		198, "TBRL", "", "Arial,,8.5,C"); //coluna3
    	$this->linha(10, 31.666,  	73.3,  		199, "", "COFINS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	73.3,  		202, "", "R$ ".$this->_valor_cofins, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	104.96,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna4
    	$this->linha(10, 31.666,  	104.96,  	199, "", "INSS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	104.96,  	202, "", "R$ ".$this->_valor_inss, "Arial,,8.5,C");
    	$this->linha(10, 31.666, 	136.62,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna5
    	$this->linha(10, 31.666,  	136.62,  	199, "", "IR", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	136.62,  	202, "", "R$ ".$this->_valor_ir, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	168.28,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna6
    	$this->linha(10, 31.666,  	168.28,  	199, "", "CSLL", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	168.28,  	202, "", "R$ ".$this->_valor_csll, "Arial,,8.5,C");
    		
    	//Demonstrativo
    	$this->linha(40, 95,  10.0,  	208, "TBRL", "Demonstrativo", "Arial,,9.5,C");
    	$this->linha(40, 40,  11.0,  	214, "", "Valor dos Servi�os", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	214, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	214, "", $this->_valor_servicos, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	218, "", "(�)  Desconto Incondicionado", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		218, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	218, "", $this->_desc_incondicionado, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	222, "", "(�)  Reten��es Federais", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		222, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	222, "", $this->_retencoes_federais, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	226, "", "(�)  ISSQN Retido pelo Tomador", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		226, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	226, "", $this->_issqn_retido, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	230, "", "(=) Valor L�quido", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		230, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	230, "", $this->_valor_liquido, "Arial,,9.5,R");
    	$this->linha(11, 47.5,  10.0,  	237, "TBRL", "Servi�o prestado em", "Arial,,9.5,C");
    	$this->linha(11, 47.5,  10.0,  	242, "", "$this->_local_prestado", "Arial,B,8,C");
    	$this->linha(11, 47.5,  57.5,  	237, "TBRL", "Imposto devido em", "Arial,,9.5,C");
    	$this->linha(11, 47.5,  57.5,  	242, "", "$this->_local_imposto", "Arial,B,8,C");
    	
    	//C�lculo do imposto
    	$this->linha(40, 95,  105.0,  208, "TBRL", "C�lculo do imposto", "Arial,,8.5,C");
    	$this->linha(40, 40,  106.0,  218, "", "Valor dos Servi�os", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  218, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  218, "", $this->_valor_servicos, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  222, "", "(�)  Desconto Incondicionado", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  222, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  222, "", $this->_desc_incondicionado, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  226, "", "(=) Valor da Nota", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  226, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  226, "", $this->_valor_nota, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  230, "", "(�)  Dedu��es", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  230, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  230, "", $this->_deducoes, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  234, "", "(=) Base de C�lculo ", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  234, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  234, "", $this->_base_calculo, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  238, "", "(x) Al�quota ", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  238, "", "%", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  238, "", $this->_aliquota, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  242, "", "(=) Valor do Imposto (ISSQN)", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  242, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  242, "", $this->_impostos_issqn, "Arial,,9.5,R");
    	
    	//Totais
    	//$this->linha(10, 190,  		10.0,  		248, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(10, 63.33,  	10.0,  		248, "TBRL", "Valor dos Servi�os", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	10.0,  		252, "","R$ ".$this->_valor_servicos, "Arial,,9.5,C");
    	$this->linha(10, 63.33,  	73.33,  	248, "TBRL", "Desconto", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	73.33,  	252, "","R$ ".$this->_desconto_total, "Arial,,9.5,C");
    	$this->linha(10, 63.33,  	136.66,  	248, "TBRL", "Valor da Nota", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	136.66,  	252, "","R$ ".$this->_valor_nota, "Arial,B,12,C");
    	*/
    }
    
    /**
     * Rodap�
     * Informa��es importantes e o link da nota
     */
    public function montarRodape(){
    	$_pos_esquerda = 20;
    	$_largura  	   = 10;
    	$this->linha(10, $_largura,  10,  $this->_altura, "TBRL", "", "Arial,B,8,L");
    	$this->linha(10, $_largura,  10.5,  $this->_altura + 3, "", "Avisos", "Arial,,8,L");    	
    	
    	$_larg_tot = 190 - $_largura;
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,L");
    	//Informa��es importantes
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "", "1- Uma via desta Nota Fiscal ser� enviada atrav�s do e-mail fornecido pelo Tomador do Servi�o.", "Arial,,6,L");
		$this->_altura += 2;
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "", "2- A autenticidade desta Nota Fiscal poder� ser verificada no site, {$this->_url} com a utiliza��o do C�digo de Verifica��o.", "Arial,,6,L");
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura + 6, "", "", "Arial,,8.5,L");    	
    	 

    }
}
?>