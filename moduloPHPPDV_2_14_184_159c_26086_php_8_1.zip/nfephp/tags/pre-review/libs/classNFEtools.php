<?php
/**
 *
 * NFEtools
 * Copyright (c) 2009 Roberto L. Machado
 *
 * AGRADECIMENTOS
 *      Sr. Dajalma Fadel Junior (por suas valiosas contribui��es ao desenvolvimento deste projeto)
 *
 * ================================================
 * Assinador funcional 2009-07-04
 * Carga do certificado funcional 2009-07-22
 *
 * ================================================
 * Depend�ncias

 *      module PHP5-curl
 *      module OpenSSL
 *      class NUSoap
 *      class FPDF
 *
 * @author   Roberto L. Machado <roberto.machado@superig.com.br>
 *
 * @license  http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @version  $Id:
 * @access   public
**/

//S� para conseguir testar, isso � in�til
$_dir_corrente = getcwd();
if(Zstripos($_dir_corrente,"pre-review")!==false) {
	chdir("../../../");
}
//No ManagerOFFLine n�o vai imprimir PDF.
if (!funcoesGerais::managerOFFLine()) {
	//require_once('nfephp/tags/pre-review/libs/nusoap/nusoap.php');
	require_once(funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/fpdf.php');
}

if(Zstripos($_dir_corrente,"pre-review")!==false) {
	chdir($_dir_corrente);
}

define('HOMOLOGACAO','2');
define('PRODUCAO','1');
define('CONTINGENCIAHOMOLOGACAO','4');
define('CONTINGENCIAPRODUCAO','3');


class NFEtools {

    //*************************
    // Propriedades
    //*************************
    //Criado para contar as conversas com o WS
    public static $_contador_conversas = 0;

    /**
     * Se sair por timeout de resposta, quando for via ws (n�o mirage)
     * vamos consultar a nota pra ver se esta dispon�vel.
     *
     * @var bool
     */
    public static $_saiu_por_timeout_de_resposta = false;
	//Arquivo gerado para controlar o nome do certificado.
	var $nome_local_cert = "";
        /**
	 * Ambiente de conexao com o webservie
	 * Esta propriedade deve ser setada na inicialização da classe
	 * @var string $ambiente
	 * @access public
	 */
    public $ambiente="0"; //homologa��o

    /**
     * Se estiver true for�a a releitura do certificado sempre.
     * Uso isso para a tela de cadastro de certificado digital
     * @var bool
     */
    protected $_forcar_releitura = false;
        /**
     * Vari�vel utilizada para armazenad o �ltimo nome de certificado
     * @var string
     */
    private $_ultimo_nome_cert = "";
        /**
         * Contem os dados para debug do NuSoap
         * @var string $debug_str
         * @access public
         */
    var $debug_str = '';

    public $_obj_memcache = null;
    var $erroEncontradoCertificadoDigital=false;

    /**
     * Data de validade do contrato.
     * @var timestamp
     */
    var $_data_validade = null;


    /**
     * Tempo de processamento soap.
     * Tempo de espera ap�s conectado.
     * @var int
     */
    var $soapTimeout=null;
    /**
     * Tempo pra conectar ao ponto
     * @var int
     */
    var $tempo_conectar = 10;//Tempo Conectar

    var $erro_http = null;
        /**
    	 * URLs dos webservice
	 * NOTA : Estes dados deve ser dinâmicamente carregados pelo sistema
         * com base em um banco de dados para tornar o sistema mais flexível
	 *
	 * @var array $aURLwsdl
	 * @access public
	 */
    /*
    var $aURLwsdl=array(
                    'ConsultaCadastro'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeWEB/services/cadconsultacadastro.asmx',
                    'NfeRecepcao'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nferecepcao.asmx',
                    'NfeRetRecepcao'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nferetrecepcao.asmx',
                    'NfeCancelamento'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nfecancelamento.asmx',
                    'NfeInutilizacao'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nfeinutilizacao.asmx',
                    'NfeStatusServico'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nfestatusservico.asmx',
                    'NfeConsultaNF'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nfeconsulta.asmx'
                    );
	*/
    var $aURLwsdl=array(
					'ConsultaCadastro'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/CadConsultaCadastro.asmx',
					'NfeRecepcao'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/NfeRecepcao.asmx',
					'NfeRetRecepcao'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/NfeRetRecepcao.asmx',
					'NfeCancelamento'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/NfeCancelamento.asmx',
					'NfeInutilizacao'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/NfeInutilizacao.asmx',
					'NfeStatusServico'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/nfestatusservico.asmx',
					//'NfeStatusServico'=>'https://homologacao.nfe.sefazvirtual.rs.gov.br/ws/nfestatusservico/nfestatusservico.asmx',
					//'NfeStatusServico'=>'https://homologacao.nfe.fazenda.sp.gov.br/nfeweb/services/nfestatusservico.asmx',
					'NfeConsultaNF'=>'https://hnfe.sefaz.ba.gov.br/webservices/nfe/NfeConsulta.asmx'
					);

	/**
	 * Funçoes do webservice
	 * NOTA : Estes dados deve ser dinâmicamente carregados pelo sistema
         * com base em um banco de dados para tornar o sistema mais flexível
	 *
	 * @var      array
	 * @access   public
	**/
    var $aFunctionWdsl=array(
                    'ConsultaCadastro'=>'consultaCadastro',
                    'NfeRecepcao'=>'nfeRecepcaoLote',
                    'NfeRetRecepcao'=>'nfeRetRecepcao',
                    'NfeCancelamento'=>'nfeCancelamentoNF',
                    'NfeInutilizacao'=>'nfeInutilizacaoNF',
                    'NfeStatusServico'=>'nfeStatusServicoNF',
                    'NfeConsultaNF'=>'nfeConsultaNF'
                    );

    var $aSoaActionWdsl=array();
    var $aMetodoWdsl=array();

	/**
	 * Arquivos xsd das funcoes do webservice
	 * NOTA : Estes dados deve ser dinâmicamente carregados pelo sistema
         * com base em um banco de dados para tornar o sistema mais flexível
         *
	 * @var      array
	 * @access   public
	 * ISTO FOI SOBRESCRITO PELA NFE.CLASS.ZANTHUS.PHP
	 **/
     var $aFxsd=array();

	/**
	 * Versoes dos layouts xsd das funcoes do webservice
	 * NOTA : Estes dados deve ser dinâmicamente carregados pelo sistema
         * com base em um banco de dados para tornar o sistema mais flexível
	 * @var      array
	 * @access   public
	 * * ISTO FOI SOBRESCRITO PELA NFE.CLASS.ZANTHUS.PHP
	**/
     var $aVerxsd=array();
     var $aPeer=array();

    /**
     * A nota tecnica diz que o qrcode de impress�o deve ser diferente.
     * Ent�o criei este atributo.
     * @var array
     */
     var $aVerImpressao=array();


        /**
         * Variaveis passadas para a operaçao do sistema
         *
         */

        /**
         * Codigo da UF da empresa emitente
         * @var string
         * @access public
         */
     var $UFcod='29';
        /**
         * Id da NFe com 47 digitos NFe83737377377373...
         * @var string
         * @access public
         */
     var $Id='';
     var $Id_inutilizado='';

        /**
         * Nome do certificado pfx
         * @var string $nameCert
         * @access public
         */
     var $nameCert='';
        /**
         * Senha da chave privada
         * @var string $passKey
         * @access public
         */
     var $passKey='';
        /**
         * Senha de decriptação da chave privada, se houver
         * Normalmente não é usado
         * @var string $passPhrase
         * @access public
         */
     var $passPhrase='';

        /**
         *  caminhos de acesso aos diretorios de armazenamento das comunicações
         *
        **/

        /**
         * Caminho completo para o diretorio que contêm os certificados,
         * em qualquer formato. Será o local onde serão gerados os certificados
         * em formato pem.
         * @var string $pathCerts
         * @access public
         */
     var $pathCerts='';
    /**
     * Gravaremos os arquivos pem em outro lugar,
     * a fim de evitar o problema que ocorre quando a pasta certificados n�o est� montada
     * @var string
     */
     var $pathCerts_pem='';
        /**
         * Caminho para os schemas xsd que serão utilizados para a validação
         * das NFe ou de mensagens
         * @var string
         * @access publico
         */
     var $pathXSD= '';
        /**
         * Caminho para o diretorio de arquivos temporarios.
         * Neste diretorio serão colocados arquivos sem necessidade de backup,
         * como  por exemplo as respostas as consultas de status ao SEFAZ
         * @var string
         * @access public
         */
     var $temporarioNF = '';
        /**
         * Caminho onde são postadas as NFe pelo sistema ERP ou as notas manuais, em xml ou txt
         * para serem assinadas, valclassNFEtoolsidadas e posteriormnte enviadas ao SEFAZ.
         * @var string
         * @access public
         */
     var $entradasNF='';
        /**
         * Caminho para onde são movidas as NFe que já foram assinadas.
         * @var string
         * @access public
         */
     var $assinadasNF='';
        /**
         * Caminho para onde são movidas as NFe assinadas, validadas internamente e já remetidas ao SEFAZ
         * para aprovação.
         * Neste diretorio também srão postadas os retornos do SEFAZ tanto o recibo do envio
         * quanto o retorno da consulta do recibo, que contêm o protocolo de aprovação da NFe
         * @var string
         * @access public
         */
     var $validadasNF='';
        /**
         * Caminho onde são colocadas as NFe retornadas do SEFAZ como aceitas.
         * Estas NFe podem ser impressas DANFE e preparadas para envio ao destinatário
         * @var string
         * @access public
         */
     var $aprovadasNF='';
        /**
         * Caminho onde são mantidas as NFe aprovadas, preparadas e já enviadas ao destinatário
         * @var string
         * @access public
         */
     var $enviadasNF='';
        /**
         * Caminho onde as solicitações de cancelamento e as respostas do cancelamento são armazenadas
         * @var string
         * @access public
         */
     var $canceladasNF='';
        /**
         * Caminho onde as solicitações e as respostas de inutilização são armazenadas
         * @var string
         * @access public
         */
     var $inutilizadasNF='';
        /**
         * Caminho onde são colocadas as NFe qunado são recebidas dos fornecedores
         * @var string
         * @access public
         */
     var $recebidasNF='';
        /**
         * Caminho onde são movidas as NFe recebidas dos fornecedores
         * e já validadas e aprovadas
         * @var string
         * @access public
         */
     var $consultadasNF='';

     /**
      * Armazenaremos informa��es de proxy
      * @var mixed
      */
     var $aProxy=null;


        /**
         *  Retornos de erros do sistema
         */

        /**
         * Estado de erro
         * @var boolean
         * @access public
         */
     var $errorStatus = false;
     var $errorXsd = null;
     var $errorDescricaoXsd = null;
        /**
         * Mensagem de erro
         * @var string
         * @access public
         */
     var $errorMsg='';
        /**
         * Código do erro
         * @var string
         * @access public
         */
     var $errorCod='';

     // retornos dos serviços SEFAZ
        /**
         * Código de retorno do serviço retornado da SEFAZ
         * @var string
         * @access public
         */
     var $cStat = '';
        /**
         * Versão do aplicativo retornado da SEFAZ
         * @var string
         * @access public
         */
     var $verAplic='';
        /**
         * Retorno do XML que ser� gravado no banco (�ber Lincoln - Zanthus).
         * Se esquecermos de gravar algo e precisarmos posteriormente estar� no xml.
         * @var string
         * @access public
         */
     var $respostaXML = '';

     var $envioXML ='';

        /**
         * Motivo relacionado ao código de retorno, retornado da SEFAZ
         * @var string
         * @access public
         */
     var $xMotivo = '';
        /**
         * Cbervações retornado da SEFAZ
         * @var string
         * @access public
         */
     var $xObs = '';
        /**
         * Tempo médio de resposta retornado da SEFAZ
         * @var int
         * @access public
        **/
     var $tMed = '1';
        /**
         * Data e hora do retorno da chamada do webservice retornado da SEFAZ
         * @var string
         * @access public
        **/
     var $dhRecbto = '';
        /**
         * Tipo de ambiente da comunicaçao retornado da SEFAZ
         * @var int
         * @access public
         */
     var $tpAmb = '';
        /**
         * Número do recibo da SEFAZ
         * @var string
         * @access public
         */
     var $nRec = '';
        /**
         * Código da UF retornado da SEFAZ
         * @var int
         * @access public
         */
     var $cUF = '';
        /**
         * Sigla da UF retornado da SEFAZ
         * @var string
         * @access public
         */
     var $UF = '';
        /**
         * Dados de retorno das NFe enviadas no lote retornado da SEFAZ
         * @var array
         * @access public
         */
     var $aNFe = array();

     /**
      * Dados de retorno dos Eventos enviados no lote retornado da SEFAZ
      * @var array
      * @access public
      */
     var $aEvto = array();
        /**
         * Número inicial de NF inutilizada retornado da SEFAZ
         * @var string
         * @access public
         */
     var $nNFIni = '';
        /**
         * Número final de NF inutilizada retornado da SEFAZ
         * @var string
         * @access public
         */
     var $nNFFin = '';
        /**
         * Número do protocolo retornado do SEFAZ
         * @var string
         * @access public
         */
     var $nProt = '';
        /**
         * N�mero do modelo de NF retornado do SEFAZ
         * Hoje pode ser 55 (NFe) ou 65 (NFCe)
         * @var int
         * @access public
         */
     public $modelo= 55;
        /**
         * Número de serie da NF retornado do SEFAZ
         * @var int
         * @access public
         */
     var $serie = '';
        /**
         * Ano da NF retornado do SEFAZ
         * @var int
         * @access public
         */
     var $ano = '';
        /**
         * Número do CNPJ da empresa emitente retornado pelo SEFAZ
         * @var string
         * @access public
         */
     var $CNPJ = '';
        /**
         * Número do CPF da consulta retornado da SEFAZ
         * @var string
         * @access public
         */
     var $CPF = '';
        /**
         * Número da inscriçao estadual retornado da SEFAZ
         *
         * @var string
         * @access public
         */
     var $IE = '';
        /**
         * Número do ID da NFe 44 digitos retornado do SEFAZ
         * @var string
         * @access public
         */
     var $chNFe = '';
        /**
         * Digest da assinatura digital da NFe retornado do SEFAZ
         * @var string
         * @access public
         */
     var $digVal='';
        /**
         * Data e hora da consulta retornado do SEFAZ
         *
         * @var string
         * @access public
         */
     var $dhCons = '';
        /**
         * Retorno do SEFAZ na consulta de cadastros retornado da SEFAZ
         * NOTA : Pode não haver este retorno
         * @var array
         * @access public
         */
     var $aCad = array();


     // variaveis relativas ao certificado
        /**
         * Número de meses até a expiração do certificado digital
         * @var int
         * @access public
         */
     var $monthsToExpire=0;
        /**
         * Número de dias até a expiração do certificado digital
         * @var int
         * @access public
         */
     var $daysToExpire=0;

    /**
     * Variáveis Privadas
     */
        /**
         * Caminho completo até o arquivo da chave publica
         * em formato pem
         * @var string $pathCert
         * @access private
         */
     public $pathCert = '';

    /**
     * Gravamos o dado nesse certificado limpo, sem o --BEGIN CERTIFIED
     * @var string
     */
     public $pathCert_limpo = '';
        /**
         * Caminho completo até o arquivo da chave privada
         * em formato pem
         * @var string $pathKey
         * @access private
         */
     public $pathKey = '';
        /**
         * Resource que contêm a chave privada
         * @var resource $rPrivkey
         * @access private
         */
     private $rPrivkey='';
        /**
         * Resource que contêm a chave publica
         * @var resource $rPubkey
         * @access private
         */
     private $rPubkey='';

        /**
         * Indicadores de schemas utilizados na construçao das mensagens SOAP
         * e na assinatura digital
         *
         */

        /**
         * $URLxsi
         * @var string
         * @access private
         */
     protected $URLxsi = 'http://www.w3.org/2001/XMLSchema-instance';
        /**
         * $URLxsd
         * @var string
         * @access private
         */
     private $URLxsd = 'http://www.w3.org/2001/XMLSchema';
        /**
         * $URLnfe
         * @var string
         * @access private
         */
     protected $URLnfe = 'http://www.portalfiscal.inf.br/nfe';
        /**
         * $URLdsig
         * @var string
         * @access private
         */
     private $URLdsig = 'http://www.w3.org/2000/09/xmldsig#';
        /**
         * $URLCanonMeth
         * @var string
         * @access private
         */
     private $URLCanonMeth = 'http://www.w3.org/TR/2001/REC-xml-c14n-20010315';
        /**
         * $URLSigMeth
         * @var string
         * @access private
         */
     private $URLSigMeth = 'http://www.w3.org/2000/09/xmldsig#rsa-sha1';
        /**
         * $URLTransfMeth_1
         * @var string
         * @access private
         */
     private $URLTransfMeth_1 = 'http://www.w3.org/2000/09/xmldsig#enveloped-signature';
        /**
         * $URLTransfMeth_2
         * @var string
         * @access private
         */
     private $URLTransfMeth_2 = 'http://www.w3.org/TR/2001/REC-xml-c14n-20010315';
        /**
         * $URLDigestMeth
         * @var string
         * @access private
         */
     private $URLDigestMeth = 'http://www.w3.org/2000/09/xmldsig#sha1';

        /**
         * Resposta do webservice
         * @var object $response
         * @access private
         */
     private $response;


    /**
     * Vers�o da NFe 1.10, 2.00, 3.00, 3.10
     * @var int
     */
    // todo:: revisar (php 8.1) - me parece que a filha � quem decide a vers�o da NFE, de qq forma n�o existe a constante
    public $_versao_nfe = 0; // ???? = VERSAO_NFE;

    /**
     * tzUFlist
     * Lista das zonas de tempo para os estados brasileiros
     * @var array
     */
    private $tzUFlist = array('AC'=>'America/Rio_Branco',
    		'AL'=>'America/Sao_Paulo',
    		'AM'=>'America/Manaus',
    		'AP'=>'America/Sao_Paulo',
    		'BA'=>'America/Bahia',
    		'CE'=>'America/Fortaleza',
    		'DF'=>'America/Sao_Paulo',
    		'ES'=>'America/Sao_Paulo',
    		'GO'=>'America/Sao_Paulo',
    		'MA'=>'America/Sao_Paulo',
    		'MG'=>'America/Sao_Paulo',
    		'MS'=>'America/Campo_Grande',
    		'MT'=>'America/Cuiaba',
    		'PA'=>'America/Belem',
    		'PB'=>'America/Sao_Paulo',
    		'PE'=>'America/Recife',
    		'PI'=>'America/Sao_Paulo',
    		'PR'=>'America/Sao_Paulo',
    		'RJ'=>'America/Sao_Paulo',
    		'RN'=>'America/Sao_Paulo',
    		'RO'=>'America/Porto_Velho',
    		'RR'=>'America/Boa_Vista',
    		'RS'=>'America/Sao_Paulo',
    		'SC'=>'America/Sao_Paulo',
    		'SE'=>'America/Sao_Paulo',
    		'SP'=>'America/Sao_Paulo',
    		'TO'=>'America/Sao_Paulo');
    /*
     caso queira for�ar o timezone do estado, mas o servidor � �nico ent�o
    isso n�o ser� utilizado.
    $timezone = $this->tzUFlist[$this->UF];
    date_default_timezone_set($timezone);
    */

    /**
     * Complemento do campo vers�o no formato string
     * @var String
     */
	public $_comp_vers  = "";
	// True somente para situa��o SVC (Sefaz Virtual de Conting?ncia)
	public $_situacao_SVC = false;

    /**
     * Campo com o n�mero de tentativas a patir erros no envio � SEFAZ
     */
    protected $_tentativa = 0;

    /**
     * Vari�vel de controle caso por algum motivo seja necess�rio ignorar o mamcache
     */
    protected $_ignore_mamcache = false;

    public function setIgnoreMamcache($_value){
        $this->_ignore_mamcache = $_value;
    }

	public function setforcar_releitura($_value) {
	    $this->_forcar_releitura = $_value;
    }

	public function setVersaoNFe($_value) {
		$this->_versao_nfe = $_value;
		//ALTNFE-15
		if($this->_versao_nfe >= 3 && $this->_versao_nfe < 4) {
            $this->_comp_vers = 2;
        }elseif($this->_versao_nfe >= 4) {
            $this->_comp_vers = 4;
        }else{
            $this->_comp_vers = 2;
        }
	}

    /**
     * Metodos Publicos
     */

    /**
     * Método construtor da classe
     *
     * TODO
     * verificar se existe o arquivo de configuração inicial
     * se existir carregas as variáveis de ambiente apartir desse arquivo
     * A ideia (iniciada pelo Djalma) é de não necessitar setar todas as variáveis
     * importantes toda vez que a classe seja invocada. Essas variáveis seriam setadas uma
     * vez e gravadas no diretorio a partir de uma função da classe, tipo um config_inc.php
     *
     */
    function __construct(){

        /*$fixfile = getcwd().'/libs/fixConfig.php';
        if (file_exists($fixfile)){
            include($fixfile);
            $this->ambiente = $tpAMB;
            $this->pathCerts = $certDIR;
            $this->nameCert = $nameCERT;
            $this->passKey = $passKEY;
            $this->passPhrase = $passPHRASE;
            $this->entradasNF = $DIRentradas;
            $this->assinadasNF = $DIRassinadas;
            $this->validadasNF = $DIRvalidadas;
            $this->aprovadasNF = $DIRaprovadas;
            $this->enviadasNF = $DIRenviadas;
            $this->canceladasNF = $DIRcanceladas;
            $this->inutilizadasNF = $DIRinutilizadas;
            $this->temporarioNF = $DIRtemporario;
            $this->recebidasNF = $DIRrecebidas;
            $this->consultadasNF = $DIRconsultadas;
        }*/

    }

    public function getpathCert() {
	    return $this->pathCert;
    }

    public function getpathKey() {
	    return $this->pathKey;
    }

    /**
     * INTINTEGRA-1
     * Rodilson M. Federico
     * Fev/2024
     * Retorna resource que cont�m a chave privada
     *
     * @return resource|string
     * @access public
     */
    public function getrPrivkey() {
        return $this->rPrivkey;
    }

    /**
     * INTINTEGRA-1
     * Rodilson M. Federico
     * Fev/2024
     * Retorna resource que cont�m a chave publica
     *
     * @return resource|string
     * @access public
     */
    public function getrPubkey() {
        return $this->rPubkey;
    }
	public function getSITUACAO_SVC(){
		return $this->_situacao_SVC;
	}
	public function setSITUACAO_SVC($_svc=false){
		$this->_situacao_SVC = $_svc;
	}
    public function getSituacaoEPEC(){
	    return $this->_setSituacaoEPEC;
    }
	public function setSituacaoEPEC($_bol=false){
        $this->_setSituacaoEPEC = $_bol;
    }

    //destrutor
    function __destruct(){


    }

    /**
     * Retorna o caminho de onde gravararemos os arquivos pem
     * Por�m se a pasta estiver vazia ele usar� a pathCert se esta n�o estiver vazia.
     * @return string
     */
    public function getPathCerts_pem() {
        if (!empty($this->pathCerts_pem)) {
            return $this->pathCerts_pem;
        }
        //Se n�o foi setado o caminho dos pem ent�o usa o do pathCerts
        if (!empty($this->pathCerts)) {
            $this->pathCerts_pem = $this->pathCerts;
            return $this->pathCerts_pem;
        }
        return "";

    }
    /**
     * fixConfig
     * Esta função monta um arquivo de configuração que será utilizada
     * automaticamente na construção da classe para setar as propriedades mais
     * importantes da classe.
     * Deve ser invocada pelo menos uma vez.
     * Para seu uso deve-se antes instanciar todas as propriedades importantes da classe
     *
     * @param boolean $bSave se TRUE salva as propriedades em um arquivo para uso interno da classe
     *                       se FALSE remove o arquivo
     * @return boolean TRUE se sucesso ou FALSE se falhou
     */
    function fixConfig($bSave=TRUE){
        $texto = '<?php '."\n";
        $texto .= '$tpAMB ='."'".$this->ambiente."';\n";
        $texto .= '$certDIR='."'".$this->pathCerts."';\n";
        $texto .= '$nameCERT='."'".$this->nameCert."';\n";
        $texto .= '$passKEY='."'".$this->passKey."';\n";
        $texto .= '$passPHRASE='."'".$this->passPhrase."';\n";
        $texto .= '$DIRentradas='."'".$this->entradasNF."';\n";
        $texto .= '$DIRassinadas='."'".$this->assinadasNF."';\n";
        $texto .= '$DIRvalidadas='."'".$this->validadasNF."';\n";
        $texto .= '$DIRaprovadas='."'".$this->aprovadasNF."';\n";
        $texto .= '$DIRenviadas='."'".$this->enviadasNF."';\n";
        $texto .= '$DIRcanceladas='."'".$this->canceladasNF."';\n";
        $texto .= '$DIRinutilizadas='."'".$this->inutilizadasNF."';\n";
        $texto .= '$DIRtemporario='."'".$this->temporarioNF."';\n";
        $texto .= '$DIRrecebidas='."'".$this->recebidasNF."';\n";
        $texto .= '$DIRconsultadas='."'".$this->consultadasNF."';\n";
        $texto .= '?>'."\n";

        $fixfile = getcwd().'/libs/fixConfig.php';

        if ($bSave){
           $n = $this->inserirDadoArquvio($fixfile,$texto);
        } else {
            unlink($fixfile);
        }

    }

    /**
     * Retorna o objeto memcache
     * @return zanthus_memcache
     */
    public function getobj_memcache() {
        //No offline n�o tem memcache.
        if (!funcoesGerais::managerOFFLine()) {
            if (!isset($this->_obj_memcache)) {
                $this->_obj_memcache = funcoesGerais::obterObjetoMemcache();
            }
        } else {
            $this->_obj_memcache = false;
        }
        return $this->_obj_memcache;
    }

    /**
     * Seta pasta pem e cria o diret�rio
     * @return bool
     */
    public function setarDiretorioPem() {
        //Seto o diret�rio tempor�rio para gravarmos os pem e criamos o diret�rio aqui.
        //$_dir = funcoesGerais::retornarDiretorioComumSAAS();
        //Vamos gravar sempre local mesmo no Prime pois o dado esta no banco.
        $_dir = "";
        if (empty($_dir)) {
            $_dir = funcoesGerais::retornarCaminhoAbsolutoManager();
        }
        /**Vamos pegar o certificado do pr�prio servidor, pois ele agora vem do banco
         *  E o disco local � mais r�pido
         */
        $this->pathCerts_pem = $_dir . "cert_temp_pem/";

        if (funcoesGerais::CriaDiretorio($this->pathCerts_pem) === false) {
            funcoesGerais::GravaLog("Problemas ao criar diret�rio tempor�rio do pem para o CERTIFICADO DIGITAL: [{$this->pathCerts_pem}]",true,true);
            return false;
        }
        return true;
    }


    /**
     * Retornar� os dados do arquivo de certificado,
     * mas tamb�m colocar� em mem�ria quando trabalhar com MemCache,
     * Vamos otimizar esse processo inclusive com os arquivos.
     *
     * @param $_nome nome do arquivo
     * @return bool|string
     */
    public function retornarDadoArquivo($_nome) {
        //Se for linux vamos no Memcache direto.
        if (AMBIENTE_SAAS === false && !funcoesGerais::managerOFFLine() &&  (funcoesGerais::isLinux() || class_exists("Memcache",false)) && !$this->_ignore_mamcache) {
            $_obj = $this->getobj_memcache();
            if ($_obj !== false) {
                $_ret = $_obj->obterRegistro($_nome);
            } else {
                $_ret = false;
            }
            //Se n�o conseguiu vai no arquivo mesmo assim.
            if ($_ret === false || empty($_ret)) {
                $_ret = file_get_contents($_nome);
                if ($_ret  !== false && $_obj !== false) {
                    //Caso tenha reiniciado o memcache
                    $_obj->adicionarRegistro($_nome, $_ret);
                }
                return $_ret;
            } else {
                return $_ret;
            }
        } else {
            return file_get_contents($_nome);
        }
    }

    /**
     * Remove o BEGIN CERTIFICADO
     * @param $_conteudo
     * @return string
     */
    public function limparDadoCertificado($_conteudo) {
        if (strpos($_conteudo,"-----BEGIN CERTIFICATE") !== false) {
            $arCert = explode("\n", $_conteudo);
            $_conteudo = "";
            foreach ($arCert AS $curData) {
                //remove a tag de inicio e fim do certificado
                if (strncmp($curData, '-----BEGIN CERTIFICATE', 22) != 0 && strncmp($curData, '-----END CERTIFICATE', 20) != 0) {
                    //carrega o resultado numa string
                    $_conteudo .= trim($curData);
                }
            }
        }
        return $_conteudo;
    }

    /**
     * Colocar� o dado no arquivo ou em mem�ria quando trabalhar
     * com o Memcache
     *
     * @param $_nome nome do arquivo
     * @param conteudo conte�do do arquivo
     * @return bool|string
     */
    public function inserirDadoArquvio($_nome,$_conteudo, $_limpar = false) {
        if ($_limpar) {
            $_conteudo = $this->limparDadoCertificado($_conteudo);
        }
        if (empty($_conteudo)) {
            funcoesGerais::GravaLog("O Conteudo do {$_conteudo}, estava vazio",true,true);
            return false;
        }
        //Se for linux vamos no Memcache direto.
        if (AMBIENTE_SAAS === false && !funcoesGerais::managerOFFLine() &&  (funcoesGerais::isLinux() || class_exists("Memcache",false))) {
            $_obj = $this->getobj_memcache();
            if ($_obj !== false) {
                $_ret = $_obj->adicionarRegistro($_nome, $_conteudo);
            }
        }
        //A escrita vamos fazer no arquivo, pois caso falhe o memcache teremos  conting�ncia.
        return file_put_contents($_nome, $_conteudo);
    }

    /**
     * Temos que apagar os arquivos, e recri�-los caso
     * queiramos reaproveitar, sen�o apagar a checagem n�o mudar� a data de
     * altera��o
     */
    public function apagarArquivosPem() {
        unlink($this->pathKey);
        unlink($this->pathCert);
        unlink($this->nome_local_cert);
        unlink($this->pathCert_limpo);
    }

    /**
     * Coim a finalidade de evitar ficar lento o openssl
     * vamos checar se o arquivo j� existe.
     * Por�m, quando o certificado for trocado precisamos recriar o pem.
     * @return bool
     */
    public function checarExistenciaArquivoPEM() {
        //Se estiver preenchido ent�o, n�o precisa fazer nada disso, pq td j� est� na mem�ria
        if ($this->nameCert === $this->_ultimo_nome_cert && !empty($this->pathCert) && !empty($this->pathKey)) {
            return true;
        }

        /**
         * @todo
         * Podiamos pensar em uma forma de otimizar isso
         * Tipo checar a data do pfx se for maior que o pem ent�o recria sen�o usa ele
         * como fazemos nom�dulo, acho q isso minimizaria o acesso a valida��o do ssh q � custoza.
         * Vi o acesso dele qdo usamos o strace ele tenta abrir muitos arquivos
         *
         */
        //Se for o managerOFFLine os arquivos j� estar�o na pasta.
        if (funcoesGerais::managerOFFLine()) {
            $this->pathCert = certificado_digital::retornarCaminhoCertificado() . certificado_digital::$_arq_public_key;
            $this->pathKey  = certificado_digital::retornarCaminhoCertificado() . certificado_digital::$_arq_private_key;
            $this->rPrivkey = $this->retornarDadoArquivo($this->pathKey);
            $this->rPrivkey = openssl_pkey_get_private($this->rPrivkey);
            return true;
        }

        if (!$this->setarDiretorioPem()){
            return false;
        }

        //Onde est� o certificado pfx
        $pCert                   = $this->pathCerts.$this->nameCert;
        $this->_ultimo_nome_cert = $this->nameCert;
        $_nome_sem_ponto         = str_replace(".","",$this->nameCert);
        //BL-6116 For�o a releitura
        $this->pathKey           = $this->getPathCerts_pem(). "{$_nome_sem_ponto}privatekey.pem";
        $this->pathCert          = $this->getPathCerts_pem()."{$_nome_sem_ponto}publickey.pem";
        $this->pathCert_limpo    = $this->getPathCerts_pem()."{$_nome_sem_ponto}publickey_limpo.pem";
        $this->nome_local_cert   = $this->getPathCerts_pem()."{$_nome_sem_ponto}cert_gerado.pem";

        //Se os dois arquivos existirem vamos comparar as datas
        if (file_exists($pCert) && file_exists($this->pathCert_limpo)) {
            //Se a data do arquivo pfx for maior que a data do arquivo de pem, ent�o manda recriar
            if (filemtime($pCert) > filemtime($this->pathCert_limpo)) {
                $this->apagarArquivosPem();
                return false;
            }
            //Se o certificado pfx n�o existir, td bem, mas se o privado n�o existir a� � um problema, pq n�o gerou nenhuma vez, ent�o manda gerar.
        } elseif (!file_exists($this->pathCert_limpo)) {
            return false;
        }

        //Precisa disso pq o rPrivKey � um resource, ent�o tem q carregar, e usamos isso pra montar a chave da nota.
        $this->rPrivkey = $this->retornarDadoArquivo($this->pathKey);
        $this->rPrivkey = openssl_pkey_get_private($this->rPrivkey);
        return true;

    }

    /**
     * carregaCert
     * Carrega o certificado pfx e gera as chaves privada e publica no
     * formato pem para uso do SOAP e registra as gvariaveis de ambiente
     * Esta fun��o deve ser invocada antes das outras do sistema que
     * dependam do certificado
     * Resultado
     *  A fun��o ir� criar o certificado digital (chaves publicas e privadas)
     *  no formato pem e grava-los no diretorio indicado em $this->pathCerts
     *  com os nomes :
     *     privatekey.pem
     *     .publickeypem
     *  Estes arquivos tamb�m ser�o carregados nas vari�veis da classe
     *  $this->pathCert (com o caminho completo para o arquivo publickey.pem)
     *  $this->pathKey (com o caminho completo para o arquivo privatekey.pem)
     * Dependencias
     *   $this->pathCerts
     *   $this->nameCert
     *   $this->passKey
     * FUNCIONAL !!
     * @param	none
     * @return	boolean TRUE se o certificado foi carregado e FALSE se nao
     * @access  public
    **/
    public function carregaCert($_force=false){
        //Se estiver preenchido ent�o
        if ($this->nameCert === $this->_ultimo_nome_cert && !empty($this->pathCert) && !empty($this->pathKey)) {
            //Se deu erro uma vez continua logando o erro, no meu caso deu erro no certificado e na segunda vez ele continuava mas n�o deveria.
            if ($this->erroEncontradoCertificadoDigital) {
                return false;
            } else {
                return true;
            }
        }

        //Se for o managerOFFLine os arquivos j� estar�o na pasta.
        if (funcoesGerais::managerOFFLine()) {
            $this->pathCert = certificado_digital::retornarCaminhoCertificado() . certificado_digital::$_arq_public_key;
            $this->pathKey  = certificado_digital::retornarCaminhoCertificado() . certificado_digital::$_arq_private_key;
            $this->rPrivkey = $this->retornarDadoArquivo($this->pathKey);
            $this->rPrivkey = openssl_pkey_get_private($this->rPrivkey);
            return true;
        }
        /*
         *
         * Se j� existir n�o faz o processo de carregar o certificado.
         */
        if ($this->checarExistenciaArquivoPEM() && !$this->_forcar_releitura) {
            return true;
        }


        //Vari�vel para comparar se ainda estamos trabalhando com o mesmo certificado
        $this->_ultimo_nome_cert = $this->nameCert;
        //verificar se o nome do certificado e
        //o path foram carregados nas variaveis da classe
        if ($this->pathCerts == '' || $this->nameCert == '') {
            $this->errorMsg = 'Um certificado deve ser passado para a classe!!';
            $this->errorCod = 'C1';
            $this->errorStatus = TRUE;
            $this->erroEncontradoCertificadoDigital = true;
            return FALSE;
        }
        $x509certdata = "";
        //monta o caminho completo at� o certificado pfx
        $pCert = $this->pathCerts . $this->nameCert;
        //verifica se o arquivo existe
        if (!file_exists($pCert)) {
            $this->errorMsg = "Certificado n�o encontrado!!\n{$pCert}";
            $this->errorCod = 'C2';
            $this->errorStatus = TRUE;
            $this->erroEncontradoCertificadoDigital = true;
            return FALSE;
        }
            //carrega o certificado em um string
            $key = $this->retornarDadoArquivo($pCert);
            if ($key === false) {
                if (!is_readable($pCert)) {
                    $this->errorMsg = "O certificado n�o pode ser lido!! Sem permiss�o de leitura!!\n{$pCert}";
                    $this->errorCod = 'C3';
                    $this->errorStatus = TRUE;
                    $this->erroEncontradoCertificadoDigital = true;
                    return FALSE;

                }
            }

        //carrega os certificados e chaves para um array denominado $x509certdata
        if (!openssl_pkcs12_read($key,$x509certdata,$this->passKey) ){
                $this->errorMsg = "O certificado n�o pode ser lido!! Provavelmente corrompido ou com formato inv�lido!!\n{$pCert}";
                $this->errorCod = 'C3';
                $this->errorStatus = TRUE;
                $this->erroEncontradoCertificadoDigital = true;
                return FALSE;
        }

        //No m�dulo vamos seguir com o certificado vencido.
        if (!funcoesGerais::managerOFFLine()) {
            //verifica sua validade
            if (!$this->validCert($x509certdata['cert'])) {
                $this->errorMsg .= 'Certificado invalido!!';
                $this->errorCod = 'C4';
                $this->errorStatus = TRUE;
                $this->erroEncontradoCertificadoDigital = true;
                return FALSE;
            }
        }
        //carrega a chave privada em um resource para uso do assinador
        $this->rPrivkey = openssl_pkey_get_private($x509certdata['pkey']);
        //carrega o certificado em um resource para uso do assinador
        $this->rPubkey = openssl_pkey_get_public($x509certdata['cert']);
        //Retira o ponto do nome do certificado
        $_nome_sem_ponto = str_replace(".","",$this->nameCert);

        /*
         * monta o path completo com o nome da chave privada
         * Pode existir mais de um processo executando ao mesmo tempo com arquivos diferentes
         * ent�o preciso manter os nomes iguais.
         */
        //$filePriv 		       = $this->getPathCerts_pem(). "{$_nome_sem_ponto}privatekey.pem";
        //$this->nome_local_cert = $this->getPathCerts_pem()."{$_nome_sem_ponto}cert_gerado.pem";

        //Como os certificados podem trocar frequentemente en�o decidimos criar.
        if(file_exists($this->nome_local_cert)){
            //se existir verificar se � o mesmo
            $conteudo = $this->retornarDadoArquivo($this->nome_local_cert);
            if ( $conteudo !== $x509certdata['pkey'].$x509certdata['cert'])  {
                 //se diferentes gravar o novo
                if (!$this->inserirDadoArquvio($this->nome_local_cert,$x509certdata['pkey'].$x509certdata['cert']) ){
                    $this->errorMsg = 'Impossivel gravar no diret�rio!!! Permiss�o negada!!';
                    $this->errorCod = 'F1';
                    $this->errorStatus = TRUE;
                    $this->erroEncontradoCertificadoDigital = true;
                    return FALSE;
                }
            }
        } else {
            $this->inserirDadoArquvio($this->nome_local_cert,$x509certdata['pkey'].$x509certdata['cert']);
        }

        //verifica se arquivo j� existe
        $filePriv = $this->pathKey;
        if(file_exists($filePriv)){
            //se existir verificar se é o mesmo
            $conteudo = $this->retornarDadoArquivo($filePriv);
            //comparar os primeiros 30 digitos
            if ( $conteudo !== $x509certdata['pkey']) {
                 //se diferentes gravar o novo
                if (!$this->inserirDadoArquvio($filePriv,$x509certdata['pkey']) ){
                    $this->errorMsg = 'Impossivel gravar no diret�rio!!! Permiss�o negada!!';
                    $this->errorCod = 'F1';
                    $this->errorStatus = TRUE;
                    $this->erroEncontradoCertificadoDigital = true;
                    return FALSE;
                }
            }
        } else {
            //salva a chave privada no formato pem para uso so SOAP
            if ( !$this->inserirDadoArquvio($filePriv,$x509certdata['pkey']) ){
                   $this->errorMsg = 'Impossivel gravar no diret�rio!!! Permiss�o negada!!';
                   $this->errorCod = 'F1';
                   $this->errorStatus = TRUE;
                   $this->erroEncontradoCertificadoDigital = true;
                   return FALSE;
            }
        }
        //monta o path completo com o nome da chave prublica
        //$filePub =  $this->getPathCerts_pem()."{$_nome_sem_ponto}publickey.pem";
        $filePub =  $this->pathCert;
        //verifica se arquivo j� existe
        if(file_exists($filePub)){

            //se existir
            //se existir verificar se � o mesmo
            $conteudo = $this->retornarDadoArquivo($filePub);
            //comparar os primeiros 30 digitos
            if ( $conteudo !== $x509certdata['cert'] ) {
                //se diferentes gravar o novo
                $this->inserirDadoArquvio($filePub, $x509certdata['cert']);
                $this->inserirDadoArquvio($this->pathCert_limpo, $x509certdata['cert'],true);
            }
        } else {
            //salva a chave prublica no formato pem para uso so SOAP
            $this->inserirDadoArquvio($filePub,$x509certdata['cert']);
            $this->inserirDadoArquvio($this->pathCert_limpo, $x509certdata['cert'],true);
        }
        //verifica que as propriedades do ambinte sejam setadas
        $this->pathCert = $filePub;
        $this->pathKey  = $filePriv;
        return TRUE;
    }

    /**
     * Validaçao do cerificado digital, alem de indicar
     * a validade este metodo carrega a propriedade
     * mesesToexpire da classe quer indica o numero de
     * meses que faltam para expirar a validade do certificado
     * esta informacao pode ser utilizada para a gestao dos
     * certificados de forma a garantir que sempre estejam validos
     * FUNCIONAL !!
     * @param	string  $cert Certificado digital no formato pem
     * @return	boolean	True se o certificado estiver dentro do prazo de validade, e False se nao
     * @access  public
    **/
    public function validCert($cert){
        $flagOK = true;
        $data = openssl_x509_read($cert);
        $cert_data = openssl_x509_parse($data);
        // reformata a data de validade;
        $ano = substr($cert_data['validTo'],0,2);
        $mes = substr($cert_data['validTo'],2,2);
        $dia = substr($cert_data['validTo'],4,2);
        //obtem o timeestamp da data de validade do certificado
        $dValid = gmmktime(0,0,0,$mes,$dia,$ano);
        $this->_data_validade = $dValid;
        // obtem o timestamp da data de hoje
        $dHoje = gmmktime(0,0,0,date("m"),date("d"),date("Y"));
        // compara a data de validade com a data atual
        if ($dValid < $dHoje ){
            $flagOK = false;
            $this->errorStatus = TRUE;
            $this->errorMsg = "Erro Certificado:  A Validade do certificado expirou em ["  . $dia.'/'.$mes.'/'.$ano . "] INVALIDO !!";
            $this->errorCod = 'C3';
        } else {
            $flagOK = $flagOK && TRUE;
        }
        //diferença em segundos entre os timestamp
        $diferenca = $dValid - $dHoje;
        // convertendo para dias
        $diferenca = round($diferenca /(60*60*24),0);
        //carregando a propriedade
        $this->daysToExpire = $diferenca;
        // convertendo para meses e carregando a propriedade
        $m = ($ano * 12 + $mes);
        $n = (date("y") * 12 + date("m"));
        $this->monthsToExpire = ($m-$n);
        return $flagOK;
    }

    /**
     * Assinador TOTALMENTE baseado em PHP das NFe e xmls
     * este assinador somente utiliza comandos nativos do PHP para assinar
     * FUNCIONAL !!!! resulta em arquivo idêntico ao assinadorRS
     * Resultado
     *      o arquivo xml com a assinatura será salvo em
     *      $outDir ou $this->assinadasNF, nessa ordem  e
     *      também retornada como uma string pela função ao chamador
     *      O arquivo tem sua denominação estabelecida como :
     *      ID-NFe.xml
     *  Onde o ID é o identificador de 44 digitos numéricos da NFe (sem a sigla NFe)
     *          ex. 35090671780456000160550010000000010000000017-NFe.xml
     *
     * Dependência
     *      carregaCert()
     * @param	string $nfe
     * @param   string $tagid TAG que devera ser assinada
     * @return	mixed FALSE se houve erro ou string com o XML assinado
     * @access  public
    **/
    public function assina($docxml, $tagid='', $outDir=''){
        if ( $tagid == '' ){
            $this->errorMsg = 'Uma tag deve ser indicada para que seja assinada!!';
            $this->errorCod = 'A1';
            $this->errorStatus = TRUE;
            return FALSE;
        }

        //carrega o certificado sem as tags de inicio e fim
        $cert 			 = $this->limpaCert();
        $_retorna_objeto = false;

        libxml_clear_errors();
        // Habilita a manipulaçao de erros da libxml
        libxml_use_internal_errors(true);
        // carrega o documento no DOM
        if ($docxml instanceof DOMDocument) {
            $xmldoc      	 = $docxml;
            //$_retorna_objeto = true;
        } else {//Se n�o for um DOM faz isso.
            //libxml_use_internal_errors(true);




            // limpeza do xml com a retirada dos CR e LF
            $order  = array("\r\n", "\n", "\r", "\s");
            $replace = '';
            $docxml = str_replace($order, $replace, $docxml);
            //O SaveXML estraga o XML e como em como UTF8 na descri��o do Produto preciso recodificar
            $xmldoc = new DOMDocument('1.0', 'UTF-8');

            $xmldoc->preservWhiteSpace = false; //elimina espaços em branco
            $xmldoc->formatOutput = false;
            // muito importante deixar ativadas as opçoes para limpar os espacos em branco
            // e as tags vazias
            //if($xmldoc->loadXML($docxml,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG)===false) {
            if($xmldoc->loadXML($docxml,LIBXML_NOEMPTYTAG)===false) {
                $aIntErrors = libxml_get_errors();
                libxml_clear_errors();
                // Habilita a manipulaçao de erros da libxml
                libxml_use_internal_errors(true);
                if($xmldoc->loadXML(utf8_encode($docxml),LIBXML_NOEMPTYTAG)===false) {
                    $aIntErrors = libxml_get_errors();
                    funcoesGerais::GravaLog("Problema ao assinar o XML: {$docxml} ". var_export($aIntErrors,true),true,true);
                    return false;
                }
            }

        }
        $root = $xmldoc->documentElement;
        //extrair a tag com os dados a serem assinados
        $node = $xmldoc->getElementsByTagName($tagid)->item(0);
        $id = trim($node->getAttribute("Id"));
        $versao = (string) trim($node->getAttribute("versao"));
        //Qdo � evento vem dois digitos.. a� faz errado, o substr
        $idnome = preg_replace('/[^0-9]/','', $id);
        //extrai os dados da tag para uma string
        /*$dados = $node->C14N(FALSE,FALSE,NULL,NULL);
        $hashValue = hash('sha1',$dados,TRUE);
        //converte o valor para base64 para serem colocados no xml
        $digValue = base64_encode($hashValue);

        funcoesGerais::GravaLog($dados . "\n digvalue: {$digValue}\n  ",true,true,true,"C14N.xml");*/
        //No php 5.2 o saveHTML n�o funciona.
        //$dados = $xmldoc->saveHTML($node);
        $dados = $xmldoc->saveXML($node,LIBXML_NOEMPTYTAG);

        //if((int) $this->modelo == 55) {
        //Tem q fazer teste pra evento, acho q n�o deve ser assim.
        //funcoesGerais::GravaLog("antes " . $dados  . "tamanho " . strlen($dados),true,true,true,"C14N_SEM_XML.xml");

        //funcoesGerais::GravaLog("depois " . $dados ,true,true,true,"C14N_SEM_XML.xml");
        if (strtolower($tagid) == "infevento") {
            $dados = substr($dados, 71);
            $dados = '<infEvento xmlns="http://www.portalfiscal.inf.br/nfe" Id="' . $id . '">' . $dados;
        } if(strtolower($tagid) == "infnfe") {
            $dados = substr($dados, 75);
            $dados = '<infNFe xmlns="http://www.portalfiscal.inf.br/nfe" Id="' . $id . '" versao="'.$versao.'">' . $dados;
        } else {
            $dados = $node->C14N(FALSE,FALSE,NULL,NULL);
        }
        //}

        //calcular o hash dos dados
        $hashValue = hash('sha1',$dados,TRUE);
        //converte o valor para base64 para serem colocados no xml
        $digValue = base64_encode($hashValue);
        //funcoesGerais::GravaLog($dados . "\n 222digvalue: {$digValue}\n  ",true,true,true,"C14N_SEM_XML.xml");
        //Vamos validar se precisa inserir qrcode antes da assinatura, se tiver sido valorada no fetch incluimos
        if(count((array)$this->_qrcode_nfce)) {
            $this->_qrcode_nfce["DIG"] = $digValue;
            $_qrcode = funcoesGerais::montarURLQrCodeNFCe(
                $this->_qrcode_nfce["ID_NFE"],
                $this->_qrcode_nfce["URL"],
                $this->_qrcode_nfce["AMBIENTE"],
                $this->_qrcode_nfce["DEST"],
                $this->_qrcode_nfce["DHEMI"],
                $this->_qrcode_nfce["VNF"],
                $this->_qrcode_nfce["VICMS"],
                $this->_qrcode_nfce["DIG"],
                $this->_qrcode_nfce["TOKEN"],
                null,
                $this->aVerxsd["IncluirQRCodeXMLNFCe"],
                $this->rPrivkey
            );
            $_url_chave = $this->_qrcode_nfce["URL_CHAVE"];
            $infNFeSupl = $xmldoc->createElement('infNFeSupl');
            $root->appendChild($infNFeSupl);
            //Na vers�o 2.0 do qrcode n�o colocamos como cdata.
            if ((int) $this->aVerxsd["IncluirQRCodeXMLNFCe"] === 1) {
                $_tag_qrcode = $xmldoc->createElement('qrCode');
                $_cdata = $xmldoc->createCDATASection($_qrcode);
                $_tag_qrcode->appendChild($_cdata);
                $infNFeSupl->appendChild($_tag_qrcode);
            } else {
                $_tag_qrcode = $xmldoc->createElement('qrCode',$_qrcode);
                $infNFeSupl->appendChild($_tag_qrcode);
            }


            if($this->_versao_nfe >= 4) {
                $_urlChave = $xmldoc->createElement('urlChave',$_url_chave);
                $infNFeSupl->appendChild($_urlChave);
            }

        }


        //monta a tag da assinatura digital
        $Signature = $xmldoc->createElementNS($this->URLdsig,'Signature');
        $root->appendChild($Signature);
        $SignedInfo = $xmldoc->createElement('SignedInfo');
        $Signature->appendChild($SignedInfo);
        //Cannocalization
        $newNode = $xmldoc->createElement('CanonicalizationMethod');
        $SignedInfo->appendChild($newNode);
        $newNode->setAttribute('Algorithm', $this->URLCanonMeth);
        //SignatureMethod
        $newNode = $xmldoc->createElement('SignatureMethod');
        $SignedInfo->appendChild($newNode);
        $newNode->setAttribute('Algorithm', $this->URLSigMeth);
        //Reference
        $Reference = $xmldoc->createElement('Reference');
        $SignedInfo->appendChild($Reference);
        $Reference->setAttribute('URI', '#'.$id);
        //Transforms
        $Transforms = $xmldoc->createElement('Transforms');
        $Reference->appendChild($Transforms);
        //Transform
        $newNode = $xmldoc->createElement('Transform');
        $Transforms->appendChild($newNode);
        $newNode->setAttribute('Algorithm', $this->URLTransfMeth_1);
        //Transform
        $newNode = $xmldoc->createElement('Transform');
        $Transforms->appendChild($newNode);
        $newNode->setAttribute('Algorithm', $this->URLTransfMeth_2);
        //DigestMethod
        $newNode = $xmldoc->createElement('DigestMethod');
        $Reference->appendChild($newNode);
        $newNode->setAttribute('Algorithm', $this->URLDigestMeth);
        //DigestValue
        $newNode = $xmldoc->createElement('DigestValue',$digValue);
        $Reference->appendChild($newNode);
        // extrai os dados a serem assinados para uma string
        $dados = $SignedInfo->C14N(FALSE,FALSE,NULL,NULL);
        //$dados = $xmldoc->saveHTML($SignedInfo);
        //inicializa a variavel que irá receber a assinatura
        $signature = '';
        //executa a assinatura digital usando o resource da chave privada
        $resp = openssl_sign($dados,$signature,$this->rPrivkey);
        //codifica assinatura para o padrao base64
        $signatureValue = base64_encode($signature);
        //$signatureValue = wordwrap($signatureValue,76,"\n",true);
        //SignatureValue
        $newNode = $xmldoc->createElement('SignatureValue',$signatureValue);
        $Signature->appendChild($newNode);
        //KeyInfo
        $KeyInfo = $xmldoc->createElement('KeyInfo');
        $Signature->appendChild($KeyInfo);
        //X509Data
        $X509Data = $xmldoc->createElement('X509Data');
        $KeyInfo->appendChild($X509Data);
        //X509Certificate
        $newNode = $xmldoc->createElement('X509Certificate',$cert);
        $X509Data->appendChild($newNode);
        if ($_retorna_objeto) {
            return $xmldoc;
        } else {
            //grava na string o objeto DOM
            $docxml = $xmldoc->saveXML();
        }
        //se for passado parametro de destino salvar o xml como arquvo
        if ($outDir != ''){
            $outname = $outDir.$idnome.'-NFe.xml';
            $ret = $xmldoc->save($outname);
        } else {
            //verificar a propriedade da classe assinadasNF
            if ($this->assinadasNF != ''){
                $outname = $this->assinadasNF.$idnome.'-NFe.xml';
                $ret = $xmldoc->save($outname);
            }
        }
        return $docxml;
    }



    /**********************************************
     * Verificaçao da NF com base no xsd
     * Há um bug no libxml2 para versões anteriores a 2.7.3
     * que causa um falso erro na validação da NFe devido ao
     * uso de uma marcação no arquivo tiposBasico_v1.02.xsd
     * onde se le {0 , } substituir por *
     * FUNCIONAL !!
     * @param	string  $docxml  string contendo o arquivo xml a ser avaliado
     * @param   string  $xsdfile Path completo para o arquivo xsd
     * @return	boolean TRUE se passou ou FALSE se foram detectados erros
     * @access  public
     ***********************************************/
    public function validaXML($docxml, $xsdfile, $_limpar_buffer = false){
        if ($_limpar_buffer) {
            libxml_clear_errors();
        }
        // Habilita a manipulaçao de erros da libxml
        libxml_use_internal_errors(true);

        if ($docxml instanceof DOMDocument) {
        	$xmldoc = $docxml;
        } else {
	        // instancia novo objeto DOM
	        $xmldoc = new DOMDocument('1.0','UTF-8');

	        // carrega o xml
	        $xml = $xmldoc->loadXML($docxml);
        }

        $erromsg='';

        // valida o xml com o xsd
        if ( !$xmldoc->schemaValidate($xsdfile) ) {
            /**
             * Se não foi possível validar, você pode capturar
             * todos os erros em um array
             * Cada elemento do array $arrayErrors
             * será um objeto do tipo LibXmlError
             *
             */
            // carrega os erros em um array
            $aIntErrors = libxml_get_errors();
            //libxml_clear_errors();
            $flagOK = FALSE;
            foreach ($aIntErrors as $intError){
                switch ($intError->level) {
                    case LIBXML_ERR_WARNING:
                        $erromsg .= " Aten��o $intError->code: ";
                        break;
                    case LIBXML_ERR_ERROR:
                        $erromsg .= " Erro $intError->code: ";
                        break;
                    case LIBXML_ERR_FATAL:
                        $erromsg .= " Erro Fatal $intError->code: ";
                        break;
                }
                $erromsg .= $intError->message . ';';
            }
            $this->cStat = ERRO_XSD_NFE;
            $this->errorXsd = ERRO_XSD_NFE;
            $this->errorDescricaoXsd = DSC_ERRO_XSD_NFE;
        } else {
            $flagOK = TRUE;
            $this->errorStatus = FALSE;
            $this->errorMsg = '';
        }
        $_retorno = $this->validarCAUTXml($docxml, $this->modelo);
        $flagOK = !$flagOK ? $flagOK : $_retorno;
        if (!$flagOK){
            $this->errorStatus = TRUE;
            $this->errorMsg = $erromsg;
        }
        return $flagOK;
    }

    /**
     * SQM-209 - Valida se term o cAut nos meios de pagamento quando necess�rio.
     * @param $_xml
     * @param $_tipo_modelo_nf
     * @return bool
     * @throws Exception
     */

    public function validarCAUTXml($_xmls, $_tipo_modelo_nf) {
        $validaNFe = ($GLOBALS['_UF_FLAGS'] & 32) > 0 && $_tipo_modelo_nf = 55 ? true : false;
        $validaNFCe = ($GLOBALS['_UF_FLAGS'] & 64) > 0 && $_tipo_modelo_nf = 65 ? true : false;
        if(!$validaNFe && !$validaNFCe) {
            return true;
        }

        foreach ((array)$_xmls as $_xml) {
            $_xml = simplexml_load_string($_xml);
            if (funcoesGerais::retornarVersaoNFe(0, null, $_tipo_modelo_nf) >= 4) {
                $_arr_pag = $_xml->infNFe->pag->detPag;
            } else {
                $_arr_pag = $_xml->infNFe->pag;
            }
            foreach ($_arr_pag as $_pagamento) {
                if ($_pagamento->tPag == 17 && empty($_pagamento->card->cAut)) {
                    $this->errorXsd = ERRO_CAUT;
                    $this->cStat = ERRO_CAUT;
                    $this->errorDescricaoXsd = DSC_ERRO_CAUT;
                    return false;
                }
            }
        }
        return true;
    }




    /**********************************************
     * Verifica o status do servico da SEFAZ
     *
     * Este metodo carrega a variavel
     * $this->cStat = 107 OK
     *        cStat = 108 sitema paralizado momentaneamente, aguardar retorno
     *        cStat = 109 sistema parado sem previsao de retorno, verificar status SCAN
     * se SCAN estiver ativado usar, caso caontrario aguardar pacientemente.
     *
     *
     * FUNCIONAL !!
     * @param	boolean $bSave Indica se o xml da resposta deveser salvo em arquivo
     * @return	boolean True se operacional e False se nao
     * @access  public
     ***********************************************/
    public function statusServico($bSave=TRUE){
    	$this->limparVariaveis();
        //retorno da funçao
        $bRet = FALSE;
        // carga das variaveis da funçao do webservice
        $wsdl = 'NfeStatusServico' . $this->_comp_vers;
        $cabecXsdfile   = $this->aFxsd['CabecMsg'.$this->_comp_vers];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        $dataXsdfile    = $this->aFxsd[$wsdl];
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;

        // array para comunicaçao soap
        /*Antes colocavamos o xsi. e xsd parece que n�o � mais necess�ro o sistema retorna um erro 587.
         *$param = '<consStatServ xmlns:xsi="'.$this->URLxsi.'" xmlns:xsd="'.$this->URLxsd.'" versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'">'.'<tpAmb>'.$this->ambiente.'</tpAmb><cUF>'.$this->UFcod.'</cUF><xServ>STATUS</xServ></consStatServ>';
         */
        $param = '<consStatServ versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'">'.'<tpAmb>'.$this->ambiente.'</tpAmb><cUF>'.$this->UFcod.'</cUF><xServ>STATUS</xServ></consStatServ>';

        if($this->_versao_nfe >= 2) {
	        //Hoje passamos somente a informa��o do xml de envio

			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
			$nfeDadosMsg = new stdClass;
			$nfeDadosMsg->any = $param;
			$param = $nfeDadosMsg;
        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }


        //envia o xml para o SOAP
        $retorno = $this->sendSOAP($param, $wsdl);
        //verifica o retorno do SOAP
        if (is_array($retorno)) {
            //pega os dados do array retornado pelo NuSoap
            //$xmlresp = $retorno[$this->aFunctionWdsl[$wsdl].'Result'];
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);
            if ($xmlresp == ''){
                //houve uma falha na comunicação SOAP
                return FALSE;
            }
            $this->respostaXML = (String) $xmlresp;
            //tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $_sucess = $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
            // status do serviço
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            // tempo medio de resposta
            $this->tMed = $doc->getElementsByTagName('tMed')->item(0)->nodeValue;
            // data e hora da mensagem
            $this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
            //converter a informaçao de data hora para timestamp
            $this->dhRecbto = $this->convertTime($this->dhRecbto);
            // motivo da resposta (opcional)
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            // obervaçoes opcional
            if($doc->getElementsByTagName('xObs')!==null) {
            	$this->xObs = $doc->getElementsByTagName('xObs')->item(0)->nodeValue;
            }
            if ($this->cStat == '107'){
                $bRet = TRUE;
            }
            /*if ($bSave){
                //nome do arquivo de retorno da função SOAP
                $nome = $this->temporarioNF.date('Ymd').'T'.date('His').'-ret_sta.xml';
                //salva o xml retornado na pasta temporarioNF
                $doc->save($nome);
            }*/
        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }
        return $bRet;
    }

    /**
		Limpa as vari�veis para evitar problemas
	*/
    public function limparVariaveis() {
    	$this->respostaXML = "";
 	     //Zero as duas vari�veis.
		$this->cStat       = null;
		$this->xMotivo     = null;
        $this->errorStatus = false;
       $this->errorMsg     = '';
    }

    /**
     * Solicita dados de situaçao de Cadastro
     * Não FUNCIONA !! Não sei porque
     * @param	string  $UF
     * @param   string  $IE
     * @param   string  $CNPJ
     * @param   string  $CPF
     * @param   boolean $bSave indica se o xml retornado deve ser salvo em arquivo
     * @return	boolean TRUE se sucesso ou FALSE se falha
     * @access  public
     * TODO
     * descobrir motivo da falha
     *
     **/
    public function consultaCadastro($UF,$IE='',$CNPJ='',$CPF='',$bSave=true){
		$this->limparVariaveis();
        //variavel de retorno do metodo
        $bRet = false;
        //variaveis do webservice
        /**
         * Tairo Miguel
         * 22/06/16
         * BL-4258
         * Obs: Adicionado numero da vers�o, sem esse n�mero o m�todo de consulta s�o � encontrado
         *      o que gera uma consulta com url mal formada, retornando falso da busca na sefaz e acaba permitindo
         *      a efetiva��o da nota no PDV.
        */
        $this->setVersaoNFe($this->_versao_nfe);
   		$wsdl = 'CadConsultaCadastro'. $this->_comp_vers;
        $cabecXsdfile   = $this->aFxsd['CabecMsg' . $this->_comp_vers];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        $dataXsdfile    = $this->aFxsd[$wsdl];
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;
        $flagIE = false;
        $flagCNPJ = false;
        $flagCPF = false;
        $marca = '';

        //selecionar o criterio de filtragem CNPJ ou IE ou CPF
        if ($IE != ''){
        	$IE     = funcoesGerais::retornarNumeros($IE);
            $flagIE = true;
            $marca  = 'IE-'.$IE;
            $filtro = "<IE>".$IE."</IE>";
            $CNPJ   = '';
            $CPF    = '';
        }
        if ($CNPJ != '') {
        	$CNPJ     = funcoesGerais::retornarNumeros($CNPJ);
            $flagCNPJ = true;
            $marca    = 'CNPJ-'.$CNPJ;
            $filtro   = "<CNPJ>".$CNPJ."</CNPJ>";
            $CPF      ='';
        }
        if($CPF != '') {
        	$CPF     = funcoesGerais::retornarNumeros($CPF);
            $flagCPF = true;
            $filtro  = "<CPF>".$CPF."</CPF>";
            $marca   = 'CPF-'.$CPF;
        }
        //se nenhum critério é satisfeito
        if ( !($flagIE || $flagCNPJ || $flagCPF) ){
            //erro nao foi passado parametro de filtragem
            $this->errorMsg = 'Um filtro deve ser indicado CNPJ, CPF ou IE.';
            $this->errorStatus = true;
            return false;
        }
        //prepara��o da mensagem SOAP
        $param = '<ConsCad versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><infCons><xServ>CONS-CAD</xServ><UF>'.$UF.'</UF>'.$filtro.'</infCons></ConsCad>';
		//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
		if($this->_versao_nfe >= 2) {
			$nfeDadosMsg 	  = new stdClass;
			$nfeDadosMsg->any = $param;
			$param 			  = $nfeDadosMsg;
		} else {
			$consultaCadastro = new stdClass;
			$consultaCadastro->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
			$consultaCadastro->nfeDadosMsg = $param;
			$param = $consultaCadastro;
		}

        //envio da mensagem ao webservice
        $retorno = $this->sendSOAP($param, $wsdl);
        //se houve retorno
        if (is_array($retorno)) {
            //pegar o xml retornado do NuSoap
            //$xmlresp = $retorno[$this->aFunctionWdsl[$wsdl].'Result'];
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                $this->errorMsg = 'Problemas ao conectar com a sefaz.';
                $this->errorStatus = true;
                return false;
            }
            $xmlresp =  current($retorno);
            $xmlresp = $this->limparXML($xmlresp);
            if ($xmlresp == ''){
                $this->errorMsg = 'Problemas ao conectar com a sefaz.';
                $this->errorStatus = true;
                return false;
            }
            $this->respostaXML = $xmlresp;
            // tratar dados de retorno
            $doc = new DOMDocument();
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
            //infCons o xml somente contera um grupo com essa tag
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            $this->xMotivo= $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            $this->UF= $doc->getElementsByTagName('UF')->item(0)->nodeValue;
            $this->IE= $doc->getElementsByTagName('IE')->item(0)->nodeValue;
            $this->CNPJ= $doc->getElementsByTagName('CNPJ')->item(0)->nodeValue;
            $this->CPF= $doc->getElementsByTagName('CPF')->item(0)->nodeValue;
            $this->dhCons= $doc->getElementsByTagName('dhCons')->item(0)->nodeValue;
            $this->cUF = $doc->getElementsByTagName('cUF')->item(0)->nodeValue;
            // se foi encontrado cStat = 111 ou 112 com varios estabelecimento com o mesmo IE
            if ($this->cStat == '111' || $this->cStat == '112') {
                $bRet = true;
                $n    = 0;
                //pode haver mais de um dado retornado
                $infCad = $doc->getElementsByTagName('infCad');
                foreach ($infCad as $iCad) {
                    $IE = $iCad->getElementsByTagName('IE')->item(0)->nodeValue;
                    $CNPJ = $iCad->getElementsByTagName('CNPJ')->item(0)->nodeValue;
                    $CPF = $iCad->getElementsByTagName('CPF')->item(0)->nodeValue;
                    $UF = $iCad->getElementsByTagName('UF')->item(0)->nodeValue;
                    $cSit = $iCad->getElementsByTagName('cSit')->item(0)->nodeValue;
                    $xNome = $iCad->getElementsByTagName('xNome')->item(0)->nodeValue;
                    $xFant = $iCad->getElementsByTagName('xFant')->item(0)->nodeValue;
                    $xRegApur = $iCad->getElementsByTagName('xRegApur')->item(0)->nodeValue;
                    $CNAE = $iCad->getElementsByTagName('CNAE')->item(0)->nodeValue;
                    $dIniAtiv = $iCad->getElementsByTagName('dIniAtiv')->item(0)->nodeValue;
                    $dUltSit = $iCad->getElementsByTagName('dUltSit')->item(0)->nodeValue;
                    $dBaixa = $iCad->getElementsByTagName('dBaixa')->item(0)->nodeValue;
                    $IEUnica = $iCad->getElementsByTagName('IEUnica')->item(0)->nodeValue;
                    $IEAtual = $iCad->getElementsByTagName('IEAtual')->item(0)->nodeValue;
                    $xLgr = $iCad->getElementsByTagName('xLgr')->item(0)->nodeValue;
                    $nro = $iCad->getElementsByTagName('nro')->item(0)->nodeValue;
                    $xCpl = $iCad->getElementsByTagName('xCpl')->item(0)->nodeValue;
                    $xBairro = $iCad->getElementsByTagName('xBairro')->item(0)->nodeValue;
                    $cMun = $iCad->getElementsByTagName('cMun')->item(0)->nodeValue;
                    $xMun = $iCad->getElementsByTagName('xMun')->item(0)->nodeValue;
                    $CEP = $iCad->getElementsByTagName('CEP')->item(0)->nodeValue;
                    //BL-4812 Quando h� um habilitado e outro n�o n�s n�o estavamos pegando o habilitado
                    $this->aCad[] = array('IE'=>$IE,'CNPJ'=>$CNPJ,'CPF'=>$CPF,'UF'=>$UF,'cSit'=>$cSit,'xNome'=>$xNome,'xFant'=>$xFant,'xRegApur'=>$xRegApur,'CNAE'=>$CNAE,'dIniAtiv'=>$dIniAtiv,'dUltSit'=>$dUltSit,'dBaixa'=>$dBaixa,'IEUnica'=>$IEUnica,'IEAtual'=>$IEAtual,'xLgr'=>$xLgr,'nro'=>$nro,'xCpl'=>$xCpl,'xBairro'=>$xBairro,'cMun'=>$cMun,'xMun'=>$xMun,'CEP'=>$CEP);
                }
            } else {
                $this->errorMsg = "{$this->cStat}-{$this->xMotivo}";
                $this->errorStatus = true;
                return false;
            }
        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Problemas ao conectar com a sefaz.';
        }
        return $bRet;
    }


    /**
     * M�todo respons�vel por enviar os eventos por lote
     * @param unknown_type $aEvento
     * @param unknown_type $idLote
     */
    public function enviarEvento($aEvento, $idLote='1') {
		$this->limparVariaveis();
    	//variavel de retorno do metodo
    	$bRet = false;

    	// carga das variaveis da fun��o do webservice
    	$wsdl 			= 'RecepcaoEvento';//. $this->_comp_vers;
    	$cabecXsdfile   = $this->aFxsd['CabecMsg'];
    	//$cabecVer       = $this->aVerxsd['CabecMsg'];
    	$dataXsdfile    = $this->aFxsd[$wsdl];
    	$dataVer        = $this->aVerxsd[$wsdl];
    	$cabecVer       = $dataVer;


    	// limpa a vari�vel
    	$sEvto = '';

    	// monta string com as NFe enviadas
    	$sEvto = implode('',$aEvento);

    	/*
    	 * Acha a tag <evento e pega dali pra frente ignorando todo o resto, inclusive o \n do come�o.
    	* Vem um \n no come�o e no fim do xml que n�o deve ir de jeito algun
    	* SE TIRAR ZOA..POIS PODE TER 2 EVENTOS.
    	*/
    	$_tagFinal  = "</evento>";
    	$sEvto      = trim($sEvto);
    	$sEvto 		= substr($sEvto,Zstripos($sEvto,"<evento"));
    	$sEvto 		= substr($sEvto,0,strlen($_tagFinal) * (-1)) . $_tagFinal;
    	/**
    	 * Isso por causa do campo de condi��o de uso do evento de carta de corre��o.
    	 * No banco gravamos como ISO-8859-1 e depois como UTF8.
    	 */
    	$sEvto      = utf8_encode($sEvto);

    	//ATEN��O $sEvto nao pode ultrapassar 500kBytes
    	if (strlen($sEvto) > 512000) {
    		//indicar erro e voltar
    		return FALSE;
    	}

    	//Montamos o XML que vamos enviar.
    	$param = '<envEvento versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><idLote>'.$idLote.'</idLote>'.$sEvto.'</envEvento>';

/*     	N�o est� validando corretamente diz que n�o tem o ROOT ent�o vamos tentar direto.
 		Ver isso depois pois � importante validar.
  		if($this->validaXML($param, $this->pathXSD . $dataXsdfile)===false) {
    		funcoesGerais::GravaLog("Schema inv�lido . {$this->errorMsg}",true,true);
    		return false;
    	}
 */
    	//Hoje passamos somente a informa��o do xml de envio
    	//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
    	$nfeDadosMsg      = new stdClass;
    	$nfeDadosMsg->any = $param;
    	$param            = $nfeDadosMsg;


    	//retorno e um array contendo a mensagem do SEFAZ
    	$retorno = $this->sendSOAP($param, $wsdl);
    	//Retorno do evento.
     	//funcoesGerais::GravaLog("Retorno " . var_export($retorno,true),true,true);
/*    	echo "<br>retorno " . var_export($retorno,true);
 */
    	if (is_array($retorno)) {

    		//$xmlresp = $retorno[$this->aFunctionWdsl[$wsdl].'Result'];
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);
    		if ($xmlresp == ''){
    			//houve uma falha na comunicação SOAP
    			return FALSE;
    		}

    		$this->respostaXML = $xmlresp;
    		//tratar dados de retorno
    		$doc = new DOMDocument(); //cria objeto DOM
    		$doc->formatOutput = false;
    		$doc->preserveWhiteSpace = false;
    		$doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);

    		// status do recebimento ou mensagem de erro
    		$this->cStat    = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
    		$this->tpAmb    = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
    		$this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
    		$this->xMotivo  = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;

    		// em caso de sucesso  cStat = 128
    		if ($this->cStat == '128'){
    			// tempo medio de processamento
    			$this->tMed = $doc->getElementsByTagName('tMed')->item(0)->nodeValue;
    			// data e hora da mensagem
    			$this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
    			// numero do recibo, se o lote foi aceito
    			// guardar o numero do recibo na base de dados pois devera ser usado
    			// para verificar o estatus dos Lotes enviados
    			$this->nRec = $doc->getElementsByTagName('nRec')->item(0)->nodeValue;





    			/********************* PROCESSANDO EVENTOS RECEBIDOS *****************/
    			//extrair a resposta da matriz e garantir que os dados retornem como UTF-8
   				//termina��o do arquivo em caso de sucesso
   				$terminacao = "xml";
   				// haver� um grupo retEvento para cada Evento enviada no lote
   				$protEvto = $doc->getElementsByTagName('retEvento');

   				//Pegamos todas as informa��es de processamento de eventos
   				foreach ($protEvto as $pEvto) {
   					$versao 	  = $pEvto->getAttribute('versao');
   					$nNFe 		  = $pEvto->getElementsByTagName('infEvento')->item(0);
   					//extrai o id da tag
   					$tpAmb        = $pEvto->getElementsByTagName('tpAmb')->item(0)->nodeValue;
   					$verAplic     = $pEvto->getElementsByTagName('verAplic')->item(0)->nodeValue;
   					$cOrgao       = $pEvto->getElementsByTagName('cOrgao')->item(0)->nodeValue;
   					$cStat        = $pEvto->getElementsByTagName('cStat')->item(0)->nodeValue;
   					$xMotivo      = utf8_decode($pEvto->getElementsByTagName('xMotivo')->item(0)->nodeValue);
   					$chNFe        = $pEvto->getElementsByTagName('chNFe')->item(0)->nodeValue;
   					//Se estiver vazio tento pegar dentro do conte�do do motivo (ocorreu no Torra)
   					if (empty($chNFe)) {
                        $_aux_chNFe = explode("chNFe:",$xMotivo);
                        $_aux_chNFe = explode("]",$_aux_chNFe[1]);
                        $chNFe = funcoesGerais::retornarNumeros($_aux_chNFe[0]);
                    }
   					$tpEvento     = $pEvto->getElementsByTagName('tpEvento')->item(0)->nodeValue;
   					$nSeqEvento   = $pEvto->getElementsByTagName('nSeqEvento')->item(0)->nodeValue;
   					$dhRegEvento  = $pEvto->getElementsByTagName('dhRegEvento')->item(0)->nodeValue;
   					$nProt        = $pEvto->getElementsByTagName('nProt')->item(0)->nodeValue;

   					/* $dhRecbto     = $pEvto->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
   					$digVal       = $pEvto->getElementsByTagName('digVal')->item(0)->nodeValue; */
   					//Isso � pra tentarmos saber como o XML estava pois o DOM zua o XML e n�o n�o traz os n�s.
   					$_xml_env     =
     					'<retEvento versao="' . $versao .'">'.
   							'<infEvento>'.
	   							'<tpAmb>' .    $tpAmb .    '</tpAmb>'.
	   							'<verAplic>' . $verAplic . '</verAplic>'.
	   							'<cOrgao>' .   $cOrgao   . '</cOrgao>' .
	   							'<cStat>' .    $cStat .    '</cStat>'.
	   							'<xMotivo>' .   $xMotivo .   '</xMotivo>'.
	   							'<chNFe>' .     $chNFe .    '</chNFe>'.
	   							'<tpEvento>' .  $tpEvento . '</tpEvento>' .
	   							'<nSeqEvento>' . $nSeqEvento . '</nSeqEvento>' .
	   							'<dhRegEvento>' . $dhRegEvento .'</dhRegEvento>'.
	   							'<nProt>' .    $nProt .    '</nProt>'.

	   							/*'<dhRecbto>' . $dhRecbto . '</dhRecbto>'.
	   							'<digVal>' .   $digVal .   '</digVal>'.*/
   							'</infEvento>'.
   						'</retEvento>';
   					$this->aEvto[] = array(
   							'chNFe'=>$chNFe,
   							'cStat'=>$cStat,
   							'xMotivo'=>$xMotivo,
   							'nProt'=>$nProt,
   							'tpAmb'=>$tpAmb,
   							'tpEvento'=>$tpEvento,
   							'nSeqEvento'=>$nSeqEvento,
   							'dhRegEvento'=>date('d-m-Y H:i:s',strtotime($dhRegEvento)),
   							'verAplic'=>$verAplic,
   							'versao'=>$versao,
   							'XML_RETORNO'=>$_xml_env);
   				}


    			/********************* FIM PROCESSAMENTO EVENTOS RECEBIDOS *****************/




    		}
    		/*
    		 if ($bSave){
    		//salvar o xml retornado do SEFAZ
    		$nome = $this->enviadasNF.$idLote.'-reclote.xml';
    		$nome = $doc->save($nome);
    		}*/
    	} else {
    		$this->errorStatus = true;
    		$this->errorMsg = 'Nao houve retorno do NuSoap!!';
    	}

    	return $bRet;
    }

    /**
     * Remove alguns caracteres especiais
     * @param string $_xml
     * @return mixed
     */
    protected function limparXML($_xml) {
		$_xml = str_replace("''", '"', $_xml);
    	return $_xml;
    }

    /*
     * MODOEPECSVC-1
     */
    protected function envioEmModoEPECTeste($param, $wsdl, $lote_sinc, $aNFe, $idLote, $lote_sinc_orig){
        if($GLOBALS["_DEBUG"]) {
            funcoesGerais::GravaLog("[MODOEPECSVC-1] ENTRANDO EM MODO EPEC FOR�ANDO ZMWSInfo", true, true,false,"MODOEPECSVC.zlg");
        }
        //$_retorno = $this->sendSOAP($param, $wsdl, $lote_sinc);
        $_retorno = false; //� oq ocorre para entrar no EPEC, o retorno vem false
        if ($this->modelo === 55) {
            /**
             * Antes de considerar como erro e transformar em EPEC vamos aguardar 5 segundos e tentar novamente
             */
            if($this->_tentativa === 0) {
                sleep(5);
                $this->_tentativa++;
                return $this->enviaNF($aNFe, $idLote, $lote_sinc_orig);
            }
            $this->_tentativa = 0;

            $_retorno = array ('NFeAutorizacaoResult' => '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body><nfeAutorizacaoLoteResult xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NfeAutorizacao"><retEnviNFe versao="3.10" xmlns="http://www.portalfiscal.inf.br/nfe"><tpAmb>' . $this->tpAmb . '</tpAmb><verAplic>3.10</verAplic><cStat>108</cStat><xMotivo>Fora do ar com erro (' . $this->erro_http . ' http)</xMotivo><cUF>'. $this->cUF . '</cUF><dhRecbto>' .  funcoesGerais::converte_data(date('d-m-Y H:i:s'),'padrao','utc',false,true,false,$this->UF,true)
                . '</dhRecbto></retEnviNFe></nfeAutorizacaoLoteResult></soap:Body></soap:Envelope>');
            $this->errorStatus = false;

        }

        return $_retorno;
    }

    /**********************************************
     * Envia lote de Notas Fiscais
     *
     * @param	array   $aNFe notas fiscais em xml uma em cada campo de uma string
     * @param   integer $idLote o id do lote e um numero que deve ser gerado pelo sistema
     *                          a cada envio mesmo que seja de apenas uma NFe usar banco
     *                          de dados
     * @param   boolean $lote_sinc indica se o envio do Lote � sincrono ou n�o.
     * @return	boolean	True se aceito o lote ou False de rejeitado
     * @access  public
     ************************************************/
    public function enviaNF($aNFe=array(),$idLote='1',$lote_sinc=false) {
		$this->limparVariaveis();

        //variavel de retorno do metodo
        $bRet = false;
    
        //Na NFe continuaremos usando o assincrono por enquanto.
        /*
         * Indica que o envio continua Assincrono
         * 0=N�o.
           1=Empresa solicita processamento s�ncrono do Lote de NF-e (sem a gera��o de Recibo para consulta futura);
            Nota: O processamento s�ncrono do Lote corresponde a entrega da resposta do processamento das NF-e do
            Lote, sem a gera��o de um Recibo de Lote para consulta futura. A resposta de forma s�ncrona pela SEFAZ
            Autorizadora s� ocorrer� se:
            - a empresa solicitar e constar unicamente uma NF-e no Lote;
            - a SEFAZ Autorizadora implementar o processamento s�ncrono para a resposta do Lote de NF-e.
         */
        //S� armazenando de como chegou por par�metro
        $lote_sinc_orig = $lote_sinc;

        //Alguns estados n�o permitem emiss�o sincrona.
        $lote_sinc = funcoesGerais::decidirNFEnviaLoteSincrono((int) $this->cUF,$lote_sinc,$this->modelo);
        $_cont_notas = substr_count( $aNFe[0], "</NFe>");
        if (($GLOBALS["_REGRA_ESPECIAL_ICMS"] & 8) > 0 and($_cont_notas == 1)and((int)$this->modelo == 65)) {
            $lote_sinc = true;
        }
        if((int)$this->modelo == 55 && $_cont_notas == 1 && ($GLOBALS['_UF_FLAGS'] & 262144) > 0) {
            $lote_sinc = true;
        }

        /*
         * Iremos implantar depois o NfeAutorizacao; para o sincrono.
         * A vers�o 3.0 permitir� chamada sincrona.
         *
         * Tem a possibilidade de compactar o dado.
         *
         * VAMOS TENTAR UTILIZAR. DEPOIS
         */
        $wsdl          = 'NfeRecepcao' . $this->_comp_vers;
        $_chave_busca  = $wsdl;
        $_strAdicional = "<idLote>".$idLote."</idLote>";

        if ($this->_versao_nfe >= 3) {
        	//No 3.1 mudou o nome do wsdl.
        	if (($this->_versao_nfe >= 3.1 && $this->modelo === 55) ||
        	    //Na NFCe at� o momento apenas o 51 = Mato Grosso tem NFCe com o Autorizador
        		($this->_versao_nfe >= 3.1 && $this->modelo === 65 && funcoesGerais::permitirNFCeAutorizacao((int) $this->cUF)) ) {
        		$wsdl          = 'NfeAutorizacao';
        		//$wsdl          = ($this->_situacao_SVC) ? "NfeRecepcao2" : "NfeAutorizacao";
     		    $_chave_busca  = $wsdl;
        	}

       		//Este � Sincrono e n�o enviaremos o lote.
       		//Se for sincrono s� pode enviar apenas 1.
       		if ($lote_sinc === true) {
        		$_strAdicional .= "<indSinc>1</indSinc>";//Isso n�o funciona qdo funcionar utilizaremos
       		} else {
       			$_strAdicional .= "<indSinc>0</indSinc>";//Isso n�o funciona qdo funcionar utilizaremos
       		}
        }


        // carga das variaveis da fun��o do webservice
        $cabecXsdfile   = $this->aFxsd['CabecMsg'];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        $dataXsdfile    = $this->aFxsd[$_chave_busca];
        $dataVer        = $this->aVerxsd[$_chave_busca];
        $cabecVer       = $dataVer;

        // limpa a variavel
        $sNFe = '';
	    // monta string com as NFe enviadas
	    $sNFe = implode('',$aNFe);

        /*
         * Acha a tag <NFe e pega dali pra frente ignorando todo o resto, inclusive o \n do come�o.
         * Vem um \n no come�o e no fim do xml que n�o deve ir de jeito algun
         * //SE TIRAR ZOA..POIS PODE TER 2 NOTAS.
         *
         * Quando for 65 NFCe s� haver� uma nota.
         */
   		$sNFe = rtrim($sNFe);
	    if ($this->modelo === 55) {
	        $_tagFinal  = "</NFe>";
	        $sNFe 		= substr($sNFe,Zstripos($sNFe,"<NFe"));
	        $sNFe 		= substr($sNFe,0,strlen($_tagFinal) * (-1)) . $_tagFinal;
	    }

        //remover <?xml version="1.0" encoding=... das NFe pois somente uma dessas tags pode existir na mensagem
        $sNFe = str_replace(array('<?xml version="1.0" encoding="utf-8"?>','<?xml version="1.0" encoding="UTF-8"?>'),'',$sNFe);
        $sNFe = str_replace(array("\r","\n","\s"),"",$sNFe);

        //ATEN��O $sNFe nao pode ultrapassar 500kBytes
        if (strlen($sNFe) > 512000) {
            funcoesGerais::GravaLog("[enviaNF] O Lote [{$idLote}] est� mto grande",true,true);
            //indicar erro e voltar
            return FALSE;
        }

        //Forma anterior $param = '<enviNFe xmlns="'.$this->URLnfe.'" xmlns:ds="'.$this->URLdsig.'" xmlns:xsi="'.$this->URLxsi.'" versao="'.$dataVer.'"><idLote>'.$idLote.'</idLote>'.$sNFe.'</enviNFe>';
        //Antes tinhamos o URLdsig e xsi mas no Rio j� pediram pra tirar temos que testar pra ver se acontece s� no Rio.
        $param = '<enviNFe versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'">'. $_strAdicional . $sNFe . '</enviNFe>';
        //S� vai validar o XSD se n�o for sincrono, pois pode ter uma nota que seja 3.10 por exemplo.
        if (!$lote_sinc) {
            if ($this->validaXML($param, $this->pathXSD . $dataXsdfile) === false) {
                funcoesGerais::GravaLog("[enviaNF] Schema do erro no lote {$idLote} Schema inv�lido: {$this->pathXSD}/{$dataXsdfile}\nErro:\n {$this->errorMsg}", true, true);
                funcoesGerais::GravaLog("[enviaNF] XML do erro no lote {$idLote} XML: {$sNFe}", true, true);
                $this->errorStatus = true;
                //Retorna true e fala q deu erro
                return true;
            }
        }

        if($this->_versao_nfe >= 2) {
	        //Hoje passamos somente a informa��o do xml de envio

			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
			$nfeDadosMsg = new stdClass;
			$nfeDadosMsg->any = $param;
			$param = $nfeDadosMsg;
        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }

        //retorno e um array contendo a mensagem do SEFAZ
        //$retorno = $this->sendSOAP($param, $wsdl);
        //------------------------------------------
        //INTERNAS-904 - Provis�rio para os testes de SVC (RETIRAR ISTO DEPOIS E DESCOMENTAR A LINHA ACIMA)
        if (!funcoesGerais::managerOFFLine()) {
            $_debug_sefaz   = $GLOBALS['_ini']->GetSessao('SEFAZ');
            $_ret_sefaz     = (int)$_debug_sefaz["RET_SEFAZ"];
            $_ret_sefaz_svc = (int)$_debug_sefaz["RET_SEFAZ_SVC"];
            $now = new DateTime('now');
            $_data_ret_sefaz = $now->format('Y-m-d\TH:i:sP');
        } else {
            $_ret_sefaz     = null;
            $_ret_sefaz_svc = null;
        }
        if($_ret_sefaz === 500) {
            $this->errorStatus = true;
            $this->erro_http   = 500;

            if($this->modelo === 55) {
                //Apenas reproduzindo para teste oq � feito ali em baixo quando o $retorno === false && $this->erro_http >=500
                $retorno = $this->envioEmModoEPECTeste($param, $wsdl, $lote_sinc, $aNFe, $idLote, $lote_sinc_orig);
            }

        } elseif(($_ret_sefaz === 108 || $_ret_sefaz === 109) && !$this->_situacao_SVC) {
        	$retorno = array ('NFeAutorizacaoResult' => '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body><nfeAutorizacaoLoteResult xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NfeAutorizacao"><retEnviNFe versao="3.10" xmlns="http://www.portalfiscal.inf.br/nfe"><tpAmb>2</tpAmb><verAplic>3.10</verAplic><cStat>'.$_ret_sefaz.'</cStat><xMotivo>Fora do ar (teste)</xMotivo><cUF>35</cUF><dhRecbto>'.$_data_ret_sefaz.'</dhRecbto></retEnviNFe></nfeAutorizacaoLoteResult></soap:Body></soap:Envelope>');
	        funcoesGerais::GravaLog("RET_SEFAZ - retorno sendSOAP = " . var_export($retorno,true),true,true);
        } elseif(($_ret_sefaz_svc === 113 || $_ret_sefaz_svc === 114) && $this->_situacao_SVC) {
            $retorno = array ('NfeAutorizacaoResult' => '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body><nfeAutorizacaoLoteResult xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NfeAutorizacao"><retEnviNFe versao="3.10" xmlns="http://www.portalfiscal.inf.br/nfe"><tpAmb>2</tpAmb><verAplic>3.10</verAplic><cStat>'.$_ret_sefaz_svc.'</cStat><xMotivo>Fora do ar (teste)</xMotivo><cUF>35</cUF><dhRecbto>'.$_data_ret_sefaz.'</dhRecbto></retEnviNFe></nfeAutorizacaoLoteResult></soap:Body></soap:Envelope>');
            funcoesGerais::GravaLog("RET_SEFAZ_SVC - retorno sendSOAP = " . var_export($retorno,true),true,true);
        } else {
	        $retorno = $this->sendSOAP($param, $wsdl, $lote_sinc);
            if ($this->modelo === 55 && $retorno === false && $this->erro_http >=500) {
                /**
                 * Antes de considerar como erro e transformar em EPEC vamos aguardar 5 segundos e tentar novamente
                 */
                if($this->_tentativa === 0) {
                    sleep(5);
                    $this->_tentativa++;
                    return $this->enviaNF($aNFe, $idLote, $lote_sinc_orig);
                }
                $this->_tentativa = 0;

                $retorno = array ('NFeAutorizacaoResult' => '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body><nfeAutorizacaoLoteResult xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NfeAutorizacao"><retEnviNFe versao="3.10" xmlns="http://www.portalfiscal.inf.br/nfe"><tpAmb>' . $this->tpAmb . '</tpAmb><verAplic>3.10</verAplic><cStat>108</cStat><xMotivo>Fora do ar com erro (' . $this->erro_http . ' http)</xMotivo><cUF>'. $this->cUF . '</cUF><dhRecbto>' .  funcoesGerais::converte_data(date('d-m-Y H:i:s'),'padrao','utc',false,true,false,$this->UF,true)
                    . '</dhRecbto></retEnviNFe></nfeAutorizacaoLoteResult></soap:Body></soap:Envelope>');
                $this->errorStatus = false;
            }
        }

        //------------------------------------------

        if (is_array($retorno)) {
            /*$retorno = array_change_key_case($retorno, CASE_LOWER); //Transforma todas as chaves em min�sculo, pois teve um caso que veio diferente
            $xmlresp = $retorno[strtolower($this->aFunctionWdsl[$wsdl].'Result')];*/
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);

            if ($xmlresp == ''){
                //Quando houver erro, percorro o array para tentar pegar o retorno pois pode estar com outro nome de �ndice
                if(count((array)$retorno) == 1) {
                    foreach ($retorno as $_ret) {
                        $xmlresp = $_ret;
                        $xmlresp = $this->limparXML($xmlresp);
                        $xmlresp = utf8_encode($xmlresp);
                    }
                }

                if ($xmlresp == '') {
                    //houve uma falha na comunicação SOAP
                    return FALSE;
                }
            }

            $this->respostaXML = $xmlresp;
            //tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);

            // status do recebimento ou mensagem de erro
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            $this->tpAmb = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            /*if ((int) $this->cStat === 656) {
                funcoesGerais::GravaLog("retornou 656 ao enviar nf [{$idLote}] {$xmlresp} ",true,true);
                funcoesGerais::GravaLog("retornou 1 656 ao enviar nf [{$idLote}] " . var_export($param,true),true,true);
            }*/
            // em caso de sucesso  cStat = 103 ou 104 para NFCe sincrono.
            if ($this->cStat == '103' || $this->cStat == '104' || $this->cStat == '999' || (empty($this->nProt) && $this->cStat != 105) || $this->cStat == '108' || $this->cStat == '109') {
                // tempo medio de processamento
                $this->tMed = $doc->getElementsByTagName('tMed')->item(0)->nodeValue;
                // data e hora da mensagem
                $this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
                // numero do recibo, se o lote foi aceito
                // guardar o numero do recibo na base de dados pois devera ser usado
                // para verificar o estatus dos Lotes enviados
                $this->nRec = $doc->getElementsByTagName('nRec')->item(0)->nodeValue;
                //Com NFCe pode ser sincrono ent�o j� cair� aqui.
                //Se o retorno for 105 siginifica que ainda est� processando, se � 103 significa que � assincrono devemos percorrer um novo ciclo.
                //Retorno 108 ou 109 significa que a SEFAZ entrou em contig�ncia e n�o temos o protocolo no retorno, n�o deve entrar no tratarRetornoNotasSefaz
                if ($this->cStat == '104' || (empty($this->nProt) && $this->cStat != '105' && $this->cStat != '103' && $this->cStat != '108' && $this->cStat != '109')) {
                    $this->tratarRetornoNotasSefaz($doc, $param);
                }
                $bRet = TRUE;
            } /*else {
                $this->tratarRetornoErroLoteSefaz($doc); //Se um dia precisar tratar o retorno para exibir nas notas
            }*/
            /*
            if ($bSave){
                //salvar o xml retornado do SEFAZ
                $nome = $this->enviadasNF.$idLote.'-reclote.xml';
                $nome = $doc->save($nome);
            }*/
        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }

        return $bRet;
    }

    /**
     * Tratando o Retorno.
     * Agora com a NFCe o Lote pode
     * ser Sincrono ou assincrono.
     * Logo usaremos este m�todo em dois lugares.
     * @param DOMDocumento $doc Objeto utilizado
     *
     */
    private function tratarRetornoNotasSefaz($doc, $param = null) {
    	$this->aNFe = array();
	    if( $this->cStat == '104' ) {
	        //terminação do arquivo em caso de sucesso
	        $terminacao = "xml";
	        // vai haver um grupo protNFe para cada NF enviada no lote
	        $protNFe = $doc->getElementsByTagName('protNFe');

	        foreach ($protNFe as $pNFe) {
	            $versao = $pNFe->getAttribute('versao');
	            $nNFe = $pNFe->getElementsByTagName('infProt')->item(0);
	            //extrai o id da tag
	            $id           = trim($nNFe->getAttribute("Id"));  // não retornou pela SEFAZ-SP (dfadel)
	            $tpAmb        = $pNFe->getElementsByTagName('tpAmb')->item(0)->nodeValue;
	            $verAplic     = $pNFe->getElementsByTagName('verAplic')->item(0)->nodeValue;
	            $chNFe        = $pNFe->getElementsByTagName('chNFe')->item(0)->nodeValue;
	            $dhRecbto     = $pNFe->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
	            $nProt        = $pNFe->getElementsByTagName('nProt')->item(0)->nodeValue;
	            $digVal       = $pNFe->getElementsByTagName('digVal')->item(0)->nodeValue;
	            $cStat        = $pNFe->getElementsByTagName('cStat')->item(0)->nodeValue;
                $cmsg       = $pNFe->getElementsByTagName('cMsg')->item(0)->nodeValue;
                $xmsg        = $pNFe->getElementsByTagName('xMsg')->item(0)->nodeValue;
              /*if ((int) $cStat === 656) {
                  funcoesGerais::GravaLog("retornou 656 ao tratarRetornoNOtasSefaz nf ",true,true);
              }*/
	            $xMotivo      = $pNFe->getElementsByTagName('xMotivo')->item(0)->nodeValue;
	            $_xml_env     = '<protNFe versao="' . $versao .'">'.
	            					'<infProt>'.
	            						'<tpAmb>' .    $tpAmb .    '</tpAmb>'.
	            						'<verAplic>' . $verAplic . '</verAplic>'.
	            						'<chNFe>' .    $chNFe .    '</chNFe>'.
	            						'<dhRecbto>' . $dhRecbto . '</dhRecbto>'.
	            						'<nProt>' .    $nProt .    '</nProt>'.
	            						'<digVal>' .   $digVal .   '</digVal>'.
	            						'<cStat>' .    $cStat .    '</cStat>'.
	            						'<xMotivo>' .  $xMotivo .   '</xMotivo>';

	            //ML-1337
	            if (!empty($cmsg)) {
                    $_xml_env .=
                        '<cMsg>' . $cmsg . '</cMsg>' .
                        '<xMsg>' . $xmsg . '</xMsg>';
                }

                $_xml_env .=
	            					'</infProt>'.
	            				'</protNFe>';
	            $this->aNFe[] = array('chNFe'=>$chNFe,'cStat'=>$cStat,'xMotivo'=>$xMotivo,'nProt'=>$nProt,'digVal'=>$digVal,'dhRecbto'=>$dhRecbto,'tpAmb'=>$tpAmb,
	            					  'verAplic'=>$verAplic,'versao'=>$versao,'Id'=>$id,'XML_RETORNO'=>$_xml_env,'xMotivoOrig'=>$xMotivo);
	        }
	    }else if($this->cStat != '105' && empty($this->nProt)){
            $nota = new DOMDocument(); //cria objeto DOM
            $nota->formatOutput = false;
            $nota->preserveWhiteSpace = false;
            if (!empty($param->any)) {
                $nota->loadXML($param->any,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
            }
            $infNFe = $nota->getElementsByTagName('infNFe');
            //preciso pegar o id da nota,
            // porque quando recebo esse tipo de resposta do sefaz ele n�o vem com o id da nota
            foreach ($infNFe as $id) {
                $chNFe = substr($id->getAttribute('Id'),3);
            }
            //nessa reposta n�o vem status do lote, s� vem status da nota
            //ent�o assumo que o lote ficou com status 104
            //$this->cStat  = '104';//N�o pode colocar 104.. pq n�o veio 104.
            $retEnv = $doc->getElementsByTagName('retEnviNFe');
            foreach ($retEnv as $pNFe) {
                $versao = $pNFe->getAttribute('versao');
            }
            $tpAmb        = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            $verAplic     = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $dhRecbto     = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
            $cStat        = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            $xMotivo      = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            $_xml_env = '<protNFe versao="' . $versao .'">'.
                        '<infProt>'.
                        '<tpAmb>' . $tpAmb . '</tpAmb>'.
                        '<verAplic>' . $verAplic . '</verAplic>'.
                        '<chNFe>' . $chNFe . '</chNFe>'.
                        '<dhRecbto>' . $dhRecbto . '</dhRecbto>'.
                        '<cStat>' . $cStat . '</cStat>'.
                        '<xMotivo>' . $xMotivo . '</xMotivo>'.
                        '</infProt>'.
                        '</protNFe>';
            $_motivo = 'Xml de retorno alternativo do Sefaz';
            $this->aNFe[] = array('chNFe'=>$chNFe,'cStat'=>$cStat,'xMotivo'=>$_motivo,'nProt'=>'','digVal'=>'','dhRecbto'=>$dhRecbto,'tpAmb'=>$tpAmb,
                'verAplic'=>$verAplic,'versao'=>$versao,'Id'=>'','XML_RETORNO'=>$_xml_env,'xMotivoOrig'=>$xMotivo);
        }
    }

    /**********************************************
     * Solicita resposta do lote de Notas Fiscais
     * FUNCIONAL!!
     * Caso $this->cStat == 105 Tentar novamente mais tarde
     * @param	string   $recibo numero do recibo do envio do lote
     * @param   boolean  $bSave indica se o xml de retorno deve ser salvo em arquivo
     * @return	boolean  True se sucesso false se falha
     * @access  public
     ************************************************/
    public function retornoNF($recibo, $bSave=TRUE){
		$this->limparVariaveis();
        //variavel de retorno do metodo
        $bRet = FALSE;

        // carga das variaveis da fun��o do webservice
//        if ($this->_versao_nfe >= 3.1) {
        if (($this->_versao_nfe >= 3.1 && $this->modelo === 55) ||
            //Na NFCe at� o momento apenas o 51 = Mato Grosso tem NFCe com o Autorizador
        	($this->_versao_nfe >= 3.1 && $this->modelo === 65 && funcoesGerais::permitirNFCeAutorizacao((int) $this->cUF)) ) {
        	$wsdl = 'NfeRetAutorizacao';
        } else {
        	$wsdl = 'NfeRetRecepcao' . $this->_comp_vers;
        	if (empty($this->_comp_vers)) {
        		$wsdl .= "2";
        	}

		}
        //$cabecXsdfile   = $this->aFxsd['CabecMsg'];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        //$dataXsdfile    = $this->aFxsd[$wsdl];
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;


        /*Antes enviavamos o xsi e xsd agora n�o precisa mais.. pois gera erro 587
        *$param = '<consReciNFe xmlns:xsi="'.$this->URLxsi.'" xmlns:xsd="'.$this->URLxsd.'" versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><tpAmb>'.$this->ambiente.'</tpAmb><nRec>'.$recibo.'</nRec></consReciNFe>';
        */
        $param = '<consReciNFe versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><tpAmb>'.$this->ambiente.'</tpAmb><nRec>'.$recibo.'</nRec></consReciNFe>';
        if($this->_versao_nfe >= 2) {
			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
			$nfeDadosMsg = new stdClass;
			$nfeDadosMsg->any = $param;
			$param = $nfeDadosMsg;
        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }


        $retorno = $this->sendSOAP($param, $wsdl);
        

        if (is_array($retorno)) {
            //extrair a resposta da matriz e garantir que os dados retornem como UTF-8
            /*$retorno = array_change_key_case($retorno, CASE_LOWER); //Transforma todas as chaves em min�sculo, pois teve um caso que veio diferente
            $xmlresp = $retorno[strtolower($this->aFunctionWdsl[$wsdl].'Result')];*/
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);
            if ($xmlresp == ''){
                //houve uma falha na comunicação SOAP
                return FALSE;
            }
            //Removo


            $this->respostaXML = $this->limparXML((String)$xmlresp);
            // houve retorno com notas aceitas ou não
            $bRet = TRUE;
            //termina��o do arquivo em caso de insucesso
            $terminacao = "err";

            // tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
            // status do recebimento ou mensagem de erro
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            /*if ((int) $this->cStat === 656) {
                funcoesGerais::GravaLog("retornou 656 ao retornoNF nf ",true,true);
            }*/

            // motivo do status
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            // tipo de ambiente da comunicaçao
            $this->tpAmb = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            //versao do aplicativa que processou a mensagem
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            // numero do recibo, consultado
            $this->nRec = $doc->getElementsByTagName('nRec')->item(0)->nodeValue;
            //caso o status da resposta seja 104 pegar os outros dados
            // caso o status seja 105 => em processamento consultar mais tarde
            // caso o status seja 106 => lote não localizado enviar novamente
            // caso o status seja 248 ou 233 recibo ou CNPJ com problemas (com erros) corrigir os dados
			$this->tratarRetornoNotasSefaz($doc);
            /*if ($bSave){
                //salvar o xml retornado do SEFAZ
                $nome = $this->validadasNF.$recibo.'-prot-rec.'.$terminacao;
                $nome = $doc->save($nome);
            }*/
        }  else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }
        return $bRet;
    }

    /**********************************************
     * Solicita inutilizaçao de uma serie de numeros de NF
     *
     * @param	string  $ano
     * @param   string  $nfSerie
     * @param   integer $numIni
     * @param   integer $numFim
     * @param   boolean $bSave
     * @return	boolean TRUE se sucesso FALSE se falha
     * FUNCIONAL !!
     * @access  public
     ************************************************/
        public function inutilizaNF($ano,$nfSerie,$modelo,$numIni,$numFim,$xJust,$bSave=TRUE){
		$this->limparVariaveis();
        //variavel de retorno
        $bRet = FALSE;
        // carga das variaveis da funçao do webservice
        $wsdl='NfeInutilizacao'.$this->_comp_vers;
        //$cabecXsdfile   = $this->aFxsd['CabecMsg'];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        $dataXsdfile    = $this->aFxsd[$wsdl];
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;


        //Identificador da TAG a ser assinada formada
        //com Codigo da UF + CNPJ + modelo + serie +
        //nro inicial e nro final precedida do literal "ID"

        $id = 'ID'.$this->UFcod.
        			($this->_versao_nfe >= 2 ?funcoesGerais::str_alinha($ano,2,DIREITA,true,'0'):'') .
        			$this->CNPJ.
        			funcoesGerais::str_alinha($modelo,2,DIREITA,true,'0') .
        			funcoesGerais::str_alinha($nfSerie,3,DIREITA,true,'0') .
        			funcoesGerais::str_alinha($numIni,9,DIREITA,true,'0') .
        			funcoesGerais::str_alinha($numFim,9,DIREITA,true,'0');
        $this->Id_inutilizado = $id;
        //dados da mensagem
        $nfeDadosMsg = utf8_encode('<?xml version="1.0" encoding="utf-8"?><inutNFe xmlns="'.$this->URLnfe.'" versao="'.$dataVer.'"><infInut Id="'.$id.'"><tpAmb>'.$this->ambiente.'</tpAmb><xServ>INUTILIZAR</xServ><cUF>'.$this->UFcod.'</cUF><ano>'.$ano.'</ano><CNPJ>'.$this->CNPJ.'</CNPJ><mod>'.$modelo.'</mod><serie>'.$nfSerie.'</serie><nNFIni>'.$numIni.'</nNFIni><nNFFin>'.$numFim.'</nNFFin><xJust>'.$xJust.'</xJust></infInut></inutNFe>');

        $order 		 = array("\r\n", "\n", "\r");
        $replace 	 = '';
        $nfeDadosMsg = str_replace($order, $replace, $nfeDadosMsg);

        //assinar a nfeDadosMsg
        $nfeDadosMsg = $this->assina($nfeDadosMsg, 'infInut');

        if($nfeDadosMsg===false) {
        	$this->errorStatus = true;
        	return false;
        }

        if($this->validaXML($nfeDadosMsg, $this->pathXSD . $dataXsdfile)===false) {
        	funcoesGerais::GravaLog("Schema inv�lido . {$this->errorMsg}",true,true);
        	return false;
        }



        $param = $nfeDadosMsg;

        if ($this->_versao_nfe >= 2) {
        	$param = str_ireplace('<?xml version="1.0" encoding="utf-8"?>',"",$nfeDadosMsg);
			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
            $param = str_replace("\n", '', $param);
			$nfeDadosMsg = new stdClass;
			$nfeDadosMsg->any = $param;
			$param = $nfeDadosMsg;

        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }

        $retorno = $this->sendSOAP($param, $wsdl);

        if (is_array($retorno)) {
            /*$retorno = array_change_key_case($retorno, CASE_LOWER); //Transforma todas as chaves em min�sculo, pois teve um caso que veio diferente
            $xmlresp = $retorno[strtolower($this->aFunctionWdsl[$wsdl].'Result')];*/
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);
            $this->envioXML = current($param);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);

            if ($xmlresp == ''){
                //houve uma falha na comunicação SOAP
                return FALSE;
            }
			$this->respostaXML = $xmlresp;
            // tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);

            $this->versao = $doc->getElementsByTagName('versao')->item(0)->nodeValue;
            $infInut= $doc->getElementsByTagName('infInut')->item(0);
            //extrai o id da tag
            $id = !empty($infInut) ? trim($infInut->getAttribute("Id")) : '';

            $this->tpAmb = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            $this->cUF = $doc->getElementsByTagName('cUF')->item(0)->nodeValue;

            if ($this->cStat == '102' || $this->cStat == '563' || $this->cStat == '206') {
                $bRet = TRUE;
                $this->ano = $doc->getElementsByTagName('ano')->item(0)->nodeValue;
                $this->CNPJ = $doc->getElementsByTagName('CNPJ')->item(0)->nodeValue;
                $this->modelo = $doc->getElementsByTagName('mod')->item(0)->nodeValue;
                $this->serie = $doc->getElementsByTagName('serie')->item(0)->nodeValue;
                $this->nNFIni = $doc->getElementsByTagName('nNFIni')->item(0)->nodeValue;
                $this->nNFFin = $doc->getElementsByTagName('nNFFin')->item(0)->nodeValue;
                $this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
                $this->nProt = $doc->getElementsByTagName('nProt')->item(0)->nodeValue;
            }
			/*
            if ($bSave){
                //salvar o xml retornado do SEFAZ
                $nome = $this->inutilizadasNF.$id.'-INUT.xml';
                $nome = $doc->save($nome);
            }*/

        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }
        return $bRet;
    }

    /**********************************************
     * Solicita o cancelamento de NF enviada
     *
     * @param	string  $idNFe ID da NFe com 44 digitos (sem o NFe na frente dos numeros)
     * @param   string  $protId Numero do protocolo de aceitaçao da NFe enviado anteriormente pelo SEFAZ
     * @param   boolean $bSave
     * @return	boolean TRUE se sucesso ou FALSE se falha
     * Obsoleto a partir da vers�o 3
     * FUNCIONAL !!!
     * @access  public
     ************************************************/
    public function cancelaNF($idNFe,$protId, $xJust, $bSave=TRUE){
    	$this->limparVariaveis();
    	//variavel de retorno
        $bRet = FALSE;
        // carga das variaveis da funçao do webservice
        $wsdl = 'NfeCancelamento'.$this->_comp_vers;
        //$cabecXsdfile   = $this->aFxsd['CabecMsg'];
        //$cabecVer       = $this->aVerxsd['CabecMsg'];
        //$dataXsdfile    = $this->aFxsd[$wsdl];
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;


        $nfeDadosMsg = utf8_encode('<?xml version="1.0" encoding="utf-8"?><cancNFe xmlns="'.$this->URLnfe.'" versao="'.$dataVer.'"><infCanc Id="ID'.$idNFe.'"><tpAmb>'.$this->ambiente.'</tpAmb><xServ>CANCELAR</xServ><chNFe>'.$idNFe.'</chNFe><nProt>'.$protId.'</nProt><xJust>'.$xJust.'</xJust></infCanc></cancNFe>');
        $nfeDadosMsg = $this->assina($nfeDadosMsg, 'infCanc');
        if($nfeDadosMsg===false) {
        	$this->errorStatus = true;
        	return false;
        }

        $order 		 = array("\r\n", "\n", "\r");
        $replace 	 = '';
        $nfeDadosMsg = str_replace($order, $replace, $nfeDadosMsg);

        $param = $nfeDadosMsg;

        if($this->_versao_nfe >= 2) {
        	$param = str_ireplace('<?xml version="1.0" encoding="utf-8"?>',"",$nfeDadosMsg);
			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
			$nfeDadosMsg = new stdClass;
			$nfeDadosMsg->any = $param;
			$param = $nfeDadosMsg;

        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }


        $retorno = $this->sendSOAP($param, $wsdl);

        if (is_array($retorno)) {
/*            $retorno = array_change_key_case($retorno, CASE_LOWER); //Transforma todas as chaves em min�sculo, pois teve um caso que veio diferente
            $xmlresp = $retorno[strtolower($this->aFunctionWdsl[$wsdl].'Result')];*/
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);

            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);
            if ($xmlresp == ''){
                //houve uma falha na comunicação SOAP
                return FALSE;
            }
			$this->respostaXML = $xmlresp;
            // tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);

            $this->versao = $doc->getElementsByTagName('versao')->item(0)->nodeValue;
            $infCanc = $doc->getElementsByTagName('infCanc')->item(0);
            //extrai o id da tag
            $id = trim($infCanc->getAttribute("Id"));

            $this->tpAmb = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            $this->cUF = $doc->getElementsByTagName('cUF')->item(0)->nodeValue;

            if ( $this->cStat == '101' ) {
                $bRet = TRUE;
                $this->chNFe = $doc->getElementsByTagName('chNFe')->item(0)->nodeValue;
                $this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
                $this->nProt = $doc->getElementsByTagName('nProt')->item(0)->nodeValue;
            }

            if($bSave){
                //salvar o xml retornado do SEFAZ
                $nome = $this->inutilizadasNF.$id.'-INUT.xml';
                $nome = $doc->save($nome);
            }

        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }
        return $bRet;
    }

    /**
     * Solicita dados de situaçao de NF
     * FUNCIONAL !!
     * @param	string   $idNFe numerico com 44 digitos
     * @param   boolean  $bSave
     * @return	mixed	response from SOAP call
     * @access  public
     **/
    public function consultaNF($idNFe, $bSave=TRUE, $_esperar_menos = false){
		$this->limparVariaveis();
    	//variavelde retorno do metodo
        $bRet = FALSE;
        if($this->_versao_nfe >= 2 && $this->_versao_nfe < 4) {
        	$wsdl = 'NfeConsulta2';
        } elseif ($this->_versao_nfe >= 4) {
            $wsdl = 'NfeConsulta4';
        } else {
        	$wsdl = 'NfeConsultaNF';
        }
        $dataVer        = $this->aVerxsd[$wsdl];
        $cabecVer       = $dataVer;

        /**
         * Antes precisava do xsi e xsd agora n�o � mais permitido sen�o gera erro 587.
         *
         *  $param = '<consSitNFe xmlns:xsi="'.$this->URLxsi.'" xmlns:xsd="'.$this->URLxsd.'" versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><tpAmb>'.$this->ambiente.'</tpAmb><xServ>CONSULTAR</xServ><chNFe>'.$idNFe.'</chNFe></consSitNFe>';
         */
        $param = '<consSitNFe versao="'.$dataVer.'" xmlns="'.$this->URLnfe.'"><tpAmb>'.$this->ambiente.'</tpAmb><xServ>CONSULTAR</xServ><chNFe>'.$idNFe.'</chNFe></consSitNFe>';

        if ($this->_versao_nfe >= 2) {
			//Acho que isso dever� vir definido como classe de cada objeto que o enviar.
			$nfeDadosMsg 	  = new stdClass;
			$nfeDadosMsg->any = $param;
			$param 			  = $nfeDadosMsg;
        } else {
        	$nfeStatusServicoNF  = new stdClass;
			$nfeStatusServicoNF->nfeCabecMsg = '<cabecMsg versao="'.$cabecVer.'" xmlns="'.$this->URLnfe.'"><versaoDados>'.$dataVer.'</versaoDados></cabecMsg>';
            $nfeStatusServicoNF->nfeDadosMsg = $param;
            $param = $nfeStatusServicoNF;
        }


        $retorno = $this->sendSOAP($param, $wsdl, $_esperar_menos);
        //$retorno["nfeRecepcaoEventoResult"] = "<env:Envelope xmlns:env='http://www.w3.org/2003/05/soap-envelope'><env:Body xmlns:env='http://www.w3.org/2003/05/soap-envelope'><nfeResultMsg xmlns='http://www.portalfiscal.inf.br/nfe/wsdl/NFeConsultaProtocolo4'><retConsSitNFe versao='4.00' xmlns='http://www.portalfiscal.inf.br/nfe'><tpAmb>1</tpAmb><verAplic>PR-v4_4_3</verAplic><cStat>101</cStat><xMotivo>Cancelamento de NF-e homologado</xMotivo><cUF>41</cUF><dhRecbto>2020-10-30T12:10:12-03:00</dhRecbto><chNFe>41201022685030004532651130000181381045211134</chNFe><protNFe versao='4.00'><infProt Id='ID141201255503139'><tpAmb>1</tpAmb><verAplic>PR-v4_4_3</verAplic><chNFe>41201022685030004532651130000181381045211134</chNFe><dhRecbto>2020-10-28T12:14:05-03:00</dhRecbto><nProt>141201255503139</nProt><digVal>1ChFGG6eNVdwyfuxcPpBh1IFzjQ=</digVal><cStat>100</cStat><xMotivo>Autorizado o uso da NF-e</xMotivo></infProt></protNFe><procEventoNFe versao='1.00'><evento versao='1.00'><infEvento Id='ID1101124120102268503000453265113000018138104521113401'><cOrgao>41</cOrgao><tpAmb>1</tpAmb><CNPJ>22685030004532</CNPJ><chNFe>41201022685030004532651130000181381045211134</chNFe><dhEvento>2020-10-29T09:06:27-03:00</dhEvento><tpEvento>110112</tpEvento><nSeqEvento>1</nSeqEvento><verEvento>1.00</verEvento><detEvento versao='1.00'><descEvento>Cancelamento por substituicao</descEvento><cOrgaoAutor>41</cOrgaoAutor><tpAutor>1</tpAutor><verAplic>2.14.132.123.c5(RADE</verAplic><nProt>141201255503139</nProt><xJust>Cancelamento por substituicao</xJust><chNFeRef>41201022685030004532651130000181399045211544</chNFeRef></detEvento></infEvento><Signature xmlns='http://www.w3.org/2000/09/xmldsig#'><SignedInfo><CanonicalizationMethod Algorithm='http://www.w3.org/TR/2001/REC-xml-c14n-20010315'/><SignatureMethod Algorithm='http://www.w3.org/2000/09/xmldsig#rsa-sha1'/><Reference URI='#ID1101124120102268503000453265113000018138104521113401'><Transforms><Transform Algorithm='http://www.w3.org/2000/09/xmldsig#enveloped-signature'/><Transform Algorithm='http://www.w3.org/TR/2001/REC-xml-c14n-20010315'/></Transforms><DigestMethod Algorithm='http://www.w3.org/2000/09/xmldsig#sha1'/><DigestValue>fy3/6KZCNqR9UcBCD2GjfX5syDo=</DigestValue></Reference></SignedInfo><SignatureValue>b8uMykocRR6Mt/B1tMQ2CJb89SMuWiphVO65D3vwh3dk0dBcO8i9JaH7EwNpMoTdg8VFLG+TvgFcyhqHwi/KGx9AnVEEdvJtBPB1a8UX8VX1NMoIXMnQKO5fcfWQktzKMemfHsawUUM4NgP3c0isKn/0IUT+PeVN1sAFz0nEFixCsRQA9Pc0QN7a2mDo5MPnUDQ7IepmA9mtL3cmwXm4i88YWNMst9+kj13HLzSbgZ9f2P7V5Exee3siYC5DfHNZ11sNhl4FcNnUFjC5G/VDqP/kQDYb+9JkmmMZbXU7+gC+RjKdkc1RPAho6R1JEllG75OmdBC1khnrIKksj//FQA==</SignatureValue><KeyInfo><X509Data><X509Certificate>MIIH4DCCBcigAwIBAgIIObi5+4+goswwDQYJKoZIhvcNAQELBQAwdDELMAkGA1UEBhMCQlIxEzARBgNVBAoTCklDUC1CcmFzaWwxNjA0BgNVBAsTLVNlY3JldGFyaWEgZGEgUmVjZWl0YSBGZWRlcmFsIGRvIEJyYXNpbCAtIFJGQjEYMBYGA1UEAxMPQUMgVkFMSUQgUkZCIHY1MB4XDTIwMDUxOTEzMzQ0MVoXDTIxMDUxOTEzMzQ0MVowggEPMQswCQYDVQQGEwJCUjELMAkGA1UECBMCU1AxEjAQBgNVBAcTCVNBTyBQQVVMTzETMBEGA1UEChMKSUNQLUJyYXNpbDE2MDQGA1UECxMtU2VjcmV0YXJpYSBkYSBSZWNlaXRhIEZlZGVyYWwgZG8gQnJhc2lsIC0gUkZCMRYwFAYDVQQLEw1SRkIgZS1DTlBKIEExMS4wLAYDVQQLEyVBUiBOT1ZPIFNBTyBQQVVMTyBDRVJUSUZJQ0FETyBESUdJVEFMMRcwFQYDVQQLEw4yMDUyMDEyNjAwMDEwMjExMC8GA1UEAxMoTUFHQVpJTkUgVE9SUkEgVE9SUkEgTFREQToyMjY4NTAzMDAwMDExMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALyZBV6dv2E4q2F6mODiJHskkiJ3f0i9CwLdG++n/zp9WT/FLGAN3O+zl/yWyvp/llh82oAVzW9/XGGK4tQF68pGLgrDvdiPSfyWpzgzOm387R8iw3R9BpRadXmRo2CY/6h7MYG4+59bjA96rfK8cAyN7PmNhpGBQTJa5fU/9hbii1nrJwLUIPQLHhzRuwg5k6xtIvPSkVb5C7mznnzAkGXyelwfLLFJx5LuTwOv0U5IUK3O6yLjWAlf7QVnHr9u+oIcHeQxO8ta753LfmxQq7/zUFm7IPV7GJuU2A5MLKtD7qbWd5fZXUUuNyGQOLsZ7+BLicwlT0lBwsNKq8FzoCsCAwEAAaOCAtcwggLTMIGcBggrBgEFBQcBAQSBjzCBjDBVBggrBgEFBQcwAoZJaHR0cDovL2ljcC1icmFzaWwudmFsaWRjZXJ0aWZpY2Fkb3JhLmNvbS5ici9hYy12YWxpZHJmYi9hYy12YWxpZHJmYnY1LnA3YjAzBggrBgEFBQcwAYYnaHR0cDovL29jc3B2NS52YWxpZGNlcnRpZmljYWRvcmEuY29tLmJyMAkGA1UdEwQCMAAwHwYDVR0jBBgwFoAUU8ul5HVQmUAsvlsVRcm+yzCqicUwcAYDVR0gBGkwZzBlBgZgTAECASUwWzBZBggrBgEFBQcCARZNaHR0cDovL2ljcC1icmFzaWwudmFsaWRjZXJ0aWZpY2Fkb3JhLmNvbS5ici9hYy12YWxpZHJmYi9kcGMtYWMtdmFsaWRyZmJ2NS5wZGYwgbYGA1UdHwSBrjCBqzBToFGgT4ZNaHR0cDovL2ljcC1icmFzaWwudmFsaWRjZXJ0aWZpY2Fkb3JhLmNvbS5ici9hYy12YWxpZHJmYi9sY3ItYWMtdmFsaWRyZmJ2NS5jcmwwVKBSoFCGTmh0dHA6Ly9pY3AtYnJhc2lsMi52YWxpZGNlcnRpZmljYWRvcmEuY29tLmJyL2FjLXZhbGlkcmZiL2xjci1hYy12YWxpZHJmYnY1LmNybDAOBgNVHQ8BAf8EBAMCBeAwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMEMIGrBgNVHREEgaMwgaCBGGZpc2NhbEBsb2phc3RvcnJhLmNvbS5icqA4BgVgTAEDBKAvBC0wMzAxMTk2NjA5NjAxNzI2ODg4MDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDCgFgYFYEwBAwKgDQQLTUFSQ09TIFJVSVqgGQYFYEwBAwOgEAQOMjI2ODUwMzAwMDAxMTGgFwYFYEwBAwegDgQMMDAwMDAwMDAwMDAwMA0GCSqGSIb3DQEBCwUAA4ICAQARGqGwe6QSv4Gz/YlfjMN7cFPp/7jSIOOSWf21cifr4bdPo6yxKqm7rKiQ6wJQl+eeBRrrsh7SnTUH9zgLsKRIwIVXyPy/J79gK0SroKiEvISC7/f9f1EdFFyJR0hi+SKQSeAd2g9Jpgc/7z4lm4rkvIqHZqv0DlcBTnvRe7AOD2H9H/JbW93YzdMTtRDtpHzK8uHrM1FhKNTlOLzGfuPXZzcc0nnRcPGwSyz0BaEAzUUhhS4ZIWua2BTN1szWeKbQCUB4ZrtGWnFS4YtpUglWFwbOU0Od2HMzgUo9UFE6ylnntDloK0DM683Ni27pHF/Z00YOt/eGGiYvw4mqOAouxe9QwBI3TmeDYqJtFCHr0mDyWBHCuv7MU76YcDvIbXN/fr3bQ3+LmpGIhgJJ0D5EFIJKfB7jPOmZoXfUXs1UBxhuX5wOZ76QN7u+C9nD0YTfp5Ta7w6M7mczc/1WfFI5FPb12e9oSLt1rcqkY4njWTR/r3NXb+pRwcUebqyFRoFDhReWFl4k11Mr2qfCZ3VdAnhyNkLOU14VUwCK7qc6yBmf1f3NPYg7Dr6k2xrBl1/9z+Z5rINP64BQ1cOgMvsFFqnzUD2cRkIyOY5f1M4rfppOE35j+lzQxTNgzSU9n4N/iCqExnyL+sPWB8uhdU9o2cxuGFvLzCYprnonrweFlg==</X509Certificate></X509Data></KeyInfo></Signature></evento><retEvento versao='1.00' xmlns='http://www.portalfiscal.inf.br/nfe'><infEvento><tpAmb>1</tpAmb><verAplic>PR-v4_4_3</verAplic><cOrgao>41</cOrgao><cStat>135</cStat><xMotivo>Evento registrado e vinculado a NF-e</xMotivo><chNFe>41201022685030004532651130000181381045211134</chNFe><tpEvento>110112</tpEvento><xEvento>Cancelamento por Substituicao</xEvento><nSeqEvento>1</nSeqEvento><dhRegEvento>2020-10-29T09:07:40-03:00</dhRegEvento><nProt>141201259146038</nProt></infEvento></retEvento></procEventoNFe></retConsSitNFe></nfeResultMsg></env:Body></env:Envelope>";

        if (is_array($retorno)) {
            /*$retorno = array_change_key_case($retorno, CASE_LOWER); //Transforma todas as chaves em min�sculo, pois teve um caso que veio diferente
            $xmlresp = $retorno[strtolower($this->aFunctionWdsl[$wsdl].'Result')];*/
            /* Essa compara��o do Result deixou de funcionar, pq a sefaz mudou o retorno ou o nosso arquivo est� errado (isso est� frequente)
             * pra resolver o problema da consulta fiz o seguinte pego o primeiro elemento, pois at� o momento sempre retorna 1
             *
             */
            $chave   = key($retorno);
            if (stripos($chave,'Result') === false) {
                return false;
            }
            $xmlresp =  current($retorno);
            $xmlresp = $this->limparXML($xmlresp);
            $xmlresp = utf8_encode($xmlresp);
            if ($xmlresp == ''){
                //houve uma falha na comunicação SOAP
                return FALSE;
            }
			$this->respostaXML = $xmlresp;
            // tratar dados de retorno
            $doc = new DOMDocument(); //cria objeto DOM
            $doc->formatOutput = false;
            $doc->preserveWhiteSpace = false;
            $doc->loadXML($xmlresp,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
            $this->tpAmb = $doc->getElementsByTagName('tpAmb')->item(0)->nodeValue;
            $this->verAplic = $doc->getElementsByTagName('verAplic')->item(0)->nodeValue;
            $this->cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
            /*if ((int) $this->cStat === 656) {
                funcoesGerais::GravaLog("retornou 656 ao consultaNF nf {$idNFe} ",true,true);
            }*/
            $this->xMotivo = $doc->getElementsByTagName('xMotivo')->item(0)->nodeValue;
            $this->cUF = $doc->getElementsByTagName('cUF')->item(0)->nodeValue;

            if ( $this->cStat == '100' || $this->cStat == '101' || $this->cStat == '110' || $this->cStat == '150' ) {
                $bRet = TRUE;
                $this->chNFe = $doc->getElementsByTagName('chNFe')->item(0)->nodeValue;
                $this->digVal = $doc->getElementsByTagName('digVal')->item(0)->nodeValue;
                $this->dhRecbto = $doc->getElementsByTagName('dhRecbto')->item(0)->nodeValue;
                $this->nProt = $doc->getElementsByTagName('nProt')->item(0)->nodeValue;
            }

            $eventos = $doc->getElementsByTagName("evento");
            if (!empty($eventos)) {
                foreach ($eventos as $evento) {
                    // BL-6980 Traremos todos os dados dos eventos para poder acertar na tab_eventos em caso de erros j� tinha a informa��o, so nao utilizava
                    $this->aEvto[] = array(
                        'cOrgao'=>$evento->getElementsByTagName('cOrgao')->item(0)->nodeValue,
                        'tpAmb'=>$evento->getElementsByTagName('tpAmb')->item(0)->nodeValue,
                        'CNPJ'=>$evento->getElementsByTagName('CNPJ')->item(0)->nodeValue,
                        'chNFe'=>$evento->getElementsByTagName('chNFe')->item(0)->nodeValue,
                        'dhEvento'=>$evento->getElementsByTagName('dhEvento')->item(0)->nodeValue,
                        'tpEvento'=>$evento->getElementsByTagName('tpEvento')->item(0)->nodeValue,
                        'nSeqEvento'=>$evento->getElementsByTagName('nSeqEvento')->item(0)->nodeValue,
                        'verEvento'=>$evento->getElementsByTagName('verEvento')->item(0)->nodeValue,
                        'descEvento'=>$evento->getElementsByTagName('descEvento')->item(0)->nodeValue,
                        'cOrgaoAutor'=>$evento->getElementsByTagName('cOrgaoAutor')->item(0)->nodeValue,
                        'tpAutor'=>$evento->getElementsByTagName('tpAutor')->item(0)->nodeValue,
                        'verAplic'=>$evento->getElementsByTagName('verAplic')->item(0)->nodeValue,
                        'nProt'=>$evento->getElementsByTagName('nProt')->item(0)->nodeValue,
                        'xJust'=>$evento->getElementsByTagName('xJust')->item(0)->nodeValue,
                        'chNFeRef'=>$evento->getElementsByTagName('chNFeRef')->item(0)->nodeValue,
                    );
                }
            }

            if($bSave){
                //salvar o xml retornado do SEFAZ
                $nome = $this->consultadasNF.$idNFe.'-PROT.xml';
                $nome = $doc->save($nome);
            }
        } else {
            $this->errorStatus = true;
            $this->errorMsg = 'Nao houve retorno do NuSoap!!';
        }
        return $bRet;
    }


    /**
     * Gera arquivo pdf para impressao de NF-e
     * @param	string   $xml
     * @param   string   $formato P=portrait L=landscape
     * @return
     * @access  public
     * @author Djalma Fadel Junior
     *
     **/
    public function imprimeNF($xml, $formato="P"){
        include_once ('danfe.class.php');
        $danfe = new danfe($xml, $formato);
        return $danfe->gera();
    }


    /**
     * Métodos Privados da Classe
     */


	/**
     * Estabelece comunicaçao com servidor SOAP
     * FUNCIONAL !!!
     * @param    array   $param Matriz com o cabeçalho e os dados da mensagem soap
     * @param    string  $wsdl Designaçao do Serviço SOAP
     * @param boolean $_esperar_menos Se for lote sincrono pode ter vindo do processar background, neste caso � cli n�o m�dulo ou fastcgi
     * @return   mixed  Array com a resposta do SOAP ou String do erro ou false
     * @access   private
     **/
    private function sendSOAP($param,$wsdl, $_esperar_menos=false){
    	//Pegamos o tempo e alteramos para que n�o demore muito no TIME-OUT.
		$_def_socket = ini_get("default_socket_timeout");

        /**
         * Se n�o estiver setado colocaremos o padr�o.
         */
        if (!isset($this->soapTimeout)) {
            //Se for pelo Mirage faremos 30 segundos, qualquer um dos dois. Mas NFe sempre esperaremos 30 seg
            if (PHP_SAPI === "cli") {
                //Se for NFe vamos esperar at� 30 segundos por causa do estado de Goiania
                ini_set("default_socket_timeout", 50);
                $this->soapTimeout = 50;
            } else {
                ini_set("default_socket_timeout", 10);
                $this->soapTimeout = 10;
            }
        } else {
            ini_set("default_socket_timeout", $this->soapTimeout);
        }

		$_metodo = $this->aFunctionWdsl[$wsdl];

        try{
        	$_urlsefaz = $this->aURLwsdl[$wsdl] . "?wsdl";
            $_versao   = $this->aVerxsd[$wsdl];
            if($this->_versao_nfe >= 4) {
                $_versao = $this->_versao_nfe;
            }
            if ((int) $this->modelo == 55) {
                //Na SEFAZ da Bahia tem umas coisas diferentes. NFe
                if ($this->cUF == 29) {
                    if ($wsdl == "NfeConsulta2") {
                        $wsdl = "NfeConsultaNF";
                    } elseif ($wsdl == "NfeInutilizacao2") {
                        $wsdl = "NfeInutilizacao";
                    }
                    /*if (strtoupper($wsdl) == "NFEAUTORIZACAO") {
                        $_metodo = "nfeAutorizacaoLote";
                    }*/
                }
                //Cear�
                //Se n�o mandar assim o nome do m�todo da erro 500 na SEFAZ eu ia mudar no arquivo, mas as pessoas sobrescrevem ele
                if ($this->cUF == 23) {
                    if ($wsdl == "NfeConsulta2") {
                        $_metodo = "nfeConsultaNF2";
                    } elseif ($wsdl == "RecepcaoEvento" && $this->getSituacaoEPEC() != true) {
                        $_metodo = "nfeRecepcaoEvento";
                    } elseif ($wsdl == "CadConsultaCadastro2") {
                        $_metodo = "consultaCadastro2";
                    } else if ($wsdl == "NfeAutorizacao") {
                        $_metodo = "nfeAutorizacaoLote";
                    } else if($wsdl == "NfeRetAutorizacao") {
                        $_metodo = "nfeRetAutorizacaoLote";
                    }
                }
            } else {
                //A Sefaz do Rio Grande do Sul deve ser tratada diferente.
                if (funcoesGerais::checarParticipaSefazRioGrandeDoSul($this->cUF, $this->modelo)) {
                    //O m�todo � outro.
                    if ($wsdl == "NfeConsulta2") {
                        $_metodo = "nfeConsultaNF2";
                    }
                }
            }

            $headerWSDL = rtrim($wsdl, 'NF');

            if(!empty($this->aSoaActionWdsl[$wsdl])) {
                $headerWSDL = $this->aSoaActionWdsl[$wsdl];
            }
            if(!empty($this->aMetodoWdsl[$wsdl])) {
                $_metodo = $this->aMetodoWdsl[$wsdl];
            }
            //funcoesGerais::GravaLog("URL: {$_urlsefaz}",true,true);
        	$_namespace = 'http://www.portalfiscal.inf.br/nfe/wsdl/'.$headerWSDL;
        	$_cabec     = '<nfeCabecMsg xmlns="'. $_namespace . '"><cUF>'.$this->cUF.'</cUF><versaoDados>'.number_format($_versao,2).'</versaoDados></nfeCabecMsg>';
        	$_dados  	= '<nfeDadosMsg xmlns="'. $_namespace . '">'. $param->any. '</nfeDadosMsg>';

            /**
             * BL-9680
             * consultaCadastro MT - Obriga a tag antes do nfeDados
             */
            if ($this->cUF==51 && $_metodo=="consultaCadastro") {
                $_dados = "<{$_metodo}>".$_dados."</{$_metodo}>";
            }

        	$_cont      = 0;
            //funcoesGerais::GravaLog("passo 5 [enviarNFCeSincrono]" ,true,true);
        	$retorno    = false;
        	$this->erro_http = null;
            self::$_saiu_por_timeout_de_resposta = false;
        	//Se n�o conseguiu falar com o SEFAZ tenta mais vezes
        	while ($_cont <= 2) {
                if ($GLOBALS["_DEBUG_SEFAZ"] === true) {
                    $_h_ini = time();
                }
                //funcoesGerais::GravaLog("passo 6 [enviarNFCeSincrono]" ,true,true);
	        	$retorno    = $this->__sendSOAP2($_urlsefaz, $_namespace, $_cabec, $_dados, $_metodo,'','',$_esperar_menos);
               /* $retorno["nfeRetAutorizacaoResult"] = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
	<soap:Body>
		<nfeResultMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRetAutorizacao4">
			<retConsReciNFe versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">
				<tpAmb>1</tpAmb>
				<verAplic>SVRSnfce202011030938</verAplic>
				<nRec>333099830823628</nRec>
				<cStat>104</cStat>
				<xMotivo>Lote processado</xMotivo>
				<cUF>33</cUF>
				<dhRecbto>2020-11-13T11:24:02-03:00</dhRecbto>
				<protNFe versao="4.00">
					<infProt>
						<tpAmb>1</tpAmb>
						<verAplic>SVRSnfce202011030938</verAplic>
						<chNFe>33201122685030007043651010000018079072805250</chNFe>
						<dhRecbto>2020-11-13T11:24:02-03:00</dhRecbto>
						<digVal>UQBCrcOIbimBhZzKBkaq7lpjTF4=</digVal>
						<cStat>539</cStat>
						<xMotivo>Rejeicao: Duplicidade de NF-e, com diferenca na Chave de Acesso [chNFe:33201122685030007043651010000018071072805255][nRec:333099817380301]</xMotivo>
					</infProt>
				</protNFe>
			</retConsReciNFe>
		</nfeResultMsg>
	</soap:Body>
</soap:Envelope>';*/
                /**
                 * BL-6116
                 * Se for NFCe vamos tentar mais veze pois o timeout ser� menor.
                 */
                if ($_esperar_menos === true || ($this->modelo === 65 && PHP_SAPI !== "cli")) {

                   //Se passou n�o vai continuar.
                    if ($this->errorStatus) {
                        /**
                         * BL-6116
                         * Se for um erro de operation timed out after, significa que chegou ent�o n�o vamos mais esperar,
                         * Vamos tentar consultar a nota
                         */
                        if (strpos($this->errMsg,"Operation timed out after") !== false) {
                            self::$_saiu_por_timeout_de_resposta = true;
                            $_cont = 3;
                        }
                        //Vamos deixar ele tentar as vezes que forem necess�rias, assim aprova mais.
                        if (strpos($this->errMsg,"Resolving timed out after") === false && strpos($this->errMsg,"Operation timed out after") === false) {
                            //funcoesGerais::GravaLog("opa... [{$_cont}] {$this->errMsg} ",true,true,false,'ACOMPANHANDO.TXT');
                            $_cont = 3;
                        }
                    }

                }

                /*if ($this->errorStatus && $_cont > 0) {
                    funcoesGerais::GravaLog("acompanhando [{$_cont}] {$this->errMsg} ",true,true,false,'ACOMPANHANDO.TXT');
                }*/

                //funcoesGerais::GravaLog("passo 7 [enviarNFCeSincrono]" ,true,true);

                if ($GLOBALS["_DEBUG_SEFAZ"] === true) {
                    $_h_fim     = time();
                    funcoesGerais::GravaLog("\n[sendSOAP] tentativa [{$_cont}] Falando com a SEFAZ: " . date('H:i:s', $_h_ini) . " - final" . date('H:i:s', $_h_fim) . "\n", true, true, false, 'monitoramento_nf.txt');
                    funcoesGerais::GravaLog("\n[sendSOAP] URL [{$_urlsefaz}], UF [{$this->cUF }], NAMESPACE [{$_namespace}], CABECALHO [{$_cabec}], DADOS [{$_dados}], METODO [{$_metodo}]   \n", true, true, false, 'monitoramento_nf.txt');
                    funcoesGerais::GravaLog("\n[sendSOAP] Tempo Final Total: {$_h_fim} - {$_h_ini} = " . funcoesGerais::timeDiff($_h_ini, $_h_fim), true, true, false, 'monitoramento_nf.txt');
                    funcoesGerais::GravaLog("\n[sendSOAP] retorno [" . var_export($retorno,true) . "]" , true, true, false, 'monitoramento_nf.txt');
                }
                //ML-278 H� uma suspeita de que como estava ele estava ficando em loop infinito, ent�o mudo a condi��o para que ele saia quando atingir o contador 3
                if ($retorno !== false) {
                    break;
                }
                //N�o tenta novamente, e tenta gerar o lote
                if ($this->erro_http >= 500) {
                    //Sai mesmo nem tenta ver nada.
                    return false;
                }
	        	$_cont++;
        	}

        }catch(Exception $e){
            $retorno = $e->getMessage();
            funcoesGerais::GravaLog("Problemas ao conectar ao WEBService {$retorno} url [{$_urlsefaz}]wsdl {$wsdl} m�todo {$this->aFunctionWdsl[$wsdl]}",true,true);
            //echo "<br>{$retorno}<br>";
            return $retorno;
        }

        if ($retorno === false) {
            return false;
        }
        ini_set("default_socket_timeout",$_def_socket);
        try {
	        $_att_ret = $this->aFunctionWdsl[$wsdl]."Result";
	        if(isset($retorno->any)) {
	        	$retorno = 	Array($_att_ret=>utf8_decode($retorno->any));
	        } elseif(isset($retorno->{$_att_ret})) {
	        	if($retorno->{$_att_ret} instanceof stdClass) {
	        		$retorno = $retorno->{$_att_ret}->any;
	        	} else {
	        		$retorno = $retorno->{$_att_ret};
	        	}

	        	$retorno =  Array($_att_ret=>$retorno);
	        }
        } catch(Exception $e){
            $retorno = $e->getMessage();
            funcoesGerais::GravaLog("Problemas ao conectar ao WEBService {$retorno} url [{$_urlsefaz}]wsdl {$wsdl} m�todo {$this->aFunctionWdsl[$wsdl]}",true,true);
            //echo "<br>{$retorno}<br>";
            return false;
        }

        return $retorno;
    }


    /**
     * Converte o campo data time retornado pelo webservice
     * em um timestamp unix
     *
     * @param    string   $DH
     * @return   timestamp
     * @access   private
     **/
    private function convertTime($DH){
        if ($DH){
            $aDH = explode('T',$DH);
            $adDH = explode('-',$aDH[0]);
            $atDH = explode(':',$aDH[1]);
            $timestampDH = mktime($atDH[0],$atDH[1],$atDH[2],$adDH[1],$adDH[2],$adDH[0]);
            return $timestampDH;
        }
    }

    /**
     * Retira as chaves de inicio e fim do certificado digital
     * para inclusão do mesmo na tag assinatura
     *
     * @param    none
     * @return   string contendo a chave digital limpa
     * @access   private
     **/
    public function limpaCert(){
        //carregar a chave publica do arquivo pem
        //Se for o m�dulo n�o tem o arquivo limpo
        if (file_exists($this->pathCert_limpo)) {
            $pubKey = $this->retornarDadoArquivo($this->pathCert_limpo);
            return $pubKey;
        } else {
            //carregar a chave publica do arquivo pem
            $pubKey = file_get_contents($this->pathCert);
            //inicializa variavel
            $data = '';
            //carrega o certificado em um array usando o LF como referencia
            $arCert = explode("\n", $pubKey);
            foreach ($arCert AS $curData) {
                //remove a tag de inicio e fim do certificado
                if (strncmp($curData, '-----BEGIN CERTIFICATE', 22) != 0 && strncmp($curData, '-----END CERTIFICATE', 20) != 0 ) {
                    //carrega o resultado numa string
                    $data .= trim($curData);
                }
            }
            //Quebra no mesmo tamanho que no programa da receita
            return $data;//wordwrap($data,76,"\n",true);
        }
    }

   /**
    * carregaSEFAZ
    * Função para extrair o URL, nome do serviço e versão dos webservices das SEFAZ de
    * todos os Estados da Federação do arquivo urlWebServicesNFe.xml
    *
    * O arquivo xml é estruturado da seguinte forma :
    * <WS>
    *   <UF>
    *      <sigla>AC</sigla>
    *          <homologacao>
    *              <Recepcao service='nfeRecepcao' versao='1.10'>http:// .....
    *              ....
    *          </homologacao>
    *          <producao>
    *              <Recepcao service='nfeRecepcao' versao='1.10'>http:// ....
    *              ....
    *          </producao>
    *   </UF>
    *   <UF>
    *      ....
    * </WS>
    *
    *  @param  string $spathXML   Caminho completo para o arquivo xml
    *  @param  string $sAmbiente Pode ser "homologacao" ou "producao"
    *  @param  string $sUF       Sigla da Unidade da Federação (ex. SP, RS, etc..)
    *  @return mixed             FALSE se houve erro ou array com os dado do URLs das SEFAZ
    */
    public function carregaSEFAZ($spathXML,$sAmbiente,$sUF) {
        $_obj_memcache = $this->getobj_memcache();
        /**
         * Se o objeto Memcache estiver ativo vamos us�-lo
         * Sen�o deixa como esta.
         */
        if ($_obj_memcache !== false) {
            $_chave_memcache = "xml_{$sAmbiente}_{$sUF}_nota_{$spathXML}";
            if (($_ret = $this->retornarDadoArquivo($_chave_memcache)) !== false) {
                $_ret = unserialize($_ret);
                if (isset($_ret["TEMPO_CONECTAR"]) && (int) $_ret["TEMPO_CONECTAR"] > 1 ) {
                    $this->tempo_conectar = (int)$_ret["TEMPO_CONECTAR"];
                }
                if (isset($_ret["TEMPO_ESPERAR"]) && (int) $_ret["TEMPO_ESPERAR"] > 1) {
                    $this->soapTimeout = (int)$_ret["TEMPO_ESPERAR"];
                }
                return $_ret["URLS"];
            }
        }



        //verifica se o arquivo xml pode ser encontrado no caminho indicado
        if ( file_exists($spathXML) ) {
            //carrega o xml
            $xml = simplexml_load_file($spathXML);
        } else {
            //sai caso não possa localizar o xml
            return FALSE;
        }

        $_ret = Array();
        //estabelece a expressão xpath de busca
        $xpathExpression = "/WS/UF[sigla='$sUF']/$sAmbiente";
        $_objExpression = $xml->xpath( $xpathExpression );
        if(empty($_objExpression)){
            funcoesGerais::GravaLog('Erro ao obter dados do XML '.$spathXML, true, true);
            return false;
        }
        //para cada "n�" no xml que atenda aos critérios estabelecidos
        foreach ($_objExpression as $gUF ) {
            $_atributos = $gUF->Attributes();
            if (sizeof((array)$_atributos) > 0) {
                if ((int)$_atributos->tempo_conectar[0] > 1) {
                    $this->tempo_conectar = (int)$_atributos->tempo_conectar[0];
                    $_ret["TEMPO_CONECTAR"] = $this->tempo_conectar;
                }
                if ((int)$_atributos->tempo_esperar[0] > 1) {
                    $this->soapTimeout     = (int)$_atributos->tempo_esperar[0];
                    $_ret["TEMPO_ESPERAR"] = $this->soapTimeout;
                }


            }
            //para cada "nó filho" retonado
            foreach ( $gUF->children() as $child ) {
                $aUrl[$child->getName()]['URL'] = (string) $child[0];
                // em cada um desses nós pode haver atributos como a identificação
                //do nome do webservice e a sua versão
                foreach ( $child->attributes() as $a => $b) {
                    $aUrl[$child->getName()][$a] = (string) $b;
                }
            }
        }

        if ($_obj_memcache !== false) {
            $_ret['URLS'] = $aUrl;
            //Por causa de outras vers�es do php
            $_serializado = serialize($_ret);
            $this->inserirDadoArquvio($_chave_memcache,$_serializado);
        }
        //funcoesGerais::GravaLog("URL NFE --->>>> ".var_export($aUrl,true),true,true);
        return $aUrl;
    }


    /**
     * Busca informa��es de proxy caso n�o tenha pego.
     */
    protected function pegarInfoProxy() {
        /*Pra n�o ir no banco desnecess�riamente.
         *Mas � preciso colocar no ZMWSInfo.ini na aba GERAL O sem proxy.
         * SEM_PROXY=S
         *
         */

        if ($GLOBALS["_sem_proxy"] === true) {
            return true;
        }

    	if($this->aProxy!==null) {
    		return true;
    	}
    	//Preenche pra n�o entrar aqui mais caso n�o exista..
    	$this->aProxy = false;
    	$_con      = $GLOBALS['_MASTER']->cloneconnection(__METHOD__);
    	$_param    = new parametro_geral($_con);
    	$_arr_info = $_param->retornarValorParametro(Array("servidor_proxy","porta_proxy","usuario_proxy","senha_proxy"));
    	$_proxy	   = trim($_arr_info['servidor_proxy']);
    	if(!empty($_proxy)) {
    		$this->aProxy['IP']     = trim($_arr_info['servidor_proxy']);
    		$this->aProxy['PORT']   = trim($_arr_info['porta_proxy']);
    		if(!empty($_arr_info['usuario_proxy'])) {
    			$this->aProxy['USER']     = $_arr_info['usuario_proxy'];
    			$this->aProxy['PASS']	  = base64_decode($_arr_info['senha_proxy']);
    		}
    	}
    	$_con->close();

    	unset($_param);
    	return true;
    }

	/**
	 * __sendSOAP2
	 * Fun��o alternativa para estabelecer comunica�ao com servidor SOAP 1.2 da SEFAZ,
	 * usando as chaves publica e privada parametrizadas na contru��o da classe.
	 * Conforme Manual de Integra��o Vers�o 4.0.1 Utilizando cURL e n�o o SOAP nativo
	 *
	 * @name __sendSOAP2
	 * @version 2.1.7
	 * @package NFePHP
	 * @author Roberto L. Machado <linux.rlm at gmail dot com>
	 * @author Jorge Luiz Rodrigues Tom� <jlrodriguestome at hotmail dot com>
	 * @param string $urlsefaz
	 * @param string $namespace
	 * @param string $cabecalho
	 * @param string $dados
	 * @param string $metodo
	 * @param numeric $ambiente
	 * @param string $UF sem uso mantido apenas para compatibilidade com __sendSOAP
     * @param boolean $_esperar_menos indica que devo fazer como fa�o qdo � m�dulo ou fastcgi
	 * @return mixed false se houve falha ou o retorno em xml do SEFAZ
	 */
	public function __sendSOAP2($urlsefaz,$namespace,$cabecalho,$dados,$metodo,$ambiente='',$UF='', $_esperar_menos=false){
		//funcoesGerais::GravaLog("Teste __sendSOAP2 [$urlsefaz]" ,true,true);
		try {
			if ($urlsefaz == ''){
				//n�o houve retorno
				throw new Exception("URL do webservice n�o dispon�vel.\n");
			}
			if ($ambiente == ''){
				$ambiente = $this->ambiente;
			}
			$data = '';
			$data .= '<?xml version="1.0" encoding="utf-8"?>';
			$data .= '<soap12:Envelope ';
			$data .= 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ';
			$data .= 'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ';
			$data .= 'xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">';
			$data .= '<soap12:Header>';
            if($this->_versao_nfe < 4) {
			    $data .= $cabecalho;
            }
			$data .= '</soap12:Header>';
			$data .= '<soap12:Body>';
			$data .= $dados;
			$data .= '</soap12:Body>';
			$data .= '</soap12:Envelope>';

            if($GLOBALS["_DEBUG_SEFAZ"]) {
                funcoesGerais::GravaLog($data, true,true,false,"envio.xml");
            }

			//funcoesGerais::GravaLog($data,true,true,true,"teste_nfce.txt");
			//funcoesGerais::GravaLog("__sendSOAP2 passo 1 " ,true,true);
			//[Informational 1xx]
			$cCode['100']="Continue";
			$cCode['101']="Switching Protocols";
			//[Successful 2xx]
			$cCode['200']="OK";
			$cCode['201']="Created";
			$cCode['202']="Accepted";
			$cCode['203']="Non-Authoritative Information";
			$cCode['204']="No Content";
			$cCode['205']="Reset Content";
			$cCode['206']="Partial Content";
			//[Redirection 3xx]
			$cCode['300']="Multiple Choices";
			$cCode['301']="Moved Permanently";
			$cCode['302']="Found";
			$cCode['303']="See Other";
			$cCode['304']="Not Modified";
			$cCode['305']="Use Proxy";
			$cCode['306']="(Unused)";
			$cCode['307']="Temporary Redirect";
			//[Client Error 4xx]
			$cCode['400']="Bad Request";
			$cCode['401']="Unauthorized";
			$cCode['402']="Payment Required";
			$cCode['403']="Forbidden";
			$cCode['404']="Not Found";
			$cCode['405']="Method Not Allowed";
			$cCode['406']="Not Acceptable";
			$cCode['407']="Proxy Authentication Required";
			$cCode['408']="Request Timeout";
			$cCode['409']="Conflict";
			$cCode['410']="Gone";
			$cCode['411']="Length Required";
			$cCode['412']="Precondition Failed";
			$cCode['413']="Request Entity Too Large";
			$cCode['414']="Request-URI Too Long";
			$cCode['415']="Unsupported Media Type";
			$cCode['416']="Requested Range Not Satisfiable";
			$cCode['417']="Expectation Failed";
			//[Server Error 5xx]
			$cCode['500']="Internal Server Error";
			$cCode['501']="Not Implemented";
			$cCode['502']="Bad Gateway";
			$cCode['503']="Service Unavailable";
			$cCode['504']="Gateway Timeout";
			$cCode['505']="HTTP Version Not Supported";
			$tamanho = strlen($data);

            /**
             * Vers�o da CURL que ser� utilizada abaixo
             * N�o ser� mais necess�rio o CURLOPT_SSLVERSION 3 pois a sefaz do RS atualizaram seus servidores
             * /
            $_curlVersion = curl_version();
            $_curlVersionArr = explode(".",$_curlVersion["version"]);
            $_curlVersionInt = str_pad($_curlVersionArr[0],3,"0",STR_PAD_RIGHT).str_pad($_curlVersionArr[1],3,"0",STR_PAD_RIGHT).str_pad($_curlVersionArr[2],3,"0",STR_PAD_RIGHT);
            /**/

			if($this->enableSCAN){
				//monta a termina��o do URL
				switch ($metodo){
					case 'nfeRecepcaoLote'.$this->_comp_vers:
						$servico = "NfeRecepcao";
						break;
					case 'nfeRetRecepcao'.$this->_comp_vers:
						$servico = "NfeRetRecepcao";
						break;
					case 'nfeCancelamentoNF'.$this->_comp_vers:
						$servico = "NfeCancelamento";
						break;
					case 'nfeInutilizacaoNF'.$this->_comp_vers:
						$servico = "NfeInutilizacao";
						break;
					case 'nfeConsultaNF'.$this->_comp_vers:
						$servico = "NfeConsulta";
						break;
					case 'nfeStatusServicoNF'.$this->_comp_vers:
						$servico = "NfeStatusServico";
						break;
					case 'consultaCadastro':
						$servico = "CadConsultaCadastro";
						break;
				}
				$aURL = $this->loadSEFAZ( $this->raizDir . 'config' . DIRECTORY_SEPARATOR . $this->xmlURLfile,$ambiente,'SCAN');
				$urlsefaz = $aURL[$servico]['URL'];
			}
			//funcoesGerais::GravaLog("__sendSOAP2 passo 2 " ,true,true);
			$parametros = Array('Content-Type: application/soap+xml;charset=utf-8;action="'.$namespace."/".$metodo.'"','SOAPAction: "'.$metodo.'"',"Content-length: $tamanho");
			$_aspa = '"';
			//funcoesGerais::GravaLog("__sendSOAP2 passo 2.1 " ,true,true);
			$oCurl = curl_init();
			if (!funcoesGerais::managerOFFLine()) {
                $this->pegarInfoProxy();
            }

			if(is_array($this->aProxy)){
				curl_setopt($oCurl, CURLOPT_HTTPPROXYTUNNEL, 1);
				curl_setopt($oCurl, CURLOPT_PROXYTYPE, "CURLPROXY_HTTP");
				curl_setopt($oCurl, CURLOPT_PROXY, $this->aProxy['IP'].':'.$this->aProxy['PORT']);
				if( $this->aProxy['PASS'] != '' ){
					curl_setopt($oCurl, CURLOPT_PROXYUSERPWD, $this->aProxy['USER'].':'.$this->aProxy['PASS']);
					curl_setopt($oCurl, CURLOPT_PROXYAUTH, "CURLAUTH_BASIC");
				} //fim if senha proxy
			}//fim if aProxy

            /*
             * Se for um envio online vamos diminuir esse timeout.
             * N�o queremos que o usu�rio fique esperando na fila por 1 minuto n�
             * Quando � background vem como cli ent�o valoro a esperar menos
             */
            if (PHP_SAPI === "cli") { //se for pelo Mirage vamos esperar mais.
                curl_setopt($oCurl, CURLOPT_CONNECTTIMEOUT, $this->tempo_conectar);
                //Colocaremos em 1 minuto pois estava travando a curl em looping infinito
                curl_setopt($oCurl, CURLOPT_TIMEOUT, $this->soapTimeout); //timeout in seconds
            } else {//if ($_esperar_menos === true || PHP_SAPI === "cgi-fcgi" || PHP_SAPI === "apache2handler") {
                //BL-6116 Sem pool de conex�o, pois tem momentos que as consultas n�o d�o certo mesmo aumentando o timeout.
                curl_setopt($oCurl, CURLOPT_MAXCONNECTS, 1);
                //Vai deixar baixo e vai tentar novamente
                //sejamos felizes, vamos ver outras coisas, a infra do cara t� zuada
                curl_setopt($oCurl, CURLOPT_CONNECTTIMEOUT, 20);
                if ($_esperar_menos) {
                    curl_setopt($oCurl, CURLOPT_TIMEOUT, 20); //timeout in seconds
                } else {
                    //A consulta entrar� aqui, mas estava 10 e em alguns casos tb n�o vai.. Qdo n�o foi r�pido n�o adianta esperar a vida toda q n�o vai.
                    curl_setopt($oCurl, CURLOPT_TIMEOUT, 11); //timeout in seconds
                }
            }
			curl_setopt($oCurl, CURLOPT_URL, $urlsefaz.'');
            NFEtools::$_contador_conversas += 1;
            //funcoesGerais::GravaLog("[" . NFEtools::$_contador_conversas . "] vezes Acessou url {$urlsefaz}",true,true);
			curl_setopt($oCurl, CURLOPT_PORT , 443);

            //No Linux isso parece surtir efeito mas no Windows n�o.
            /*if (funcoesGerais::isLinux()) {
                curl_setopt($oCurl, CURLOPT_FRESH_CONNECT, true);
                //BL-6116 For�a enviar um fechar na conex�o..
                curl_setopt($oCurl, CURLOPT_FORBID_REUSE, true);
            }*/

			//BL-6116 n�o far� recursivos location
            //curl_setopt($oCurl, CURLOPT_FOLLOWLOCATION , false);
            //BL-6116 For�o a resolu��o por ipv4 para a SEFAZ, por algum motivo ele pega ipv6 gerando timeout.
			//curl_setopt($oCurl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
			//funcoesGerais::GravaLog("__sendSOAP2 passo 3 " ,true,true);
			//Colocar 1 para auditar.
            //Se deixar ativo vamos assumir que esta com algum problema ent�o vamos logar td
            if($GLOBALS["_DEBUG_SEFAZ"]) {
                curl_setopt($oCurl, CURLOPT_VERBOSE, 1);
                /* o Erro j� aparece no get erro por hora vamos deixar de fora isso.
                 * try {
                    curl_setopt($oCurl, CURLOPT_STDERR, fopen(dirname(__FILE__) . "/erro_curl.txt", "w+"));
                } catch (Exception $_e) {
                    curl_setopt($oCurl, CURLOPT_STDERR,0);
                }*/
            } else {
                curl_setopt($oCurl, CURLOPT_VERBOSE, 0);
            }
			curl_setopt($oCurl, CURLOPT_HEADER, 1); //retorna o cabe�alho de resposta
			//curl_setopt($oCurl, CURLOPT_SSLVERSION, 3);
			//curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, 0);

            //Para a Bahia s� funcionou assim.
            if (($_apeer = reset($this->aPeer)) > 0) {
                //Se pegarmos mais um problema basta colocarmos a cadeia intermediaria, no caso da SOLUTI foi o AC_Soluti_v5.crt
                //A SEFAZ disse q na homologa��o n�o possui o certificado intermediario ent�o precisa disso.
                curl_setopt($oCurl, CURLOPT_CAINFO, dirname(__FILE__) . '/cacert.pem');
                curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, 2); // verifica o host evita MITM
                curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, 1);
            } else {
                if (funcoesGerais::checarParticipaSefazRioGrandeDoSul($this->cUF, $this->modelo)) {
                    curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, 0); // N�o verifica
                    //N�o ser� mais necess�rio o CURLOPT_SSLVERSION 3 pois a sefaz do RS atualizaram seus servidores
                    /*if ($_curlVersionInt >= 700540000) { //The flag defines maximum supported TLS version as TLS v1.3. (Added in 7.54.0)
                        curl_setopt($oCurl, CURLOPT_SSLVERSION, 3);
                    }*/
                    //curl_setopt($oCurl, CURLOPT_DNS_CACHE_TIMEOUT, 1);
                } else {
                    curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, 2); // verifica o host evita MITM
                }
			    curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, 0);
            }
            //BL-6116 Vamos ver se diminuimos o timeout de conex�o
            /*if (funcoesGerais::isLinux()) {
                curl_setopt($oCurl, CURLOPT_DNS_CACHE_TIMEOUT, 600);
            }*/
			curl_setopt($oCurl, CURLOPT_SSLCERT,$this->pathCert);
			curl_setopt($oCurl, CURLOPT_SSLKEY, $this->pathKey);
			curl_setopt($oCurl, CURLOPT_POST, 1);
			curl_setopt($oCurl, CURLOPT_POSTFIELDS, $data);
			curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($oCurl, CURLOPT_HTTPHEADER,$parametros);
			//funcoesGerais::GravaLog("__sendSOAP2 passo 4 " ,true,true);
			$__xml = curl_exec($oCurl);

            //funcoesGerais::GravaLog($data, true,true,true,"retorno.xml");
			//funcoesGerais::GravaLog("__sendSOAP2 passo 5 " ,true,true);
            //funcoesGerais::GravaLog($__xml, true,true,true,"retorno.xml");
            //Quando esta esperando n�o vamos colocar em contigencia aqui, deixa o MIRAGE FAZER ISSO.
            if ($GLOBALS["_DEBUG_SEFAZ"] || $_esperar_menos !== true) {
                $info = curl_getinfo($oCurl); //informa��es da conex�o
                $this->erro_http = (int) $info['http_code'];
            }
            /*if ((int) $this->cUF == 29) {
                $info = curl_getinfo($oCurl); //informa��es da conex�o
                funcoesGerais::GravaLog( "tipo " . var_export($this,true) .  " uf [" . $this->cUF  . "] tempo [" . $this->soapTimeout .  "] data " . $data . "\nxml " . var_export($__xml,true) . " info " . var_export($info, true), true, true, false, "retorno.xml");
            }*/
            //funcoesGerais::GravaLog( "tipo [" . PHP_SAPI . "] url [{$urlsefaz}] [{$this->modelo}]  erro [{$this->errMsg}]" .  " uf [" . $this->cUF  . "] tempo [" . $this->soapTimeout .  "] data " . $data . "\nxml " . var_export($__xml,true) . " info " . var_export($info, true), true, true, false, "retorno.xml");
			//funcoesGerais::GravaLog("__sendSOAP2 passo 6 " ,true,true);
			/*$txtInfo ="";
			$txtInfo .= "URL={$info[url]} ou {$urlsefaz}\n";
			$txtInfo .= "Content type=$info[content_type]\n";
			$txtInfo .= "Http Code=$info[http_code]\n";
			$txtInfo .= "Header Size=$info[header_size]\n";
			$txtInfo .= "Request Size=$info[request_size]\n";
			$txtInfo .= "Filetime=$info[filetime]\n";
			$txtInfo .= "SSL Verify Result=$info[ssl_verify_result]\n";
			$txtInfo .= "Redirect Count=$info[redirect_count]\n";
			$txtInfo .= "Total Time=$info[total_time]\n";
			$txtInfo .= "Namelookup=$info[namelookup_time]\n";
			$txtInfo .= "Connect Time=$info[connect_time]\n";
			$txtInfo .= "Pretransfer Time=$info[pretransfer_time]\n";
			$txtInfo .= "Size Upload=$info[size_upload]\n";
			$txtInfo .= "Size Download=$info[size_download]\n";
			$txtInfo .= "Speed Download=$info[speed_download]\n";
			$txtInfo .= "Speed Upload=$info[speed_upload]\n";
			$txtInfo .= "Download Content Length=$info[download_content_length]\n";
			$txtInfo .= "Upload Content Length=$info[upload_content_length]\n";
			$txtInfo .= "Start Transfer Time=$info[starttransfer_time]\n";
			$txtInfo .= "Redirect Time=$info[redirect_time]\n";
			$txtInfo .= "Certinfo=$info[certinfo]\n";*/
			if ($__xml !== false) {
                $n = strlen($__xml);
                $x = strpos($__xml, "<");
                if ($x !== false) {
                    $xml = substr($__xml, $x, $n - $x);
                } else {
                    $xml = '';
                }
            }

            if($GLOBALS["_DEBUG_SEFAZ"]) {
                funcoesGerais::GravaLog("XML RESULTADO " . $xml, true,true);
                if ($__xml === false || $x === false){
                    funcoesGerais::GravaLog("log- Erro da CURL {$urlsefaz} " . curl_error($oCurl) . " [info ["  . var_export($info,true) . "] TipoModelo [{$this->modelo}] exe[" . PHP_SAPI . "] curlInfo [".curl_getinfo($oCurl, CURLINFO_HTTP_CODE)."]" . $data, true, true,  false,"LOG_ERRO_CURL_DETALHADO.ZLG");
                }
    
            }
            //funcoesGerais::GravaLog(" {$urlsefaz} " . curl_error($oCurl) . " envio: " . $data . "\nretorno: {$__xml} ", true,true,false,"envio_retorno_sucessoounao.xml");

			//$this->soapDebug = $data."\n\n".$txtInfo."\n".$__xml;
			if ($__xml === false || $x === false){
				//n�o houve retorno
				$this->errMsg = curl_error($oCurl) . $info['http_code'] . $cCode[$info['http_code']]."\n";
				$this->errorStatus = true;
                if (($GLOBALS["_DEBUG_SEFAZ"]) || ($_esperar_menos !== true && PHP_SAPI !== "cgi-fcgi" && PHP_SAPI === "apache2handler")) {
                    funcoesGerais::GravaLog("1- Erro da CURL {$urlsefaz} " . curl_error($oCurl) . " httperror [{$info['http_code']}] [" . $cCode[$info['http_code']] . "] TipoModelo [{$this->modelo}] exe[" . PHP_SAPI . "] curlInfo [".curl_getinfo($oCurl, CURLINFO_HTTP_CODE)."]" . $data, true, true);
                }
                //. "\nInfo: {$this->soapDebug}",true,true);
			} else {
				//houve retorno mas ainda pode ser uma mensagem de erro do webservice
				if((int) $info['http_code'] > 300) {
					$this->errMsg = curl_error($oCurl) . $info['http_code'] . $cCode[$info['http_code']]."\n";
					$this->errorStatus = true;
                    //Diminuindo o log
					funcoesGerais::GravaLog("2 Erro da CURL {$urlsefaz} " . curl_error($oCurl) . " httperror [{$info['http_code']}] ["  . $cCode[$info['http_code']] . "] TipoModelo [{$this->modelo}] exe[" . PHP_SAPI . "] curlInfo [".curl_getinfo($oCurl, CURLINFO_HTTP_CODE)."]" . $data,true,true);
                    //funcoesGerais::GravaLog(" {$urlsefaz} " . curl_error($oCurl) . " envio: " . $data . "\nretorno: {$__xml} parametros: " . var_export($parametros,true), true,true,false,"envio_retorno.xml");
                    //funcoesGerais::GravaLog(" {$urlsefaz} " . curl_error($oCurl) . " " ., true,true,true,"retorno.xml");
                        //. "\nInfo: {$this->soapDebug}",true,true);
                } else {
                    if ((Zstrpos($__xml,"<soap:Fault>",0)) > 0) {
                        funcoesGerais::GravaLog("SoapFault url {$urlsefaz}: " . $__xml,true,true);
                        $this->errMsg = "SoapFault\n";
                        $this->errorStatus = true;
				    } else {
                        //houve retorno mas ainda pode ser uma mensagem de erro do webservice
                        $this->errMsg = $info['http_code'] . $cCode[$info['http_code']]."\n";
                        $this->errorStatus = false;
				    }
			    }
            }
			curl_close($oCurl);
			//funcoesGerais::GravaLog("fim do m�todo sem exce��o __sendSOAP2 [" . var_export($x,true) . "] [" . var_export($this->errorStatus,true) . "]'{$__xml}' '{$this->errMsg}'" ,true,true);
			if(!$this->errorStatus) {
                /**
                 * ML-2545
                 * Maio de 2023
                 * Ajustando
                 */

                $_ult_pos     = 0;
                $_palavra     = "<cStat>";
                $_tam_palavra = strlen($_palavra);
                do {
                    $_pos_fim = strpos($xml, "</cStat>", $_ult_pos);
                    $_pos_ini = strpos($xml, $_palavra, $_ult_pos);
                    if ($_pos_ini == false || $_pos_fim == false) {
                        break;
                    }
                    //echo "\n{$_pos_ini} - {$_pos_fim}\n";
                    $_status = (int) substr($xml, $_pos_ini + $_tam_palavra, $_pos_fim - ($_pos_ini + $_tam_palavra));
                    //111 - Consulta cadastro com uma ocorr�ncia
                    //259 - CNPJ da consulta não cadastrado como contribuinte na UF
                    //262 - Rejei��o: UF n�o fornece consulta por CPF
                    if(!in_array($_status,[100, 101, 102, 103, 104, 105, 110, 111, 128, 135, 136, 150, 259, 262])) {
                        $_msg_erro = str_replace(["\r\n", "\n", "\r","\t"], " ", $xml);
                        funcoesGerais::GravaLog($_msg_erro,true,true,false,'erros_doc_eletronicos.zlg');
                        break;
                    }
                    $_ult_pos = $_pos_fim + $_tam_palavra;
                } while ($_pos_fim !== false && $_pos_ini !== false);
                /*$doc = new DOMDocument(); //cria objeto DOM
                $doc->formatOutput = false;
                $doc->preserveWhiteSpace = false;
                $doc->loadXML($xml,LIBXML_NOBLANKS | LIBXML_NOEMPTYTAG);
                $_cStat = $doc->getElementsByTagName('cStat')->item(0)->nodeValue;
                if(!in_array($_cStat,[100, 101, 110, 128, 135, 136, 150])) {
                    $_msg_erro = str_replace(["\r\n", "\n", "\r","\t"], " ", $xml);
                    funcoesGerais::GravaLog($_msg_erro,true,true,false,'erros_doc_eletronicos.zlg');
                }
                unset($doc);*/
				return [$metodo."Result"=>$xml];
			} else {
				return false;
			}
		} catch (Exception $e) {
			$this->errMsg    = "Erro ao enviar NFe: " . $e->getMessage() . "\n";
			$this->errorStatus = true;
			funcoesGerais::GravaLog("fim do m�todo por exce��o __sendSOAP2 {$this->errMsg } " ,true,true);
            /**
             * ML-2545
             * BIT
             * Jan.2023
             */
            $_msg_erro = str_replace(["\r\n", "\n", "\r","\t"], " ", $this->errMsg);
            funcoesGerais::GravaLog($_msg_erro,true,true,false,'erros_doc_eletronicos.zlg');
			return false;
		}
	} //fim __sendSOAP2
}
