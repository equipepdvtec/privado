<?php
/**
 * DANFE PAISAGEM
 * @author: �ber Lincoln
 * @data: 01/02/2010
 *
 * Baseado no DANFE feito por
 * dfadel
 * 22/07/2009
 *
 * Multiplas p�ginas, organiza��o rodap�, cabe�alho
 * @author: dlemes
 * @data: 15/08/2009
 * Classe PDF_Code128 obtida em: http://www.fpdf.org/en/script/script88.php
 *
 * TODO: Revis�o dos itens
 */


include_once(funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/fpdf.php');
include_once(funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/code128.php');

if (!defined('FPDF_FONTPATH')) {
    define('FPDF_FONTPATH',funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/font/');
}

if (!function_exists('dmy2ymd')) {
    function dmy2ymd($data) {
        if (!empty($data)) {
            $needle = "/";
            if (strstr($data, "-")) {
                $needle = "-";
            }
            $dt = explode($needle, $data);
            return "$dt[2]-$dt[1]-$dt[0]";
        }
    }
}

class danfe_paisagem extends PDF_Code128{

    public $canhoto;   // se true, imprime campos do canhoto
    public $issqn;     // se true, imprime campos do issqn
    public $pdf;       // objeto fpdf()
    public $xml;       // string XML NFe
    public $logo;      // path para logomarca
    public $cUF;	   // C�digo da UF
    public $array_uf;  // usado para obter c�digo do estado do destinatario qdo em contingencia
    public $protocolo; // protocolo de autorizacao deve sair em infCpl
    public $data_hora; // data e hora de autorizacao devem sair em infCpl
    public $formato;   // Indica o layout Paisagem (L) ou Retrato (P). Se der certo teremos um arquivo S�
    public $_desc_marca_dagua_danfe_nfe;
    private $margem_esquerda;//Margem adicional a esquerda se for paisagem.
    private $margem_topo;//Margem adicional TOPO se for paisagem.
    private $altura_padrao;//Altura das linhas Retrato 8.5 paisagem 6.4
    private $qtd_itens;
    private $tamanho_descricao;
    private $infNFe;
    private $ide;
    private $infProt;
    private $emit;
    private $dest;
    private $enderEmit;
    private $enderDest;
    private $det;
    private $cobr;
    private $dup;
    private $ICMSTot;
    private $transp;
    private $transporta;
    private $veicTransp;
    private $vols;
    private $infAdic;
    private $issqn_extra;
    private $totalPaginas;
    private $totBCISSQN;
    private $totValorISSQN;
    private $totValorServico;
    public $_num_protocolo_evto;
    public $_imprimir_cod_lido = false;
    private $_imprimir_divisoria_itens = true;
    private $_totais_impressao_unica = false;
    private $_imprimir_blocos = true;
    private $qtd_itens_aux;
    private $defaut_ajuste_horizontal;
    private $defaut_ajuste_horizontal2;
    private $defaut_ajuste_vertical;
    private $defaut_ajuste_vertical2;
    function __construct($xml=null, $formato="P", $protocolo="",$logo="",$_issqn=false,$_info_impressao = null) {
        //Pus isso aqui pq preciso do n�mero do protocolo no Danfe.
        $this->protocolo = $protocolo;
        $this->formato   = $formato;
        //Se for paisagem, mudamos o alinhamento.
        if ($this->formato=="L") {
            $this->margem_esquerda = 19.1;
            $this->margem_topo	   = -20;
            $this->altura_padrao   = 6.4;
            $this->qtd_itens 	   = 22;
            $this->tamanho_descricao = 69;
            //Ajustes para danfe totais so na primeira p�gina
            $this->defaut_ajuste_horizontal = 20;
            $this->defaut_ajuste_horizontal2 = 92.8;
            $this->qtd_itens_aux   = 56;
        } else {
            $this->margem_esquerda = 0;
            $this->margem_topo	   = 0;
            $this->altura_padrao   = 8.5;
            $this->qtd_itens 	   = 29;
            $this->tamanho_descricao = 35;
            //Ajustes para danfe totais so na primeira p�gina
            $this->qtd_itens_aux   = 85;
            $this->defaut_ajuste_vertical = 113;
            $this->defaut_ajuste_vertical2 = 20;
        }

        if (!empty($_info_impressao["opcoes_impressao_nota"])) {
            $this->_imprimir_divisoria_itens = !($_info_impressao["opcoes_impressao_nota"] & 128) > 0;
            $this->_totais_impressao_unica = ($_info_impressao["opcoes_impressao_nota"] & 64) > 0;
        }

        parent::__construct($formato, 'mm', 'A4');

        libxml_use_internal_errors(true);
        $dom = new DomDocument ( );
        //Algo est� acontecendo na SEFAZ que no retorno do protocolo ao inv�s de retornar aspas duplas, est� retornando duas aspas simples
        $xml = str_replace('\'\'','"',$xml);
        //libxml_use_internal_errors(true);

        if (!empty($xml) && $dom->loadXML($xml) == false) {
            //$_erro = libxml_get_errors();
            $xml = utf8_encode($xml);
            $dom->loadXML($xml);
        }
        $this->infNFe     = $dom->getElementsByTagName("infNFe")->item(0);
        $this->ide        = $dom->getElementsByTagName("ide")->item(0);
        $this->infProt    = $dom->getElementsByTagName("infProt")->item(0);
        $this->emit       = $dom->getElementsByTagName("emit")->item(0);
        $this->dest       = $dom->getElementsByTagName("dest")->item(0);
        $this->enderEmit  = $dom->getElementsByTagName("enderEmit")->item(0);
        $this->enderDest  = $dom->getElementsByTagName("enderDest")->item(0);
        $this->det        = $dom->getElementsByTagName("det");
        $this->cobr       = $dom->getElementsByTagName("cobr")->item(0);
        $this->dup        = $dom->getElementsByTagName('dup');
        $this->ICMSTot    = $dom->getElementsByTagName("ICMSTot")->item(0);
        $this->ISSQNtot   = $dom->getElementsByTagName("ISSQNtot")->item(0);
        $this->transp     = $dom->getElementsByTagName("transp")->item(0);
        $this->transporta = $dom->getElementsByTagName("transporta")->item(0);
        $this->veicTransp = $dom->getElementsByTagName("veicTransp")->item(0);
        $this->vols       = $dom->getElementsByTagName("vol");
        $this->infAdic    = $dom->getElementsByTagName("infAdic")->item(0);
        $this->canhoto         = true;
        $this->_desc_marca_dagua_danfe_nfe = null;
        $this->_num_protocolo_evto = $_info_impressao["num_protocolo_evto"];
        /*Imagine que o sistema n�o esteja mais permitindo itens de ISS, mas um dia permitiu.
         * O sistema dever� continuar imprimindo quando for um tiver itens de ISS.
         */

        if(is_object($this->ISSQNtot)) {
            $this->issqn           = true;
        } else {
            $this->issqn           = false;
        }
        $this->totBCISSQN      = 0.00;
        $this->totValorISSQN   = 0.00 ;
        $this->totValorServico = 0.00;

        $this->setTotalPaginas();

        //$this->PDF_Code128($formato, 'mm', 'A4');
        $this->logo 	 = $logo;
        $this->logomarca = $logo;
        //$this->logomarca = 'logomarca.jpg';

        $this->xml       = $xml;
        $this->array_uf  = array('SP' => 35);
    }

    /**
     * @param $esquerda float que define a margem esquerda original
     * @param $inc_esquerda_paisagem float que ser� utilizado quando for paisagem para
     */
    protected function getMargemEsquerda($esquerda,$inc_esquerda_paisagem=0) {
        if($this->formato=="L") {
            return (float) $esquerda + $this->margem_esquerda + $inc_esquerda_paisagem;
        } else {
            return $esquerda;
        }
    }

    /**
     * @param $altura float que define a margem esquerda original
     */
    protected function getMargemTop($altura) {
        if($this->formato=="L") {
            return (float) $altura + $this->margem_topo;
        } else {
            return $altura;
        }
    }

    protected function getFonteLinha($fonte_retrato,$fonte_paisagem="") {
        if($this->formato=="L"&&$fonte_paisagem!=="") {
            return $fonte_paisagem;
        } else {
            return $fonte_retrato;
        }
    }

    /**
     * @param $altura int que define a margem esquerda original
     */
    protected function getLargura($largura,$inc_largura_paisagem=0) {
        if($this->formato=="L") {
            return $largura + $inc_largura_paisagem;
        } else {
            return $largura;
        }
    }

    /**
     * @return int com o numero total de p�ginas
     */
    protected function getTotalPaginas(){
        return (int)$this->totalPaginas;
    }

    protected function setTotalPaginas(){
        $i = 0;
        $_qtdLinha = 0;
        foreach ($this->det as $d) {
            $prod = $this->det->item($i)->getElementsByTagName("prod")->item(0);
            if (($GLOBALS["_VERSAO_NT"] & 256) > 0) {
                $infAdProd = (string)$this->det->item($i)->getElementsByTagName("infAdProd")->item(0)->nodeValue;
                if (empty($infAdProd)) {
                    $infAdProd = "Nao houve arrecadacao para o FECP";
                }
            }
            $_descricao = trim($prod->getElementsByTagName("xProd")->item(0)->nodeValue);
            $_arr_desc = funcoesGerais::quebrarTextoEmPalavrasComLimite($_descricao, $this->tamanho_descricao, $infAdProd);
            $_qtdLinha += count($_arr_desc);
            $i++;
        }
        if ($this->_totais_impressao_unica) {
            $totalLinhasRestantes = $_qtdLinha - $this->qtd_itens;
            $totalPaginas = 1 + (int)ceil($totalLinhasRestantes / $this->qtd_itens_aux);
            $this->totalPaginas = $totalPaginas;
        } else {
            $this->totalPaginas = (int)ceil($_qtdLinha/$this->qtd_itens);
            $this->totalPaginas = ($this->totalPaginas===0) ? 1 : $this->totalPaginas;
        }
    }

    /*
     * Este m�todo faz com que as linhas subam para que
     * possa ser ajustada ao modelo Landscape.
     * @param $y int que ser� somado a margem
     */
    protected function alterarMargemTopo($y) {
        if($this->formato=="L") {
            $this->margem_topo += ($y * -1);
        }
    }

    function mask_cnpj($c) {
        return sprintf("%s.%s.%s/%s-%s", $c[0].$c[1], $c[2].$c[3].$c[4], $c[5].$c[6].$c[7], $c[8].$c[9].$c[10].$c[11], $c[12].$c[13]);
    }


    function mask_cpf($c) {
        return sprintf("%s.%s.%s-%s", $c[0].$c[1].$c[2], $c[3].$c[4].$c[5], $c[6].$c[7].$c[8], $c[9].$c[10]);
    }


    function mask_nnf($n) {
        $n = sprintf("%09s", $n);
        return sprintf("%s.%s.%s", $n[0].$n[1].$n[2], $n[3].$n[4].$n[5], $n[6].$n[7].$n[8]);
    }

    function mask_chave($c) {
        for ($i=0; $i<=strlen($c); ++$i) {
            $cf.= $c[$i-1];
            if ($i % 4 == 0) {
                $cf.= " ";
            }
        }
        return $cf;
    }


    function calcula_dv($chave35) {
        $multiplicadores = array(2,3,4,5,6,7,8,9);
        $i = 34;
        while ($i >= 0) {
            for ($m=0; $m<count((array)$multiplicadores) && $i>=0; $m++) {
                $soma_ponderada+= $chave35[$i] * $multiplicadores[$m];
                $i--;
            }
        }
        $resto = $soma_ponderada % 11;
        if ($resto == '0' || $resto == '1') {
            $dv = 0;
        } else {
            $dv = 11 - $resto;
        }
        return $dv;
    }


    function linha($altura, $largura, $esquerda, $superior, $sbordas, $label="", $fonte="", $texto="", $tfonte="") {

        $bordas = array();
        for ($i=0; $i<strlen($sbordas); $i++) {
            $bordas[] = $sbordas[$i];
        }

        //Isso s� � v�lido para o modo Retrato.
        if (!$this->canhoto&&$this->formato!=="P") {
            $superior-= 21;
        }

        // configura largura da linha N=negrito
        if (in_array("N", $bordas)) {
            $this->SetLineWidth(0.25);
        } else {
            $this->SetLineWidth(0.05);
        }

        if (in_array("T", $bordas)) {
            $this->line($esquerda, $superior, ($esquerda+$largura), $superior);
        }
        if (in_array("B", $bordas)) {
            $this->line($esquerda, ($superior+$altura), ($esquerda+$largura), ($superior+$altura));
        }
        if (in_array("L", $bordas)) {
            $this->line($esquerda, $superior, $esquerda, ($superior+$altura));
        }
        if (in_array("R", $bordas)) {
            $this->line(($esquerda+$largura), $superior, ($esquerda+$largura), ($superior+$altura));
        }

        // impressao das labels
        if (!empty($label)) {
            if (empty($fonte)) {
                $fonte = "Courier,B,5,L";
            }
            $f = explode(",",$fonte);
            $this->SetFont($f[0], $f[1], $f[2]);
            $this->setXY($esquerda-($f[2]/10), $superior+($f[2]/4));
            $this->Cell($largura, 0, $label, 0, 0, $f[3]);
        }

        // impressao do texto
        if (strlen($texto)!==0) {
            if (empty($tfonte)) {
                if($this->formato!="L") {
                    $tfonte = "Courier,,7,L";
                } else {
                    $tfonte = "Courier,,9,L";
                }
            }
            $f = explode(",",$tfonte);
            $this->SetFont($f[0], $f[1], $f[2]);
            $this->setXY($esquerda, $superior+5);
            $this->Cell($largura, 0, $texto, 0, 0, $f[3]);
        }
    }

    /*
     * M�todo utilizado para desenhar linhas tracejadas.
     * Baseado no m�tod dashedRectangle de: www.fpdf.org
     */
    private function DashedLine($altura, $largura, $esquerda, $superior)  {
        $this->SetLineWidth(0.05);
        $Pointilles = 0.25;
        for($i=$esquerda;$i<=$esquerda+$largura;$i+=$Pointilles+$Pointilles) {
            if($i<=(($largura+$esquerda)-$Pointilles)) {
                $this->Line($i,$superior,$i+$Pointilles,$superior);
            }
        }
    }


    /*
     * M�todo utilizado para escrever texto da esquerda para direita.
     * Escrever de tr�s pra frente.
     * M�todo retirado de: http://www.fpdf.org/en/script/script31.php
     *
     */
    function TextWithDirection($x, $y, $txt, $direction='R') {
        //Escreve para da Esquerda pra Direita
        if ($direction=='R')
            $s=sprintf('BT %.2F %.2F %.2F %.2F %.2F %.2F Tm (%s) Tj ET',1,0,0,1,$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        elseif ($direction=='L') //Escreve de cabe�a para baixo e da direita pra esquerda
            $s=sprintf('BT %.2F %.2F %.2F %.2F %.2F %.2F Tm (%s) Tj ET',-1,0,0,-1,$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        elseif ($direction=='U')//Escreve de baixo para cima
            $s=sprintf('BT %.2F %.2F %.2F %.2F %.2F %.2F Tm (%s) Tj ET',0,1,-1,0,$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        elseif ($direction=='D')//Escreve de cima para baixo
            $s=sprintf('BT %.2F %.2F %.2F %.2F %.2F %.2F Tm (%s) Tj ET',0,-1,1,0,$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        else
            $s=sprintf('BT %.2F %.2F Td (%s) Tj ET',$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        if ($this->ColorFlag)
            $s='q '.$this->TextColor.' '.$s.' Q';
        $this->_out($s);
    }

    /*
     * M�todo utilizado para rotacionar
     * Retirado de: http://www.fpdf.org/en/script/script31.php
     */
    function TextWithRotation($x, $y, $txt, $txt_angle, $font_angle=0)	{
        $font_angle+=90+$txt_angle;
        $txt_angle*=M_PI/180;
        $font_angle*=M_PI/180;

        $txt_dx=cos($txt_angle);
        $txt_dy=sin($txt_angle);
        $font_dx=cos($font_angle);
        $font_dy=sin($font_angle);

        $s=sprintf('BT %.2F %.2F %.2F %.2F %.2F %.2F Tm (%s) Tj ET',$txt_dx,$txt_dy,$font_dx,$font_dy,$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
        if ($this->ColorFlag)
            $s='q '.$this->TextColor.' '.$s.' Q';
        $this->_out($s);
    }

    /*
     * Todos os subtitulos ser�o montados por aqui.
     * Quando Retrato monta em cima
     * Quando Paisagem coloca na lateral.
     */
    private function montarSubTitulosCabecalho($largura, $superior,$texto_1,$texto_2,$largura_paisagem=0,$superior_paisagem=0,$size_fonte=6) {
        if($this->formato==="L") {
            //Subimos a margem do topo aqui
            $this->_imprimir_blocos ? $_ajuste_horizontal = 0 : $_ajuste_horizontal = $this->defaut_ajuste_horizontal;
            $_posicao_esquerda   = 5.1;
            $_margem_esquerda    = $this->margem_esquerda - $_posicao_esquerda - $_ajuste_horizontal;
            $this->setXY(10.0 + $_margem_esquerda ,$this->getMargemTop($superior_paisagem));
            $this->SetFillColor(0,0,0);
            $this->Cell($_posicao_esquerda, $largura_paisagem, "", 0, 0, "", true);
            $this->SetTextColor(255,255,255);
            $this->SetFont("Courier", "B", $size_fonte);

            $align_center = $this->getMargemTop($superior_paisagem) + ($largura_paisagem / 2);
            if($texto_2=="") {
                $this->TextWithDirection(10.0 + $_margem_esquerda + ($_posicao_esquerda/2) + 0.7, $align_center + ($this->GetStringWidth($texto_1)/2), $texto_1,"U");
            } else {
                $this->TextWithDirection(10.0 + $_margem_esquerda + ($_posicao_esquerda/2) - 0.5, $align_center + ($this->GetStringWidth($texto_1)/2), $texto_1,"U");
                $this->TextWithDirection(10.0 + $_margem_esquerda +     $_posicao_esquerda - 0.5, $align_center + ($this->GetStringWidth($texto_2)/2), $texto_2,"U");
            }
            $this->SetTextColor(0,0,0);
        } else {
            $this->linha( 4.2,    $largura,  10.0,  $superior,      "", $texto_1.$texto_2, "Courier,B,6,L");
        }
    }

    /*
     * Monta informa��es do Destinat�rio e Remetente
     * de Acordo com o layout
     */
    private function montarDestinatarioRemetente() {
        $this->alterarMargemTopo($this->altura_padrao);
        $this->montarSubTitulosCabecalho(33,82.6," DESTINAT�RIO/"," REMETENTE",19.1,85.9);

        // destinatario/remetente
        $this->linha( $this->altura_padrao, $this->getLargura(110.0,63),  $this->getMargemEsquerda(10.0),  $this->getMargemTop(85.8),  "BTRL", "NOME/RAZ�O SOCIAL","", utf8_decode($this->dest->getElementsByTagName("xNome")->item(0)->nodeValue),$this->getFonteLinha("Courier,,7,L","Courier,,9,L"));
        $this->dest_doc = (!empty($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue)) ? $this->mask_cnpj($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue) : $this->mask_cpf($this->dest->getElementsByTagName("CPF")->item(0)->nodeValue);
        $this->linha( $this->altura_padrao,       $this->getLargura(51.0), $this->getMargemEsquerda(120.0,63),  $this->getMargemTop(85.8), "BTRL", "C.N.P.J./C.P.F.","",   $this->dest_doc);
        //Na vers�o 3.1 o campo mudou para dh
        $_data = $this->ide->getElementsByTagName("dEmi")->item(0)->nodeValue;
        if (empty($_data)) {
            $_data = $this->ide->getElementsByTagName("dhEmi")->item(0)->nodeValue;
            $_data = funcoesGerais::converte_data($_data, "utc", "padrao",false,true);
        } else {
            $_data = dmy2ymd($_data);
        }

        $this->linha( $this->altura_padrao,  $this->getLargura(29.0,10.3),   $this->getMargemEsquerda(171,63),  $this->getMargemTop(85.8),  "BTRL", "DATA DA EMISS�O","",   $_data);
        $this->dest_ender = utf8_decode($this->enderDest->getElementsByTagName("xLgr")->item(0)->nodeValue);
        $this->dest_ender.= (!empty($this->enderDest->getElementsByTagName("nro")->item(0)->nodeValue)) ? ", ".utf8_decode($this->enderDest->getElementsByTagName("nro")->item(0)->nodeValue) : null;

        $this->alterarMargemTopo(2.1);

        $this->linha( $this->altura_padrao,  $this->getLargura(91.0,31.5),       $this->getMargemEsquerda(10.0),  $this->getMargemTop(94.3),  "BTRL", "ENDERE�O","",          $this->dest_ender);
        $this->linha( $this->altura_padrao,  $this->getLargura(45.0,31.5), $this->getMargemEsquerda(101.0,31.5),  $this->getMargemTop(94.3),  "BTRL", "BAIRRO/DISTRITO","",   utf8_decode($this->enderDest->getElementsByTagName("xBairro")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,  	  $this->getLargura(25.0),   $this->getMargemEsquerda(146.0,63),  $this->getMargemTop(94.3),  "BTRL", "CEP","",               utf8_decode($this->enderDest->getElementsByTagName("CEP")->item(0)->nodeValue));
        //Na vers�o 3.1 o campo mudou para dh
        $_data = $this->ide->getElementsByTagName("dSaiEnt")->item(0)->nodeValue;
        if (empty($_data)) {
            $_data = $this->ide->getElementsByTagName("dhSaiEnt")->item(0)->nodeValue;
            $_data = funcoesGerais::converte_data($_data, "utc", "padrao", false, true);
        } else {
            $_data = dmy2ymd($_data);
        }

        $this->linha( $this->altura_padrao,  $this->getLargura(29.0,10.3),     $this->getMargemEsquerda(171,63),  $this->getMargemTop(94.3), "BTRL", "DATA DA SA�DA/ENTRADA","",$_data);

        $this->alterarMargemTopo(2.1);

        $this->linha( $this->altura_padrao,  $this->getLargura(64.0,63),     $this->getMargemEsquerda(10.0), $this->getMargemTop(102.8),  "BTRL", "MUNIC�PIO","",         utf8_decode($this->enderDest->getElementsByTagName("xMun")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,     $this->getLargura(35.0),  $this->getMargemEsquerda(74.0,63), $this->getMargemTop(102.8),  "BTRL", "FONE/FAX","",          utf8_decode($this->enderDest->getElementsByTagName("fone")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,     $this->getLargura(11.0), $this->getMargemEsquerda(109.0,63), $this->getMargemTop(102.8),  "BTRL", "UF","",                utf8_decode($this->enderDest->getElementsByTagName("UF")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,     $this->getLargura(51.0), $this->getMargemEsquerda(120.0,63), $this->getMargemTop(102.8),  "BTRL", "INSCRI��O ESTADUAL","",utf8_decode($this->dest->getElementsByTagName("IE")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,$this->getLargura(29.0,10.3), $this->getMargemEsquerda(171.0,63), $this->getMargemTop(102.8), "BTRL", "HORA DA SA�DA","",     date("H:i:s")); // BUG: como esta TAG n�o existe no XML, obter hora atual
    }

    private function montarDuplicatas() {
        if($this->formato=="L") {
            $this->alterarMargemTopo(5.9);
            $this->montarSubTitulosCabecalho(0,0,"FAT/","DUP",6.4,115.2);
        } else {
            $this->montarSubTitulosCabecalho(10,111.9,"FATURA/","DUPLICATAS");
        }
        // faturas/duplicatas
        // TODO: melhorar fatura aqui tb
        $this->dups = "";
        foreach ($this->dup as $k => $d) {
            $this->dups.= "*" . $this->dup->item($k)->getElementsByTagName('nDup')->item(0)->nodeValue." - ";
            $this->dups.= dmy2ymd($this->dup->item($k)->getElementsByTagName('dVenc')->item(0)->nodeValue);
            $this->dups.= " - R$ ".number_format($this->dup->item($k)->getElementsByTagName('vDup')->item(0)->nodeValue, 2, ",", ".")."*";
        }

        $_array_dup = explode("*",$this->dups);
        $_linha_dup = "";
        $_cont = 0;

        foreach ($_array_dup as $_dup) {
            //por enaqunto conseguimos imprimir 3 linhas sem precisar alterar a posi��o dos outros quadros
            if($_cont>=3){
               $_linha_dup ="";
                break;
        }
            if(empty($_dup)){
                continue;
            }

            if(strlen($_linha_dup . trim($_dup) . "//") < 121){
                $_linha_dup .=trim($_dup) . "//";
            }else{
                $this->linha( $this->altura_padrao, $this->getLargura(190.0,73.3),  $this->getMargemEsquerda(10.0), $this->getMargemTop(112.1 +$this->extra+($_cont*3)),  "", "", "", utf8_decode($_linha_dup));
                $_linha_dup=trim($_dup) . "//";
                $_cont++;
            }
        }
        if(!empty($_linha_dup)){
            $this->linha( $this->altura_padrao, $this->getLargura(190.0,73.3),  $this->getMargemEsquerda(10.0), $this->getMargemTop(112.1 +$this->extra+($_cont*3)),  "", "", "", utf8_decode($_linha_dup));
        }
        $this->linha( $this->altura_padrao, $this->getLargura(190.0,73.3),  $this->getMargemEsquerda(10.0), $this->getMargemTop(115.1),  "BTRL", "", "", "");

    }

    /*
     * Monta os campos de C�lculo de Impostos
     */
    private function montarCalculoImpostos() {
        $this->alterarMargemTopo(6.2);
        $this->montarSubTitulosCabecalho(56,124.6,"C�LCULO DO ","IMPOSTO",12.8,127.9,5);

        // calculo do imposto
        $this->linha( $this->altura_padrao,  $this->getLargura(37.5,12.6),       $this->getMargemEsquerda(10.0), $this->getMargemTop(127.8),  "BTRL", "BASE DE C�LCULO DO ICMS",     "",   ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vBC")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(27.5,12.6),  $this->getMargemEsquerda(47.5,12.6), $this->getMargemTop(127.8),  "BTRL", "VALOR DO ICMS",               "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vICMS")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(28.75,12.3),  $this->getMargemEsquerda(75.0,25.2), $this->getMargemTop(127.8),  "BTRL", "B.C. DO ICMS ST",  "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vBCST")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(18.75,12.6),  $this->getMargemEsquerda(103.75,25.2), $this->getMargemTop(127.8),  "BTRL", "VALOR DO ICMS ST",  "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vST")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(18.75,12.6), $this->getMargemEsquerda(122.5,37.8), $this->getMargemTop(127.8),  "BTRL", "VALOR DO FCP",            "",   ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vFCPUFDest")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(18.75,12.6), $this->getMargemEsquerda(141.25,37.8), $this->getMargemTop(127.8),  "BTRL", "V. ICMS UF DEST",            "",   ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vICMSUFDest")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(40.0,22.9), $this->getMargemEsquerda(160.0,50.4), $this->getMargemTop(127.8),  "BTRL", "VALOR TOTAL DOS PRODUTOS",    "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vProd")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));

        $this->alterarMargemTopo(2);

        $this->linha( $this->altura_padrao,  $this->getLargura(30.0,10.5),       $this->getMargemEsquerda(10.0), $this->getMargemTop(136.3),  "BTRL", "VALOR DO FRETE",              "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vFrete")->item(0)->nodeValue, 2, ",", "."):"*****"),   $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(30.0,10.5),  $this->getMargemEsquerda(40.0,10.5), $this->getMargemTop(136.3),  "BTRL", "VALOR DO SEGURO",             "",   ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vSeg")->item(0)->nodeValue, 2, ",", "."):"*****"),   $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(30.0,10.5),  $this->getMargemEsquerda(70.0,21.0), $this->getMargemTop(136.3),  "BTRL", "DESCONTO",                    "",  ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vDesc")->item(0)->nodeValue, 2, ",", "."):"*****"),   $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(30.0,10.5), $this->getMargemEsquerda(100.0,31.5), $this->getMargemTop(136.3),  "BTRL", "OUTRAS DESPESAS ACESS�RIAS",  "", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vOutro")->item(0)->nodeValue, 2, ",", "."):"*****"),   $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(30.0,10.5), $this->getMargemEsquerda(130.0,42.0), $this->getMargemTop(136.3),  "BTRL", "VALOR DO IPI",                "",   ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vIPI")->item(0)->nodeValue, 2, ",", "."):"*****"),   $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(40.0,20.8), $this->getMargemEsquerda(160.0,52.5), $this->getMargemTop(136.3),  "BTRL", "VALOR TOTAL DA NOTA",         "",    ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ? number_format($this->ICMSTot->getElementsByTagName("vNF")->item(0)->nodeValue, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,B,8,R","Courier,B,11,R"));
    }

    private function montarTransportador() {
        if($this->formato=="L") {
            $this->alterarMargemTopo(6.2);
            $this->montarSubTitulosCabecalho(0,0,"TRANSP/VOL","TRANSPORTADOS",19.5,149);
        } else {
            $this->montarSubTitulosCabecalho(52,145.8,"TRANSPORTADOR/VOLUMES ","TRANSPORTADOS");
        }
        // transportador/volumes transportados

        if (is_object($this->transporta)) {
            $this->transp_doc     = (!empty($this->transporta->getElementsByTagName("CNPJ")->item(0)->nodeValue)) ? $this->mask_cnpj($this->transporta->getElementsByTagName("CNPJ")->item(0)->nodeValue) : $this->mask_cpf($this->transporta->getElementsByTagName("CPF")->item(0)->nodeValue);
            $this->transp_xNome   = utf8_decode($this->transporta->getElementsByTagName("xNome")->item(0)->nodeValue);
            $this->transp_xEnder  = utf8_decode($this->transporta->getElementsByTagName("xEnder")->item(0)->nodeValue);
            $this->transp_xMun    = utf8_decode($this->transporta->getElementsByTagName("xMun")->item(0)->nodeValue);
            $this->transp_UF      = utf8_decode($this->transporta->getElementsByTagName("UF")->item(0)->nodeValue);
            $this->transp_IE      = utf8_decode($this->transporta->getElementsByTagName("IE")->item(0)->nodeValue);
        }
        if (is_object($this->veicTransp)) {
            $veic_RNTC      = utf8_decode($this->veicTransp->getElementsByTagName("RNTC")->item(0)->nodeValue);
            $veic_placa     = utf8_decode($this->veicTransp->getElementsByTagName("placa")->item(0)->nodeValue);
            $veic_UF        = utf8_decode($this->veicTransp->getElementsByTagName("UF")->item(0)->nodeValue);
        }
        $this->linha( $this->altura_padrao,  $this->getLargura(80.0,26.05),        $this->getMargemEsquerda(10.0),   $this->getMargemTop(149),  "BTRL", "RAZ�O SOCIAL",        "", $this->transp_xNome);
        $this->linha( $this->altura_padrao,        $this->getLargura(26.0),  $this->getMargemEsquerda(90.0,26.05),   $this->getMargemTop(149),  "BTRL", "FRETE POR CONTA DE",  "");
        //Aqui � s� NFe
        if (funcoesGerais::retornarVersaoNFe(0,$this->cUF)  < 2) {
            $this->linha( $this->altura_padrao,        $this->getLargura(26.0),  $this->getMargemEsquerda(90.0,26.05),   $this->getMargemTop(151),      "", "1 - EMITENTE",  "");
            $this->linha( $this->altura_padrao,        $this->getLargura(26.0),  $this->getMargemEsquerda(90.0,26.05),   $this->getMargemTop(153),      "", "2 - DESTINAT.",  "");
            $this->linha( 				   3.5,         $this->getLargura(4.0), $this->getMargemEsquerda(110.0,26.05), $this->getMargemTop(151.5),  "BTRL", "");
            $this->linha(                  3.5,         $this->getLargura(4.0), $this->getMargemEsquerda(110.2,26.05), $this->getMargemTop(148.2),      "", "",                    "", $this->transp->getElementsByTagName("modFrete")->item(0)->nodeValue);
        } else {
            $_info_frete = "";

            switch ($this->transp->getElementsByTagName("modFrete")->item(0)->nodeValue)  {
                case "0" :
                    $_info_frete = "0- Emitente";
                    break;
                case "1" :
                    $_info_frete = "1- Dest/Rem";
                    break;
                case "2" :
                    $_info_frete = "2- Terceiros";
                    break;
                /**
                 * NT2021004-1
                 * BIT
                 * Jan.2022
                 * Inclus�o dos modos 3 e 4
                 */
                case "3":
                    $_info_frete = "3-Pr�p.Remet";
                    break;
                case "4":
                    $_info_frete = "4-Pr�p.Dest.";
                    break;
                case "9" :
                    $_info_frete = "9- Sem Frete";
                    break;
            }
            $this->linha( $this->altura_padrao,        $this->getLargura(26.0),  $this->getMargemEsquerda(90.0,23.05),   $this->getMargemTop(151),      "", $_info_frete,$this->getFonteLinha("Courier,B,8,R","Courier,B,8,R"));
        }


        $this->linha( $this->altura_padrao,  $this->getLargura(16.0,15.75), $this->getMargemEsquerda(116.0,26.05),   $this->getMargemTop(149),  "BTRL", "C�DIGO ANTT",         "", $veic_RNTC);
        $this->linha( $this->altura_padrao,  $this->getLargura(21.0,15.75), $this->getMargemEsquerda(132.0,41.80),   $this->getMargemTop(149),  "BTRL", "PLACA DO VE�CULO",    "", $veic_placa);
        $this->linha( $this->altura_padrao,         $this->getLargura(8.0), $this->getMargemEsquerda(153.0,57.55),   $this->getMargemTop(149),  "BTRL", "UF",                  "", $veic_UF);
        $this->linha( $this->altura_padrao,  $this->getLargura(39.0,15.75), $this->getMargemEsquerda(161.0,57.55),   $this->getMargemTop(149),  "BTRL", "C.N.P.J./C.P.F.",     "", $this->transp_doc);

        $this->alterarMargemTopo(2);

        $this->linha( $this->altura_padrao,  $this->getLargura(80.0,31.5),       $this->getMargemEsquerda(10.0), $this->getMargemTop(157.5),  "BTRL", "ENDERE�O",            "", $this->transp_xEnder);
        $this->linha( $this->altura_padrao,  $this->getLargura(63.0,31.5),  $this->getMargemEsquerda(90.0,31.5), $this->getMargemTop(157.5),  "BTRL", "MUNIC�PIO",           "", $this->transp_xMun);
        $this->linha( $this->altura_padrao,        $this->getLargura(8.0),   $this->getMargemEsquerda(153.0,63), $this->getMargemTop(157.5),  "BTRL", "UF",                  "", $this->transp_UF);
        $this->linha( $this->altura_padrao,  $this->getLargura(39.0,10.3),   $this->getMargemEsquerda(161.0,63), $this->getMargemTop(157.5),  "BTRL", "INSCRI��O ESTADUAL",  "", $this->transp_IE);

        // faz somatorios/concatenacoes dos volumes e coloca nos campos
        foreach ($this->vols as $key => $v) {
            $barra   = ($key != 0) ? "/" : "";
            $qVol   += $v->getElementsByTagName("qVol")->item(0)->nodeValue;
            $esp    .= $barra.$v->getElementsByTagName("esp")->item(0)->nodeValue;
            $marca  .= $barra.$v->getElementsByTagName("marca")->item(0)->nodeValue;
            $nVol   .= $barra.$v->getElementsByTagName("nVol")->item(0)->nodeValue;
            $pesoB  += $v->getElementsByTagName("pesoB")->item(0)->nodeValue;
            $pesoL  += $v->getElementsByTagName("pesoL")->item(0)->nodeValue;
        }
        $this->alterarMargemTopo(2);

        $this->linha( $this->altura_padrao,  $this->getLargura(26.0,10.5),       $this->getMargemEsquerda(10.0),   $this->getMargemTop(166),  "BTRL", "QUANTIDADE",          "", number_format($qVol, 2, ",", "."), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(27.0,10.5),  $this->getMargemEsquerda(36.0,10.50),   $this->getMargemTop(166),  "BTRL", "ESP�CIE",             "", utf8_decode($esp));
        $this->linha( $this->altura_padrao,  $this->getLargura(27.0,10.5),  $this->getMargemEsquerda(63.0,21.00),   $this->getMargemTop(166),  "BTRL", "MARCA",               "", utf8_decode($marca));
        $this->linha( $this->altura_padrao,  $this->getLargura(46.0,10.5),  $this->getMargemEsquerda(90.0,31.50),   $this->getMargemTop(166),  "BTRL", "NUMERA��O",           "", utf8_decode($nVol));
        $this->linha( $this->altura_padrao,  $this->getLargura(32.0,10.5), $this->getMargemEsquerda(136.0,42.00),   $this->getMargemTop(166),  "BTRL", "PESO BRUTO",          "", !empty($pesoB)?number_format($pesoB, 3, ",", "."):"", $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
        $this->linha( $this->altura_padrao,  $this->getLargura(32.0,20.8), $this->getMargemEsquerda(168.0,52.50),   $this->getMargemTop(166),  "BTRL", "PESO L�QUIDO",        "", !empty($pesoL)?number_format($pesoL, 3, ",", "."):"", $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
    }

    private function montarCanhoto() {
        if($this->formato=="P") {
            // CANHOTO DEVER� APARECER A ESQUERDA QUANDO FOR PAISAGEM
            if ($this->canhoto) {
                // canhoto
                $this->linha($this->altura_padrao, 150.0,  10.0,  4.8, "TBRL", "RECEBI(EMOS) DE ".utf8_decode($this->emit->getElementsByTagName("xNome")->item(0)->nodeValue).", OS PRODUTOS CONSTANTE DA NOTA FISCAL ELETR�NICA INDICADA AO LADO,");
                $this->linha(5.5, 150.0,  10.0,  7.5,     "", "BEM COMO ATESTAMOS QUE OS MESMOS FORAM EXAMINADOS, SERVINDO O ACEITE DA PRESENTE PARA TODOS OS EFEITOS LEGAIS.");
                $this->linha( 17,  40.0, 160.0,  4.8, "TBRL", "NF-e", "Courier,B,7,C");
                $this->setXY(161, 11);
                $this->Cell(15, 2, "No.");
                $this->setXY(167, 9.8);
                $this->SetFillColor(230,230,230);
                $this->Cell(32, 3.8, "", 0, 0, "", true);
                $this->setXY(161, 17);
                $this->Cell(15, 0, "S�RIE");

                $this->linha($this->altura_padrao, 20, 168,  6.7, "", "", "", $this->mask_nnf($this->ide->getElementsByTagName('nNF')->item(0)->nodeValue),   "Courier,B,9,L");
                $this->linha($this->altura_padrao, 20, 172, 11.9, "", "", "", $this->ide->getElementsByTagName('serie')->item(0)->nodeValue, "Courier,B,9,L");

                $this->linha($this->altura_padrao,    40, 10.0, 13.3, "TBRL", "DATA DE RECEBIMENTO");
                $this->linha($this->altura_padrao,   110, 50.0, 13.3, "TBRL", "IDENTIFICA��O E ASSINATURA DO RECEBEDOR","",utf8_decode($this->dest->getElementsByTagName("xNome")->item(0)->nodeValue));

                $this->extra = 0;

            } else {
                $this->extra = 21;
            }
        } elseif($this->formato=="L") {
            // no landscape deixei sempre ter canhoto por enquanto. Pois no meu caso sempre tem.
            //Retangulo geral
            $this->linha( 201.4, 19.8,   0.1,  5.4, "BTRL",       "");
            $this->linha(    17, 19.8,   1.3, 10.5,     "",   "NOTA", "ARIAL,B,10,C");
            $this->linha(    17, 19.8,   1.3, 16.5,     "", "FISCAL", "ARIAL,B,10,C");
            $this->linha(    17, 19.8,   1.3, 23.3,     "",    "No.", "ARIAL,B,10,C");

            $this->setXY(0.4, 30);
            $this->SetFillColor(230,230,230);
            $this->Cell(19, 4.3, "", 0, 0, "", true);
            $this->linha(   4.3, 18,  1.0,  27.5,   "",     "", "", $this->mask_nnf($this->ide->getElementsByTagName('nNF')->item(0)->nodeValue),   "Courier,B,8,C");
            //Desenha os tra�os
            $this->linha(    10, 19.9,   0.1,  47.0,   "T");
            $this->linha( 159.8, 10.2,   0.3,  47.0,   "R");
            $this->SetFont("Courier","B",5);
            $_espaco = 2.2;
            $this->TextWithDirection( 3.8                 , 205.8, "RECEBI(EMOS) DE ".utf8_decode($this->emit->getElementsByTagName("xNome")->item(0)->nodeValue).",","U");
            $this->TextWithDirection( 3.8 +       $_espaco, 205.8, "OS PRODUTOS CONSTANTE DA NOTA FISCAL ELETR�NICA INDICADA AO LADO, BEM COMO ATESTAMOS QUE OS MESMOS FORAM","U");
            $this->TextWithDirection( 3.8 + ($_espaco * 2), 205.8, "EXAMINADOS, SERVINDO O ACEITE DA PRESENTE PARA TODOS OS EFEITOS LEGAIS.","U");

            $this->linha( 10, 9.2,   10.6,  139.3,   "T");

            $this->TextWithDirection(13.2 , 205.8, "DATA DE RECEBIMENTO","U");
            $this->TextWithDirection(13.2 , 136.3, "IDENTIFICA��O E ASSINATURA DO RECEBEDOR","U");
            $this->TextWithDirection(16.8 , 136.3, utf8_decode($this->dest->getElementsByTagName("xNome")->item(0)->nodeValue),"U");
            $this->extra = 0;
        }

    }

    /**
     * montarDadosEmitente
     *
     * Informa��es da empresa que est� emitindo a nota
     */
    public function montarDadosEmitente() {
        $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_vertical2;
        $_ajuste_horizontal = 0;
        if ($this->formato=="L") {
            $this->_imprimir_blocos ? $_ajuste_horizontal = 0 : $_ajuste_horizontal = $this->defaut_ajuste_horizontal;
            $_ajuste = 0;
        }
        $this->linha(39.2,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(25.4 - $_ajuste), "B");    // identificacao emitente/logo
        if (!empty($this->logomarca) && is_file($this->logomarca)) {
            $this->Image($this->logomarca, $this->getMargemEsquerda(11 - $_ajuste_horizontal), $this->getMargemTop(28-$this->extra - $_ajuste), 0, 10, 'jpeg');
        }
        $this->linha( 5.0,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(40.0 - $_ajuste), "", "", "", substr(utf8_decode($this->emit->getElementsByTagName("xNome")->item(0)->nodeValue),0,44), "Courier,B,9,L");
        $endereco_emitente = $this->enderEmit->getElementsByTagName("xLgr")->item(0)->nodeValue;
        $endereco_emitente.= (!empty($this->enderEmit->getElementsByTagName("nro")->item(0)->nodeValue)) ? ", ".$this->enderEmit->getElementsByTagName("nro")->item(0)->nodeValue : null;
        $this->linha( 5.0,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(43.0 - $_ajuste), "", "", "", utf8_decode($endereco_emitente));
        $desloca = 0.0;
        if(!empty($this->enderEmit->getElementsByTagName("xCpl")->item(0)->nodeValue)){
            $endereco_emitente_c= (!empty($this->enderEmit->getElementsByTagName("xCpl")->item(0)->nodeValue)) ? "Compl.: ".$this->enderEmit->getElementsByTagName("xCpl")->item(0)->nodeValue : null;
            $this->linha( 5.0,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(46.0 - $_ajuste), "", "", "", utf8_decode($endereco_emitente_c));
            $desloca = 3.0;
        }
        $endereco_emitente2 = $this->enderEmit->getElementsByTagName("xBairro")->item(0)->nodeValue;
        $endereco_emitente2.= (!empty($this->enderEmit->getElementsByTagName("xMun")->item(0)->nodeValue)) ? " - ".$this->enderEmit->getElementsByTagName("xMun")->item(0)->nodeValue : null;
        $endereco_emitente2.= (!empty($this->enderEmit->getElementsByTagName("UF")->item(0)->nodeValue)) ? "/".$this->enderEmit->getElementsByTagName("UF")->item(0)->nodeValue : null;
        $this->linha( 5.0,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(46.0 + $desloca - $_ajuste), "", "", "", utf8_decode($endereco_emitente2));
        $this->linha( 5.0,  84.6,  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(49.0 + $desloca - $_ajuste), "", "", "", "CEP: ".utf8_decode($this->emit->getElementsByTagName("CEP")->item(0)->nodeValue)." - FONE: ".utf8_decode($this->emit->getElementsByTagName("fone")->item(0)->nodeValue));
    }


    /**
     * Gera cabe�alho
     * @param	string   $xml
     * @param   string   $formato P=portrait L=landscape
     * @return
     * @access  public
     * @author Daniel B. Lemes
     *
     **/
    function Header(){
        if ($this->_totais_impressao_unica) {
            $this->_imprimir_blocos = $this->PageNo() == 1;
        }
        $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_vertical2;
        $_ajuste_horizontal = 0;
        if ($this->formato=="L") {
            $this->_imprimir_blocos ? $_ajuste_horizontal = 0 : $_ajuste_horizontal = $this->defaut_ajuste_horizontal;
            $_ajuste = 0;
        }
        $this->AliasNbPages('{total}');
        if ($this->_imprimir_blocos) {
            $this->montarCanhoto();
        }
        $chave_acesso = str_replace('NFe', '', $this->infNFe->getAttribute("Id"));
        $this->SetFillColor(0,0,0);
        $this->Code128($this->getMargemEsquerda(125,35.5), $this->getMargemTop(26.8 - $_ajuste), $chave_acesso, $this->getLargura(70,30.1), 12);

        // dados da nfe
        $this->montarDadosEmitente();

        if ($this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue != 1) {
            // contingencia
            $this->SetTextColor(170,170,170);
            $this->linha( 5.0, 190.0,  $this->getMargemEsquerda(10.0,35.5), $this->getMargemTop(120.0 - $_ajuste), "", "", "", "DANFE em Conting�ncia",   "Courier,B,30,C");
            $this->linha( 5.0, 190.0,  $this->getMargemEsquerda(10.0,35.5), $this->getMargemTop(140.0 - $_ajuste), "", "", "", "Impresso em decorr�ncia", "Courier,B,30,C");
            $this->linha( 5.0, 190.0,  $this->getMargemEsquerda(10.0,35.5), $this->getMargemTop(160.0 - $_ajuste), "", "", "", "de problemas t�cnicos",   "Courier,B,30,C");
            $this->SetTextColor(0,0,0);
        }

        /**
         * ML-447
         */
        if (!empty($this->_desc_marca_dagua_danfe_nfe)) {
            $_altura = 5.0;
            $_largura = 190.0;
            $_dist_margem_top = 110.0;
            $_desc_fonte = "Courier";
            $_tamanho_fonte = "90";
            $_limite_caracteres_linha = 10;
            $_limite_caracteres_total = 50;
            $this->SetTextColor(170, 170, 170);

            /**
             * Controle apenas para pular linha quando a descri��o ultrapassar a p�gina
             */
            $_descricao_marca_dagua = substr($this->_desc_marca_dagua_danfe_nfe, 0,$_limite_caracteres_total);
            $_controle = 0;
            do {
                $_desc_linha_abaixo = substr($_descricao_marca_dagua, $_limite_caracteres_linha);
                $_descricao_marca_dagua = substr($_descricao_marca_dagua, 0, $_limite_caracteres_linha);
                $this->linha($_altura, $_largura, $this->getMargemEsquerda(20, 0), $this->getMargemTop($_dist_margem_top - $_ajuste), "", "", "", $_descricao_marca_dagua, "{$_desc_fonte},B,{$_tamanho_fonte},C");
                if (empty($_desc_linha_abaixo)) {
                    $_controle ++;
                } else {
                    $_dist_margem_top += 25;
                    $_descricao_marca_dagua = $_desc_linha_abaixo;
                }
            } while ($_controle < 1);

            //Seto para cor padr�o de novo (preto)
            $this->SetTextColor(0, 0, 0);
        }

        if ($this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue === 5) {

            $dados_nfe = $this->cUF;//$this->array_uf[$this->enderDest->getElementsByTagName("UF")->item(0)->nodeValue];
            $dados_nfe.= $this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue;
            //$dados_nfe.= $this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue;
            //Pega o CNPJ do Emitente.
            $dados_nfe.= sprintf("%014s",$this->emit->getElementsByTagName("CNPJ")->item(0)->nodeValue);
            $dados_nfe.= sprintf("%014s", str_replace(',', '', number_format($this->ICMSTot->getElementsByTagName("vNF")->item(0)->nodeValue, 2, ",", "")));
            $dados_nfe.= 1; // ICMSp
            $dados_nfe.= 2; // ICMSs
            $data_emissao = dmy2ymd($this->ide->getElementsByTagName("dEmi")->item(0)->nodeValue);
            $dados_nfe.= $data_emissao[0].$data_emissao[1];
            $dados_nfe.= $this->calcula_dv($dados_nfe);

            $this->Code128($this->getMargemEsquerda(125,35.5), $this->getMargemTop(51.2 - $_ajuste), $dados_nfe, $this->getLargura(70,30.1), 12); // codigo de barras

            $this->linha(                 14.8,     $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(49.8 - $_ajuste),  "BTRL", ""); // codigo de barras dos dados
            $this->linha( $this->altura_padrao,     $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(64.6 - $_ajuste),  "BTRL",  "DADOS DA NF-e", "", $this->mask_chave($dados_nfe), $this->getFonteLinha("Courier,B,6.5,L","Courier,B,10,C"));

        } else {
            // normal
            $prot_data_hora =  $this->protocolo." ".$this->data_hora;
            $this->linha(                 14.8,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(49.8 - $_ajuste),  "BTRL", "", "", "Consulta de autenticidade no portal nacional");
            $this->linha(                 14.8,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(52.8 - $_ajuste),      "", "", "", "da NF-e www.nfe.fazenda.gov.br/portal ou");
            $this->linha(                 14.8,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(55.8 - $_ajuste),      "", "", "", "no site da Sefaz Autorizadora");

            if ((int) $this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue === 6 || (int) $this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue === 7) {
                $prot_data_hora = controle_nfe::retornarTipoAutorizador($this->ide->getElementsByTagName("tpEmis")->item(0)->nodeValue) . " " . $prot_data_hora;
                $this->linha( $this->altura_padrao,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(64.6 - $_ajuste),  "BTRL",  "PROTOCOLO DE AUTORIZA��O DE USO", "", "", $this->getFonteLinha("Courier,B,7,C","Courier,B,10,C"));
                $this->linha( $this->altura_padrao,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(63.6 - $_ajuste),  "",  "", "", $this->ide->getElementsByTagName("xJust")->item(0)->nodeValue, $this->getFonteLinha("Courier,B,7,C","Courier,B,10,C"));
                $this->linha( $this->altura_padrao,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(66.6 - $_ajuste),  "",  "", "", $prot_data_hora, $this->getFonteLinha("Courier,B,7,C","Courier,B,10,C"));
            } else {
                $this->linha( $this->altura_padrao,    $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(64.6 - $_ajuste),  "BTRL",  "PROTOCOLO DE AUTORIZA��O DE USO", "", $prot_data_hora, $this->getFonteLinha("Courier,B,7,C","Courier,B,10,C"));
            }
        }


        // se for ambiente de homologa��o, escreve SEM VALOR FISCAL
        if ($this->ide->getElementsByTagName("tpAmb")->item(0)->nodeValue == 2) {
            $this->SetTextColor(170,170,170);
            $this->linha( 5.0, 190.0,  $this->getMargemEsquerda(10.0,25.5), $this->getMargemTop(205.0 + (2.4 * $this->margem_topo) - $_ajuste), "", "", "", "SEM VALOR FISCAL", "Courier,B,50,C");
            $this->SetTextColor(0,0,0);
        }


        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(94.6,19.7),  $this->getMargemTop(25.4 - $_ajuste),  "BTRL", "DANFE",              "Courier,B,12,C"); // DANFE
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(94.6,19.7),    $this->getMargemTop(31 - $_ajuste),      "", "DOCUMENTO AUXILIAR", "Courier,B,6,C");
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(94.6,19.7),    $this->getMargemTop(33 - $_ajuste),      "", "DA NOTA FISCAL",     "Courier,B,6,C");
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(94.6,19.7),    $this->getMargemTop(35 - $_ajuste),      "", "ELETR�NICA",         "Courier,B,6,C");

        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(95.6,19.7),    $this->getMargemTop(42 - $_ajuste),      "", "0 - ENTRADA",        "Courier,B,6,L");
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(95.6,19.7),    $this->getMargemTop(45 - $_ajuste),      "", "1 - SA�DA",          "Courier,B,6,L");
        $this->linha(   7,     5,   $this->getMargemEsquerda(113,19.7),    $this->getMargemTop(41 - $_ajuste),  "BTRL", "", "", $this->ide->getElementsByTagName('tpNF')->item(0)->nodeValue, "Courier,B,10,C");

        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(95.6,19.7),    $this->getMargemTop(52 - $_ajuste),      "", "No.",   "Courier,B,6,L");
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(95.6,19.7),    $this->getMargemTop(56 - $_ajuste),      "", "S�RIE", "Courier,B,5,L");
        $this->linha(39.2,  25.4,  $this->getMargemEsquerda(95.6,19.7),    $this->getMargemTop(60 - $_ajuste),      "", "FOLHA", "Courier,B,5,L");
        $this->linha(39.2,  25.4,   $this->getMargemEsquerda(101,19.7),  $this->getMargemTop(48.5 - $_ajuste),      "", "", "", $this->mask_nnf($this->ide->getElementsByTagName('nNF')->item(0)->nodeValue),"Courier,B,7,L");
        $this->linha(39.2,  25.4,   $this->getMargemEsquerda(102,19.7),  $this->getMargemTop(52.2 - $_ajuste),      "", "", "", $this->ide->getElementsByTagName('serie')->item(0)->nodeValue,"Courier,B,7,L");
        $this->linha(39.2,  25.4,   $this->getMargemEsquerda(102,19.7),  $this->getMargemTop(56.0 - $_ajuste),      "", "", "", $this->PageNo().' de {total}',"Courier,B,7,L");

        $this->linha(                14.8,     $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(25.4 - $_ajuste),  "BTRL"); // codigo de barras da chave
        $this->linha(                 9.6,     $this->getLargura(80,53.4), $this->getMargemEsquerda(120.0,19.7),  $this->getMargemTop(40.2 - $_ajuste),  "BTRL",  "CHAVE DE ACESSO", "", $this->mask_chave($chave_acesso), $this->getFonteLinha("Courier,B,6.5,L","Courier,B,10,C") );
        $this->linha ( $this->altura_padrao, $this->getLargura ( 110.0 + $_ajuste_horizontal, 19.7 ), $this->getMargemEsquerda ( 10.0 - $_ajuste_horizontal), $this->getMargemTop ( 64.6  - $_ajuste), "BTRL", "NATUREZA DA OPERA��O", "", funcoesGerais::strToUpperLatin ( utf8_decode ( ( string ) $this->ide->getElementsByTagName ( "natOp" )->item ( 0 )->nodeValue ) ) );

        $this->alterarMargemTopo(2.2);

        $this->linha( $this->altura_padrao,  $this->getLargura(63.4 + $_ajuste_horizontal,25.5),  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal),  $this->getMargemTop(73.1 - $_ajuste),  "BTRL", "INSCRI��O ESTADUAL", "", utf8_decode($this->emit->getElementsByTagName("IE")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,  $this->getLargura(63.3,25.5),  $this->getMargemEsquerda(73.4,25.5),  $this->getMargemTop(73.1 - $_ajuste),  "BTRL", "INSCRI��O ESTADUAL DO SUBST. TRIB.", "", utf8_decode($this->emit->getElementsByTagName("IEST")->item(0)->nodeValue));
        $this->linha( $this->altura_padrao,  $this->getLargura(63.3,22.3), $this->getMargemEsquerda(136.7,51),  $this->getMargemTop(73.1 - $_ajuste),  "BTRL", "C.N.P.J.", "", $this->mask_cnpj($this->emit->getElementsByTagName("CNPJ")->item(0)->nodeValue));

        if ($this->_imprimir_blocos) {
            $this->montarDestinatarioRemetente();
            $this->montarDuplicatas();
            $this->montarCalculoImpostos();
            $this->montarTransportador();
        }

        $this->issqn_extra = 0;
        if (!$this->issqn) {
            $this->issqn_extra = 12.7;
        } else {
            if($this->formato=="L") {
                $this->issqn_extra = 12.7;
            }
        }

    }

    function cabecalhoProdutos() {
        $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_vertical;
        $_altura_linha = 65.8 + $_ajuste;
        !$this->_imprimir_blocos && $this->PageNo() == 2 ? $this->extra += 33 : $this->extra;
        $_ajuste_horizontal = 0;
        if ($this->formato=="L") {
            $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_horizontal2;
            $this->_imprimir_blocos ? $_ajuste2 = 0 : $_ajuste2 = 55;
            $this->_imprimir_blocos ? $_ajuste_horizontal = 0 : $_ajuste_horizontal = $this->defaut_ajuste_horizontal;
            $this->alterarMargemTopo(6.2);
            if ($this->issqn===true) {
                $_altura_linha 		 = 42.1 + $_ajuste2;
                $this->qtd_itens    -= 3;
            } else {
                $_altura_linha 		 = 48 + $_ajuste2;
            }
        }

        $this->montarSubTitulosCabecalho(40,175.5 - $_ajuste,"DADOS DOS PRODUTOS/SERVI�OS","",$_altura_linha+$this->extra+$this->issqn_extra,178.8 - $_ajuste);
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra, $this->getLargura(190.0 + $_ajuste_horizontal,73.3 ),  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "");
        //Quando for paisagem h� 63 cm que devem ser distribuidos.
        //Fiz com soma pois � mais f�cil andar as margens
        $this->linha(2.6 								           , $this->getLargura(190.0 + $_ajuste_horizontal,73.3),  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "");

        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,     $this->getLargura(16.0,5),  $this->getMargemEsquerda(10.0 - $_ajuste_horizontal), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "C�DIGO",    "Courier,,5,C");
        //Como aumentei s� a largura, vou utilizar essa vari�vel pra tentar regular o tamanho
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,    $this->getLargura(48.0 + $_ajuste_horizontal,40),      $this->getMargemEsquerda(26.0 - $_ajuste_horizontal,5), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "DESCRI��O", "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(9.5),     $this->getMargemEsquerda(74.0,45), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "NCM/SH",    "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(4.5),     $this->getMargemEsquerda(83.5,45), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "CST",       "Courier,,5,L");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(5.5),    $this->getMargemEsquerda(88.0,45), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "CFOP",      "Courier,,5,L");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(5.0),    $this->getMargemEsquerda(93.5,45), $this->getMargemTop(178.7 - $_ajuste), "BTRL", " UN.",      "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,     $this->getLargura(13.0,3),    $this->getMargemEsquerda(98.5,45), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "QUANT.",    "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,     $this->getLargura(13.0,5),    $this->getMargemEsquerda(111.5,48), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "V.UNIT.",   "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,     $this->getLargura(13.0,0),    $this->getMargemEsquerda(124.5,53), $this->getMargemTop(178.7- $_ajuste), "BTRL", "DESCONTO",   "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,  $this->getLargura(14.0,15.3),    $this->getMargemEsquerda(137.5,53), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "V.TOTAL",   "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,     $this->getLargura(12.5,5),  $this->getMargemEsquerda(151.5,68.3), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "BC.ICMS",   "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,       $this->getLargura(11.0),  $this->getMargemEsquerda(164.0,73.3), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "V.ICMS",    "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,       $this->getLargura(11.0),  $this->getMargemEsquerda(175.0,73.3), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "V.IPI",     "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(7.0),  $this->getMargemEsquerda(186.0,73.3), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "%ICMS",     "Courier,,5,C");
        $this->linha($_altura_linha+$this->extra+$this->issqn_extra,        $this->getLargura(7.0),  $this->getMargemEsquerda(193.0,73.3), $this->getMargemTop(178.7 - $_ajuste), "BTRL", "%IPI",      "Courier,,5,C");
    }

    /**
     * Gera o PDF se a vari�vel retornar_buffer estiver como true
     * retorna o buffer do pdf sen�o tenta mandar por download o arquivo.
     *
     * @param unknown_type $_retonar_buffer
     * @return unknown
     */
    function gera($_retonar_buffer=false) {
        $this->AddPage();
        if (empty($this->xml)) {
            return false;
        }

        //Dados dos produtos/servicos
        $this->cabecalhoProdutos();
        $i = 0;
        $ii = 0;
        $_qtlinhas = 0;
        foreach ($this->det as $d) {
            //Line(float x1, float y1, float x2, float y2)
            //Cell(float w [, float h [, string txt [, mixed border [, int ln [, string align [, boolean fill [, mixed link]]]]]]])
            $prod = $this->det->item($i)->getElementsByTagName("prod")->item(0);
            if (($GLOBALS["_VERSAO_NT"] & 256) > 0) {
                $infAdProd = (String) $this->det->item($i)->getElementsByTagName("infAdProd")->item(0)->nodeValue;
                if (empty($infAdProd)) {
                    $infAdProd = "Nao houve arrecadacao para o FECP";
                }
            }
            $imposto = $this->det->item($i)->getElementsByTagName("imposto")->item(0);

            //Tira os espa�os em branco
            $_descricao = trim($prod->getElementsByTagName("xProd")->item(0)->nodeValue);
            $_arr_desc = funcoesGerais::quebrarTextoEmPalavrasComLimite($_descricao, $this->tamanho_descricao, $infAdProd);
            $_qtlinhas += count($_arr_desc);

            /**
             * Se a descri��o vai usar duas linhas ent�o vamos pular duas linhas se n�o couber vai pra pr�xima.
             * Pula quantas linhas forem necess�rias.
             */
            if (($_qtlinhas > $this->qtd_itens && $this->_imprimir_blocos)
                || ($_qtlinhas  > $this->qtd_itens_aux && !$this->_imprimir_blocos)) {
                $this->AddPage();
                $this->cabecalhoProdutos();
                $_qtlinhas = count($_arr_desc); // Quantidade de linhas iniciadas na nova pagina
                $ii=0;
            }

            $ICMS = $imposto->getElementsByTagName("ICMS")->item(0);
            $IPI  = $imposto->getElementsByTagName("IPI")->item(0);
            $vIPI = (!empty($IPI)) ? $IPI->getElementsByTagName("vIPI")->item(0)->nodeValue : 0;
            $pIPI = (!empty($IPI)) ? $IPI->getElementsByTagName("pIPI")->item(0)->nodeValue : 0;
            $NCM = (!empty($prod->getElementsByTagName("NCM")->item(0)->nodeValue)) ? $prod->getElementsByTagName("NCM")->item(0)->nodeValue : '';

            $ISSQNOT = $imposto->getElementsByTagName("ISSQN")->item(0);
            if ($this->issqn&&is_object($ISSQNOT)) {
                // calculo do issqn
                $this->totBCISSQN      += (isset($ISSQNOT->getElementsByTagName("vBC")->item(0)->nodeValue) ? floatval($ISSQNOT->getElementsByTagName("vBC")->item(0)->nodeValue) : 0);
                $this->totValorISSQN   += (isset($ISSQNOT->getElementsByTagName("vISSQN")->item(0)->nodeValue) ? floatval($ISSQNOT->getElementsByTagName("vISSQN")->item(0)->nodeValue) : 0);
                $this->totValorServico += floatval($prod->getElementsByTagName("vProd")->item(0)->nodeValue);
                $_issSitTrib			= $ISSQNOT->getElementsByTagName("cSitTrib")->item(0)->nodeValue;
            }

            /** CST */
            $_cst = '';
            if(isset($ICMS)) {
                $_cst = (string) $ICMS->getElementsByTagName('orig')->item(0)->nodeValue;
                $_cst .= (isset($ICMS->getElementsByTagName("CSOSN")->item(0)->nodeValue)
                    ? $ICMS->getElementsByTagName("CSOSN")->item(0)->nodeValue
                    : (isset($ICMS->getElementsByTagName("CST")->item(0)->nodeValue)
                        ? $ICMS->getElementsByTagName("CST")->item(0)->nodeValue
                        : ''
                    )
                );
            } else {
                $_cst = $_issSitTrib;
            }
            $i++;

            //Se houver EAN no XML, uso ele na impress�o.
            if($this->_imprimir_cod_lido && !empty($prod->getElementsByTagName("cEAN")->item(0)->nodeValue) && $prod->getElementsByTagName("cEAN")->item(0)->nodeValue != 'SEM GTIN'){
                $prod->getElementsByTagName("cProd")->item(0)->nodeValue = $prod->getElementsByTagName("cEAN")->item(0)->nodeValue;
            }

            //Percorro o array e se necess�rio, repito fazendo a quebra da linha.
            foreach($_arr_desc as $_chave => $_desc) {
                $ii++;
                $_descricao = substr(utf8_decode(trim($_desc)), 0, $this->tamanho_descricao);
                //Em caso de quebra de linha pela descri��o, n�o preciso repetir os valores e deixo as colunas em branco.
                $_codigo = ($_chave === 0) ? funcoesGerais::removeZerosEsquerdaNumerosGrandes(utf8_decode($prod->getElementsByTagName("cProd")->item(0)->nodeValue)) : "";
                $_ncm = ($_chave === 0) ? $NCM : "";
                $_cst = ($_chave === 0) ? $_cst : "";
                $_cfop = ($_chave === 0) ? $prod->getElementsByTagName("CFOP")->item(0)->nodeValue : "";
                $_un = ($_chave === 0) ? utf8_decode($prod->getElementsByTagName("uCom")->item(0)->nodeValue) : "";
                $_qtd = ($_chave === 0) ? number_format($prod->getElementsByTagName("qCom")->item(0)->nodeValue, 4, ",", ".") : "";
                $_vUnit = ($_chave === 0) ? number_format($prod->getElementsByTagName("vUnCom")->item(0)->nodeValue, 4, ",", ".") : "";
                $_desconto = ($_chave === 0) ? number_format($prod->getElementsByTagName("vDesc")->item(0)->nodeValue, 2, ",", ".") : "";
                $_tot_prod = ($_chave === 0) ? funcoesGerais::ConverterParaNumero($prod->getElementsByTagName("vProd")->item(0)->nodeValue, 2) - funcoesGerais::ConverterParaNumero($prod->getElementsByTagName("vDesc")->item(0)->nodeValue, 2) : "";
                $_vTotal = ($_chave === 0) ? number_format($_tot_prod, 2, ",", ".") : "";
                $_bcICMS = ($_chave === 0) ? (isset($ICMS) ? number_format($ICMS->getElementsByTagName("vBC")->item(0)->nodeValue, 2, ",", ".") : "") : "";
                $_vICMS = ($_chave === 0) ? (isset($ICMS) ? number_format($ICMS->getElementsByTagName("vICMS")->item(0)->nodeValue, 2, ",", ".") : "") : "";
                $_vIPI = ($_chave === 0) ? number_format($vIPI, 2, ",", ".") : "";
                $_percICMS = ($_chave === 0) ? (isset($ICMS) ? number_format($ICMS->getElementsByTagName("pICMS")->item(0)->nodeValue, 2, ",", ".") : "") : "";
                $_percIPI = ($_chave === 0) ? number_format($pIPI, 2, ",", ".") : "";

                if (($_chave === 0)) {
                    if ($this->formato == 'L') {
                        $_font_mercadoria = $this->getFontSizeCodMercadoriaPaisagem($_codigo);
                    } else {
                        $_font_mercadoria = $this->getFontSizeCodMercadoriaRetrato($_codigo);
                    }
                }

                $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_vertical;
                $_ajuste_horizontal = 0;
                if ($this->formato=="L") {
                    $this->_imprimir_blocos ? $_ajuste = 0 : $_ajuste = $this->defaut_ajuste_horizontal2;
                    $this->_imprimir_blocos ? $_ajuste_horizontal = 0 : $_ajuste_horizontal = $this->defaut_ajuste_horizontal;
                }
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(16.0 + $_ajuste_horizontal, 5), $this->getMargemEsquerda(11.0 - $_ajuste_horizontal), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_codigo, "Courier,,{$_font_mercadoria},L");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(48.0 + $_ajuste_horizontal, 40),   $this->getMargemEsquerda(26.0 - $_ajuste_horizontal, 5),     $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_descricao, "Courier,,6,L");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(9.5), $this->getMargemEsquerda(74.0, 45), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_ncm, "Courier,,5.5,L");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(4.5), $this->getMargemEsquerda(83.5, 45), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_cst, "Courier,,5.5,L");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(5.5), $this->getMargemEsquerda(88.0, 45), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_cfop, "Courier,,5.5,L");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(5.0), $this->getMargemEsquerda(93.5, 45), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_un, "Courier,,5.5,C");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(13.5, 3), $this->getMargemEsquerda(98.5, 45), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_qtd, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(13.5, 5), $this->getMargemEsquerda(111.5, 48), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_vUnit, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(14.5, 15.3), $this->getMargemEsquerda(124.5, 37), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_desconto, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(14.5, 15.3), $this->getMargemEsquerda(137.5, 53), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_vTotal, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(13.0, 5), $this->getMargemEsquerda(151.5, 68.3), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_bcICMS, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(11.5), $this->getMargemEsquerda(164.0, 73.3), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_vICMS, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(11.5), $this->getMargemEsquerda(175.0, 73.3), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_vIPI, "Courier,,6,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(7.5), $this->getMargemEsquerda(186.0, 73.3), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_percICMS, "Courier,,5.5,R");
                $this->linha(85.0 + $this->extra + $this->issqn_extra, $this->getLargura(7.5), $this->getMargemEsquerda(193.0, 73.3), $this->getMargemTop(178.9 + ($ii * 2.6) - $_ajuste), "", $_percIPI, "Courier,,5.5,R");

            }

            //Linha horizontal divis�ria.
            if ($this->_imprimir_divisoria_itens) {
                if (($_qtlinhas < $this->qtd_itens && $this->_imprimir_blocos)
                    || ($_qtlinhas < $this->qtd_itens_aux && !$this->_imprimir_blocos)) {
                    $this->DashedLine(2.6, $this->getLargura(190 + $_ajuste_horizontal,73.3),$this->getMargemEsquerda(10.1 - $_ajuste_horizontal), $this->getMargemTop(178.7+($ii*2.6) - $_ajuste) + 2.6);
                }
            }
        }

        if($_retonar_buffer===false) {
            $this->Output("danfe.pdf","I");
        } else {
            return $this->Output("danfe.pdf","S");
        }
    }
    /**
     * Gera Rodap�
     * @return
     * @access  public
     * @author Daniel B. Lemes
     *
     **/
    function Footer() {
       if ($this->_imprimir_blocos) {
            if ($this->issqn) {
                $this->alterarMargemTopo(14.5);
                $this->montarSubTitulosCabecalho(23,244.3+$this->extra,"C�LCULO"," ISSQN",6.1,248.1+$this->extra,4);

                $this->linha($this->altura_padrao, $this->getLargura(46.0,15.75),        $this->getMargemEsquerda(10.0), $this->getMargemTop(247.9+$this->extra), "BTRL",      "INSCRI��O MUNICIPAL","Courier,B,6,L",(isset($this->emit->getElementsByTagName("IM")->item(0)->nodeValue) ? $this->emit->getElementsByTagName("IM")->item(0)->nodeValue : ""));
                $this->linha($this->altura_padrao, $this->getLargura(47.0,15.75),  $this->getMargemEsquerda(56.0,15.75), $this->getMargemTop(247.9+$this->extra), "BTRL", "VALOR TOTAL DOS SERVI�OS","Courier,B,6,R", ($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ?number_format($this->totValorServico, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
                $this->linha($this->altura_padrao, $this->getLargura(47.0,15.75), $this->getMargemEsquerda(103.0,31.50), $this->getMargemTop(247.9+$this->extra), "BTRL", "BASE DE C�LCULO DO ISSQN","Courier,B,6,R",($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ?number_format($this->totBCISSQN , 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
                $this->linha($this->altura_padrao, $this->getLargura(50.0,26.05), $this->getMargemEsquerda(150.0,47.25), $this->getMargemTop(247.9+$this->extra), "BTRL",           "VALOR DO ISSQN","Courier,B,6,R",($this->PageNo()===$this->getTotalPaginas() || $this->_totais_impressao_unica ?number_format($this->totValorISSQN, 2, ",", "."):"*****"), $this->getFonteLinha("Courier,,7,R","Courier,,10,R"));
                $this->alterarMargemTopo($this->altura_padrao);
            } else {
                $this->alterarMargemTopo(8 * 2.65);
            }

            // dados adicionais
            $this->montarSubTitulosCabecalho(23,257.4+$this->extra,"DADOS ADICIONAIS","",30.7,260.7+$this->extra);
            $this->linha(30.7, $this->getLargura(113.0,73.3),       $this->getMargemEsquerda(10.0), $this->getMargemTop(260.6+$this->extra),  "BTRL", "INFORMA��ES COMPLEMENTARES");
            $this->linha(30.7,  $this->getLargura(77.0,0),     $this->getMargemEsquerda(123.0,73.3), $this->getMargemTop(260.6+$this->extra),  "BTRL", "RESERVADO AO FISCO");


            $this->setFont("Courier", "", "6");
            $this->SetAutopagebreak(false);

            if (is_object($this->infAdic)) {
                $infCpl = $this->infAdic->getElementsByTagName("infCpl")->item(0)->nodeValue;
                if(funcoesGerais::is_utf8($infCpl)) {
                    $infCpl = utf8_decode($infCpl);
                }
                $infCpl = Zstrpos ( $infCpl, "[" ) !== false ? substr ( $infCpl, 1, strlen ( $infCpl ) - 2 ) : $infCpl;
                //$infAdFisco = $this->infAdic->getElementsByTagName("infAdFisco")->item(0)->nodeValue;
                $infCpl .= "\n" . $this->infAdic->getElementsByTagName("infAdFisco")->item(0)->nodeValue;
            }

            if(!empty($this->_num_protocolo_evto)) {
                $infCpl .= "EPEC: {$this->_num_protocolo_evto}";
            }

            // IMPRIME infCpl
            for ($i=0; $i<=strlen($infCpl); $i++) {
                $txt.= $infCpl[$i];
                if ($this->GetStringWidth($txt) >= (($this->formato==="L") ? 180 : 110) || $i >= strlen($infCpl)) {
                    $this->setXY($this->getMargemEsquerda(10), $this->getMargemTop(265+$this->extra+($l*3)));
                    $this->Cell($this->getLargura(90,31.5), 0, $txt, 0, 0, 'L');
                    $txt = '';
                    $l++;
                    //9 linhas
                    if ($l === 9) {
                        break;
                    }
                }
            }

            $cMsg             = $this->infProt->getElementsByTagName("cMsg")->item(0)->nodeValue;
            $xMsg             = $this->infProt->getElementsByTagName("xMsg")->item(0)->nodeValue;
            if ((int) $cMsg == 200 && !empty($xMsg)) {
                $infAdFisco .= $xMsg;
            }


            // IMPRIME infAdFisco
            $l = 0;
            for ($i=0; $i<=strlen($infAdFisco); $i++) {
                $txt.= $infAdFisco[$i];
                if ($this->GetStringWidth($txt) >= 74 || $i >= strlen($infAdFisco)) {
                    $this->setXY($this->getMargemEsquerda(123,41.8), $this->getMargemTop(265+$this->extra+($l*3)));
                    $this->Cell($this->getLargura(77,31.5), 0, $txt, 0, 0, 'L');
                    $txt = '';
                    $l++;
                }
            }
            if($this->formato=="L") {
                $this->margem_topo	   = -20;
            }
        } else if ($this->formato=="L") {
               $this->margem_topo	   = -20;
       }
    }

    /*
     * Retorna tamanho da fonte no modo paisagem
     */
    private function getFontSizeCodMercadoriaPaisagem($_cod_mercadoria) {
        $_qtd_digitos = strlen($_cod_mercadoria);
        if ($_qtd_digitos < 16) {
            return 6;
        }
        return 5.3;
    }

    /*
     * Retorna tamanho da fonte no modo retrato
     */
    private function getFontSizeCodMercadoriaRetrato($_cod_mercadoria) {
        $_qtd_digitos = strlen($_cod_mercadoria);
        if ($_qtd_digitos < 12) {
            return 6;
        }

        switch ($_qtd_digitos) {
            case 12:
                return 5.6;
            case 13:
                return 5.2;
            case 14:
                return 4.8;
            case 15:
                return 4.4;
            case 16:
                return 4.2;
            default:
                return 4;
        }
    }

}

?>