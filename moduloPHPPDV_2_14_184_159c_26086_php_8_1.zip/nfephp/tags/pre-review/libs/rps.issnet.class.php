<?php
/**
 * RPS C/ NOTA DO IssNet
 * @author: �ber Lincoln
 * @data: 12/11/2015
 */
		
include_once('nfephp/tags/pre-review/libs/danfe.class.paisagem.php');

class rps_issnet extends danfe_paisagem{
	private $_obj_integrador = null;
	//Dados da nota
	private $_numero_nota;
	private $_data_emissa;
	private $_data_emissao_rps;
	private $_cod_verificacao;
	
	//Dados Prestador
	private $_cpfcnpj_prestador;
	private $_nome_prestador;
	private $_nome_fantasia_prestador;
	private $_end_prestador;
	private $_complemento_prestador;
	private $_bairro_prestador;
	private $_mun_prestador;
	private $_sigla_prestador;
	private $_cep_prestador;
	private $_tel_prestador;
	private $_email_prestador;
	private $_insc_mun_tomador;
	private $_insc_mun_prestador;
	
	//Dados Tomador
	private $_nome_tomador;
	private $_cpfcnpj_tomador;
	private $_end_tomador;
	private $_numero_end_tomador;
	private $_tel_tomador;
	private $_emailtomador;
	private $_complemento_tomador;
	private $_bairro_tomador;
	private $_mun_tomador;
	private $_sigla_tomador;
	private $_cep_tomador;
	private $_regime_especial; 	    
	private $_simples_nacional; 	    
	private $_incentivo_cultura;
	private $_competencia;
	private $_naturezaoperacao;
	
	//Info adicionais
	private $_discriminacao;
	private $_info_adicionais;
	
	//Atividade
	private $_num_atividade;
	private $_desc_atividade;
	private $_item_lc;
	private $_cod_nacional_atividade_economica;
	
	//Impostos
	private $_valor_pis;
	private $_valor_cofins;
	private $_valor_inss;
	private $_valor_ir;
	private $_valor_csll;
	
	private $_valor_servicos;
	private $_desc_incondicionado;
	private $_retencoes_federais;
	private $_issqn_retido;
	private $_txt_issqn_retido;
	private $_valor_liquido;
	//private $_local_prestado;
	private $_local_imposto;
	private $_valor_nota;
	private $_deducoes;
	private $_base_calculo;
	private $_deducao_base_calculo;
	private $_aliquota;
	private $_impostos_issqn;
	private $_desconto_total;
	private $_desconto_condicionado;
	private $_num_rps;
	private $_info_importante;
	private $_link_nota;
    
    private $_tamanho_itens = 80;
    //private $_tamanho_itens = 6;    
    private $_altura = 0;
    private $_url = "sem url";
	
	function __construct($_dados, $formato="P", $protocolo="",$logo="",$_issqn=false, $_info_adicionais = null, $_obj_integrador = null) {
		$this->setObjIntegrador($_obj_integrador);
		//Removo pra conseguir ler.
		$_dados["DSC_XML_NFS"] = str_replace("e:", "", $_dados["DSC_XML_NFS"]);
		$_obj 					= simplexml_load_string($_dados["DSC_XML_NFS"]);
		//funcoesGerais::GravaLog(var_export($_obj,true),true,true);
		$_obj					= $_obj->InfRps;

		$_obj_retorno			= simplexml_load_string($_dados["DSC_XML_RETORNO_NFS"]);
        $_obj_retorno           = $_obj_retorno->soapBody->ConsultarLoteRpsResponse->ConsultarLoteRpsResult->ListaNfse->CompNfse->tcCompNfse;
		//funcoesGerais::GravaLog(var_export($_obj_retorno,true),true,true);		
		//$_obj_retorno			= $_obj_retorno->ListaNfse->CompNfse->Nfse->InfNfse;
		$_municipio				= new municipio($GLOBALS['_MASTER']);
		
		//CPF/CNPJ
		$_cpf_cnpj_prestador 	= (!empty($_obj->Prestador->Cnpj) ? funcoesGerais::AplicaMascara($_obj->Prestador->Cnpj,"99.999.999/9999-99") : funcoesGerais::AplicaMascara($_obj->Prestador->Cpf,"999.999.999-99"));
		$_cpf_cnpj_tomador 		= (!empty($_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cnpj) ? funcoesGerais::AplicaMascara($_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cnpj,"99.999.999/9999-99") : funcoesGerais::AplicaMascara($_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cpf,"999.999.999-99"));
		
		//Data emissao
		$_data_emissao = funcoesGerais::converte_data($_obj_retorno->Nfse->InfNfse->DataEmissao,"utc","padrao",false,true);
	
		
		$_dados["UF"] . $_dados["IBGE_LOJA"];
		//Munic�pio Prestado
		$_mun_prestador = $_dados["MUNICIPIOPRESTACAODESCRICAO"];
		$_mun_incidencia = $_mun_prestador; 
		
		//Munic�pio Prestador
		$_mun_tomador 	= $_dados["CIDACLIENTE"];
		$this->_url     = $this->getObjIntegrador()->getURLNFe();
		
		
		//Pegando os dados do XML
		$this->_numero_nota				= $_dados["NUM_NFSE"];
		$this->_data_emissa				= $_data_emissao;
		//Ajustar isso ser�o prov�velmente hor�rios diferentes??
		$this->_data_emissao_rps		= funcoesGerais::converte_data($_obj_retorno->Nfse->InfNfse->DataEmissaoRps,"utc","padrao",false,true);
		$this->_cod_verificacao			= $_dados["COD_VERIFICACAO"];
		$this->_cpfcnpj_prestador		= $_cpf_cnpj_prestador;
		$this->_nome_prestador			= $_dados["DES_LOJA"];
		$this->_nome_fantasia_prestador = $_dados["DES_FANTASIA"];
		$this->_end_prestador			= $_dados["DES_ENDERECO"].", ".$_dados["NUMERO"];
		$this->_bairro_prestador		= $_dados["DES_BAIRRO"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Bairro;
		$this->_complemento_prestador	= $_obj_retorno->Nfse->InfNfse->PrestadorServico->Endereco->Complemento;		
		$this->_mun_prestador			= $_mun_prestador;//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->CodigoMunicipio;
		$this->_sigla_prestador			= $_dados["DES_SIGLA"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Uf;
		$this->_cep_prestador			= funcoesGerais::AplicaMascara($_dados["NUM_CEP"],'99.999-999');//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Cep;
		$this->_insc_mun_prestador		= $_obj->Prestador->InscricaoMunicipal;
		$this->_insc_mun_tomador		= $_obj->Tomador->InscricaoMunicipal;
		$this->_tel_prestador			= funcoesGerais::retornarNumeros($_dados["NUM_FONE"]);
		$this->_nome_tomador			= $_dados["NOMECLIENTE"];
		$this->_email_prestador         = $_dados["EMAIL_PRESTADOR"];
		$this->_cpfcnpj_tomador			= $_cpf_cnpj_tomador;
		$this->_end_tomador				= $_obj->Tomador->Endereco->Endereco;
		$this->_numero_end_tomador		= $_obj->Tomador->Endereco->Numero;
		$this->_tel_tomador 			= $_dados["TELCLIENTE"];
		$this->_emailtomador		    = strtolower($_dados["DES_EMAIL"]);
		$this->_bairro_tomador			= $_obj->Tomador->Endereco->Bairro;
		$this->_mun_tomador				= $_mun_tomador;//$_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->CodigoMunicipio;
		$this->_complemento_tomador	    = $_obj_retorno->Nfse->InfNfse->TomadorServico->Endereco->Complemento;		
		$this->_sigla_tomador			= $_obj->Tomador->Endereco->Estado;
		$this->_cep_tomador				= funcoesGerais::AplicaMascara($_obj->Tomador->Endereco->Cep,'99.999-999');
		$this->_discriminacao			= str_replace(array("\\n","\s"),"",$_obj->Servico->Discriminacao);
		$this->_discriminacao			= str_replace("\\n","",$this->_discriminacao);
		$this->_discriminacao			= str_replace(array("\\","\n","\s"),"",$this->_discriminacao);
        if ($_dados["MSG_DADOS_ADICIONAIS_NF"] != NULL){
            $this->_discriminacao .= "\n" . $_dados["MSG_DADOS_ADICIONAIS_NF"];
        }
        $this->_discriminacao = substr($this->_discriminacao, 0, 1999);
		//$this->_info_adicionais			= $_obj->OutrasInformacoes;
		$this->_num_atividade			= $_obj->Servico->CodigoTributacaoMunicipio;
		//C�digo LC116/2003 ver o que � isso.
		$this->_item_lc					= substr($_obj_retorno->Nfse->InfNfse->Servico->ItemListaServico,0,1);
		$this->_cod_nacional_atividade_economica = $_obj_retorno->Nfse->InfNfse->Servico->CodigoCnae;
		$this->_desc_atividade			= $_obj->Servico->Discriminacao;
		$this->_valor_pis				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorPis,2);
		$this->_valor_cofins			= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorCofins,2);
		$this->_valor_inss				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorInss,2);
		$this->_valor_ir				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorIr,2);
		$this->_valor_csll				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorCsll,2);
		$this->_valor_servicos			= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorServicos,2);
		$this->_desc_incondicionado		= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->DescontoIncondicionado,2);
		$this->_retencoes_federais		= funcoesGerais::ConverterParaNumero($this->_valor_pis + $this->_valor_cofins + $this->_valor_inss + $this->_valor_ir + $this->_valor_csll, 2);
		$this->_issqn_retido			= funcoesGerais::ConverterParaNumero(0, 2);
		$this->_txt_issqn_retido		= "N�o";
		$this->_valor_liquido			= funcoesGerais::ConverterParaNumero($this->_valor_servicos - $this->_retencoes_federais - $this->_desc_incondicionado - $this->_desconto_condicionado - $this->_issqn_retido, 2);
		//$this->_local_prestado			= $_mun_prestado;
		$this->_local_imposto			= $_mun_incidencia;
		$this->_regime_especial 	    = $_obj_retorno->Nfse->InfNfse->RegimeEspecialTributacao;
		$this->_simples_nacional 	    = $_obj_retorno->Nfse->InfNfse->OptanteSimplesNacional;		
		$this->_incentivo_cultura	    = $_obj_retorno->Nfse->InfNfse->IncentivadorCultural;
		$this->_competencia				= $_obj_retorno->Nfse->InfNfse->Competencia;
		$this->_naturezaoperacao        = $_obj_retorno->Nfse->InfNfse->NaturezaOperacao;

		
		$this->_valor_nota				= funcoesGerais::ConverterParaNumero($this->_valor_servicos - $this->_desc_incondicionado, 2);
		$this->_deducoes				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorDeducoes, 2);
		$this->_base_calculo			= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->BaseCalculo, 2);
		$this->_deducao_base_calculo	= 0.00;
		//$this->_aliquota				= number_format( $_obj->Servico->Valores->Aliquota,2,",",".");
		$this->_aliquota				= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->Aliquota,2);
		$this->_aliquota				= number_format($this->_aliquota ,2,",",".");
		$this->_impostos_issqn			= funcoesGerais::ConverterParaNumero($_obj->Servico->Valores->ValorIss, 2);
		$this->_desconto_total			= funcoesGerais::ConverterParaNumero($this->_desc_incondicionado, 2);
		$this->_desconto_condicionado   = 0.00;
		$this->_num_rps					= $_obj->IdentificacaoRps->Numero;
/*		$this->_info_importante 		= Array("- Nota fiscal referente o RPS N� ". $_obj_retorno->IdentificacaoRps->Numero,
										  "- A autenticidade desta Nota Fiscal pode ser verificada na p�gina da Prefeitura em www.goiania.go.gov.br.");*/
		$this->_link_nota 				= "";

        $xml = null;
		parent::__construct($xml, $formato, $protocolo, $logo, $_issqn);
    }
    
    /**
     * Setamos o objeto integrador.
     * @param oject $_value
     */
    public function setObjIntegrador($_value) {
    	$this->_obj_integrador = $_value;
    }
    
    /**
     * Objeto integrador
     * @param obje $_value
     */
    public function getObjIntegrador() {
    	return $this->_obj_integrador;
    }
    
    /**
     * Dados da nota 
     */
    public function montarDadosNota() {

		$this->_altura += 6;
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 188,  12.0,  $this->_altura, "", "Identifica��o da Nota Fiscal Eletr�nica", "Arial,B,12,L");
    	////////////////////////////////
		$this->_altura += 6;    			
		
    	$this->linha(26, 40,  160,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha( 6, 40,  160,  $this->_altura + 6, "", "N�mero da Nota Fiscal", "Arial,,9,C");
    	$this->linha( 6, 40,  160,  $this->_altura + 12, "", $this->_numero_nota, "Arial,B,14,C");    	
		/////////////////////////////////////////
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 50;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "Natureza da Opera��o",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Data de emiss�o da NFS-e",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "C�digo de Verifica��o de Autencidade",   "Arial,,7,L");
     	
     	
		$this->_altura += 4;	

		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 50;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "Tributa��o no munic�pio",   "Arial,B,10,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_data_emissa,   "Arial,B,10,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_cod_verificacao,   "Arial,B,10,L");


		///////////////////////////////////////////////////////////////////////////////////////////////////     	
		$this->_altura += 6;
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 30;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "N�mero do RPS",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 70;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "S�rie do RPS",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Data de Emiss�o do RPS",   "Arial,,7,L");
     	
     	
		$this->_altura += 4;	

		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 30;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", $this->_num_rps,   "Arial,B,10,C");

     	$_pos_esquerada += $_largura;
		$_largura		= 70;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada + 2,  $this->_altura, "", "RPS - Recibo Provis�rio de Servi�o",   "Arial,B,10,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada + 2,  $this->_altura, "", $this->_data_emissao_rps,   "Arial,B,10,L");
     	
     	///////////////////////////////////////////////
		$this->_altura += 6;
    	$this->linha(6, 150,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 150,  12.0,  $this->_altura + .5, "", "Consulte a autenticiade deste documento acessando o site: ", "Arial,B,9,L");
    	$this->linha(4,  40,  105,  $this->_altura + .5, "B", "www.issnetonline.com.br", "Arial,B,9,L");    	
    	
     	
    	
    }
    /**
     * Gera o PDF se a vari�vel retornar_buffer estiver como true
     * retorna o buffer do pdf sen�o tenta mandar por download o arquivo.
     *
     * @param unknown_type $_retonar_buffer
     * @return unknown
     */
    function gerarRPS($_retonar_buffer=false){
    	$this->AddPage();
    	$this->montarDadosPrestador();
    	$this->montarDadosNota();
    	$this->montarDadosTomador();
    	
    	$this->montarDadosDiscriminacao();
    	
    	$this->montarDadosValores();
    	$this->montarDadosRetencaoImposto();
    	$this->montarDadosTotalNota();
    	/**
    	 * PARA TESTE
    	 */
    	//$_retonar_buffer = false;

    	if($_retonar_buffer===false) {
    		$this->Output("danfe.pdf","I");
    	} else {
    		return $this->Output("danfe.pdf","D");
    	}
    }
    
    /**
     * Cabe�alho da nota, m�todo herdado
     * (non-PHPdoc)
     * @see danfe_paisagem::Header()
     */
    function Header(){
		$this->montarCabecalho();
    }
    
    /**
     * Rodap� da nota, m�todo heradado
     * @see danfe_paisagem::Footer()
     */
    function Footer(){
    	$this->montarRodape();
    }
    
    /**
     * Todo o conte�do daqui deve ir no cabe�alho da nota.
     */
    private function montarCabecalho(){

		$_altura_cabecalho = 23;
    	//Padr�o busco logo direto do portal
   		//$this->linha($_altura_cabecalho, 25,  10.0,  10, "TBRL", "", "Arial,B,12,C");    	
    	if (empty($this->logomarca)) {
    		//$this->logomarca = 'http://www.goiania.go.gov.br/Imagem/Brasaogyn_cor.gif';
    		//$this->logomarca = "C:/SandBoxes/manager_1_11_38_1/plugin/nfse/integradores/GISS/guarulhos.gif";
    		$_mun_image = funcoesGerais::removerLatinCharacters($this->_mun_prestador);
    		$_mun_image = strtolower($_mun_image);
    		$_mun_image = str_replace(" ", "_", $_mun_image);
    		
    		$this->logomarca = "plugin/nfse/integradores/ISSNET/" . $_mun_image. ".gif";
    		//funcoesGerais::GravaLog("nome imagem {$this->logomarca}",true,true);
    		if (file_exists($this->logomarca)) {
	    		$this->Image($this->logomarca, $this->getMargemEsquerda(13), $this->getMargemTop(11), 0, 18, 'gif');
    		}
    	} else {
    		//Base 64
    		$_decode_img 		= base64_decode($this->logomarca);
    		$_img_temporaria 	= 'temporario.jpg';
    		if( file_put_contents($_img_temporaria,$_decode_img)!==false ) {
    			$this->Image($_img_temporaria, $this->getMargemEsquerda(18), $this->getMargemTop(11), 0, 18);
    			//Deleto a img do servidor
    			unlink($_img_temporaria);
    		} else {
    			new Exception("Erro ao gerar arquivo tempor�rio(logo).");
    		}
    	}
    	
    	//Esquerda
    	$this->linha($_altura_cabecalho, 145,  10.0,  10, "TBRL", "", "Arial,B,12,C");
    	$this->linha(20.0, 130.0,  40.0,  11, "", "PREFEITURA MUNICIPAL DE {$this->_mun_prestador}", "Arial,B,12,L");
    	$this->linha(7.5,  130.0,  40.0,  16,     "", "SECRETARIA DE FAZENDA","Arial,,12,L");
    	$this->linha(7.5,  130.0,  40.0,  21,     "", $this->_url,"Arial,,10,L");

    
    	//Direita
    	$this->linha($_altura_cabecalho, 190.0, 10, 10, "TBRL", "", "Arial,B,14,L");
    	$this->linha(15, 23, 155, 8,"", "", "", "S�rie do Documento",   "Arial,,9,L");
  	    $this->linha(15, 23, 165, 13,"", "", "", "Nota Fiscal de Servi�o",   "Arial,B,11,C");
  	    $this->linha(15, 23, 165, 17.5,"", "", "", "Eletr�nica - NFSe",   "Arial,B,11,C");  	    
		//$this->SetFillColor(230,230,230);
    	//$this->setXY(37, 10);
		$this->_altura = 33;  
    }
    
    /**
     * Monta os dados do prestador no PDF
     * Informa��es da empresa que est� emitindo a nota
     */
    private function montarDadosPrestador(){
    	  	
    	//////////////////////////////////////////////////////Prestador...
    	
    	$_pos_esquerda = 10;
    	$_largura 	   = 163;
    	    	

		$this->linha(25, 190,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
	   	$this->linha(6, 190,  $_pos_esquerda +2,  $this->_altura+1, "", $this->_nome_prestador, "Arial,B,12,L");
		
		////////////////////
		$this->_altura += 6;   
    	$_pos_esquerda  = 10;
    	$_largura 	    = 190;
    	    	    	
	   	$this->linha(6, $_largura,  $_pos_esquerda +2,  $this->_altura, "", $this->_nome_fantasia_prestador, "Arial,,12,L");    			
		

		$this->_altura 	  += 5;   
	   	$this->linha(3, $_largura,  $_pos_esquerda + 2,  $this->_altura, "", $this->_end_prestador . " " . $this->_complemento_prestador . " - " . $this->_bairro_prestador, "Arial,,8,L");
		$this->_altura 	  += 4;
	   	$this->linha(3, $_largura,  $_pos_esquerda + 2,  $this->_altura, "", "CEP: " . $this->_cep_prestador . " - Fone: " . $this->_tel_prestador . " - " . $this->_mun_prestador . "-" . $this->_sigla_prestador, "Arial,,8,L");
		$this->_altura 	  += 4;	   	
	   	$this->linha(3, $_largura,  $_pos_esquerda + 2,  $this->_altura, "", "Inscri��o Municipal " . $this->_insc_mun_prestador . "  CPF/CNPJ " . $this->_cpfcnpj_prestador, "Arial,,8,L");		
    	
    }
    
    /**
     * Monta os dados do tomador no PDF
     * Informa��es do cliente
     */
    private function montarDadosTomador(){

		$this->_altura += 6;
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 188,  12.0,  $this->_altura, "", "Dados Tomador de Servi�os", "Arial,B,12,L");
    	////////////////////////////////
		$this->_altura += 6;    			
		
		/////////////////////////////////////////
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 40;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "CNPJ/CPF",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Inscri��o Mun�cipial",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 110;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Raz�o Social",   "Arial,,7,L");
     	/////////////////////////////////////
     	
		$this->_altura += 4;	

		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 40;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", $this->_cpfcnpj_prestador,   "Arial,B,10,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_insc_mun_tomador,   "Arial,B,10,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 110;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_nome_tomador,   "Arial,B,10,L");


	

		/////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////////     	
		$this->_altura += 6;
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 70;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "Endere�o",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 20;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "N�mero",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Complemento",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Bairro",   "Arial,,7,L");     


		///////////////////////////////////////////////////////////////////////////////////////////////////

		$this->_altura += 4;
		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 70;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", $this->_end_tomador,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 20;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_numero_end_tomador,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_complemento_tomador,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", $this->_bairro_tomador,   "Arial,,9,L");     			
     	
		///////////////////////////////////////////////////////////////////////////////////////////////////     	
		$this->_altura += 6;
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 25;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "CEP",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 45;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Cidade / UF",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Telefone",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 70;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "e-mail",   "Arial,,7,L");


		///////////////////////////////////////////////////////////////////////////////////////////////////

		$this->_altura += 4;
		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 25;

    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura + 1, "", $this->_cep_tomador,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 45;
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", $this->_mun_prestador . " / " . $this->_sigla_tomador,   "Arial,,8,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", $this->_tel_tomador,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 70;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+1, "", $this->_emailtomador,   "Arial,,9,L");  		

     	$this->_altura += 6;		
    }
    
    
    
    
    /**
     * Monta os dados Discrimina��o no PDF
     */
    private function montarDadosDiscriminacao(){
    	//$this->_altura = 117;    	
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  12.0,  $this->_altura, "", "Descri��o do Servi�o", "Arial,B,12,L");

    	$this->_altura += 6;    	

    	$this->linha($this->_tamanho_itens, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");    	
    	
    	//$this->linha(30, 37.5, 10.0,  60, "TBRL", "", "Arial,B,8.5,L");
    	$_texto = wordwrap($this->_discriminacao,90,"\n");

    	$_linhas = explode("\n", $_texto);
    	$_pos = $this->_altura;
    	foreach ($_linhas as $_valor) {
	    	$this->linha(5, 20, 11.0,  $_pos, "", $_valor, "Arial,,9.5,L");
	    	$_pos = $_pos + 5;
	    	if ($_pos >= $this->_tamanho_itens + $this->_altura) {
	    		break;
	    	}
	    }
	    

		$this->_altura += $this->_tamanho_itens; 	    	
	    
    }
    
    /**
     * Monta os dados de reten��o de imposto
     */
    public function montarDadosTotalNota() {


    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  12.0,  $this->_altura, "", "Valor L�quido da Nota Fiscal", "Arial,B,12,L");
    	$this->linha(6, 50,  150,  $this->_altura, "RL", "R$ " .  $this->_valor_liquido, "Arial,B,12,R");    	

		////////////////////
		$this->_altura 	  += 6;   
    	
    }
    /**
     * Monta os dados de reten��o de imposto
     */
    public function montarDadosRetencaoImposto() {

    	$this->_altura += 0;    	

    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  12.0,  $this->_altura, "", "Reten��es de Impostos", "Arial,B,12,L");

		////////////////////
		$this->_altura 	  += 6;   
    	
		
		/////////////////////////////////////////
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 27.14;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "PIS",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "COFINS",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "INSS",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "IRRF",   "Arial,,7,L");     	

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "CSLL",   "Arial,,7,L");     	

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Outras Reten��es",   "Arial,,7,L");   

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "ISSQN",   "Arial,,7,L");   
     	     	
     	/////////////////////////////////////
     	
		$this->_altura += 4;	

		/////////////////////////////////////////
		$_altura_linha  = 6;
		$_pos_esquerada = 10;

		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura +1, "", "R$ " . $this->_valor_pis,   "Arial,,10,L");

     	$_pos_esquerada += $_largura;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_valor_cofins,   "Arial,,10,R");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_valor_inss,   "Arial,,10,R");

     	$_pos_esquerada += $_largura;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_valor_ir,   "Arial,,10,R");

		$_pos_esquerada += $_largura;
     	
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_valor_csll,   "Arial,,10,R");
     	
		$_pos_esquerada += $_largura;
     	
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_retencoes_federais,   "Arial,,10,R");
     	
		$_pos_esquerada += $_largura;
     	
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", "R$ " . $this->_impostos_issqn,   "Arial,,10,R");
     	
     	/////////////////////////////////////////
		$this->_altura 	  += 6;
    	
    }
    /**
     * Valores e impostos
     */
    public function montarDadosValores(){
    	$this->_altura += 0;    	

    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  12.0,  $this->_altura, "", "Impostos Sobre Servi�os de Qualquer Natureza-ISSQN", "Arial,B,12,L");

		////////////////////
		$this->_altura 	  += 6;   
    	
		
		/////////////////////////////////////////
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 85;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "", "Atividade do Munic�pio",   "Arial,,7,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 20;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Aliquota",   "Arial,,7,C");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 35;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Item LC116/2003",   "Arial,,7,C");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "C�d. Nacional Atividade Econ�mica",   "Arial,,7,L");     	
     	
     	/////////////////////////////////////
     	
		$this->_altura += 4;	

		/////////////////////////////////////////
		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 85;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura +1, "", $this->_num_atividade . " - ",   "Arial,,10,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 20;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", $this->_aliquota,   "Arial,B,10,C");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 35;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", $this->_item_lc,   "Arial,,10,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 50;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + 1, "", $this->_cod_nacional_atividade_economica,   "Arial,,10,L");
     	/////////////////////////////////////////
		$this->_altura 	  += 6;
		
		/////////////////////////////////////////
		$_altura_linha  = 4;
		$_pos_esquerada = 10;
		$_largura		= 30;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura + .5, "", "Valor Total dos Servi�os",   "Arial,B,7,L");

     	$_pos_esquerada += $_largura;
		$_largura		= 27;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + .5, "", "Desconto Incondicionado",   "Arial,,6,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 35;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "Dedu��o Base C�lculo",   "Arial,,6,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 25;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "Base de C�lculo",   "Arial,,6,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 30;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "Total do ISSQN",   "Arial,,6,L");


     	$_pos_esquerada += $_largura;
     	$_largura		 = 18;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "ISSQN Retido",   "Arial,,6,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 25;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "", "Desconto Condicionado",   "Arial,,6,L");
     	
     	/////////////////////////////////////
     	
		$this->_altura += 4;	
		$_altura_linha  = 6;
		$_pos_esquerada = 10;
		$_largura		= 30;
		///////////////////////////////////////////////////////////////////////////////////////////////////
    	$this->linha($_altura_linha, $_largura, 10,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, 10,  $this->_altura + .5, "", "R$ " . $this->_valor_servicos,   "Arial,B,10,R");

     	$_pos_esquerada += $_largura;
		$_largura		= 27;
		
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura + .5, "", "R$ " . $this->_desc_incondicionado,   "Arial,,9,R");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 35;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "R$ " . $this->_deducao_base_calculo,   "Arial,,9,R");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 25;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "R$ " . $this->_base_calculo,   "Arial,,9,R");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 30;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura+ .5, "", "R$ " . $this->_impostos_issqn,   "Arial,,9,R");


     	$_pos_esquerada += $_largura;
     	$_largura		 = 18;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada +.5,  $this->_altura +.5, "", $this->_txt_issqn_retido,   "Arial,,9,L");

     	$_pos_esquerada += $_largura;
     	$_largura		 = 25;

     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura, "TRL", "", "", "",   "Arial,,8.5,C");
     	$this->linha($_altura_linha, $_largura, $_pos_esquerada,  $this->_altura +.5, "", "R$ " . $this->_desconto_condicionado,   "Arial,,9,R");
     	
     	/////////////////////////////////////		
		
		$this->_altura += 6;		
    }
    
    /**
     * Rodap�
     * Informa��es importantes e o link da nota
     */
    public function montarRodape(){
    	$this->linha(6, 190,  10.0,  $this->_altura, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(6, 190,  12.0,  $this->_altura, "", "Informa��es complementares", "Arial,B,12,L");
    	$this->_altura += 6;
    	
    	$_pos_esquerda = 10;
    	$_larg_tot 	   = 190;
    	$this->linha(25, $_larg_tot,  $_pos_esquerda,  $this->_altura, "TBRL", "", "Arial,B,8.5,L");
    	//Informa��es importantes
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "", $this->_info_importante[0], "Arial,,6,L");
		$this->_altura += 2;
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "", $this->_info_importante[1], "Arial,,6,L");
		$this->_altura += 2;    	
    	$this->linha(10, $_larg_tot,  $_pos_esquerda,  $this->_altura, "", $this->_info_importante[2], "Arial,,6,L");
    	 

    }
}
?>