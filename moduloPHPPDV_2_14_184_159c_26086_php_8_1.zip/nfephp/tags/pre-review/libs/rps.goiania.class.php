<?php
/**
 * RPS C/ NOTA GOIANIA
 * @author: Marcelo Anast�cio
 * @data: 27/05/2015
 */
		
include_once('nfephp/tags/pre-review/libs/danfe.class.paisagem.php');

class rps_goiania extends danfe_paisagem{
	//Dados da nota
	private $_numero_nota;
	private $_data_emissa;
	private $_cod_verificacao;
	
	//Dados Prestador
	private $_cpfcnpj_prestador;
	private $_nome_prestador;
	private $_end_prestador;
	private $_bairro_prestador;
	private $_mun_prestador;
	private $_sigla_prestador;
	private $_cep_prestador;
	private $_tel_prestador;
	private $_insc_mun;
	
	//Dados Tomador
	private $_nome_tomador;
	private $_cpfcnpj_tomador;
	private $_end_tomador;
	private $_bairro_tomador;
	private $_mun_tomador;
	private $_sigla_tomador;
	private $_cep_tomador;
	
	//Info adicionais
	private $_discriminacao;
	private $_info_adicionais;
	
	//Atividade
	private $_num_atividade;
	private $_desc_atividade;
	
	//Impostos
	private $_valor_pis;
	private $_valor_cofins;
	private $_valor_inss;
	private $_valor_ir;
	private $_valor_csll;
	
	private $_valor_servicos;
	private $_desc_incondicionado;
	private $_retencoes_federais;
	private $_issqn_retido;
	private $_valor_liquido;
	private $_local_prestado;
	private $_local_imposto;
	private $_valor_nota;
	private $_deducoes;
	private $_base_calculo;
	private $_aliquota;
	private $_impostos_issqn;
	private $_desconto_total;
	private $_info_importante;
	private $_link_nota;
    private $_array_municipio = null;
	
	function __construct($_dados, $formato="P", $protocolo="",$logo="",$_issqn=false, $_info_adicionais = null) {
		$_obj 					= simplexml_load_string($_dados["DSC_XML_NFS"]);
		$_obj 					= $_obj->InfDeclaracaoPrestacaoServico;
		$_obj_retorno			= simplexml_load_string($_dados["DSC_XML_RETORNO_NFS"]);
		$_obj_retorno			= $_obj_retorno->ListaNfse->CompNfse->Nfse->InfNfse;
		$_municipio				= new municipio($GLOBALS['_MASTER']);
		
		//CPF/CNPJ
		$_cpf_cnpj_prestador 	= (!empty($_obj->Prestador->CpfCnpj->Cnpj) ? $_obj->Prestador->CpfCnpj->Cnpj : $_obj->Prestador->CpfCnpj->Cpf);
		$_cpf_cnpj_tomador 		= (!empty($_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cnpj) ? $_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cnpj : $_obj->Tomador->IdentificacaoTomador->CpfCnpj->Cpf);
		
		//Data emissao
		$_data_emissao = explode("T", $_obj_retorno->DataEmissao); //Separa hor�rio
		$_data_emissao = explode("-", $_data_emissao[0]); //Separa o dia/mes/ano
		$_data_emissao = $_data_emissao[2]."/".$_data_emissao[1]."/".$_data_emissao[0];
		
		//$this->_array_municipio[];
		$_dados["UF"] . $_dados["IBGE_LOJA"];
		//Munic�pio Prestado
		$_mun_prestador = $_dados["MUNICIPIOPRESTACAODESCRICAO"];
		$_mun_incidencia = $_mun_prestador; 
		
		//Munic�pio Prestador
		$_mun_tomador 	= $_dados["CIDACLIENTE"];
		
		
		//Pegando os dados do XML
		$this->_numero_nota				= $_obj_retorno->Numero;
		$this->_data_emissa				= $_data_emissao;
		$this->_cod_verificacao			= $_obj_retorno->CodigoVerificacao;
		$this->_cpfcnpj_prestador		= $_cpf_cnpj_prestador;
		$this->_nome_prestador			= $_dados["DES_LOJA"];
		$this->_end_prestador			= $_dados["DES_ENDERECO"].", ".$_dados["NUMERO"];
		$this->_bairro_prestador		= $_dados["DES_BAIRRO"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Bairro;
		$this->_mun_prestador			= $_mun_prestador;//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->CodigoMunicipio;
		$this->_sigla_prestador			= $_dados["DES_SIGLA"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Uf;
		$this->_cep_prestador			= $_dados["NUM_CEP"];//$_obj_retorno->DeclaracaoPrestacaoServico->Prestador->Endereco->Cep;
		$this->_insc_mun				= $_obj_retorno->DeclaracaoPrestacaoServico->Prestador->IdentificacaoPrestador->InscricaoMunicipal;
		$this->_tel_prestador			= $_dados["NUM_FONE"];
		$this->_nome_tomador			= $_obj_retorno->DeclaracaoPrestacaoServico->Tomador->RazaoSocial;
		$this->_cpfcnpj_tomador			= $_cpf_cnpj_tomador;
		$this->_end_tomador				= $_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->Endereco;
		$this->_bairro_tomador			= $_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->Bairro;
		$this->_mun_tomador				= $_mun_tomador;//$_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->CodigoMunicipio;
		$this->_sigla_tomador			= $_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->Uf;
		$this->_cep_tomador				= $_obj_retorno->DeclaracaoPrestacaoServico->Tomador->Endereco->Cep;
		$this->_discriminacao			= str_replace(array("\\n","\s"),"",$_obj_retorno->DeclaracaoPrestacaoServico->Servico->Discriminacao);
		$this->_discriminacao			= str_replace("\\n","",$this->_discriminacao);
		$this->_discriminacao			= str_replace(array("\\","\n","\s"),"",$this->_discriminacao);
        if ($_dados["MSG_DADOS_ADICIONAIS_NF"] != NULL){
            $this->_discriminacao .= "\n" . $_dados["MSG_DADOS_ADICIONAIS_NF"];
        }
        $this->_discriminacao = substr($this->_discriminacao, 0, 1999);
		$this->_info_adicionais			= $_obj_retorno->OutrasInformacoes;
		$this->_num_atividade			= $_obj_retorno->DeclaracaoPrestacaoServico->Servico->CodigoTributacaoMunicipio;
		$this->_desc_atividade			= $_obj->Servico->Discriminacao;
		$this->_valor_pis				= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorPis,2);
		$this->_valor_cofins			= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorCofins,2);
		$this->_valor_inss				= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorInss,2);
		$this->_valor_ir				= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorIr,2);
		$this->_valor_csll				= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorCsll,2);
		$this->_valor_servicos			= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorServicos,2);
		$this->_desc_incondicionado		= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->DescontoIncondicionado,2);
		$this->_retencoes_federais		= funcoesGerais::ConverterParaNumero($this->_valor_pis + $this->_valor_cofins + $this->_valor_inss + $this->_valor_ir + $this->_valor_csll, 2);
		$this->_issqn_retido			= funcoesGerais::ConverterParaNumero(0, 2);
		$this->_valor_liquido			= funcoesGerais::ConverterParaNumero($this->_valor_servicos - $this->_retencoes_federais - $this->_desc_incondicionado - $this->_issqn_retido, 2);
		$this->_local_prestado			= $_mun_prestador; //$_mun_prestado;
		$this->_local_imposto			= $_mun_incidencia;
		$this->_valor_nota				= funcoesGerais::ConverterParaNumero($this->_valor_servicos - $this->_desc_incondicionado, 2);
		$this->_deducoes				= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorDeducoes, 2);
		$this->_base_calculo			= funcoesGerais::ConverterParaNumero($_obj_retorno->ValoresNfse->BaseCalculo, 2);
		$this->_aliquota				= $_obj_retorno->ValoresNfse->Aliquota;
		$this->_impostos_issqn			= funcoesGerais::ConverterParaNumero($_obj_retorno->DeclaracaoPrestacaoServico->Servico->Valores->ValorIss, 2);
		$this->_desconto_total			= funcoesGerais::ConverterParaNumero($this->_desc_incondicionado, 2);
		$this->_info_importante 		= Array("- Nota fiscal referente o RPS N� ". $_obj_retorno->DeclaracaoPrestacaoServico->IdentificacaoRps->Numero,
										  "- A autenticidade desta Nota Fiscal pode ser verificada na p�gina da Prefeitura em www.goiania.go.gov.br.");
		$this->_link_nota 				= "http://www2.goiania.go.gov.br/sistemas/snfse/asp/snfse00200w0.asp?nota=";

        $xml = null;
		parent::__construct($xml, $formato, $protocolo, $logo, $_issqn);
    }
    
    /**
     * Gera o PDF se a vari�vel retornar_buffer estiver como true
     * retorna o buffer do pdf sen�o tenta mandar por download o arquivo.
     *
     * @param unknown_type $_retonar_buffer
     * @return unknown
     */
    function gerarRPS($_retonar_buffer=false){
    	$this->AddPage();
    
    	$this->montarDadosPrestador();
    	$this->montarDadosTomador();
    	$this->montarDadosDiscriminacao();
    	$this->montarInformacoesAdicionais();
    	$this->montarDadosAtividade();
    	$this->montarDadosValores();
    	
    	/**
    	 * PARA TESTE
    	 */
    	//$_retonar_buffer = false;
    	
    	if($_retonar_buffer===false) {
    		$this->Output("danfe.pdf","I");
    	} else {
    		return $this->Output("danfe.pdf","D");
    	}
    }
    
    /**
     * Cabe�alho da nota, m�todo herdado
     * (non-PHPdoc)
     * @see danfe_paisagem::Header()
     */
    function Header(){
    	$this->montarCabecalho();
    }
    
    /**
     * Rodap� da nota, m�todo heradado
     * @see danfe_paisagem::Footer()
     */
    function Footer(){
    	$this->montarRodape();
    }
    
    /**
     * Todo o conte�do daqui deve ir no cabe�alho da nota.
     */
    private function montarCabecalho(){
    	//Padr�o busco logo direto do portal
    	if (empty($this->logomarca)) {
    		$this->logomarca = 'http://www.goiania.go.gov.br/Imagem/Brasaogyn_cor.gif';
    		$this->Image($this->logomarca, $this->getMargemEsquerda(11), $this->getMargemTop(11), 0, 18, 'gif');
    	} else {
    		//Base 64
    		$_decode_img 		= base64_decode($this->logomarca);
    		$_img_temporaria 	= 'temporario.jpg';
    		if( file_put_contents($_img_temporaria,$_decode_img)!==false ) {
    			$this->Image($_img_temporaria, $this->getMargemEsquerda(11), $this->getMargemTop(11), 0, 18);
    			//Deleto a img do servidor
    			unlink($_img_temporaria);
    		} else {
    			new Exception("Erro ao gerar arquivo tempor�rio(logo).");
    		}
    	}
    	
    	//Esquerda
    	$this->linha(20.0, 135.0,  10.0,  10, "TBRL", "", "Arial,B,12,C");
    	$this->linha(20.0, 155.0,  10.0,  11, "", "Prefeitura de Goi�nia", "Arial,,10,C");
    	$this->linha(7.5, 155.0,  10.0,  16,     "", "Secretaria Municipal de Finan�as","Arial,,10,C");
    	$this->linha(7.5, 155.0,  10.0,  21,     "", "Nota Fiscal de Servi�os Eletr�nica - NFS-e","Arial,,10,C");
    	$this->linha(7.5, 155.0,  10.0,  26,     "", "AIDF 68870/2013 - NFS-e","Arial,,7,C");
    	$this->setXY(8, 7);
    	$this->Cell(15, 0, date("d/m/Y"));
    	$this->setXY(75, 7);
    	$this->Cell(15, 0, "Prefeitura de Goi�nia - Nota Fiscal de Servi�os (NFS-e)");
    	$this->setXY(146, 16);
    
    	//Direita
    	$this->linha(20.0, 55.0, 145.0, 10, "TBRL", "");
    	$this->Cell(15, 2, "N�mero da Nota");
    	//$this->setXY(167, 8);
    	//$this->SetFillColor(230,230,230);
    	//$this->Cell(32, 3.8, "", 0, 0, "", true);
    	$this->setXY(146, 22);
    	$this->Cell(15, 0, "Data Emiss�o");
    	$this->setXY(146, 27);
    	$this->Cell(15, 0, "C�digo Verifica��o");
        //$this->linha($this->altura_padrao, 20, 175,  11.7, "", "", "", $this->_numero_nota,   "Arial,B,9,L");
        $this->linha(8.5, 20, 175,  11.7, "", "", "", $this->_numero_nota,   "Arial,B,9,L");
        //$this->linha($this->altura_padrao, 20, 175, 16.9, "", "", "", $this->_data_emissa, "Arial,B,9,L");
        $this->linha(8.5, 20, 175, 16.9, "", "", "", $this->_data_emissa, "Arial,B,9,L");
        //$this->linha($this->altura_padrao, 20, 175, 21.9, "", "", "", $this->_cod_verificacao, "Arial,B,9,L");
        $this->linha(8.5, 20, 175, 21.9, "", "", "", $this->_cod_verificacao, "Arial,B,9,L");
    }
    
    /**
     * Monta os dados do prestador no PDF
     * Informa��es da empresa que est� emitindo a nota
     */
    private function montarDadosPrestador(){
    	$this->linha(30, 190,  10.0,  30, "TBRL", "PRESTADOR DOS SERVI�OS", "Arial,B,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	//$this->linha(30, 37.5, 10.0,  30, "TBRL", "", "Arial,B,8.5,L");
    	$this->linha(5, 20, 11.0,  35, "", "CPF/CNPJ", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  40, "", "Nome/Raz�o Social","Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  45, "", "Endere�o", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  50, "", "Bairro","Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  55, "", "Munic�pio", "Arial,,9.5,L");
    
    	//S� para utilizar como base os itens do centro
    	//$this->linha(30, 105,   47.5,  30, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(5, 105,   47.5,  35, "", $this->_cpfcnpj_prestador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  40, "", $this->_nome_prestador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  45, "", $this->_end_prestador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  50, "", $this->_bairro_prestador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  55, "", "{$this->_mun_prestador}-{$this->_sigla_prestador}   CEP {$this->_cep_prestador}       Telefone  {$this->_tel_prestador}", "Arial,,9.5,L");
    	//S� para utilizar como base os itens a direita
    	//$this->linha(30.0, 52.5,  147.5,  30, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(30.0, 52.5,  147.5,  35, "", "Incri��o Municipal", "Arial,,8.5,L");
    	$this->linha(30.0, 60,  175,  35, "", $this->_insc_mun, "Arial,,8.5,L");
    }
    
    /**
     * Monta os dados do tomador no PDF
     * Informa��es do cliente
     */
    private function montarDadosTomador(){
    	$this->linha(30, 190,  10.0,  60, "TBRL", "TOMADOR DOS SERVI�OS", "Arial,B,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	//$this->linha(30, 37.5, 10.0,  60, "TBRL", "", "Arial,B,8.5,L");
    	$this->linha(5, 20, 11.0,  65, "", "Nome/Raz�o Social", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  70, "", "CPF/CNPJ", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  75, "", "Endere�o", "Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  80, "", "Bairro","Arial,,9.5,L");
    	$this->linha(5, 20, 11.0,  85, "", "Munic�pio", "Arial,,9.5,L");
    
    	//S� para utilizar como base os itens do centro
    	//$this->linha(30, 105,   47.5,  30, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(5, 105,   47.5,  65, "", $this->_nome_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  70, "", $this->_cpfcnpj_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  75, "", $this->_end_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  80, "", $this->_bairro_tomador, "Arial,,9.5,L");
    	$this->linha(5, 105,   47.5,  85, "", "{$this->_mun_tomador}�{$this->_sigla_tomador}   CEP {$this->_cep_tomador}", "Arial,,9.5,L");
    }
    
    /**
     * Monta os dados Discrimina��o no PDF
     */
    private function montarDadosDiscriminacao(){
    	$this->linha(80, 190,  10.0,  90, "TBRL", "DISCRIMINA��O DOS SERVI�OS", "Arial,B,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	//$this->linha(30, 37.5, 10.0,  60, "TBRL", "", "Arial,B,8.5,L");
    	$_texto = wordwrap($this->_discriminacao,90,"\n");
    	$_linhas = explode("\n", $_texto);
    	$_pos = 95;
    	foreach ($_linhas as $_valor) {
	    	$this->linha(5, 20, 11.0,  $_pos, "", $_valor, "Arial,,9.5,L");
	    	$_pos = $_pos + 5;
	    }
    }
    
    /**
     * Monta as informa��es adicionais
     */
    private function montarInformacoesAdicionais(){
    	$this->linha(20, 190,  10.0,  170, "TBRL", "INFORMA��ES ADICIONAIS", "Arial,B,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	$this->linha(5, 170, 11.0,  175, "", $this->_info_adicionais, "Arial,,9.5,L");
    }
    
    /**
     * Numero e nome da atividade
     */
    private function montarDadosAtividade(){
    	$this->linha(8, 190,  10.0,  190, "TBRL", "", "Arial,,8.5,C");
    	//S� para utilizar como base os itens a esquerda
    	$this->linha(5, 20, 11.0,  190, "", "Atividade ".$this->_num_atividade, "Arial,,8.5,L");
    	$this->linha(5, 20, 11.0,  194, "", $this->_desc_atividade, "Arial,,8.5,L");
    }
    
    /**
     * Valores e impostos
     */
    public function montarDadosValores(){
    	//Reten��es Federais
     	$this->linha(10, 31.666,  	10.0,  		198, "TBRL", "", "Arial,,8.5,C"); //coluna1
     	$this->linha(10, 31.666,  	10.0,  		199, "", "Reten��es", "Arial,,8.5,C");
     	$this->linha(10, 31.666,  	10.0,  		202, "", "Federais", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	41.666,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna2
    	$this->linha(10, 31.666,  	41.666,  	199, "", "PIS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	41.666,  	202, "", "R$ ".$this->_valor_pis, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	73.3,  		198, "TBRL", "", "Arial,,8.5,C"); //coluna3
    	$this->linha(10, 31.666,  	73.3,  		199, "", "COFINS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	73.3,  		202, "", "R$ ".$this->_valor_cofins, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	104.96,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna4
    	$this->linha(10, 31.666,  	104.96,  	199, "", "INSS", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	104.96,  	202, "", "R$ ".$this->_valor_inss, "Arial,,8.5,C");
    	$this->linha(10, 31.666, 	136.62,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna5
    	$this->linha(10, 31.666,  	136.62,  	199, "", "IR", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	136.62,  	202, "", "R$ ".$this->_valor_ir, "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	168.28,  	198, "TBRL", "", "Arial,,8.5,C"); //coluna6
    	$this->linha(10, 31.666,  	168.28,  	199, "", "CSLL", "Arial,,8.5,C");
    	$this->linha(10, 31.666,  	168.28,  	202, "", "R$ ".$this->_valor_csll, "Arial,,8.5,C");
    		
    	//Demonstrativo
    	$this->linha(40, 95,  10.0,  	208, "TBRL", "Demonstrativo", "Arial,,9.5,C");
    	$this->linha(40, 40,  11.0,  	214, "", "Valor dos Servi�os", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	214, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	214, "", $this->_valor_servicos, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	218, "", "(�)  Desconto Incondicionado", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		218, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	218, "", $this->_desc_incondicionado, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	222, "", "(�)  Reten��es Federais", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		222, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	222, "", $this->_retencoes_federais, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	226, "", "(�)  ISSQN Retido pelo Tomador", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		226, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	226, "", $this->_issqn_retido, "Arial,,9.5,R");
    	$this->linha(40, 40,  11.0,  	230, "", "(=) Valor L�quido", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  		230, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  65,  	 	230, "", $this->_valor_liquido, "Arial,,9.5,R");
    	$this->linha(11, 47.5,  10.0,  	237, "TBRL", "Servi�o prestado em", "Arial,,9.5,C");
    	$this->linha(11, 47.5,  10.0,  	242, "", "$this->_local_prestado", "Arial,B,8,C");
    	$this->linha(11, 47.5,  57.5,  	237, "TBRL", "Imposto devido em", "Arial,,9.5,C");
    	$this->linha(11, 47.5,  57.5,  	242, "", "$this->_local_imposto", "Arial,B,8,C");
    	
    	//C�lculo do imposto
    	$this->linha(40, 95,  105.0,  208, "TBRL", "C�lculo do imposto", "Arial,,8.5,C");
    	$this->linha(40, 40,  106.0,  218, "", "Valor dos Servi�os", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  218, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  218, "", $this->_valor_servicos, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  222, "", "(�)  Desconto Incondicionado", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  222, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  222, "", $this->_desc_incondicionado, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  226, "", "(=) Valor da Nota", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  226, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  226, "", $this->_valor_nota, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  230, "", "(�)  Dedu��es", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  230, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  230, "", $this->_deducoes, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  234, "", "(=) Base de C�lculo ", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  234, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  234, "", $this->_base_calculo, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  238, "", "(x) Al�quota ", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  238, "", "%", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  238, "", $this->_aliquota, "Arial,,9.5,R");
    	$this->linha(40, 40,  106.0,  242, "", "(=) Valor do Imposto (ISSQN)", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  242, "", "R$", "Arial,,9.5,L");
    	$this->linha(40, 40,  160.0,  242, "", $this->_impostos_issqn, "Arial,,9.5,R");
    	
    	//Totais
    	//$this->linha(10, 190,  		10.0,  		248, "TBRL", "", "Arial,B,8.5,C");
    	$this->linha(10, 63.33,  	10.0,  		248, "TBRL", "Valor dos Servi�os", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	10.0,  		252, "","R$ ".$this->_valor_servicos, "Arial,,9.5,C");
    	$this->linha(10, 63.33,  	73.33,  	248, "TBRL", "Desconto", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	73.33,  	252, "","R$ ".$this->_desconto_total, "Arial,,9.5,C");
    	$this->linha(10, 63.33,  	136.66,  	248, "TBRL", "Valor da Nota", "Arial,,8.5,C");
    	$this->linha(10, 63.33,  	136.66,  	252, "","R$ ".$this->_valor_nota, "Arial,B,12,C");
    }
    
    /**
     * Rodap�
     * Informa��es importantes e o link da nota
     */
    public function montarRodape(){
    	//Informa��es importantes
    	$this->linha(10, 190,  10.0,  257.9, "TBRL", "", "Arial,B,8.5,L");
    	$this->linha(10, 190,  11.0,  257.9, "", "Informa��es Importantes:", "Arial,B,8.5,L");
    	$this->linha(10, 190,  11.0,  260.9, "", $this->_info_importante[0], "Arial,,8.5,L");
    	$this->linha(10, 190,  11.0,  264.0, "", $this->_info_importante[1], "Arial,,8.5,L");    	
    	 
    	$this->linha(1, 190,  10.0,  274, "", $this->_link_nota.$this->_numero_nota, "Arial,,8,L");
    }
}
?>