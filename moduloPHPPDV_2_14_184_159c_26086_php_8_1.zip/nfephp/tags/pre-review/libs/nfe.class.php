<?php
/**
 * NF-e - Nota Fiscal eletr�nica
 * Classes para gera��o da NF-e e grava��o em DB
 * NFe layout 1.10
 *
 * @author  Djalma Fadel Junior <dfadel at ferasoft dot com dot br>
 * @date    27/06/2009
 */


/**
 * O objeto $con a ser passado para NFe � um objeto MDB2 do PEAR
 *  $dsn = array (
 *      'phptype'  => 'mysql',
 *      'username' => 'usuario',
 *      'password' => 'senha',
 *      'hostspec' => '192.168.0.1',
 *      'database' => 'banco_dados'
 *  );
 *  $con =& MDB2::connect($dsn);
 *
 * OBS: o fetchRow do MDB2 retorna o array associativo em lowercase
 */


/**
 * set_error()
 * Voc� pode definir sua fun��o para tratamento de erros
 */
if (!function_exists('set_error')) {
    $_ERROR = array();
    function set_error($err_msg) {
        global $_ERROR;
        return $_ERROR[] = $err_msg;
    }
}


/* NIVEL 0 ********************************************************************/
define("MDB2_FETCHMODE_ASSOC",2);
include_once('nfephp/tags/pre-review/libs/classNFEtools.php');
class situacao {

    var $situacao_id;
    var $descricao;

    function __construct() {
        global $con;
        $this->fetch($con, 5); // 5 = em digita��o
    }

    function fetch($con, $situacao_id) {
        $sql = "SELECT * FROM situacao WHERE situacao_id = ".$situacao_id;
        $qry = $con->query($sql);
        if (!MDB2::isError($qry)) {
            $row = $qry->fetchRow(MDB2_FETCHMODE_ASSOC);
            $this->situacao_id = $row['situacao_id'];
            $this->descricao   = $row['descricao'];
        }
    }
}

class NFe extends NFEtools {

    var $infNFe;        // A01 - grupo das informa��es da NFe
    var $situacao;      // objeto de situa��o da NF-e
    var $infCFe;		// A01 - grupo das informa��es do CFe
    static $_tipo_nota = null; //Para ser utilizado nas subclasses que checam a vers�o

    function __construct() {
        $this->infNFe   = new infNFe;
        $this->situacao = new situacao;
    }

    /**
     * Retorna o XML ou objeto DOM
     * @param boolean $_formatar Define se formata ou n�o
     * @param boolean $_passar_dom Define se passa o Dom ou n�o
     * @return string
     */
    function get_xml($_formatar=false, $_passar_dom = false) {
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->formatOutput = $_formatar;

        $raiz = $dom->appendChild($dom->createElement('NFe'));
        $raiz_att = $raiz->appendChild($dom->createAttribute('xmlns'));
                    $raiz_att->appendChild($dom->createTextNode('http://www.portalfiscal.inf.br/nfe'));

        $raiz->appendChild($this->infNFe->get_xml($dom));
        if ($_passar_dom) {
			return $dom;
        } else {
        	$_xml = $dom->saveXML();
        	//Se existir algum destes caracteres ser� rejeitado.
        	$_xml = str_replace(array("\r","\n","\t"),' ',$_xml);
	        return $_xml;
        }
    }

    // BUG: � feio. � gambi. mas funciona.
    function fetch($con, $NFe_id) {
    	return true;
    }
}



/* NIVEL 1 ********************************************************************/

// A01
class infNFe {

    var $versao;        // A02 - vers�o do leiaute
    var $Id;            // A03 - identificador da TAG a ser assinada
    var $ide;           // B01 - grupo das informa��es de identifica��o da NFe
    var $emit;          // C01 - grupo de identifica��o do emitente da NFe
    var $avulsa;        // D01 - informa��es do fisco emitente
    var $dest;          // E01 - grupo de identifica��o do destinat�rio da NFe
    var $retirada;      // F01 - grupo de identifica��o do local de retirada
    var $entrega;       // G01 - grupo de identifica��o do local de entrega
    /**
     * @var det
     */
    var $det;           // H01 - grupo do detalhamento de prod. e serv. da NFe
    var $total;         // W01 - grupo de valores totais da NFe
    var $transp;        // X01 - grupo de informa��o do transporte da NFe
    var $cobr;          // Y01 - grupo de cobran�a
    var $infAdic;       // Z01 - grupo de informa��es adicionais
    var $obsCont;
    var $exporta;       // ZA01- grupo de exporta��o
    var $compra;        // ZB01- grupo de compra
    var $Signature;     // ZC01- assinatura XML da NFe segundo padr�o digital
    var $pag;			// YA01- Grupo de Formas de Pagamento
    var $infIntermed;	// YB01- Informa��es do Intermediador da Transa��o
    var $detPag;        // YA01A - Grupo do detalhe das formas de pagamento
    var $infRespTec;    // ZD01 - Grupo de ifnorma��es da Software House emissora
    var $agropecuario;  // ZF01 - Informa��es de produtos da agricultura, pecu�ria e produ��o Florestal

    function __construct() {
        $this->versao       = '2.00';
        $this->ide          = new ide;
        $this->emit         = new emit;
        $this->avulsa       = null;
        $this->dest         = new dest;
        $this->autXML       = new autXML;
        $this->retirada     = null;
        $this->entrega      = null;
        $this->det          = array();
        $this->total        = new total;
        $this->transp       = new transp;
        $this->cobr         = new cobr;
        $this->infIntermed  = new infIntermed;
        $this->infAdic      = null;
        $this->obsCont      = null;
        $this->exporta      = null;
        $this->compra       = null;
        $this->Signature    = new Signature;
        if(($GLOBALS["_VERSAO_NT"] & 1) > 0) {
            $this->infRespTec    = new infRespTec;
        }
        $this->agropecuario = null;
    }

    function add_avulsa($obj_avulsa) {
        if (!$this->avulsa) {
            $this->avulsa = $obj_avulsa;
            return true;
        } else {
            return false;
        }
    }

    function add_retirada($obj_retirada) {
        if (!$this->retirada) {
            $this->retirada = $obj_retirada;
            return true;
        } else {
            return false;
        }
    }

    function add_entrega($obj_entrega) {
        if (!$this->entrega) {
            $this->entrega = $obj_entrega;
            return true;
        } else {
            return false;
        }
    }

    function add_det($obj_det) {
        $this->det[] = $obj_det;
        return true;
    }


    function add_pag($obj_pag) {
    	$this->pag[] = $obj_pag;
    	return true;
    }

    /**
     * Informa��es do intermediador.
     * @param $obj_intermed
     * @return bool
     */
    function add_infIntermed($obj_intermed) {
        if (!$this->infIntermed) {
            $this->infIntermed = $obj_intermed;
            return true;
        } else {
            return false;
        }
    }

    function add_cobr($obj_cobr) {
        if (!$this->cobr) {
            $this->cobr = $obj_cobr;
            return true;
        } else {
            return false;
        }
    }

    function add_infAdic($obj_infAdic) {
        if (!$this->infAdic) {
            $this->infAdic = $obj_infAdic;
            return true;
        } else {
            return false;
        }
    }

    function add_agropecuario($obj_agropecuario) {
        if (!$this->agropecuario) {
            $this->agropecuario = $obj_agropecuario;
            return true;
        } else {
            return false;
        }
    }

    function add_exporta($obj_exporta) {
        if (!$this->exporta) {
            $this->exporta = $obj_exporta;
            return true;
        } else {
            return false;
        }
    }

    function add_compra($obj_compra) {
        if (!$this->compra) {
            $this->compra = $obj_compra;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Calcula digito verificador para chave de acesso de 43 d�gitos
     * conforme manual, p�g. 72
     */
    function calcula_dv($chave43) {
        $multiplicadores = array(2,3,4,5,6,7,8,9);
        $i = 42;
        while ($i >= 0) {
            for ($m=0; $m<count((array)$multiplicadores) && $i>=0; $m++) {
                $soma_ponderada+= $chave43[$i] * $multiplicadores[$m];
                $i--;
            }
        }
        $resto = $soma_ponderada % 11;
        if ($resto == '0' || $resto == '1') {
            $this->ide->cDV = 0;
        } else {
            $this->ide->cDV = 11 - $resto;
        }
        return $this->ide->cDV;
    }

    function get_chave_acesso() {

        // 02 - cUF  - c�digo da UF do emitente do Documento Fiscal
        $chave = sprintf("%02d", $this->ide->cUF);

        // 04 - AAMM - Ano e Mes de emiss�o da NF-e
        $chave.= sprintf("%04d", substr($this->ide->dEmi, 2, 2).substr($this->ide->dEmi, 5, 2));

        // 14 - CNPJ - CNPJ do emitente
        $chave.= sprintf("%014s", $this->emit->CNPJ);

        // 02 - mod  - Modelo do Documento Fiscal
        $chave.= sprintf("%02d", $this->ide->mod);

        // 03 - serie - S�rie do Documento Fiscal
        $chave.= sprintf("%03d", $this->ide->serie);

        // 09 - nNF  - N�mero do Documento Fiscal
        $chave.= sprintf("%09d", $this->ide->nNF);

        // 09 - cNF  - C�digo Num�rico que comp�e a Chave de Acesso
        $chave.= sprintf("%09d", $this->ide->cNF);

        // 01 - cDV  - D�gito Verificador da Chave de Acesso
        $chave.= $this->calcula_dv($chave);

        return $chave;
    }

    function get_xml($dom) {
        $_chave = substr($this->Id,3);
        $A01 = $dom->appendChild($dom->createElement('infNFe'));
        $A02 = $A01->appendChild($dom->createAttribute('versao'));
               $A02->appendChild($dom->createTextNode($this->versao));
        $A03 = $A01->appendChild($dom->createAttribute('Id'));
               $A03->appendChild($dom->createTextNode($this->Id = "NFe". $_chave));//.$this->get_chave_acesso()));

        $_id_nfe = funcoesGerais::destrincharIDNFE($_chave);

		$this->ide->verNFe = $this->versao;
        $B01 = $A01->appendChild($this->ide->get_xml($dom));
        $C01 = $A01->appendChild($this->emit->get_xml($dom));
        $D01 = (is_object($this->avulsa))   ? $A01->appendChild($this->avulsa->get_xml($dom))   : null;
        if (($_obj_dest = $this->dest->get_xml($dom)) !== false) {
	        $E01 = $A01->appendChild($_obj_dest);
        }

        if(!empty($this->autXML->CNPJ) && $_id_nfe["TIPO_MODELO_NF"] == 55) {
            if(!empty($this->autXML->CPF)){
                $BA01 = $A01->appendChild($this->autXML->get_xml($dom,'CPF'));
            }
            $BA01 = $A01->appendChild($this->autXML->get_xml($dom,'CNPJ'));
        }

        $F01 = (is_object($this->retirada)) ? $A01->appendChild($this->retirada->get_xml($dom)) : null;
        $G01 = (is_object($this->entrega))  ? $A01->appendChild($this->entrega->get_xml($dom))  : null;
        $detalhe = null;
        for ($i=0; $i<count((array)$this->det); $i++) {
        	$detalhe = $this->det[$i]->get_xml($dom);
        	if (!is_null($detalhe)) {
	            $H01 = $A01->appendChild($detalhe);
        	}
        }

        $W01 = $A01->appendChild($this->total->get_xml($dom));
        $X01 = $A01->appendChild($this->transp->get_xml($dom));
        if($_id_nfe["TIPO_MODELO_NF"] == 55) {
            if (is_object($this->cobr) && (sizeof((array)$this->cobr->dup) || sizeof((array)$this->cobr->fat))) {
                $Y01 = (is_object($this->cobr))     ? $A01->appendChild($this->cobr->get_xml($dom))     : null;
            }
        }
		$pag = null;
        for ($i=0; $i<count((array)$this->pag); $i++) {
        	$pag = $this->pag[$i]->get_xml($dom);
        	if (!is_null($pag)) {
	        	$YA01 = $A01->appendChild($pag);
        	}
        }

        if (($GLOBALS['_VERSAO_NT'] & 131072) != 0) {
            if (!empty($this->infIntermed->CNPJ) && in_array($this->ide->indPres, [1,2,3,4,9])) { //S� pode ter intermediador se o indPres fo diferente desses
                $YB01 = $A01->appendChild($this->infIntermed->get_xml($dom));
            }
        }

        $Z01 = (is_object($this->infAdic))  ? $A01->appendChild($this->infAdic->get_xml($dom))  : null;
        $ZA01= (is_object($this->exporta))  ? $A01->appendChild($this->exporta->get_xml($dom))  : null;
        $ZB01= (is_object($this->compra))   ? $A01->appendChild($this->compra->get_xml($dom))   : null;
        // BUG: assinado posteriormente por NFe_utils
        // S� podemos validar se $this->infRespTec � um objeto se tivermos instanciado a classe infRespTec;
        $ZD01 = ($GLOBALS["_VERSAO_NT"] & 1)>0 ? (is_object($this->infRespTec) ? $A01->appendChild($this->infRespTec->get_xml($dom)) : null) : null;
        $ZF01= (is_object($this->agropecuario)) ? $A01->appendChild($this->agropecuario->get_xml($dom)) : null;
        return $A01;
    }

}



/* NIVEL 2 ********************************************************************/

// B01
class ide {

    var $cUF;       // B02 - c�digo da UF do emitente
    var $cNF;       // B03 - c�digo num�rico que comp�e a chave de acesso;
    var $natOp;     // B04 - descri��o da natureza da opera��o
    var $indPag;    // B05 - indicador da forma de pagamento
    /**
       55=NF-e emitida em substitui��o a Nota Fiscal modelo 1/1A;
	   65=NFC-e, utilizada nas opera��es de vendas no varejo, onde n�o for exigida a NF-e por dispositivo legal.

       @var int
     */
    var $mod;       // B06 - c�digo do modelo do documento fiscal
    var $serie;     // B07 - s�rie do documento fiscal
    var $nNF;       // B08 - n�mero do documento fiscal
    var $dEmi;      // B09 - data de emiss�o do documento fiscal
    var $dSaiEnt;   // B10 - data da sa�da ou da entrada da mercadoria/produto
    var $hSaiEnt;   // B10a - hora da sa�da ou da entrada da mercadoria/produto
    var $tpNF;      // B11 - tipo do documento fiscal (0-entrada / 1-saida)
    var $idDest;    // B11a - Identificador de local de destino da opera��o (1=Opera��o interna / 2=Opera��o interestadual / 3=Opera��o com exterior)
    var $cMunFG;    // B12 - c�digo do munic�pio de ocorr�ncia do fato gerador
    var $NFref;     // B12a- informa��o das NF/NFe referenciadas
    /**
     	B21 - formato de impress�o do DANFE

		0 = Sem gera��o de DANFE;
		1 = DANFE normal, Retrato;
		2 = DANFE normal, Paisagem;
		3 = DANFE Simplificado;
		4 = DANFE NFC-e;
		5 = DANFE NFC-e em mensagem eletr�nica.
		Nota: O envio de mensagem eletr�nica pode ser feita de forma simult�nea com a impress�o do DANFE. Usar o
		tpImp=5 na NFC-e quando esta for a �nica forma de disponibiliza��o do DANFE.
     */
    var $tpImp;     // B21 - formato de impress�o do DANFE
    /**
     * B22 - forma de emiss�o da NFe
     *
		1=Emiss�o normal (n�o em conting�ncia);
		2=Conting�ncia FS-IA, com impress�o do DANFE em
		formul�rio de seguran�a;
		3=Conting�ncia SCAN (Sistema de Conting�ncia do
		Ambiente Nacional);
		4=Conting�ncia DPEC (Declara��o Pr�via da Emiss�o
		em Conting�ncia);
		5=Conting�ncia FS-DA, com impress�o do DANFE em
		formul�rio de seguran�a;
		6=Conting�ncia SVC-AN (SEFAZ Virtual de Conting�ncia
		do AN);
		7=Conting�ncia SVC-RS (SEFAZ Virtual de Conting�ncia
		do RS);
		9=Conting�ncia off-line da NFC-e;
		Nota: Para a NFC-e somente est�o dispon�veis e s�o
		v�lidas as op��es de conting�ncia 5 e 9.
     * @var unknown_type
     */
    var $tpEmis;    // B22 - forma de emiss�o da NFe
    var $cDV;       // B23 - d�gito verificador da chave de acesso
    var $tpAmb;     // B24 - identifica��o do ambiente
    /**
        1=NF-e normal;
		2=NF-e complementar;
		3=NF-e de ajuste;
		4=Devolu��o/Retorno
     * @var unknown_type
     */
    var $finNFe;    // B25  - finalidade de emiss�o da NFe
    var $indFinal;  // B25a - Indica opera��o com Consumidor final

    /**
		0=N�o se aplica (por exemplo, para a Nota Fiscal complementar ou de ajuste);
		1=Opera��o presencial;
		2=Opera��o n�o presencial, pela Internet;
		3=Opera��o n�o presencial, Teleatendimento;
		4=NFC-e em opera��o com entrega em domic�lio;
		9=Opera��o n�o presencial, outros.
		Nota: Para a NFC-e, somente s�o aceitas as op��es 1 e 4.
     * @var unknown_type
     */
    var $indPres;   // B25b - Indicador de presen�a do comprador no estabelecimento comercial no momento da opera��o
    var $indIntermed; // B25c - Indicador de intermediador/marketplace

    var $procEmi;   // B26 - processo de emiss�o da NFe
    var $verProc;   // B27 - vers�o do processo de emiss�o da NFe


	//VERS�O 2.0 Campos novos.
	var $dhCont;	//B28 - Data e Hora da entrada em conting�ncia
	var $xJust;		//B29 - Justificativa da entrada em conting�ncia

    var $verNFe; //Vers�o da NFE, utilizado apenas pra consulta

    //Vari�veis exclusivas para o SAT
    var $CNPJ;
    var $signAC;
    var $numeroCaixa;

    function __construct() {
        $this->mod      = 55;               // NFe
        $this->NFref    = array();
        $this->procEmi  = 0;                // emiss�o de NFe com aplicativo do contribuinte

    }

    // NFe ou NF
    function add_NFref($obj_NFref) {
        $this->NFref[] = $obj_NFref;
        return true;
    }

    function get_xml($dom) {
        $B01 = $dom->appendChild($dom->createElement('ide'));
        $B02 = $B01->appendChild($dom->createElement('cUF',     $this->cUF));
        if ((int)$this->verNFe < 2) {
        	$B03 = $B01->appendChild($dom->createElement('cNF',     sprintf("%09d", $this->cNF)));
        } else {
        	$B03 = $B01->appendChild($dom->createElement('cNF',     sprintf("%08d", $this->cNF)));
        }
        $B04 = $B01->appendChild($dom->createElement('natOp',   $this->natOp));
        //ALTNFE-19 - No layout 4.00 n�o podemos mais montar essa tag
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) < 4) {
        $B05 = $B01->appendChild($dom->createElement('indPag',  $this->indPag));
        }
        $B06 = $B01->appendChild($dom->createElement('mod',     $this->mod));
        $B07 = $B01->appendChild($dom->createElement('serie',   $this->serie));
        $B08 = $B01->appendChild($dom->createElement('nNF',     $this->nNF));
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) == 2) { //Trocaram de nome na vers�o 3.10.
	        $B09 = $B01->appendChild($dom->createElement('dEmi',    $this->dEmi));
	        $B10 = (!empty($this->dSaiEnt)) ? $B01->appendChild($dom->createElement('dSaiEnt', $this->dSaiEnt)) : '';
        } else {
        	//Temos que converter para UTC-3
        	$B09 = $B01->appendChild($dom->createElement('dhEmi',  $this->dEmi));
        	//Segundo a Val�ria existe uma norma t�cnica q diz q na NFCe (65) este campo n�o vir�.
        	if ((int) $this->mod === 55) {
	        	$B10 = (!empty($this->dSaiEnt)) ? $B01->appendChild($dom->createElement('dhSaiEnt', $this->dSaiEnt)) : '';
        	}
        }
        //VERS�O 2.0
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) == 2) { //Removido na vers�o 3.1
	        $B10a = (!empty($this->hSaiEnt)) ? $B01->appendChild($dom->createElement('hSaiEnt', $this->hSaiEnt)) : '';
        }
        $B11  = $B01->appendChild($dom->createElement('tpNF',    $this->tpNF));

        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 2) {
			$B11a = $B01->appendChild($dom->createElement('idDest',    $this->idDest));
        }


        $B12 = $B01->appendChild($dom->createElement('cMunFG',  $this->cMunFG));
        //tpImp est� em todas as vers�es.
        $B21  = $B01->appendChild($dom->createElement('tpImp',   $this->tpImp));
        //tpEmis est� em todas as vers�es.
        $B22  = $B01->appendChild($dom->createElement('tpEmis',  $this->tpEmis));

        $B23  = $B01->appendChild($dom->createElement('cDV',     $this->cDV));
        $B24  = $B01->appendChild($dom->createElement('tpAmb',   $this->tpAmb));

        $B25  = $B01->appendChild($dom->createElement('finNFe',  $this->finNFe));
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 2) {
        	$B25a = $B01->appendChild($dom->createElement('indFinal',  $this->indFinal));
	        $B25b = $B01->appendChild($dom->createElement('indPres',  $this->indPres));
            if (($GLOBALS['_VERSAO_NT'] & 131072) != 0) {
                if((int)$this->indIntermed > 0){ //Temos que gravar oq vier, essa regra/if deveria estar em outro ponto
                    $B25c = $B01->appendChild($dom->createElement('indIntermed', $this->indIntermed));
                } else if (($this->indPres >= 1 && $this->indPres <= 4) || ($this->indPres == 9)) {
                    $B25c = $B01->appendChild($dom->createElement('indIntermed', 0)); //Padr�o zero
                }
            }
        }

        $B26 = $B01->appendChild($dom->createElement('procEmi', $this->procEmi));
        $B27 = $B01->appendChild($dom->createElement('verProc', $this->verProc));
        //VERS�O 2.0
        if((int)$this->tpEmis!==1) {
	        $B28 = (!empty($this->dhCont) ? $B01->appendChild($dom->createElement('dhCont',  $this->dhCont)) : '');
    	    $B29 = (!empty($this->xJust) ? $B01->appendChild($dom->createElement('xJust', $this->xJust)) : '');
        }
        for ($i=0; $i<count((array)$this->NFref); $i++) {
            $B12a= $B01->appendChild($this->NFref[$i]->get_xml($dom));
        }

        return $B01;
    }

}

// C01
class emit {

    var $CNPJ;      // C02 - CNPJ do emitente
    var $CPF;       // C02a- CPF do remetente
    var $xNome;     // C03 - raz�o social ou nome do emitente
    var $xFant;     // C04 - nome fantasia
    var $enderEmit; // C05 - grupo do endere�o do emitente
    var $IE;        // C17 - IE
    var $IEST;      // C18 - IE do substituto tribut�rio
    var $IM;        // C19 - Inscri��o Municipal
    var $CNAE;      // C20 - CNAE fiscal
    var $CRT;		// C21 - CRT C�digo do Regime Tribut�rio 2.0 (1- Simples Nacional

    function __construct() {
        $this->enderEmit = new enderEmit;
    }

    function get_xml($dom) {
        /**
         * @var DOMElement $dom
         */
        $C01 = $dom->appendChild($dom->createElement('emit'));
        $C02 = (empty($this->CPF)) ? $C01->appendChild($dom->createElement('CNPJ', sprintf("%014s", $this->CNPJ))) : $C01->appendChild($dom->createElement('CPF', sprintf("%011s", $this->CPF)));
        //C02a - ou exclusivo com C02
        $C03 = $C01->appendChild($dom->createElement('xNome',htmlentities($this->xNome,null,"ISO-8859-1")));
        $C04 = $C01->appendChild($dom->createElement('xFant',htmlentities($this->xFant,null,"ISO-8859-1")));
        $C05 = $C01->appendChild($this->enderEmit->get_xml($dom));
        $C17 = $C01->appendChild($dom->createElement('IE',          $this->IE));

        $C18 = (!empty($this->IEST)) ? $C01->appendChild($dom->createElement('IEST',    $this->IEST)) : '';
        $C19 = (!empty($this->IM)) ? $C01->appendChild($dom->createElement('IM',        $this->IM)) : '';
        $C20 = (!empty($this->CNAE) && !empty($this->IM)) ? $C01->appendChild($dom->createElement('CNAE',    $this->CNAE)) : '';
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota)>1.10) {
        	$C21 = $C01->appendChild($dom->createElement('CRT',    $this->CRT));
        }
        return $C01;
    }

}

// D01
class avulsa {

    var $CNPJ;      // D02 - CNPJ do �rg�o emitente
    var $xOrgao;    // D03 - �rg�o emitente
    var $matr;      // D04 - matr�cula do agente
    var $xAgente;   // D05 - nome do agente
    var $fone;      // D06 - telefone
    var $UF;        // D07 - sigla da UF
    var $nDAR;      // D08 - n�mero do documento de arrecada��o de receita
    var $dEmi;      // D09 - data de emiss�o do documento de arrecada��o
    var $vDAR;      // D10 - valor total no documento de arrecada��o de receita
    var $repEmi;    // D11 - reparti��o fiscal emitente
    var $dPag;      // D12 - data de pagamento do documento de arrecada��o

    function __construct() {
    }

    function get_xml($dom) {
        $D01 = $dom->appendChild($dom->createElement('avulsa'));
        $D02 = $D01->appendChild($dom->createElement('CNPJ',    sprintf("%014s", $this->CNPJ)));
        $D03 = $D01->appendChild($dom->createElement('xOrgao',  $this->xOrgao));
        $D04 = $D01->appendChild($dom->createElement('matr',    $this->matr));
        $D05 = $D01->appendChild($dom->createElement('xAgente', $this->xAgente));
        $D06 = $D01->appendChild($dom->createElement('fone',    funcoesGerais::retornarNumeros($this->fone)));
        $D07 = $D01->appendChild($dom->createElement('UF',      $this->UF));
        $D08 = $D01->appendChild($dom->createElement('nDAR',    $this->nDAR));
        $D09 = $D01->appendChild($dom->createElement('dEmi',    $this->dEmi));
        $D10 = $D01->appendChild($dom->createElement('vDAR',    number_format((float)$this->vDAR, 2, ".", "")));
        $D11 = $D01->appendChild($dom->createElement('repEmi',  $this->repEmi));
        $D12 = (!empty($this->dPag)) ? $D01->appendChild($dom->createElement('dPag', $this->dPag)) : '';
        return $D01;
    }

}


//YA04 Grupo de Cart�es
class card {
	var $CNPJ;  //YA05 CNPJ da Credenciadora de cart�o de cr�dito e/ou d�bito
	var $tBand; //YA06 Bandeira da operadora de cart�o de cr�dito e/ou d�bito
	var $cAut;  //YA07 N�mero de autoriza��o da opera��o cart�o de cr�dito e/ou d�bito
    var $tpIntegra; //$YA04a N�mero integra��o 1 = TEF, 2 = POS
    /**
     * SQA-2133/SQA-2151
     * Rodilson M. Federico
     * MAN - Novos campos na tab_nota_pagamentos
     * Mai/2024
     */
    var $CNPJReceb; //YA07a CNPJ do benefici�rio do pagamento
    var $idTermPag; //YA07b Identificador do terminal de pagamento

 	function get_xml($dom) {
        /**
         * Para o projeto BASE-2339 quando vier preenchido o caut devemos enviar o CARD.
         */
		if (!empty($this->CNPJ) || (!empty($this->cAut) && !empty($this->idTermPag))) {
			$YA04  = $dom->appendChild($dom->createElement('card'));
            $YA04a  = $YA04->appendChild($dom->createElement('tpIntegra', $this->tpIntegra));
            if (!empty($this->CNPJ)) {
                $YA05 = $YA04->appendChild($dom->createElement('CNPJ', str_pad($this->CNPJ, 14, "0", STR_PAD_LEFT)));
            }
            if (!empty($this->tBand)) {
                $YA06 = $YA04->appendChild($dom->createElement('tBand', sprintf("%02s", $this->tBand)));
            }
			$YA07  = $YA04->appendChild($dom->createElement('cAut', $this->cAut));

            /**
             * SQA-2133/SQA-2151
             * Rodilson M. Federico
             * MAN - Novos campos na tab_nota_pagamentos
             * Mai/2024
             */
            if (!empty($this->CNPJReceb)) {
                $YA07a = $YA04->appendChild($dom->createElement('CNPJReceb', $this->CNPJReceb));
            }

            if (!empty($this->idTermPag)) {
                $YA07b = $YA04->appendChild($dom->createElement('idTermPag', $this->idTermPag));
            }

			return $YA04;
		}

	}
}

//YA01 Grupo de Formas de Pagamento
class pag {
	/**
	 * Forma de pagamento
	 *
	    01=Dinheiro
		02=Cheque
		03=Cart�o de Cr�dito
		04=Cart�o de D�bito
		05=Cr�dito Loja
		10=Vale Alimenta��o
		11=Vale Refei��o
		12=Vale Presente
		13=Vale Combust�vel
        17=PIX
        90=Sem Pagamento
		99=Outros
	 * @var string
	 */
	var $tPag; //YA01 Forma de pagamento
    var $xPag; //YA02A Descri��o do pagamento
	var $vPag; //YA03 Valor do Pagamento
	var $card; //YA04 Grupo de Cart�es
    var $vTroco; //YA09 Valor do Troco
    var $detPag;

	function __construct() {
		$this->card = new card();
	}

    function add_detPag($obj_pag) {
        $this->detPag[] = $obj_pag;
        return true;
    }

	function get_xml($dom) {
		//Se o valor do pagamento estiver vazio cai fora.
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) < 4) {
    		if (empty($this->vPag)) {
	    		return null;
		    }
        }
		$YA01  = $dom->appendChild($dom->createElement('pag'));
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $detPag = null;
            for ($i=0; $i<count((array)$this->detPag); $i++) {
                $detPag = $this->detPag[$i]->get_xml($dom);
                if (!is_null($detPag)) {
                    $YA01A = $YA01->appendChild($detPag);
                }
            }
            /**
             * ALTNFE-26
             * Se houver troco, montamos a tag no xml
             * ALTNFE-40 Se o troco for false n�o insere, estava inserindo zero na troca e n�o pode.
             */
            if (!empty($this->vTroco)) {
                $YA09 = $YA01->appendChild($dom->createElement('vTroco', number_format((float)$this->vTroco, 2, '.', '')));
            }
            return $YA01;
        }
		$YA02  = $YA01->appendChild($dom->createElement('tPag', sprintf("%02s", $this->tPag)));

        if (($this->tPag == '99' || $this->tPag == 99) && !empty($this->xPag)){
            $YA02A = $YA01->appendChild($dom->createElement('xPag', $this->xPag));
        }

		$YA03  = $YA01->appendChild($dom->createElement('vPag', $this->vPag));
        /**
         * SQA-2820
         * Tratar a Rejei��o 963 em Formas de Pagamento que n�o deve conter a tag Card
         * Rodilson Federico
         * 02/Jul/2024
         *
         * Conforme alinhado com Valeria Pinheiro:
         * Se Meio de Pagamento (tag: tPag) for diferente de (03, 04, 10, 11, 12, 13, 15, 17 e 18),
         * N�o pode ser preenchido o grupo de cart�es (tag: card).
         */
        if (!empty($this->tPag) && in_array((int)$this->tPag, [3, 4, 10, 11, 12, 13, 15, 17, 18])) {
            if (($_card = $this->card->get_xml($dom)) !== null) {
                $YA04 = $YA01->appendChild($_card);
            }
        }
		return $YA01;
	}

}

//YB01 Informa��es do Intermediador da Transa��o
class infIntermed {
    var $CNPJ; //YB01 Forma de pagamento
    var $idCadIntTran; //YB02 Valor do Pagamento

    /**
     * Monta o objeto do XML.
     * @param $dom
     * @return mixed
     */
    function get_xml($dom) {
        $YB01  = $dom->appendChild($dom->createElement('infIntermed'));
        $YB02  = $YB01->appendChild($dom->createElement('CNPJ', $this->CNPJ));
        $YB03  = $YB01->appendChild($dom->createElement('idCadIntTran', $this->idCadIntTran));
        return $YB01;
    }
}


//YA01 Grupo de Formas de Pagamento
class detPag {
    /**
     * Forma de pagamento
     *
    01=Dinheiro
    02=Cheque
    03=Cart�o de Cr�dito
    04=Cart�o de D�bito
    05=Cr�dito Loja
    10=Vale Alimenta��o
    11=Vale Refei��o
    12=Vale Presente
    13=Vale Combust�vel
    99=Outros
     * @var string
     */
    var $tPag; //YA01 Forma de pagamento
    var $indPag; //$YA01B indicador de forma de pagamento
    var $xPag; //YA02A Descri��o do pagamento
    var $vPag; //YA03 Valor do Pagamento
    var $card; //YA04 Grupo de Cart�es
    /**
     * SQA-2133/SQA-2151
     * Rodilson M. Federico
     * MAN - Novos campos na tab_nota_pagamentos
     * Mai/2024
     */
    var $dPag; //YA03A Data do Pagamento
    var $CNPJPag; //YA03C CNPJ transacional do pagamento
    var $UFPag; //YA03D UF do CNPJ do estabelecimento onde o pagamento foi processado/transacionado/recebido

    function __construct() {
        $this->card = new card();
    }

    function get_xml($dom) {
        //Se o valor do pagamento estiver vazio cai fora.
        //a menos que a forma de pagamento seja 90, que indica que n�o tem pagamento
        //ou forma de pagamento seja 91, que indica que o pagamento ser� posterior
        if (empty($this->vPag)&&(!in_array($this->tPag,[90,91]))) {
            return null;
        }

        /**
         * SQM-4356
         * Quando a forma de pagamento for 91, o valor do pagamento � zerado,
         * pois o pagamento � posterior.
         */
        if(in_array($this->tPag,[90,91])){
            $this->vPag=0;
        }

        $YA01A  = $dom->appendChild($dom->createElement('detPag'));
        $YA01B  = $YA01A->appendChild($dom->createElement('indPag', (int) $this->indPag));
        $YA02  = $YA01A->appendChild($dom->createElement('tPag', sprintf("%02s", $this->tPag)));

        if (($this->tPag == '99' || $this->tPag == 99) && !empty($this->xPag)){
            $YA02A = $YA01A->appendChild($dom->createElement('xPag', $this->xPag));
        }

        $YA03  = $YA01A->appendChild($dom->createElement('vPag', number_format($this->vPag, 2, ".", "")));

        /**
         * SQA-2133/SQA-2151
         * Rodilson M. Federico
         * MAN - Novos campos na tab_nota_pagamentos
         * Mai/2024
         */
        if (!empty($this->dPag) && $this->tPag!=91) {
            $YA03A = $YA01A->appendChild($dom->createElement('dPag', $this->dPag));
        }
        if (!empty($this->CNPJPag)) {
            //$YA03B = $dom->createElement('x');
            $YA03C = $YA01A->appendChild($dom->createElement('CNPJPag',$this->CNPJPag));
            $YA03D = $YA01A->appendChild($dom->createElement('UFPag',$this->UFPag));
            //$YA01A->appendChild($YA03B);
        }

        /**
         * SQA-2820
         * Tratar a Rejei��o 963 em Formas de Pagamento que n�o deve conter a tag Card
         * Rodilson Federico
         * 02/Jul/2024
         *
         * Conforme alinhado com Valeria Pinheiro:
         * Se Meio de Pagamento (tag: tPag) for diferente de (03, 04, 10, 11, 12, 13, 15, 17 e 18),
         * N�o pode ser preenchido o grupo de cart�es (tag: card).
         */
        if (!empty($this->tPag) && in_array((int)$this->tPag, [3, 4, 10, 11, 12, 13, 15, 17, 18])) {
            if (($_card = $this->card->get_xml($dom)) !== null) {
                $YA04 = $YA01A->appendChild($_card);
            }
        }
        return $YA01A;
    }

}

// E01
class dest {

    var $CNPJ;      // E02 - CNPJ do destinat�rio
    var $CPF;       // E02a- CPF do destinat�rio
    var $xNome;     // E03 - raz�o social ou nome do emitente
    var $enderDest; // E05 - grupo do endere�o do emitente
    /**
     1=Contribuinte ICMS (informar a IE do destinat�rio);
     2=Contribuinte isento de Inscri��o no cadastro de
     Contribuintes do ICMS;
     9=N�o Contribuinte, que pode ou n�o possuir Inscri��o
     Estadual no Cadastro de Contribuintes do ICMS;
     Nota 1: No caso de NFC-e informar indIEDest=9 e n�o
     informar a tag IE do destinat�rio;
     Nota 2: No caso de opera��o com o Exterior informar
     indIEDest=9 e n�o informar a tag IE do destinat�rio;
     Nota 3: No caso de Contribuinte Isento de Inscri��o
     (indIEDest=2), n�o informar a tag IE do destinat�rio.
     * @var int
     */
    var $indIEDest; // E16a - Indicador da IE do Destinat�rio
    var $IE;        // E17 - IE
    var $IM;		// E18a - IM
    var $ISUF;      // E18 - Inscri��o na SUFRAMA

    var $email;     // E19 - EMAIL VERS�O 2.0

    function __construct() {
        $this->enderDest = new enderDest;
    }

    function get_xml($dom) {
    	//Checar tamb�m o estrangeiro, na NFCe pode ser que n�o tenha mesmo
    	if (empty($this->CPF) && empty($this->CNPJ) ) {
    		return false;
    	}
    	if($this->enderDest->UF == 'EX') {
    	    $_tagName = 'idEstrangeiro';
        }else{
            if(!empty( $this->CNPJ)) {
                $this->CNPJ = sprintf("%014s", $this->CNPJ);
            }
            if(!empty( $this->CPF)) {
                $this->CPF = sprintf("%011s", $this->CPF);
            }
        }
        $E01  = $dom->appendChild($dom->createElement('dest'));
        $E02  = (empty($this->CPF)) ? (empty($this->CNPJ)) ? $E01->appendChild($dom->createElement(($_tagName!=''?$_tagName:'CNPJ'), '')) : $E01->appendChild($dom->createElement(($_tagName!=''?$_tagName:'CNPJ'), $this->CNPJ)) : $E01->appendChild($dom->createElement(($_tagName!=''?$_tagName:'CPF'), $this->CPF));

        //Na NFCe posso vender apenas para CPF ent�o pode n�o vir preenchido o nome.
		if (!empty($this->xNome)) {
        	//E03 - ou exclusivo com E02
        	$E04  = $E01->appendChild($dom->createElement('xNome',       $this->xNome));
		}


        //Se for 65 � NFCe logo pode n�o vir com dados de cliente ent�o nem monto.
        if (($_enderDest = $this->enderDest->get_xml($dom)) !== false) {
	        $E05  = $E01->appendChild($_enderDest);
        }
        //Criado para NFE 3.1
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 3) {
        	$E16a = (!empty($this->indIEDest)) ? $E01->appendChild($dom->createElement('indIEDest',    $this->indIEDest)) : '';
        }
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 3) {
	    	if ($this->IE !== "ISENTO") {
		        $E17  = isset($this->IE) && !empty($this->IE)  ?  $E01->appendChild($dom->createElement('IE',          $this->IE)) : "";
	        }
        } else {
        	//Na vers�o 2.0 vazio ou n�o ele deve criar.
       	    $E17  = $E01->appendChild($dom->createElement('IE',          $this->IE));
        }

        $E18  = (!empty($this->ISUF)) ? $E01->appendChild($dom->createElement('ISUF',    $this->ISUF)) : '';
        //Vers�o 3.10
        $E18a  = (!empty($this->IM)) ? $E01->appendChild($dom->createElement('IM', $this->IM)) : '';
        //VERS�O 2.0
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota)>1.10) {
        	$E19 = (!empty($this->email)) ? $E01->appendChild($dom->createElement('email',    $this->email)) : '';
        }
        return $E01;
    }
}

// Essa tag � usada somente para o estado da BAHIA e � fixo o valor do CNPJ
class autXML {

    var $CNPJ;
    var $CPF;

    function __construct() {
    }

    function get_xml($dom, $v) {

        $BA01  = $dom->appendChild($dom->createElement('autXML'));

        if($v=='CNPJ'){
            $BA02  = $BA01->appendChild($dom->createElement( $v,       sprintf("%014s", $this->CNPJ)));
            return $BA01;
        }
        $BA02  = $BA01->appendChild($dom->createElement( $v,       sprintf("%011s", $this->CPF)));
        return $BA01;
    }

}

// F01
class retirada {

    var $CNPJ;      // F02 - CNPJ do local da retirada
    var $CPF;       // F02a - CPF  do local da retirada Vers�o 2.0
    var $xLgr;      // F03 - logradouro do local da retirada
    var $nro;       // F04 - n�mero do local da retirada
    var $xCpl;      // F05 - complemento do local da retirada
    var $xBairro;   // F06 - bairro do local da retirada
    var $cMun;      // F07 - c�digo do munic�pio do local da retirada
    var $xMun;      // F08 - nome do munic�pio do local da retirada
    var $UF;        // F09 - sigla da UF do local da retirada

    function __construct() {
    }

    function get_xml($dom) {
        $F01  = $dom->appendChild($dom->createElement('retirada'));
        $F02 = (empty($this->CPF)) ? $F01->appendChild($dom->createElement('CNPJ', sprintf("%014s", $this->CNPJ))) : $F01->appendChild($dom->createElement('CPF', sprintf("%011s", $this->CPF)));
        $F03  = $F01->appendChild($dom->createElement('xLgr',       str_pad($this->xLgr, 3, "...")));
        $F04  = $F01->appendChild($dom->createElement('nro',        "{$this->nro}"));
        $F05  = (!empty($this->xCpl)) ? $F01->appendChild($dom->createElement('xCpl',       $this->xCpl)) : '';
        $F06  = $F01->appendChild($dom->createElement('xBairro',    $this->xBairro));
        $F07  = $F01->appendChild($dom->createElement('cMun',       $this->cMun));
        $F08  = $F01->appendChild($dom->createElement('xMun',       $this->xMun));
        $F09  = $F01->appendChild($dom->createElement('UF',         $this->UF));
        return $F01;
    }

}

// G01
class entrega {

    var $CNPJ;      // G02 - CNPJ  do local da entrega
    var $CPF;		// G02a - CPF  do local da entrega vers�o 2.0
    var $xLgr;      // G03 - logradouro do local da entrega
    var $nro;       // G04 - n�mero do local da entrega
    var $xCpl;      // G05 - complemento do local da entrega
    var $xBairro;   // G06 - bairro do local da entrega
    var $cMun;      // G07 - c�digo do munic�pio do local da entrega
    var $xMun;      // G08 - nome do munic�pio do local da entrega
    var $UF;        // G09 - sigla da UF do local da entrega

    function __construct() {
    }

    function get_xml($dom) {
        $G01  = $dom->appendChild($dom->createElement('entrega'));
        $G02 = (empty($this->CPF)) ? $G01->appendChild($dom->createElement('CNPJ', sprintf("%014s", $this->CNPJ))) : $G01->appendChild($dom->createElement('CPF', sprintf("%011s", $this->CPF)));
        $G03  = $G01->appendChild($dom->createElement('xLgr',       str_pad($this->xLgr, 3, "...")));
        $G04  = $G01->appendChild($dom->createElement('nro',        "{$this->nro}"));
        $G05  = (!empty($this->xCpl)) ? $G01->appendChild($dom->createElement('xCpl',       $this->xCpl)) : '';
        $G06  = $G01->appendChild($dom->createElement('xBairro',    $this->xBairro));
        $G07  = $G01->appendChild($dom->createElement('cMun',       $this->cMun));
        $G08  = $G01->appendChild($dom->createElement('xMun',       $this->xMun));
        $G09  = $G01->appendChild($dom->createElement('UF',         $this->UF));
        return $G01;
    }

}

class vitem {

    var $vitem;      // VB01 - Valor total do item da NF-e

    function __construct() {
    }

    function get_xml($dom) {
        $VB01 = $dom->createElement('vItem', number_format((float)$this->vItem, 2, ".", ""));
        return $VB01;
    }
}

// H01
class det {

    var $nItem;     // H02 - n�mero do item
    var $prod;      // I01 - grupo do detalhamento de prod e serv da NFe
    var $imposto;   // M01 - grupo de tributos incidentes no produto ou servi�o
    var $infAdProd; // V01 - informa��es adicionais do produto
    var $vItem;     // VB01 - Valor total do item da NF-e

    function __construct() {
        $this->prod         = new prod;
        $this->imposto      = new imposto;
        $this->infAdProd    = null;
        $this->vItem        = null;
    }

    function add_infAdProd($obj_infAdProd) {
        if (!$this->infAdProd) {
            $this->infAdProd = $obj_infAdProd;
            return true;
        } else {
            return false;
        }
    }

    function add_vItem($obj_vItem)
    {
        if (!$this->vItem){
            $this->vItem = $obj_vItem;
            return true;
        }else{
            return false;
        }
    }

    function get_xml($dom) {
    	if (empty($this->nItem)) {
    		return null;
    	}
        $H01 = $dom->appendChild($dom->createElement('det'));
        $H02 = $H01->appendChild($dom->createAttribute('nItem'));
               $H02->appendChild($dom->createTextNode($this->nItem));
        $I01 = $H01->appendChild($this->prod->get_xml($dom));
        $M01 = $H01->appendChild($this->imposto->get_xml($dom));
        $V01 = (is_object($this->infAdProd)) ? $H01->appendChild($this->infAdProd->get_xml($dom)) : null;
        $VB01 = (!empty($this->vItem)) ? $H01->appendChild($dom->createElement('vItem', $this->vItem)) : null;
        return $H01;
    }

}

// W01
class total {

    var $ICMSTot;   // W02 - grupo de valores totais referentes ao ICMS
    var $ISSQNtot;  // W17 - grupo de valores totais referentes ao ISSQN
    var $retTrib;   // W23 - grupo de reten��es de tributos
    var $ISTot;     // W31 - grupo de valores totais do IS
    var $IBSCBSTot; // W31 - grupo de valores totais do IS
    var $vNFTot;    // W60 - Valor total da NF-e com IBS / CBS / IS

    function __construct() {
        $this->ICMSTot      = new ICMSTot;
        $this->ISSQNtot     = null;
        $this->retTrib      = null;
        $this->ISTot        = null;
        $this->IBSCBSTot    = null;
        $this->vNFTot       = null;
    }

    function add_ISSQNtot($obj_ISSQNtot) {
        if (!$this->ISSQNtot) {
            $this->ISSQNtot = $obj_ISSQNtot;
            return true;
        } else {
            return false;
        }
    }

    function add_retTrib($obj_retTrib) {
        if (!$this->retTrib) {
            $this->retTrib = $obj_retTrib;
            return true;
        } else {
            return false;
        }
    }

    function add_ISTot ($obj_ISTot) {
        if (!$this->ISTot) {
            $this->ISTot  = $obj_ISTot;
            return true;
        } else {
            return false;
        }
    }

    function add_IBSCBSTot($obj_IBSCBSTot) {
        if (!$this->IBSCBSTot) {
            $this->IBSCBSTot = $obj_IBSCBSTot;
            return true;
        } else {
            return false;
        }
    }

    function add_vNFTot($obj_vNFTot) {
        if (!$this->vNFTot) {
            $this->vNFTot = $obj_vNFTot;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $W01 = $dom->appendChild($dom->createElement('total'));
        $W02 = $W01->appendChild($this->ICMSTot->get_xml($dom));
        $W17 = (is_object($this->ISSQNtot)) ? $W01->appendChild($this->ISSQNtot->get_xml($dom)) : null;
        $W23 = (is_object($this->retTrib)) ? $W01->appendChild($this->retTrib->get_xml($dom)) : null;
        $W32 = (is_object($this->ISTot)) ? $W01->appendChild($this->ISTot->get_xml($dom)) : null;
        $W34 = (is_object($this->IBSCBSTot)) ? $W01->appendChild($this->IBSCBSTot->get_xml($dom)) : null;
        $W60 = (!empty($this->vNFTot)) ? $W01->appendChild($dom->createElement('vNFTot',$this->vNFTot)) : null;
        return $W01;
    }

}

// X01
class transp {

    var $modFrete;      // X02 - modalidade do frete
    var $transporta;    // X03 - grupo transportador
    var $retTransp;     // X11 - grupo de reten��o do ICMS do transporte
    var $veicTransp;    // X18 - grupo ve�culo
    var $reboque;       // X22 - grupo reboque
    var $vol;           // X26 - grupo volumes

    function __construct() {
        $this->transporta   = null;
        $this->retTransp    = null;
        $this->veicTransp   = null;
        $this->reboque      = array();
        $this->vol          = null;//array();
    }

    function add_transporta($obj_transporta) {
        if (!$this->transporta) {
            $this->transporta = $obj_transporta;
            return true;
        } else {
            return false;
        }
    }

    function add_retTransp($obj_retTransp) {
        if (!$this->retTransp) {
            $this->retTransp = $obj_retTransp;
            return true;
        } else {
            return false;
        }
    }

    function add_veicTransp($obj_veicTransp) {
        if (!$this->veicTransp) {
            $this->veicTransp = $obj_veicTransp;
            return true;
        } else {
            return false;
        }
    }

    function add_reboque($obj_reboque) {
        if (count((array)$this->reboque) < 2) {
            $this->reboque[] = $obj_reboque;
            return true;
        } else {
            return false;
        }
    }

    function add_vol($obj_vol) {
        //$this->vol[] = $obj_vol;
        //return true;
        if (!$this->vol) {
            $this->vol = $obj_vol;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $X01 = $dom->appendChild($dom->createElement('transp'));
        //Na vers�o 1.10 dever ser 0 ou 1 se vier 9 colocamos 0.
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota)==1.10) {
        	if((int) $this->modFrete!==0&&(int) $this->modFrete!==1) {
        		$this->modFrete = 0;
        	}
        }
        $X02 = $X01->appendChild($dom->createElement('modFrete', $this->modFrete));
        /**
         * NT2021004-1
         * BIT
         * Jan.2022
         * Se for frete=9 n�o enviamos os dados de transporte
         */
        if($this->modFrete!=9) {
            $X03 = (is_object($this->transporta)) ? $X01->appendChild($this->transporta->get_xml($dom)) : null;
            $X11 = (is_object($this->retTransp)) ? $X01->appendChild($this->retTransp->get_xml($dom)) : null;
            $X18 = (is_object($this->veicTransp)) ? $X01->appendChild($this->veicTransp->get_xml($dom)) : null;
            foreach($this->reboque as $_reboque) {
                //$_reboque = $this->reboque[$i];
                $X22 = $X01->appendChild($_reboque->get_xml($dom));
            }
            /*for ($i=0; $i<count((array)$this->vol); $i++) {
                $X26 = $X01->appendChild($this->vol[$i]->get_xml($dom));
            }*/
            //Por enquanto iremos mandar 1 �nica vez.
            if(isset($this->vol)) {
                $X26 = $X01->appendChild($this->vol->get_xml($dom));
            }
        }
        return $X01;
    }

}

// Y01
class cobr {

    var $fat;       // Y02 - grupo de fatura
    var $dup;       // Y07 - grupo de duplicata

    function __construct() {
        $this->fat = array();
        $this->dup = array();
    }

    function add_fat($obj_fat) {
        $this->fat = $obj_fat;
        return true;
    }

    function add_dup($obj_dup) {
        $this->dup[] = $obj_dup;
        return true;
    }

    function get_xml($dom) {
        $Y01 = $dom->appendChild($dom->createElement('cobr'));
        $Y02 = (is_object($this->fat)) ? $Y01->appendChild($this->fat->get_xml($dom)) : null;
        for ($i=0; $i<count((array)$this->dup); $i++) {
            $Y07 = $Y01->appendChild($this->dup[$i]->get_xml($dom));
        }
        return $Y01;
    }

}

class agropecuario {
    var $defensivo;     // ZF02 - Defensivos Agr�colas

    function __construct() {
        $this->defensivo = array();
    }

    function add_defensivo($obj_defensivo) {
        if (count((array)$this->defensivo) < 20) {
            $this->defensivo[] = $obj_defensivo;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $ZF01 = $dom->appendChild($dom->createElement('agropecuario'));
        foreach ($this->defensivo as $defensivo) {
            if (is_object($defensivo)) {
                $ZF01->appendChild($defensivo->get_xml($dom));
            }
        }
        return $ZF01;
    }
}

class defensivo {
    var $nReceituario;  // ZF03 - N�mero da receita ou receitu�rio do agrot�xico / defensivo agr�cola.
    var $CPFRespTec;    // ZF03a - CPF do Respons�vel T�cnico pela emiss�o do receitu�rio.

    function __construct() {
        $this->nReceituario = null;
        $this->CPFRespTec = null;
    }

    function get_xml($dom) {
        $ZF02 = $dom->appendChild($dom->createElement('defensivo'));
        $ZF03 = $ZF02->appendChild($dom->createElement('nReceituario',  $this->nReceituario));
        $ZF03a= $ZF02->appendChild($dom->createElement('CPFRespTec',   $this->CPFRespTec));
        return $ZF02;
    }
}

// Z01
class infAdic {

    var $infAdFisco;    // Z02 - informa��es adicionais de interesse do fisco
    var $infCpl;        // Z03 - informa��es de interesse do contribuinte
    var $obsCont;       // Z04 - grupo de campo de uso livre do contribuinte
    var $obsFisco;      // Z07 - grupo de campo de uso livre do fisco
    var $procRef;       // Z10 - grupo do processo

    function __construct() {
        $this->obsCont  = array();
        $this->obsFisco = array();
        $this->procRef  = array();
    }

    function add_obsCont($obj_obsCont) {
        if (count((array)$this->obsCont) < 10) {
            $this->obsCont[] = $obj_obsCont;
            return true;
        } else {
            return false;
        }
    }

    function add_obsFisco($obj_obsFisco) {
        if (count((array)$this->obsFisco) < 10) {
            $this->obsFisco[] = $obj_obsFisco;
            return true;
        } else {
            return false;
        }
    }

    function add_procRef($obj_procRef) {
        $this->procRef[] = $obj_procRef;
        return true;
    }

    function get_xml($dom) {
        $Z01 = $dom->appendChild($dom->createElement('infAdic'));
        $Z02 = (!empty($this->infAdFisco))  ? $Z01->appendChild($dom->createElement('infAdFisco',  $this->infAdFisco)) : null;
        $Z03 = (!empty($this->infCpl))      ? $Z01->appendChild($dom->createElement('infCpl',      $this->infCpl))     : null;
        for ($i=0; $i<count((array)$this->obsCont) && $i < 10; $i++) {
            $Z04 = $Z01->appendChild($this->obsCont[$i]->get_xml($dom));
        }
        for ($i=0; $i<count((array)$this->obsFisco); $i++) {
            $Z07 = $Z01->appendChild($this->obsFisco[$i]->get_xml($dom));
        }
        for ($i=0; $i<count((array)$this->procRef); $i++) {
            $Z10 = $Z01->appendChild($this->procRef[$i]->get_xml($dom));
        }
        return $Z01;
    }

}

// ZA01
class exporta {

    var $UFSaidaPais;   // ZA02 - Sigla da UF de Embarque ou de transposi��o de fronteira.
    var $xLocExporta;   // ZA03 - Descri��o do Local de Embarque ou de transposi��o de fronteira.
    var $xLocDespacho;  // ZA04 - Descri��o do local de despacho.

    function __construct() {
    }

    function get_xml($dom) {
        $ZA01 = $dom->appendChild($dom->createElement('exporta'));
        $ZA02 = (!empty($this->UFSaidaPais)) ? $ZA01->appendChild($dom->createElement('UFSaidaPais',  $this->UFSaidaPais)) : null;
        $ZA03 = (!empty($this->xLocExporta)) ? $ZA01->appendChild($dom->createElement('xLocExporta',  $this->xLocExporta)) : null;
        $ZA04 = (!empty($this->xLocDespacho)) ? $ZA01->appendChild($dom->createElement('xLocDespacho',  $this->xLocDespacho)) : null;
        return $ZA01;
    }

}

// ZB01
class compra {

    var $xNEmp; // ZB02 - nota de empenho
    var $xPed;  // ZB03 - pedido
    var $xCont; // ZB04 - contrato

    function __construct() {
    }

    function get_xml($dom) {
        $ZB01 = $dom->appendChild($dom->createElement('compra'));
        $ZB02 = (!empty($this->xNEmp))  ? $ZB01->appendChild($dom->createElement('xNEmp',  $this->xNEmp)) : null;
        $ZB02 = (!empty($this->xPed))   ? $ZB01->appendChild($dom->createElement('xPed',   $this->xPed))  : null;
        $ZB02 = (!empty($this->xCont))  ? $ZB01->appendChild($dom->createElement('xCont',  $this->xCont)) : null;
        return $ZB01;
    }

}

// ZC01
class Signature {
}



/* NIVEL 3 ********************************************************************/

// B12a
/**
 * *** Roberto
 * Estes campos sao para indicar as notas fiscais referenciadas na notas principal
 * por exemplo quando fazemos um beneficiamento industrial para alguem na fatura temos que devolver
 * os materiais enviados para o beneficimento que entraram com NF (eh claro)
 * Esta referencias podem ser a NFe, onde so e necessario indicar o Id da NFe 44 digitos
 * ou NF modelo 1, e neste caso temos que fornecer as outras informaçoes
 */
class NFref {

    var $refNFe;    // B13 - chave de acesso das NFe referenciadas
    var $refNF;     // B14 - informa��es das NF referenciadas

    function __construct($tipo = 'NFe') {
        if ($tipo == 'NF') {
            $this->refNF   = new refNF;
        }
    	if ($tipo == 'CUPOM') {
            $this->refNF   = new refECF();
        }

    }

    function get_xml($dom) {
        $B12a= $dom->appendChild($dom->createElement('NFref'));
        if (!empty($this->refNFe)) {
            $B13 = $B12a->appendChild($dom->createElement('refNFe', $this->refNFe));
        } else if (is_object($this->refNF)) {
            $B14 = $B12a->appendChild($this->refNF->get_xml($dom));
        }
        return $B12a;
    }

}

// C05
class enderEmit {

    var $xLgr;      // C06 - logradouro do emitente
    var $nro;       // C07 - n�mero do emitente
    var $xCpl;      // C08 - complemento do emitente
    var $xBairro;   // C09 - bairro do emitente
    var $cMun;      // C10 - c�digo do munic�pio do emitente
    var $xMun;      // C11 - nome do munic�pio do emitente
    var $UF;        // C12 - sigla da UF do emitente
    var $CEP;       // C13 - c�digo do CEP do emitente
    var $cPais;     // C14 - c�digo do Pa�s (1058 - Brasil) do emitente
    var $xPais;     // C15 - nome do Pa�s (Brasil ou BRASIL) do emitente
    var $fone;      // C16 - telefone do emitente

    function __construct() {
        $this->cPais    = 1058;
        $this->xPais    = "BRASIL";
    }

    function get_xml($dom) {
        $C05 = $dom->appendChild($dom->createElement('enderEmit'));
        $C06 = $C05->appendChild($dom->createElement('xLgr',    str_pad($this->xLgr, 3, "...")));
        $C07 = $C05->appendChild($dom->createElement('nro',     "{$this->nro}"));
        $C08 = (!empty($this->xCpl)) ? $C05->appendChild($dom->createElement('xCpl',    $this->xCpl)) : null;
        $C09 = $C05->appendChild($dom->createElement('xBairro', $this->xBairro));
        $C10 = $C05->appendChild($dom->createElement('cMun',    $this->cMun));
        $C11 = $C05->appendChild($dom->createElement('xMun',    $this->xMun));
        $C12 = $C05->appendChild($dom->createElement('UF',      $this->UF));
        $this->CEP = funcoesGerais::retornarNumeros($this->CEP);
        $C13 = (!empty($this->CEP))   ? $C05->appendChild($dom->createElement('CEP',     sprintf("%08s", $this->CEP)))   : null;
        if(!empty($this->cPais) && $this->cPais > 0) {
            $this->cPais = str_pad($this->cPais,4, "0", STR_PAD_LEFT);
        }
        if(!empty($this->xPais) && $this->xPais > 0) {
            $this->xPais = str_pad($this->xPais, 4, "0", STR_PAD_LEFT);
        }
        $C14 = (!empty($this->cPais)) ? $C05->appendChild($dom->createElement('cPais',   $this->cPais)) : null;
        $C15 = (!empty($this->xPais)) ? $C05->appendChild($dom->createElement('xPais',   $this->xPais)) : null;
        $C16 = (!empty($this->fone))  ? $C05->appendChild($dom->createElement('fone',    funcoesGerais::retornarNumeros($this->fone)))  : null;
        return $C05;
    }

}

// E05
class enderDest {

    var $xLgr;      // E06 - logradouro do destinatario
    var $nro;       // E07 - n�mero do destinatario
    var $xCpl;      // E08 - complemento do destinatario
    var $xBairro;   // E09 - bairro do destinatario
    var $cMun;      // E10 - c�digo do munic�pio do destinatario
    var $xMun;      // E11 - nome do munic�pio do destinatario
    var $UF;        // E12 - sigla da UF do destinatario
    var $CEP;       // E13 - c�digo do CEP do destinatario
    var $cPais;     // E14 - c�digo do Pa�s (1058 - Brasil) do destinatario
    var $xPais;     // E15 - nome do Pa�s (Brasil ou BRASIL) do destinatario
    var $fone;      // E16 - telefone do destinatario


    function __construct() {

    }

    function get_xml($dom) {
        /**
         * Se n�o tiver essas 3 informa��es fica subentendido que � uma nota sem
         * cliente identificado, ou seja, N�O TEM ENDERE�O, N�O DEVE MONTAR.
         */
        if (empty($this->xLgr) && empty($this->xBairro) && empty($this->xMun)) {
            return false;
        }

        $this->cPais = (string) $this->cPais;
        $this->xPais = (string) $this->xPais;
        if($this->UF != 'EX') {
            $this->cPais    = 1058;
            $this->xPais    = "";
        }

        // BL-8776 - Empty estava ignorando numero 0, n�o montando a tag causando rejei��o xsd
        $this->nro = trim($this->nro);
        $this->fone = (string) $this->fone;

        // Valida valor Conforme XSD
        $this->xLgr = funcoesGerais::validarCampoNotaEletronica($this->xLgr, true, 2, 60, null, 'NAO INFORMADO'); // Obrigat�rio (Tenta corrigir)
        $this->nro = funcoesGerais::validarCampoNotaEletronica($this->nro, true, 1, 60, null, 'SN'); // Obrigat�rio (Tenta corrigir)
        $this->xCpl = funcoesGerais::validarCampoNotaEletronica($this->xCpl, false, 1, 60);  // Opcional (N�o monta)
        $this->xBairro = funcoesGerais::validarCampoNotaEletronica($this->xBairro, true, 2, 60, null, 'NAO INFORMADO'); // Obrigat�rio (Tenta corrigir)
        $this->cMun = funcoesGerais::validarCampoNotaEletronica($this->cMun, true, null, null, '/^[0-9]{7}$/');  // Obrigat�rio
        $this->xMun = funcoesGerais::validarCampoNotaEletronica($this->xMun, true, 2, 60, null, 'NAO INFORMADO'); // Obrigat�rio (Tenta corrigir)

        // Obrigat�rio
        $this->UF = strtoupper($this->UF);
        $this->UF = funcoesGerais::validarCampoNotaEletronica($this->UF, true, null, null, '/^(AC|AL|AM|AP|BA|CE|DF|ES|GO|MA|MG|MS|MT|PA|PB|PE|PI|PR|RJ|RN|RO|RR|RS|SC|SE|SP|TO|EX)$/');

        // Obrigat�rio
        $this->CEP = funcoesGerais::retornarNumeros($this->CEP);
        $this->CEP = sprintf("%08s", $this->CEP);
        $this->CEP = funcoesGerais::validarCampoNotaEletronica($this->CEP, true, null, null, '/^[0-9]{8}$/');

        // Opcional (N�o monta)
        $this->cPais = funcoesGerais::validarCampoNotaEletronica($this->cPais, false, null, null, '/^[0-9]{1,4}$/');
        $this->xPais = funcoesGerais::validarCampoNotaEletronica($this->xPais, false, 2, 60);

        // Opcional (N�o monta)
        $this->fone = funcoesGerais::retornarNumeros((string)$this->fone);
        $this->fone = funcoesGerais::validarCampoNotaEletronica($this->fone, false, null, null, '/^[0-9]{6,14}$/');

        $E05 = $dom->appendChild($dom->createElement('enderDest'));
        $E06 = $E05->appendChild($dom->createElement('xLgr', $this->xLgr));
        $E07 = $E05->appendChild($dom->createElement('nro', $this->nro));
        $E08 = (!is_null($this->xCpl)) ? $E05->appendChild($dom->createElement('xCpl', $this->xCpl)) : null; // Opcional
        $E09 = $E05->appendChild($dom->createElement('xBairro', $this->xBairro));
        $E10 = $E05->appendChild($dom->createElement('cMun', $this->cMun));
        $E11 = $E05->appendChild($dom->createElement('xMun', $this->xMun));
        $E12 = $E05->appendChild($dom->createElement('UF', $this->UF));
        $E13 = (!is_null($this->CEP)) ? $E05->appendChild($dom->createElement('CEP', $this->CEP)) : null; // Opcional
        $E14 = (!is_null($this->cPais)) ? $E05->appendChild($dom->createElement('cPais', $this->cPais)) : null; // Opcional
        $E15 = (!is_null($this->xPais)) ? $E05->appendChild($dom->createElement('xPais', $this->xPais)) : null; // Opcional
        $E16 = (!is_null($this->fone)) ? $E05->appendChild($dom->createElement('fone', $this->fone)) : null; // Opcional

        return $E05;
    }

}

// I01
class prod {

    var $cProd;     // I02 - c�digo do produto ou servi�o
    var $cEAN;      // I03 - GTIN (Global Trade Item Number)do produto
    var $xProd;     // I04 - descri��o do produto ou servi�o
    var $NCM;       // I05 - c�digo NCM
    var $CEST;		// I05c- c�digo CEST (C�d. Especificador da Substitui��o Tribut�ria)
    var $EXTIPI;    // I06 - EX_TIPI
    var $genero;    // I07 - g�nero do produto ou servi�o
    var $CFOP;      // I08 - c�digo fiscal de opera��es e presta��es
    var $uCom;      // I09 - unidade comercial
    var $qCom;      // I10 - quantidade comercial
    var $vUnCom;    // I10a- valor unit�rio de comercializa��o
    var $vProd;     // I11 - valor total bruto dos produtos ou servi�os
    var $cEANTrib;  // I12 - GTIN da unidade tribut�vel
    var $uTrib;     // I13 - unidade tribut�vel
    var $qTrib;     // I14 - quantidade tribut�vel
    var $vUnTrib;   // I14a- valor unit�rio de tributa��o
    var $vFrete;    // I15 - valor total do frete
    var $vSeg;      // I16 - valor total do seguro
    var $vDesc;     // I17 - valor do desconto
    var $vOutro;    // I17a - valor Outros
    var $indTot;    // I17b - Indica se o valor do item (vProd) comp�e o valor todal da NFE 1- Comp�e 0- N�o comp�e.
    var $DI;        // I18 - declara��o de importa��o
    var $veicProd;  // J01 - grupo do detalhamento de ve�culos novos
    var $med;       // K01 - grupo do detalhamento de medicamentos
    var $arma;      // L01 - grupo do detalhamento do armamento
    var $comb;      // L101- grupo de informa��es para combust�veis l�quidos
    var $indEscala;		// I05c- c�digo CEST (C�d. Especificador da Substitui��o Tribut�ria)
    var $rastro;    //I80 - rastreabilidade do produto
    var $cBenef;    //I05f - C�digo benef�cio do produto


    function __construct() {
        $this->DI       = array();
        $this->veicProd = null;
        $this->med      = array();
        $this->arma     = array();
        $this->comb     = null;
        $this->rastro   = null;
    }

    function add_DI($obj_DI) {
        $this->DI[] = $obj_DI;
        return true;
    }

    function add_veicProd($obj_veicProd) {
        if (!$this->veicProd) {
            $this->veicProd = $obj_veicProd;
            return true;
        } else {
            return false;
        }
    }

    function add_med($obj_med) {
        if (!$this->med) {
            $this->med = $obj_med;
            return true;
        } else {
            return false;
        }
    }

    function add_arma($obj_arma) {
        $this->arma[] = $obj_arma;
        return true;
    }

    function add_rastro($obj_rastro) {
        if (!$this->rastro) {
            $this->rastro = $obj_rastro;
            return true;
        } else {
            return false;
        }
    }

    function add_comb($obj_comb) {
        if (!$this->comb) {
            $this->comb = $obj_comb;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $I01  = $dom->appendChild($dom->createElement('prod'));
        $I02  = $I01->appendChild($dom->createElement('cProd',       $this->cProd));
        $I03  = $I01->appendChild($dom->createElement('cEAN',        $this->cEAN));
        $I04  = $I01->appendChild($dom->createElement('xProd',       $this->xProd));
        //Pra NF-e existe a nota de servi�o pro DF ent�o o NCM deve ser 00.
        if ((int) $this->mod === 55 || (int) NFe::$_tipo_nota === 55) {
            $I05 = (!empty($this->NCM)) ? $I01->appendChild($dom->createElement('NCM', $this->NCM)) : null;
        } else {
            //Colocando tratamento como inteiro, pois do PDV pode vir como 000000, o m�dulo n�o pode gerar um xml diferente do Manager, sen�o rejeita no cancelamento por substitui��o
            $I05  = (!empty($this->NCM) && (int) $this->NCM > 0 || $GLOBALS['_NFRECFIN']==1) ? $I01->appendChild($dom->createElement('NCM',     $this->NCM))     : null;
        }
        //Colocando tratamento como inteiro, pois do PDV pode vir como 0000000, o m�dulo n�o pode gerar um xml diferente do Manager, sen�o rejeita no cancelamento por substitui��o
        $I05c = (!empty($this->CEST) && (int) $this->CEST > 0)    ? $I01->appendChild($dom->createElement('CEST',    (string) funcoesGerais::str_alinha($this->CEST, 7, DIREITA, true, '0')))    : null;
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            //Colocando tratamento como inteiro, pois do PDV pode vir como 0000000, o m�dulo n�o pode gerar um xml diferente do Manager, sen�o rejeita no cancelamento por substitui��o
            $I05f = (!empty($this->indEscala) && !empty($this->CEST) && (int) $this->CEST > 0) ? $I01->appendChild($dom->createElement('indEscala',    $this->indEscala))    : null;
        }
        $I05f2 = (!empty($this->cBenef))    ? $I01->appendChild($dom->createElement('cBenef',    $this->cBenef))    : null;
        $I06  = (!empty($this->EXTIPI))  ? $I01->appendChild($dom->createElement('EXTIPI',  $this->EXTIPI))  : null;
        $I07  = (!empty($this->genero))  ? $I01->appendChild($dom->createElement('genero',  $this->genero))  : null;
        $I08  = $I01->appendChild($dom->createElement('CFOP',        $this->CFOP));
        $I09  = $I01->appendChild($dom->createElement('uCom',        "{$this->uCom}"));
        //VERS�O 2.0 qCom passou a ser obrigat�rio
        $I10  = $I01->appendChild($dom->createElement('qCom',        number_format((float)$this->qCom, 4, ".", "")));
        $I10a = $I01->appendChild($dom->createElement('vUnCom',      number_format((float)$this->vUnCom, 4, ".", "")));
        $I11  = $I01->appendChild($dom->createElement('vProd',       number_format((float)$this->vProd, 2, ".", "")));
        $I12  = $I01->appendChild($dom->createElement('cEANTrib',    $this->cEANTrib));
        $I13  = $I01->appendChild($dom->createElement('uTrib',       "{$this->uTrib}"));
        $I14  = $I01->appendChild($dom->createElement('qTrib',       number_format((float)$this->qTrib, 4, ".", "")));
        $I14a = $I01->appendChild($dom->createElement('vUnTrib',     number_format((float)$this->vUnTrib, 10, ".", "")));
        $I15  = (floatval(number_format((float)$this->vFrete, 2, ".", "")) > 0.00)  ? $I01->appendChild($dom->createElement('vFrete',  number_format((float)$this->vFrete, 2, ".", "")))  : null;
        $I16  = (floatval(number_format((float)$this->vSeg, 2, ".", "")) > 0.00)    ? $I01->appendChild($dom->createElement('vSeg',    number_format((float)$this->vSeg, 2, ".", "")))    : null;
        $I17  = (floatval( number_format((float)$this->vDesc, 2, ".", "")) > 0.00)   ? $I01->appendChild($dom->createElement('vDesc',  number_format((float)$this->vDesc, 2, ".", "")))   : null;
        $I17a = (floatval(number_format((float)$this->vOutro, 2, ".", "")) > 0.00) ? $I01->appendChild($dom->createElement('vOutro',   number_format((float)$this->vOutro, 2, ".", "")))  : null;
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota)>1.10) {
        	$I17b = $I01->appendChild($dom->createElement('indTot',   $this->indTot));
        }

        for ($i=0; $i<count((array)$this->DI); $i++) {
            $I18 = $I01->appendChild($this->DI[$i]->get_xml($dom));
        }
        for ($i=0; $i<count((array)$this->arma); $i++) {
            $L01 = $I01->appendChild($this->arma[$i]->get_xml($dom));
        }
        //A ordem das letras deve ser respeitada, pois o XSD rejeita
        if(funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $I80 = (is_object($this->rastro)) ? $I01->appendChild($this->rastro->get_xml($dom)) : null;
        }

        $J01 = (is_object($this->veicProd)) ? $I01->appendChild($this->veicProd->get_xml($dom)) : null;

        $K01 = (is_object($this->med)) ? $I01->appendChild($this->med->get_xml($dom)) : null;

        $L101= (is_object($this->comb)) ? $I01->appendChild($this->comb->get_xml($dom)) : null;
        return $I01;
    }

}

// M01
class imposto {

	var $vTotTrib;  // M02 - Valor estimado total de impostos federais, estaduais e municipais
    var $ICMS;      // N01 - grupo de ICMS da opera��o pr�pria e ST
    var $ICMSUFDest;// NA01 - grupo de ICMSUFDest da opera��o de icms de partilha
    var $IPI;       // O01 - grupo de IPI
    var $II;        // P01 - grupo de imposto de importa��o
    var $PIS;       // Q01 - grupo do PIS
    var $PISST;     // R01 - grupo de PIS substitui��o tribut�ria
    var $COFINS;    // S01 - grupo de COFINS
    var $COFINSST;  // T01 - grupo de COFINS substitui��o tribut�ria
    var $ISSQN;     // U01 - grupo do ISSQN
    var $IS;        // UB01 - grupo do IS
    var $IBSCBS;    // UB12 - grupo do IBS/CBS

    function __construct() {
    	$this->vTotTrib = null;
        //$this->ICMS     = new ICMS;
        $this->ICMS     = null;
        $this->ICMSUFDest     = null;
        $this->IPI      = null;
        $this->II       = null;
        //$this->PIS      = new PIS;
        $this->PIS      = null;
        $this->PISST    = null;
        //$this->COFINS   = new COFINS;
        $this->COFINS   = null;
        $this->COFINSST = null;
        $this->ISSQN    = null;
        $this->IS       = null;
        $this->IBSCBS   = null;
    }

    function add_COFINS($obj_COFINS) {
        if (!$this->COFINS) {
            $this->COFINS = $obj_COFINS;
            return true;
        } else {
            return false;
        }
    }

    function add_PIS($obj_PIS) {
        if (!$this->PIS) {
            $this->PIS = $obj_PIS;
            return true;
        } else {
            return false;
        }
    }

    function add_ICMS($obj_ICMS) {
        if (!$this->ICMS) {
            $this->ICMS = $obj_ICMS;
            return true;
        } else {
            return false;
        }
    }

    function add_ICMSUFDest($obj_ICMSUFDest) {
        if (!$this->ICMSUFDest) {
            $this->ICMSUFDest = $obj_ICMSUFDest;
            return true;
        } else {
            return false;
        }
    }

    function add_IPI($obj_IPI) {
        if (!$this->IPI) {
            $this->IPI = $obj_IPI;
            return true;
        } else {
            return false;
        }
    }

    function add_II($obj_II) {
        if (!$this->II) {
            $this->II = $obj_II;
            return true;
        } else {
            return false;
        }
    }

    function add_PISST($obj_PISST) {
        if (!$this->PISST) {
            $this->PISST = $obj_PISST;
            return true;
        } else {
            return false;
        }
    }

    function add_COFINSST($obj_COFINSST) {
        if (!$this->COFINSST) {
            $this->COFINSST = $obj_COFINSST;
            return true;
        } else {
            return false;
        }
    }

    function add_IS($obj_IS) {
        if (!$this->IS) {
            $this->IS = $obj_IS;
            return true;
        } else {
            return false;
        }
    }

    function add_IBSCBS($obj_IBSCBS) {
        if (!$this->IBSCBS) {
            $this->IBSCBS = $obj_IBSCBS;
            return true;
        } else {
            return false;
        }
    }

    function add_ISSQN($obj_ISSQN) {
        if (!$this->ISSQN) {
            $this->ISSQN = $obj_ISSQN;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $M01 = $dom->appendChild($dom->createElement('imposto'));
        //Adicionamos o novo campo de Total de tributa��o.
        $M02 = (!empty($this->vTotTrib) && $this->vTotTrib > 0) ? $M01->appendChild($dom->createElement('vTotTrib',   number_format((float)$this->vTotTrib, 2, ".", ""))) : null;
      	$N01 = (is_object($this->ICMS)) ?$M01->appendChild($this->ICMS->get_xml($dom)) : null;
        $U01 = (is_object($this->ISSQN)) ? $M01->appendChild($this->ISSQN->get_xml($dom)) : null;
        $O01 = (is_object($this->IPI)) ? $M01->appendChild($this->IPI->get_xml($dom)) : null;
        $P01 = (is_object($this->II)) ? $M01->appendChild($this->II->get_xml($dom)) : null;
        $Q01 = (is_object($this->PIS)) ?$M01->appendChild($this->PIS->get_xml($dom)) : null;
        $R01 = (is_object($this->PISST)) ? $M01->appendChild($this->PISST->get_xml($dom)) : null;
        $S01 = (is_object($this->COFINS)) ? $M01->appendChild($this->COFINS->get_xml($dom)) : null;
        $T01 = (is_object($this->COFINSST)) ? $M01->appendChild($this->COFINSST->get_xml($dom)) : null;
        $NA01 = (!empty($this->ICMSUFDest) && is_object($this->ICMSUFDest)) ?$M01->appendChild($this->ICMSUFDest->get_xml($dom)) : null;
        $UB01 = (!empty($this->IS)) ? $M01->appendChild($this->IS->get_xml($dom)) : null;
        $UB12 = (!empty($this->IBSCBS)) ? $M01->appendChild($this->IBSCBS->get_xml($dom)) : null;
        return $M01;
    }

}


// M01
class rastro {

    var $nLote;      // I81 - Valor estimado total de impostos federais, estaduais e municipais
    var $qLote;      // I82 - grupo de ICMS da opera��o pr�pria e ST
    var $dFab;       // I - grupo de ICMSUFDest da opera��o de icms de partilha
    var $dVal;       // O01 - grupo de IPI
    var $cAgreg;     // P01 - grupo de imposto de importa��o

    function __construct() {
        $this->nLote = null;
        $this->qLote     = null;
        $this->dFab     = null;
        $this->dVal      = null;
        $this->cAgreg       = null;
    }

    function get_xml($dom) {
        $I80 = $dom->appendChild($dom->createElement('rastro'));
        //Adicionamos o novo campo de Total de tributa��o.
        $I81 = (!empty($this->nLote)) ? $I80->appendChild($dom->createElement('nLote',   $this->nLote)) : null;
        $I82 = (!empty($this->qLote)) ? $I80->appendChild($dom->createElement('qLote',   number_format((float)$this->qLote, 3, ".", ""))) : null;
        $I83 = (!empty($this->dFab)) ? $I80->appendChild($dom->createElement('dFab',   $this->dFab)) : null;
        $I84 = (!empty($this->dVal)) ? $I80->appendChild($dom->createElement('dVal',   $this->dVal)) : null;
        $I85 = (!empty($this->cAgreg)) ? $I80->appendChild($dom->createElement('cAgreg',   $this->cAgreg)) : null;

        return $I80;
    }

}

/*
 * Atualmente s� o estado do Paran� exige isso
 *
 * LA11
 */
class encerrante_nota {
    public $nBico;
    public $nTanque;
    public $nBomba;
    public $vEncIni;
    public $vEncFin;

    public function __construct() {
        $this->nBico = null;
        $this->nTanque = null;
        $this->nBomba = null;
        $this->vEncIni = null;
        $this->vEncFin = null;
    }

    public function get_xml($dom) {
        $_enc = $dom->appendChild($dom->createElement('encerrante'));
        //LA12
        $_bico = (!empty($this->nBico)) ? $_enc->appendChild($dom->createElement('nBico',   $this->nBico)) : null;
        //LA14
        //Por hora n�o vamos mandar bomba.
        $_bomba = (!empty($this->nBomba) && $this->nBomba <= 999) ? $_enc->appendChild($dom->createElement('nBomba', $this->nBomba)) : null;
        //LA13
        $_tanque = (!empty($this->nTanque)) ? $_enc->appendChild($dom->createElement('nTanque', $this->nTanque)) : null;
        //LA15
        $_ini = (!empty($this->vEncIni)) ? $_enc->appendChild($dom->createElement('vEncIni', number_format((float)$this->vEncIni, 3, ".", ""))) : null;
        //LA16
        $_fin = (!empty($this->vEncFin)) ? $_enc->appendChild($dom->createElement('vEncFin', number_format((float)$this->vEncFin, 3, ".", ""))) : null;
        return $_enc;
    }
}

class origComb {
    public $indImport;
    public $cUFOrig;
    public $pOrig;

    public function __construct() {
        $this->indImport = null;
        $this->cUFOrig = null;
        $this->pOrig = null;
    }

    public function get_xml($dom) {
        $_LA18 = $dom->appendChild($dom->createElement('origComb'));
        $_LA19 = (isset($this->indImport)) ? $_LA18->appendChild($dom->createElement('indImport', $this->indImport)) : null;
        $_LA20 = (!empty($this->cUFOrig)) ? $_LA18->appendChild($dom->createElement('cUFOrig', $this->cUFOrig)) : null;
        $_LA21 = (!empty($this->pOrig) && (floatval($this->pOrig)>0.00)) ? $_LA18->appendChild($dom->createElement('pOrig', number_format((float)$this->pOrig, 4, ".", ""))) : null;
        return $_LA18;
    }
}

// V01
class infAdProd {

    var $infAdProd;

    function __construct() {
    }

    function get_xml($dom) {
        //$V01
        return $dom->appendChild($dom->createElement('infAdProd',   $this->infAdProd));
    }

}

// W02
class ICMSTot {

    var $vBC;        // W03 - base de c�culo para ICMS
    var $vICMS;      // W04 - valor total do ICMS
    var $vICMSDeson; // W04a - valor total do ICMS Desonera��o
    var $vFCPUFDest; // W04c - Valor total do ICMS relativo Fundo de Combate � Pobreza (FCP) da UF de destino
    var $vICMSUFDest; //W04e - Valor total do ICMS Interestadual para a UF de destino
    var $vICMSUFRemet; // W04g - Valor total do ICMS Interestadual para a UF do remetente
    var $vBCST;     // W05 - base de c�lculo para ICMS ST
    var $vST;       // W06 - valor total do ICMS ST
    var $vProd;     // W07 - valor total dos produtos e servi�os
    var $vFrete;    // W08 - valor total do frete
    var $vSeg;      // W09 - valor total do seguro
    var $vDesc;     // W10 - valor total do desconto
    var $vII;       // W11 - valor total do II
    var $vIPI;      // W12 - valor total do IPI
    var $vIPIDevol;      // W12 - valor total do IPI de Devolu��o
    var $vPIS;      // W13 - valor total do PIS
    var $vCOFINS;   // W14 - valor total do COFINS
    var $vOutro;    // W15 - outras despesas acess�rias
    var $vNF;       // W16 - valor total da NFe
    var $vTotTrib;  // W16a - Valor aproximado total de tributos federais, estaduais e municipais
    var $vFCP; // W04a - Valor fundo de combate a pobreza
    var $vFCPST; // W04b - Valor fundo de combate a pobreza
    var $vFCPSTRet; // W04c - Valor fundo de combate a pobreza
    var $qBCMono; //W06b.1 - Valor total da quantidade tributada do ICMS monof�sico pr�prio
    var $qBCMonoReten; //W06c.1 - Valor total da quantidade tributada do ICMS monof�sico sujeito a reten��o
    var $qBCMonoRet; //W06d.1 - Valor total da quantidade tributada do ICMS monof�sico retido anteriormente
    var $vICMSMono; //W06c - Valor total do ICMS monof�sico pr�prio
    var $vICMSMonoReten; //W06d - Valor total do ICMS monof�sico sujeito a reten��o
    var $vICMSMonoRet; //W06e - Valor total do ICMS monof�sico retido anteriormente

    function __construct() {
    }

    function get_xml($dom) {
        $W02  = $dom->appendChild($dom->createElement('ICMSTot'));
        $W03  = $W02->appendChild($dom->createElement('vBC',     number_format((float)$this->vBC, 2, ".", "")));
        $W04  = $W02->appendChild($dom->createElement('vICMS',   number_format((float)$this->vICMS, 2, ".", "")));
        //Ainda n�o implementada a tag vICMSDeson, pois n�o trabalhamos com importa��o
        if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 3) {
	        $W04a = $W02->appendChild($dom->createElement('vICMSDeson',   number_format((float)$this->vICMSDeson, 2, ".", "")));
        }

        //Campos de valores novos para o ICMS de partilha (ALTNFENFCE-1)
        if(!empty($this->vFCPUFDest) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4 && $this->vFCPUFDest !== 0) {
        	$W04c = $W02->appendChild($dom->createElement('vFCPUFDest',   number_format((float)$this->vFCPUFDest, 2, ".", "")));
        }
        if(!empty($this->vICMSUFDest) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4 && $this->vICMSUFDest !== 0) {
        	$W04e  = $W02->appendChild($dom->createElement('vICMSUFDest',   number_format((float)$this->vICMSUFDest, 2, ".", "")));
        }
        if(!empty($this->vICMSUFRemet) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4 && $this->vICMSUFRemet !== 0 ) {
        	$W04g  = $W02->appendChild($dom->createElement('vICMSUFRemet',   number_format((float)$this->vICMSUFRemet, 2, ".", "")));
        }

        if(!empty($this->vFCP) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $W04g = $W02->appendChild($dom->createElement('vFCP', number_format((float)$this->vFCP, 2, ".", "")));
        }
        $W05  = $W02->appendChild($dom->createElement('vBCST',   number_format((float)$this->vBCST, 2, ".", "")));
        $W06  = $W02->appendChild($dom->createElement('vST',     number_format((float)$this->vST, 2, ".", "")));
        if(!empty($this->vFCPST) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $W06a = $W02->appendChild($dom->createElement('vFCPST', number_format((float)$this->vFCPST, 2, ".", "")));
        }
        if(!empty($this->vFCPSTRet) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $W06b = $W02->appendChild($dom->createElement('vFCPSTRet', number_format((float)$this->vFCPSTRet, 2, ".", "")));
        }

        /**
         * NT2023001-1 e NT2023001F2-1
         */
        //Se tiver qBCMonoReten n�o deve montar o qBCMono (causa erro no XSD)
        if(!empty($this->qBCMonoReten) && $this->qBCMonoReten > 0){
            $W06c_1 = $W02->appendChild($dom->createElement('qBCMonoReten', number_format((float)$this->qBCMonoReten, 2, ".", "")));
        }elseif(!empty($this->qBCMono) && $this->qBCMono > 0){
            $W06b_1 = $W02->appendChild($dom->createElement('qBCMono', number_format((float)$this->qBCMono, 2, ".", "")));
        }
        if(!empty($this->qBCMonoRet) && $this->qBCMonoRet > 0){
            $W06e = $W02->appendChild($dom->createElement('qBCMonoRet', number_format((float)$this->qBCMonoRet, 2, ".", "")));
        }

        //Se tiver vICMSMonoReten n�o deve montar o vICMSMono (causa erro no XSD)
        if(!empty($this->vICMSMonoReten) && $this->vICMSMonoReten > 0){
            $W06d = $W02->appendChild($dom->createElement('vICMSMonoReten', number_format((float)$this->vICMSMonoReten, 2, ".", "")));
        }elseif(!empty($this->vICMSMono) && $this->vICMSMono > 0){
            $W06c = $W02->appendChild($dom->createElement('vICMSMono', number_format((float)$this->vICMSMono, 2, ".", "")));
        }
        if(!empty($this->vICMSMonoRet) && $this->vICMSMonoRet > 0){
            $W06e = $W02->appendChild($dom->createElement('vICMSMonoRet', number_format((float)$this->vICMSMonoRet, 2, ".", "")));
        }

        $W07  = $W02->appendChild($dom->createElement('vProd',   number_format((float)$this->vProd, 2, ".", "")));
        $W08  = $W02->appendChild($dom->createElement('vFrete',  number_format((float)$this->vFrete, 2, ".", "")));
        $W09  = $W02->appendChild($dom->createElement('vSeg',    number_format((float)$this->vSeg, 2, ".", "")));
        $W10  = $W02->appendChild($dom->createElement('vDesc',   number_format((float)$this->vDesc, 2, ".", "")));
        $W11  = $W02->appendChild($dom->createElement('vII',     number_format((float)$this->vII, 2, ".", "")));
        $W12  = $W02->appendChild($dom->createElement('vIPI',    number_format((float)$this->vIPI, 2, ".", "")));
        if(!empty($this->vIPIDevol) || funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 4) {
            $W12 = $W02->appendChild($dom->createElement('vIPIDevol', number_format((float)$this->vIPIDevol, 2, ".", "")));
        }
        $W13  = $W02->appendChild($dom->createElement('vPIS',    number_format((float)$this->vPIS, 2, ".", "")));
        $W14  = $W02->appendChild($dom->createElement('vCOFINS', number_format((float)$this->vCOFINS, 2, ".", "")));
        $W15  = $W02->appendChild($dom->createElement('vOutro',  number_format((float)$this->vOutro, 2, ".", "")));
        $W16  = $W02->appendChild($dom->createElement('vNF',     number_format((float)$this->vNF, 2, ".", "")));
        $W16a = (!empty($this->vTotTrib) && $this->vTotTrib > 0) ? $W02->appendChild($dom->createElement('vTotTrib',   number_format((float)$this->vTotTrib, 2, ".", ""))) : null;
        return $W02;
    }

}

// W17
class ISSQNtot {

    var $vServ;     // W18 - valor total dos servi�os n�o tributados pelo ICMS
    var $vBC;       // W19 - base de c�lculo do ISS
    var $vISS;      // W20 - valor total do ISS
    var $vPIS;      // W21 - valor do PIS sobre servi�os
    var $vCOFINS;   // W22 - valor do COFINS sobre servi�os
    var $dCompet;		// W22a- data da presta��o do servi�o 'AAAA-MM-DD'
    var $vDeducao;		// W22b- valor total dedu��o para redu��o da base de c�lculo
    var $vOutro;		// w22c- valor total outras reten��es
    var $vDescIncond;	// w22d- valor total desconto incondicionado
    var $vISSRet;		// w22f- valor total reten��o ISS
    var $cRegTrib;		// w22g- c�dgo do regime especial de tributa��o

    function __construct() {
    }

    function get_xml($dom) {
        $W17 = $dom->appendChild($dom->createElement('ISSQNtot'));
        $W18 = (floatval($this->vServ)>0.00)   ? $W17->appendChild($dom->createElement('vServ',   number_format((float)$this->vServ, 2, ".", "")))   : null;
        $W19 = (floatval($this->vBC)>0.00)  ? $W17->appendChild($dom->createElement('vBC',     number_format((float)$this->vBC, 2, ".", "")))     : null;
        $W20 = (floatval($this->vISS)>0.00)    ? $W17->appendChild($dom->createElement('vISS',    number_format((float)$this->vISS, 2, ".", "")))    : null;
        $W21 = (floatval($this->vPIS)>0.00)    ? $W17->appendChild($dom->createElement('vPIS',    number_format((float)$this->vPIS, 2, ".", "")))    : null;
        $W22 = (floatval($this->vCOFINS)>0.00) ? $W17->appendChild($dom->createElement('vCOFINS', number_format((float)$this->vCOFINS, 2, ".", ""))) : null;
        /* Vers�o NFe 3.10 */
        $W22a = $W17->appendChild($dom->createElement('dCompet', funcoesGerais::converte_data($this->dCompet,"mssql","mssql"))); //Campo Obrigat�rio (?AAAA-MM-DD?)
        $W22b = (floatval($this->vDeducao)>0.00) ? $W17->appendChild($dom->createElement('vDeducao', number_format((float)$this->vDeducao, 2, ".", ""))) : null;
        $W22c = (floatval($this->vOutro)>0.00) ? $W17->appendChild($dom->createElement('vOutro', number_format((float)$this->vOutro, 2, ".", ""))) : null;
        $W22d = (floatval($this->vDescIncond)>0.00) ? $W17->appendChild($dom->createElement('vDescIncond', number_format((float)$this->vDescIncond, 2, ".", ""))) : null;
        $W22f = (floatval($this->vISSRet)>0.00) ? $W17->appendChild($dom->createElement('vISSRet', number_format((float)$this->vISSRet, 2, ".", ""))) : null;
        $W22g = (!empty($this->cRegTrib)) ? $W17->appendChild($dom->createElement('cRegTrib', $this->deParaCodigoRegimeTributacao($this->cRegTrib))) : null;
        return $W17;
    }

    /**
     * M�todo para fazer o "De Para" do C�digo do Regime Especial de Tributa��o
     * @param int $_cod_reg_trib
     *  1=Microempresa Municipal;
	 *	2=Estimativa;
	 *	3=Sociedade de Profissionais;
	 *	4=Cooperativa;
	 *	5=Microempres�rio Individual (MEI);
	 *	6=Microempres�rio e Empresa de Pequeno Porte (ME/EPP)
	 */
    function deParaCodigoRegimeTributacao ($_cod_reg_trib) {
    	switch ((int)$_cod_reg_trib) {
    		case 1:
    			$_result = 1;
    			break;
    		case 6:
    			$_result = 2;
    			break;
    		case 7:
    			$_result = 3;
    			break;
    		case 8:
    			$_result = 4;
    			break;
    		case 9:
    			$_result = 5;
    			break;
    		case 10:
    			$_result = 6;
    			break;
    	}
    	return $_result;
    }

}

// W23
class retTrib {

    var $vRetPIS;       // W24 - valor retido do PIS
    var $vRetCOFINS;    // W25 - valor retido de COFINS
    var $vRetCSLL;      // W26 - valor retido de CSLL
    var $vBCIRRF;       // W27 - base de c�lculo do IRRF
    var $vIRRF;         // W28 - valor retido do IRRF
    var $vBCRetPrev;    // W29 - base de c�lculo da reten��o da previd�ncia
    var $vRetPrev;      // W30 - valor da reten��o da previd�ncia social

    function __construct() {
    }

    function get_xml($dom) {
        $W23 = $dom->appendChild($dom->createElement('retTrib'));
        $W24 = (isset($this->vRetPIS))     ? $W23->appendChild($dom->createElement('vRetPIS',      number_format((float)$this->vRetPIS, 2, ".", "")))      : null;
        $W25 = (isset($this->vRetCOFINS))  ? $W23->appendChild($dom->createElement('vRetCOFINS',   number_format((float)$this->vRetCOFINS, 2, ".", "")))   : null;
        $W26 = (isset($this->vRetCSLL))    ? $W23->appendChild($dom->createElement('vRetCSLL',     number_format((float)$this->vRetCSLL, 2, ".", "")))     : null;
        $W27 = (isset($this->vBCIRRF))     ? $W23->appendChild($dom->createElement('vBCIRRF',      number_format((float)$this->vBCIRRF, 2, ".", "")))      : null;
        $W28 = (isset($this->vIRRF))       ? $W23->appendChild($dom->createElement('vIRRF',        number_format((float)$this->vIRRF, 2, ".", "")))        : null;
        $W29 = (isset($this->vBCRetPrev))  ? $W23->appendChild($dom->createElement('vBCRetPrev',   number_format((float)$this->vBCRetPrev, 2, ".", "")))   : null;
        $W30 = (isset($this->vRetPrev))    ? $W23->appendChild($dom->createElement('vRetPrev',     number_format((float)$this->vRetPrev, 2, ".", "")))     : null;
        return $W23;
    }

}

// X03
class transporta {

    var $CNPJ;      // X04 - CNPJ
    var $CPF;       // X05 - CPF
    var $xNome;     // X06 - raz�o social ou nome
    var $IE;        // X07 - inscri��o estadual
    var $xEnder;    // X08 - endere�o completo
    var $xMun;      // X09 - nome do munic�pio
    var $UF;        // X10 - sigla da UF

    function __construct() {
    }

    function get_xml($dom) {
        $X03 = $dom->appendChild($dom->createElement('transporta'));
        $X04 = (empty($this->CPF)) ? (!empty($this->CNPJ)) ? $X03->appendChild($dom->createElement('CNPJ', sprintf("%014s", $this->CNPJ))) : null : $X03->appendChild($dom->createElement('CPF', sprintf("%011s", $this->CPF)));
        //X05 - ou exclusivo com X04
        $X06 = (!empty($this->xNome))   ? $X03->appendChild($dom->createElement('xNome',    $this->xNome))  : null;
        $X07 = (!empty($this->IE))      ? $X03->appendChild($dom->createElement('IE',       $this->IE))     : null;
        $this->xEnder = trim($this->xEnder);
        $X08 = (!empty($this->xEnder) && strlen($this->xEnder) > 5) ? $X03->appendChild($dom->createElement('xEnder',   $this->xEnder)) : null;
        $X09 = (!empty($this->xMun))    ? $X03->appendChild($dom->createElement('xMun',     $this->xMun))   : null;
        $X10 = (!empty($this->UF))      ? $X03->appendChild($dom->createElement('UF',       $this->UF))     : null;
        return $X03;
    }


}

// X11
class retTransp {

    var $vServ;     // X12 - valor do servi�o
    var $vBCRet;    // X13 - BC da reten��o do ICMS
    var $pICMSRet;  // X14 - al�quota da reten��o
    var $vICMSRet;  // X15 - valor do ICMS retido
    var $CFOP;      // X16 - CFOP
    var $cMunFG;    // X17 - c�digo do munic�pio do fato gerador do ICMS do transp

    function __construct() {
    }

    function get_xml($dom) {
        $X11 = $dom->appendChild($dom->createElement('retTransp'));
        $X12 = $X11->appendChild($dom->createElement('vServ',    number_format((float)$this->vServ, 2, ".", "")));
        $X13 = $X11->appendChild($dom->createElement('vBCRet',   number_format((float)$this->vBCRet, 2, ".", "")));
        $X14 = $X11->appendChild($dom->createElement('pICMSRet', number_format((float)$this->pICMSRet, 2, ".", "")));
        $X15 = $X11->appendChild($dom->createElement('vICMSRet', number_format((float)$this->vICMSRet, 2, ".", "")));
        $X16 = $X11->appendChild($dom->createElement('CFOP',     $this->CFOP));
        $X17 = $X11->appendChild($dom->createElement('cMunFG',   $this->cMunFG));
        return $X11;
    }

}

// X18
class veicTransp {

    var $placa;     // X19 - placa do ve�culo
    var $UF;        // X20 - sigla da UF
    var $RNTC;      // X21 - registro nacional de transportador de carga (ANTT)

    function __construct() {
    }

    function get_xml($dom) {
        $X18 = $dom->appendChild($dom->createElement('veicTransp'));
        $X19 = $X18->appendChild($dom->createElement('placa',   $this->placa));
        $X20 = $X18->appendChild($dom->createElement('UF',      $this->UF));
        $X21 = (!empty($this->RNTC)) ? $X18->appendChild($dom->createElement('RNTC', $this->RNTC)) : null;
        return $X18;
    }

}

// X22
class reboque {

    var $placa;     // X23 - placa do ve�culo
    var $UF;        // X24 - sigla da UF
    var $RNTC;      // X25 - registro nacional de transportador de carga (ANTT)

    function __construct() {
    }

    function get_xml($dom) {
        $X22 = $dom->appendChild($dom->createElement('reboque'));
        $X23 = $X22->appendChild($dom->createElement('placa',   $this->placa));
        $X24 = $X22->appendChild($dom->createElement('UF',      $this->UF));
        $X25 = (!empty($this->RNTC)) ? $X22->appendChild($dom->createElement('RNTC', $this->RNTC)) : null;
        return $X22;
    }

}

// X26
class vol {

    var $qVol;      // X27 - quantidade de volumes transportados
    var $esp;       // X28 - esp�cie dos volumes transportados
    var $marca;     // X29 - marca dos volumes transportados
    var $nVol;      // X30 - numera��o dos volumes transportados
    var $pesoL;     // X31 - peso l�quido (em kg)
    var $pesoB;     // X32 - peso bruto (em kg)
    var $lacres;    // X33 - grupo de lacres

    function __construct() {
        $this->lacres = array();
    }

    function add_lacres($obj_lacres) {
        $this->lacres[] = $obj_lacres;
        return true;
    }

    function get_xml($dom) {
        $X26 = $dom->appendChild($dom->createElement('vol'));
        $X27 = (!empty($this->qVol))    ? $X26->appendChild($dom->createElement('qVol',    (int)$this->qVol))  : null;
        $X28 = (!empty($this->esp))     ? $X26->appendChild($dom->createElement('esp',     $this->esp))   : null;
        $X29 = (!empty($this->marca))   ? $X26->appendChild($dom->createElement('marca',   $this->marca)) : null;
        $X30 = (!empty($this->nVol))    ? $X26->appendChild($dom->createElement('nVol',    $this->nVol))  : null;
        $X31 = (!empty($this->pesoL))   ? $X26->appendChild($dom->createElement('pesoL',   number_format((float)$this->pesoL, 3, ".", ""))) : null;
        $X32 = (!empty($this->pesoB))   ? $X26->appendChild($dom->createElement('pesoB',   number_format((float)$this->pesoB, 3, ".", ""))) : null;
        for ($i=0; $i<count((array)$this->lacres); $i++) {
            $X33 = $X26->appendChild($this->lacres[$i]->get_xml($dom));
        }
        return $X26;
    }

}

// Y02
class fat {

    var $nFat;      // Y03 - n�mero da fatura
    var $vOrig;     // Y04 - valor original da fatura
    var $vDesc;     // Y05 - valor do desconto
    var $vLiq;      // Y06 - valor l�quido da fatura

    function __construct() {
    }

    function get_xml($dom) {
        $Y02 = $dom->appendChild($dom->createElement('fat'));
        $Y03 = (!empty($this->nFat)) ? $Y02->appendChild($dom->createElement('nFat',    $this->nFat))    : null;
        $Y04 = ($this->vOrig > 0)    ? $Y02->appendChild($dom->createElement('vOrig',   number_format((float)$this->vOrig, 2, ".", "")))   : null;
        $Y05 = $Y02->appendChild($dom->createElement('vDesc',   number_format((float)$this->vDesc, 2, ".", "")));
        $Y06 = ($this->vLiq > 0)     ? $Y02->appendChild($dom->createElement('vLiq',    number_format((float)$this->vLiq, 2, ".", "")))    : null;
        return $Y02;
    }

}

// Y07
class dup {

    var $nDup;      // Y08 - n�mero da duplicata
    var $dVenc;     // Y09 - data de vencimento
    var $vDup;      // Y10 - valor da duplicata

    function __construct() {
    }

    function get_xml($dom) {
        $Y07 = $dom->appendChild($dom->createElement('dup'));
        $Y08 = (isset($this->nDup))  ? $Y07->appendChild($dom->createElement('nDup',    $this->nDup))    : null;
        $Y09 = (!empty($this->dVenc)) ? $Y07->appendChild($dom->createElement('dVenc',   $this->dVenc))   : null;
        $Y10 = ($this->vDup > 0)      ? $Y07->appendChild($dom->createElement('vDup',    number_format((float)$this->vDup, 2, ".", "")))    : null;
        return $Y07;
    }

}

// Z04
class obsCont {

    var $xCampo;    // Z05 - identifica��o do campo
    var $xTexto;    // Z06 - conte�do do campo

    function __construct() {
    }

    function get_xml($dom) {
        // Cria o elemento obsCont com o atributo xCampo
        $Z04 = $dom->createElement('obsCont');
        $Z04->setAttribute('xCampo', $this->xCampo);  // Define o atributo xCampo
        $Z06 = $Z04->appendChild($dom->createElement('xTexto', $this->xTexto));  // Adiciona xTexto como elemento filho
        return $Z04;
    }

}

// Z07
class obsFisco {

    var $xCampo;    // Z08 - identifica��o do campo
    var $xTexto;    // Z09 - conte�do do campo

    function __construct() {
    }

    function get_xml($dom) {
        $Z07 = $dom->appendChild($dom->createElement('obsFisco'));
        $Z08 = $Z07->appendChild($dom->createElement('xCampo', $this->xCampo));
        $Z09 = $Z07->appendChild($dom->createElement('xTexto', $this->xTexto));
        return $Z07;
    }

}

// Z10
class procRef {

    var $nProc;     // Z11 - identificador do processo ou ato concess�rio
    var $indProc;   // Z12 - indicador da origem do processo

    function __construct() {
    }

    function get_xml($dom) {
        $Z10 = $dom->appendChild($dom->createElement('procRef'));
        $Z11 = $Z10->appendChild($dom->createElement('nProc',   $this->nProc));
        $Z12 = $Z10->appendChild($dom->createElement('indProc', $this->indProc));
        return $Z10;
    }

}



/* NIVEL 4 ********************************************************************/

/*
 * B20j VERS�O 2.0
 * Refer�ncia ao cupom
 */
class refECF {

    var $mod;       /*
                     * B20k - Modelo do documento Fiscal
                     * "2B" Cupom de maquina registradora.
                     * "2C" Cupom fiscal PDV
                     * "2D" Cupom fiscal ECF
                     */
    var $nECF;      // B20l - N�mero do ECF
    var $nCOO;		// B20m - N�mero do Contador de Ordem de Opera��o - COO.

    function __construct() {
    }

    function get_xml($dom) {
    	if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) >= 2) {
	        $B20j = $dom->appendChild($dom->createElement('refECF'));
	        $B20k = $B20j->appendChild($dom->createElement('mod',   $this->mod));
	        $B20l = $B20j->appendChild($dom->createElement('nECF',  (int)$this->nECF));
	        $B20m = $B20j->appendChild($dom->createElement('nCOO',  (int)$this->nCOO));
    	}
        return $B20j;
    }

}



// B14
class refNF {

    var $cUF;       // B15 - c�digo da UF do emitente do documento fiscal
    var $AAMM;      // B16 - ano e m�s de emiss�o da NFe
    var $CNPJ;      // B17 - CNPJ do emitente
    var $mod;       // B18 - modelo do documento fiscal
    var $serie;     // B19 - s�rie do documento fiscal
    var $nNF;       // B20 - n�mero do documento fiscal

    function __construct() {
    }

    function get_xml($dom) {
        $B14 = $dom->appendChild($dom->createElement('refNF'));
        $B15 = $B14->appendChild($dom->createElement('cUF',   $this->cUF));
        $B16 = $B14->appendChild($dom->createElement('AAMM',  $this->AAMM));
        $B17 = $B14->appendChild($dom->createElement('CNPJ',  sprintf("%014s", $this->CNPJ)));
        $B18 = $B14->appendChild($dom->createElement('mod',   $this->mod));
        $B19 = $B14->appendChild($dom->createElement('serie', $this->serie));
        $B20 = $B14->appendChild($dom->createElement('nNF',   $this->nNF));
        return $B14;
    }

}

// I18
class DI {

    var $nDI;           // I19 - n�mero do documento de importa��o DI/DSI/DA
    var $dDi;           // I20 - data da registro da DI/DSI/DA
    var $xLocDesemb;    // I21 - local de desembara�o
    var $UFDesemb;      // I22 - UF onde ocorreu o desembara�o aduaneiro
    var $dDesemb;       // I23 - data do desembara�o aduaneiro
    var $cExportador;   // I24 - c�digo do exportador
    var $adi;           // I25 - adi��es

    function __construct() {
        $this->adi = array();
    }

    function add_adi($obj_adi) {
        $this->adi[] = $obj_adi;
        return true;
    }

    function get_xml($dom) {
        $I18 = $dom->appendChild($dom->createElement('DI'));
        $I19 = $I18->appendChild($dom->createElement('nDI',         $this->nDi));
        $I20 = $I18->appendChild($dom->createElement('dDi',         $this->dDi));
        $I21 = $I18->appendChild($dom->createElement('xLocDesemb',  $this->xLocDesemb));
        $I22 = $I18->appendChild($dom->createElement('UFDesemb',    $this->UFDesemb));
        $I23 = $I18->appendChild($dom->createElement('dDesemb',     $this->dDesemb));
        $I24 = $I18->appendChild($dom->createElement('cExportador', $this->cExportador));
        for ($i=0; $i<count((array)$this->adi); $i++) {
            $I25 = $I18->appendChild($this->adi[$i]->get_xml($dom));
        }
        return $I18;
    }

}

// J01
/**
 NA VERS�O 2.0 ELES MUDARAM MTO ISSO SE PRECISAR USAR, REVER.
 */
class veicProd {

    var $tpOp;      // J02 - tipo da opera��o
    var $chassi;    // J03 - chassi do ve�culo
    var $cCor;      // J04 - cor
    var $xCor;      // J05 - descri��o da cor
    var $pot;       // J06 - pot�ncia do motor
    var $CM3;       // J07 - CM3 (pot�ncia)
    var $pesoL;     // J08 - peso l�quido
    var $pesoB;     // J09 - peso bruto
    var $nSerie;    // J10 - serial
    var $tpComb;    // J11 - tipo de combust�vel
    var $nMotor;    // J12 - n�mero do motor
    var $CMKG;      // J13 - CMKG
    var $dist;      // J14 - dist�ncia entre eixos
    var $RENAVAM;   // J15 - RENAVAM
    var $anoMod;    // J16 - ano modelo de fabrica��o
    var $anoFab;    // J17 - ano de fabrica��o
    var $tpPint;    // J18 - tipo de pintura
    var $tpVeic;    // J19 - tipo de ve�culo
    var $espVeic;   // J20 - esp�cie de ve�culo
    var $VIN;       // J21 - condi��o do VIN
    var $condVeic;  // J22 - condi��o do ve�culo
    var $cMod;      // J23 - c�digo marca modelo

    function __construct() {
    }

    function get_xml($dom) {
        $J01 = $dom->appendChild($dom->createElement('veicProd'));
        $J02 = $J01->appendChild($dom->createElement('tpOp',        $this->tpOp));
        $J03 = $J01->appendChild($dom->createElement('chassi',      $this->chassi));
        $J04 = $J01->appendChild($dom->createElement('cCor',        $this->cCor));
        $J05 = $J01->appendChild($dom->createElement('xCor',        $this->xCor));
        $J06 = $J01->appendChild($dom->createElement('pot',         $this->pot));
        $J07 = $J01->appendChild($dom->createElement('CM3',         $this->CM3));
        $J08 = $J01->appendChild($dom->createElement('pesoL',       $this->pesoL));
        $J09 = $J01->appendChild($dom->createElement('pesoB',       $this->pesoB));
        $J10 = $J01->appendChild($dom->createElement('nSerie',      $this->nSerie));
        $J11 = $J01->appendChild($dom->createElement('tpComb',      $this->tpComb));
        $J12 = $J01->appendChild($dom->createElement('nMotor',      $this->nMotor));
        $J13 = $J01->appendChild($dom->createElement('CMKG',        $this->CMKG));
        $J14 = $J01->appendChild($dom->createElement('dist',        $this->dist));
        $J15 = (!empty($this->RENAVAM)) ? $J01->appendChild($dom->createElement('RENAVAM',     $this->RENAVAM)) : null;
        $J16 = $J01->appendChild($dom->createElement('anoMod',      $this->anoMod));
        $J17 = $J01->appendChild($dom->createElement('anoFab',      $this->anoFab));
        $J18 = $J01->appendChild($dom->createElement('tpPint',      $this->tpPint));
        $J19 = $J01->appendChild($dom->createElement('tpVeic',      $this->tpVeic));
        $J20 = $J01->appendChild($dom->createElement('espVeic',     $this->espVeic));
        $J21 = $J01->appendChild($dom->createElement('VIN',         $this->VIN));
        $J22 = $J01->appendChild($dom->createElement('condVeic',    $this->condVeic));
        $J23 = $J01->appendChild($dom->createElement('cMod',        $this->cMod));
        return $J01;
    }

}

// K01
class med {

    var $cProdANVISA; // K01a - C�digo de Produto da ANVISA
    var $xMotivoIsencao; // K01b - C�digo Isen��o ANVISA
    var $vPMC;      // K06 - pre�o m�ximo consumidor
    /*var $nLote;     // K02 - n�mero do lote do medicamento
    var $qLote;     // K03 - quantidade de produto no lote do medicamento
    var $dFab;      // K04 - data de fabrica��o
    var $dVal;      // K05 - data de validade
    */


    function __construct() {
    }

    function get_xml($dom) {
        $K01 = $dom->appendChild($dom->createElement('med'));
        /*$K02 = $K01->appendChild($dom->createElement('nLote',   $this->nLote));
        $K03 = $K01->appendChild($dom->createElement('qLote',   $this->qLote));
        $K04 = $K01->appendChild($dom->createElement('dFab',    $this->dFab));
        $K05 = $K01->appendChild($dom->cProdANVISAcreateElement('dVal',    $this->dVal));*/
        /**
         * Os campos foram removidos pois est�o na rastreabilidade agora.
         * ALTNFE-52
         */
        $K01a = $K01->appendChild($dom->createElement('cProdANVISA', $this->cProdANVISA));
        if ( $this->cProdANVISA == 'ISENTO' ) {
            $K01b = $K01->appendChild($dom->createElement('xMotivoIsencao', $this->xMotivoIsencao));
        }
        $K06  = $K01->appendChild($dom->createElement('vPMC', number_format((float)$this->vPMC, 2, ".", "")));
        return $K01;
    }

}

// L01
class arma {

    var $tpArma;    // L02 - indicador do tipo de arama de fogo
    var $nSerie;    // L03 - n�mero de s�rie da arma
    var $nCano;     // L04 - n�mero de s�rie do cano
    var $descr;     // L05 - descri��o completa da arma

    function __construct() {
    }

    function get_xml($dom) {
        $L01 = $dom->appendChild($dom->createElement('arma'));
        $L02 = $L01->appendChild($dom->createElement('tpArma',  $this->tpArma));
        $L03 = $L01->appendChild($dom->createElement('nSerie',  $this->nSerie));
        $L04 = $L01->appendChild($dom->createElement('nCano',   $this->nCano));
        $L05 = $L01->appendChild($dom->createElement('descr',   $this->descr));
        return $L01;
    }

}

// L101
class comb {

    var $cProdANP;      // L102 - c�digo de produto da ANP
    var $descANP;       // LA03 - Descri��o do produto conforme ANP
    var $pGLP;          //LA03a - Percentual do GLP derivado do petr�leo no produto GLP
    var $pGNn;          //LA03b - Percentual de G�s Natural Nacional ? GLGNn para o produto GLP (
    var $pGNi;          //LA03c - Percentual de G�s Natural Importado ? GLGNi para o produto GLP
    var $CODIF;         // L103 - c�digo de autoriza��o / registro do CODIF
    var $qTemp;         // L104 - quantidade de combust�vel faturada
    var $CIDE;          // L105 - grupo da CIDE
    var $ICMSComb;      // L109 - grupo do ICMSComb
    var $ICMSInter;     // L114 - grupo do ICMSST de opera��o interestadual
    var $ICMSCons;      // L117 - ICMS consumo em UF diferente da UF do destinat
    /**
     * @var encerrante_nota
     * LA11
     */
    public $encerrante; // Encerrante para controle de combustiveis
    public $pBio; //LA17 - Percentual do �ndice de mistura do Biodiesel (B100) no �leo Diesel B institu�do pelo �rg�o regulamentador
    public $origComb;


    function __construct() {
        $this->CIDE         = null;
        $this->ICMSComb     = new ICMSComb;
        $this->ICMSInter    = null;
        $this->ICMSCons     = null;
        $this->encerrante   = null;
        $this->pBio         = null;
        $this->origComb     = null;
    }

    function add_CIDE($obj_CIDE) {
        if (!$this->CIDE) {
            $this->CIDE = $obj_CIDE;
            return true;
        } else {
            return false;
        }
    }

    function add_ICMSInter($obj_ICMSInter) {
        if (!$this->ICMSInter) {
            $this->ICMSInter = $obj_ICMSInter;
            return true;
        } else {
            return false;
        }
    }

    function add_ICMSCons($obj_ICMSCons) {
        if (!$this->ICMSCons) {
            $this->ICMSCons = $obj_ICMSCons;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Adiciona o objeto de encerrantes.
     * @param $_obj_enc
     * @return bool
     */
    public function add_encerrante($_obj_enc) {
        if(!$this->encerrante) {
            $this->encerrante = $_obj_enc;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Adiciona o objeto de origComb.
     * @param $_obj_enc
     * @return bool
     */
    public function add_origComb($_obj_enc) {
        if(!$this->origComb) {
            $this->origComb = $_obj_enc;
            return true;
        } else {
            return false;
        }
    }

    function get_xml($dom) {
        $L101 = $dom->appendChild($dom->createElement('comb'));
        $L102 = $L101->appendChild($dom->createElement('cProdANP',  $this->cProdANP));
        $LA03 = $L101->appendChild($dom->createElement('descANP',  $this->descANP));
        $LA03a = (!empty($this->pGLP) && (float)$this->pGLP > 0) ? $L101->appendChild($dom->createElement('pGLP', number_format((float)$this->pGLP, 4, ".", ""))) : null;
        $LA03b = (!empty($this->pGNn) && (float)$this->pGNn > 0) ? $L101->appendChild($dom->createElement('pGNn', number_format((float)$this->pGNn, 4, ".", ""))) : null;
        $LA03c = (!empty($this->pGNi) && (float)$this->pGNi > 0) ? $L101->appendChild($dom->createElement('pGNi', number_format((float)$this->pGNi, 4, ".", ""))) : null;
        //$L103 = $L101->appendChild($dom->createElement('CODIF',     $this->CODIF));
        //$L104 = $L101->appendChild($dom->createElement('qTemp',     $this->qTemp));
        $L120 = $L101->appendChild($dom->createElement('UFCons',     $this->UFCons));

        if (is_object($this->encerrante)) {
            $LA11 = $L101->appendChild($this->encerrante->get_xml($dom));
        }

        $LA17 = (!empty($this->pBio)) ? $L101->appendChild($dom->createElement('pBio', number_format((float)$this->pBio, 4, ".", ""))) : null;

        if (is_object($this->origComb)) {
            $LA11 = $L101->appendChild($this->origComb->get_xml($dom));
        }
        //$L105 = (is_object($this->CIDE)) ? $L101->appendChild($this->CIDE->get_xml($dom)) : null;
        //$L109 = $L101->appendChild($this->ICMSComb->get_xml($dom));
        //$L114 = (is_object($this->ICMSInter)) ? $L101->appendChild($this->ICMSInter->get_xml($dom)) : null;
        //$L117 = (is_object($this->ICMSCons)) ? $L101->appendChild($this->ICMSCons->get_xml($dom)) : null;
        return $L101;
    }

}

// N01
class ICMS {

    var $orig;      // N11 - origem da mercadoria
    var $CST;       // N12 - tributa��o do ICMS
    var $modBC;     // N13 - modalidade de determina��o da BC do ICMS
    var $pRedBC;    // N14 - percentual da redu��o de BC
    var $vBC;       // N15 - valor da BC do ICMS
    var $pICMS;     // N16 - al�quota do imposto
    var $vICMSOp;	// N16a - Valor como se n�o tivesse o diferimento
    var $pDif; 		// N16b - Percentual de diferimento
    var $vICMSDif;  // N16c - Valor do ICMS diferido
    var $vICMS;     // N17 - valor do ICMS
    var $modBCST;   // N18 - modalidade de determina��o da BC do ICMS ST
    var $pMVAST;    // N19 - percentual da margem de valor adicionado do ICMS ST
    var $pRedBCST;  // N20 - percentual da redu��o de BC do ICMS ST
    var $vBCST;     // N21 - valor da BC do ICMS ST
    var $pICMSST;   // N22 - al�quota do imposto do ICMS ST
    var $vICMSST;   // N23 - valor do ICMS ST
    var $vICMSDeson;// N27a valor icms de desonera��o
    var $motDesICMS;// N28 Motivo do icms de desonera��o
    var $indDeduzDeson; // Indicador de dedu��o do ICMS Desonerado
    var $vICMSSTDeson;// N33 valor icms de desonera��o ST
    var $motDesICMSST;// N33 Motivo do icms de desonera��o ST
    var $pFCP; // Percentual fundo de combate a pobreza
    var $vFCP; // Valor fundo de combate a pobreza
    var $vBCFCP; // Base fundo de combate a pobreza
    var $pFCPST; // Percentual fundo de combate a pobreza
    var $vFCPST; // Valor fundo de combate a pobreza
    var $vBCFCPST; // Base fundo de combate a pobreza

    var $vBCSTRet; //N26 - Informar o valor da BC do ICMS ST retido na UF remetente (v2.0)
    var $pST; //N26a - Deve ser informada a al�quota do c�lculo do ICMS-ST, j� incluso o FCP caso incida sobre a mercadoria. Exemplo: al�quota da mercadoria na venda ao consumidor final = 18% e 2% de FCP. A al�quota a ser informada no campo pST deve ser 20%.
    var $vICMSSubstituto; //N26b - Valor do ICMS Pr�prio do Substituto cobrado em opera��o anterior
    var $vICMSSTRet; //N27 - Informar o valor do ICMS ST retido na UF remetente (v2.0)

    var $pRedBCEfet; //N34 - Percentual de redu��o, caso estivesse submetida ao regime comum de tributa��o, para obten��o da base de c�lculo efetiva (vBCEfet). Obs.: opcional a crit�rio da UF.
    var $vBCEfet; //N35 - Valor da base de c�lculo que seria atribu�da � opera��o pr�pria do contribuinte substitu�do, caso estivesse submetida ao regime comum de tributa��o, obtida pelo produto do Vprod por (1- pRedBCEfet). Obs.: opcional a crit�rio da UF
    var $pICMSEfet; //N36 - Al�quota do ICMS na opera��o a consumidor final, caso estivesse submetida ao regime comum de tributa��o. Obs.: opcional a crit�rio da UF
    var $vICMSEfet; //N37 - Obtido pelo produto do valor do campo pICMSEfet  pelo valor do campo vBCEfet, caso estivesse submetida ao regime comum de tributa��o. Obs.: opcional a crit�rio da UF

    var $pDifFCP; // Percentual Diferido FCP
    var $vICMSFCPDif; // Valor ICMS FCP diferido
    var $vICMSEfFCPDif; // Valor ICMS Efetivo FCP Diferido

    //NT2023001-1
    var $qBCMono;
    var $qBCMonoReten;
    var $qBCMonoRet; //Quantidade tributada retida anteriormente - OBS.: Informar a BC do ICMS em quantidade conforme unidade de medida estabelecida na legisla��o.
    var $adRemICMS; //Al�quota ad rem do imposto
    var $adRemICMSReten; //Al�quota ad rem do imposto com reten��o
    var $adRemICMSRet; //Al�quota ad rem do imposto retido anteriormente - OBS.: Al�quota ad rem do ICMS estabelecida em legisla��o para o produto. (Buscar do cadastro de mercadorai info estendida tipo 51)
    var $vICMSMono; //Valor do ICMS pr�prio
    var $vICMSMonoReten; //Valor do ICMS com reten��o
    var $vICMSMonoRet; //Valor do ICMS retido anteriormente - OBS.: O valor do ICMS � obtido pela multiplica��o da al�quota ad rem pela quantidade do produto conforme unidade de medida estabelecida em legisla��o.


    function __construct($_comb = false) {
        $this->comb = $_comb;
    }

    function get_xml($dom) {
        $_CST = '';
        $N01 = $dom->appendChild($dom->createElement('ICMS'));

        //Esse switch case deveria estar no valorarObjeto e n�o aqui
        switch ($this->CST) {

            case '00' :
                $N02 = $N01->appendChild($dom->createElement('ICMS00'));
                $N11 = $N02->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = $N02->appendChild($dom->createElement('modBC',       $this->modBC));
                $N15 = $N02->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $N16 = $N02->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
                $N17 = $N02->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")));

                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17b = $N02->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N02->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }

                break;

            case '10' :
                $N03 = $N01->appendChild($dom->createElement('ICMS10'));
                $N11 = $N03->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N03->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = $N03->appendChild($dom->createElement('modBC',       $this->modBC));
                $N15 = $N03->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $N16 = $N03->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
                $N17 = $N03->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")));

                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17a = $N03->appendChild($dom->createElement('vBCFCP',       number_format((float)$this->vBCFCP, 2, ".", "")));
                    $N17b = $N03->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N03->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }

                $N18 = $N03->appendChild($dom->createElement('modBCST',     $this->modBCST));
                $N19 = (isset($this->pMVAST))   ? $N03->appendChild($dom->createElement('pMVAST',      number_format((float)$this->pMVAST, 2, ".", "")))   : null;
                $N20 = (isset($this->pRedBCST)) ? $N03->appendChild($dom->createElement('pRedBCST',    number_format((float)$this->pRedBCST, 2, ".", ""))) : null;
                $N21 = $N03->appendChild($dom->createElement('vBCST',       number_format((float)$this->vBCST, 2, ".", "")));
                $N22 = $N03->appendChild($dom->createElement('pICMSST',     number_format((float)$this->pICMSST, 2, ".", "")));
                $N23 = $N03->appendChild($dom->createElement('vICMSST',     number_format((float)$this->vICMSST, 2, ".", "")));

                if(isset($this->pFCPST) && $this->vFCPST > 0) {
                    $N17a = $N03->appendChild($dom->createElement('vBCFCPST',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    $N17b = $N03->appendChild($dom->createElement('pFCPST',       number_format((float)$this->pFCPST, 2, ".", "")));
                    $_valor_fcpst = ($this->vBCFCPST * ($this->pFCPST / 100)-$this->vFCP);
                    $N17c = $N03->appendChild($dom->createElement('vFCPST',       number_format((float)$_valor_fcpst, 2, ".", "")));
                }

                /**
                 * NT20005110-5
                 * BIT
                 * Jun.2021
                 */
                if($this->vICMSSTDeson>0) {
                    $N33a = $N03->appendChild($dom->createElement('vICMSSTDeson',  number_format((float)$this->vICMSSTDeson, 2, ".", "")));
                    $N33b = $N03->appendChild($dom->createElement('motDesICMSST',  $this->motDesICMSST));
                }

                break;

            case '20' :
                $N04 = $N01->appendChild($dom->createElement('ICMS20'));
                $N11 = $N04->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = $N04->appendChild($dom->createElement('modBC',       $this->modBC));
                $N14 = $N04->appendChild($dom->createElement('pRedBC',      number_format((float)$this->pRedBC, 4, ".", "")));
                $N15 = $N04->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $N16 = $N04->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
                $N17 = $N04->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")));

                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17a = $N04->appendChild($dom->createElement('vBCFCP',       number_format((float)$this->vBCFCP, 2, ".", "")));
                    $N17b = $N04->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N04->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }

                if($this->vICMSDeson > 0){
                    $N17d = $N04->appendChild($dom->createElement('vICMSDeson',  number_format((float)$this->vICMSDeson, 2, ".", "")));
                    $N17e = $N04->appendChild($dom->createElement('motDesICMS',  $this->motDesICMS));
                    if($this->indDeduzDeson == '0' || $this->indDeduzDeson == '1'){
                        $N17f = $N04->appendChild($dom->createElement('indDeduzDeson', $this->indDeduzDeson));
                    }
                }

                break;

            case '30' :
                $N05 = $N01->appendChild($dom->createElement('ICMS30'));
                $N11 = $N05->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N05->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N18 = $N05->appendChild($dom->createElement('modBCST',     $this->modBCST));
                $N19 = (isset($this->pMVAST))   ? $N05->appendChild($dom->createElement('pMVAST',      number_format((float)$this->pMVAST, 2, ".", ""))) : null;
                $N20 = (isset($this->pRedBCST)) ? $N05->appendChild($dom->createElement('pRedBCST',    number_format((float)$this->pRedBCST, 2, ".", ""))) : null;
                $N21 = $N05->appendChild($dom->createElement('vBCST',       number_format((float)$this->vBCST, 2, ".", "")));
                $N22 = $N05->appendChild($dom->createElement('pICMSST',     number_format((float)$this->pICMSST, 2, ".", "")));
                $N23 = $N05->appendChild($dom->createElement('vICMSST',     number_format((float)$this->vICMSST, 2, ".", "")));

                if(isset($this->pFCPST) && $this->vFCPST > 0) {
                    $N17a = $N05->appendChild($dom->createElement('vBCFCPST',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    $N17b = $N05->appendChild($dom->createElement('pFCPST',       number_format((float)$this->pFCPST, 2, ".", "")));
                    $_valor_fcpst = $this->vBCFCPST * ($this->pFCPST / 100);
                    $N17c = $N05->appendChild($dom->createElement('vFCPST',       number_format((float)$_valor_fcpst, 2, ".", "")));
                }


                if($this->vICMSDeson > 0){
                    $N17d = $N05->appendChild($dom->createElement('vICMSDeson',  number_format((float)$this->vICMSDeson, 2, ".", "")));
                    $N17e = $N05->appendChild($dom->createElement('motDesICMS',  $this->motDesICMS));
                    if($this->indDeduzDeson == '0' || $this->indDeduzDeson == '1'){
                        $N17f = $N05->appendChild($dom->createElement('indDeduzDeson', $this->indDeduzDeson));
                    }
                }

                break;

            case '40' :
            case '41' :
            case '50' :
                /**
                 * Autor: Tairo Miguel
                 * BL-3302
                 * OBS: Adicionado tag de icms de desonera��es para cst 40 e 41
                 */
                $N06 = $N01->appendChild($dom->createElement('ICMS40'));
                $N11 = $N06->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N06->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));

                if($this->vICMSDeson > 0){
                    $N27a = $N06->appendChild($dom->createElement('vICMSDeson',  number_format((float)$this->vICMSDeson, 2, ".", "")));
                    $N28 = $N06->appendChild($dom->createElement('motDesICMS',  $this->motDesICMS));
                    if($this->indDeduzDeson == '0' || $this->indDeduzDeson == '1'){
                        $N28a = $N06->appendChild($dom->createElement('indDeduzDeson', $this->indDeduzDeson));
                    }
                }

                break;

            case '51' :
                $N07 = $N01->appendChild($dom->createElement('ICMS51'));
                $N11 = $N07->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N07->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = (isset($this->modBC))  ? $N07->appendChild($dom->createElement('modBC',       $this->modBC))                    : null;
                $N14 = (isset($this->pRedBC)) ? $N07->appendChild($dom->createElement('pRedBC',      number_format((float)$this->pRedBC, 4, ".", ""))) : null;
                $N15 = (isset($this->vBC))    ? $N07->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")))    : null;
                $N16 = (isset($this->pICMS))  ? $N07->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")))  : null;
                $N16a  = (isset($this->vICMSOp))    ? $N07->appendChild($dom->createElement('vICMSOp',     number_format((float)$this->vICMSOp, 2, ".", "")))  : null;
                $N16b  = (isset($this->pDif))       ? $N07->appendChild($dom->createElement('pDif',        number_format((float)$this->pDif, 2, ".", "")))  : null;
                $N16c  = (isset($this->vICMSDif))   ? $N07->appendChild($dom->createElement('vICMSDif',    number_format((float)$this->vICMSDif, 2, ".", "")))  : null;
                $N17 = (isset($this->vICMS))  ? $N07->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")))  : null;

                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17a = $N07->appendChild($dom->createElement('vBCFCP',       number_format((float)$this->vBCFCP, 2, ".", "")));
                    $N17b = $N07->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N07->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }

                /**
                 * NT20005110-23
                 * BIT
                 * Jun.2021
                 */
                $N17f = $N07->appendChild($dom->createElement('pFCPDif',  number_format((float)$this->pDifFCP, 2, ".", "")));
                $N17g = $N07->appendChild($dom->createElement('vFCPDif',  number_format((float)$this->vICMSFCPDif, 2, ".", "")));
                $N17h = $N07->appendChild($dom->createElement('vFCPEfet',  number_format((float)$this->vICMSEfFCPDif, 2, ".", "")));

                break;

            case '60' :
                //NT_2016_002
                if ($this->comb == true) {
                    $N08 = $N01->appendChild($dom->createElement('ICMSST'));
                } else {
                    $N08 = $N01->appendChild($dom->createElement('ICMS60'));
                }
                /**
                 * A ordem deve ser respeitada, mas isso ficou complexo e a f�rmula entrou aqui tb..
                 * Ent�o mudei a forma como ele trabalhar�.
                 */

                //$N08 = $N01->appendChild($dom->createElement('ICMS60'));
                $N11 = $N08->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N08->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $_xml_ordem = [];
                if (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) < 2) {
                    $_xml_ordem["N21"] = ['vBCST'=>number_format((float)$this->vBCST, 2, ".", "")];
                    $_xml_ordem["N23"] = ['vICMSST'=>number_format((float)$this->vBCST, 2, ".", "")];
                    //$N21 = $N08->appendChild($dom->createElement('vBCST',       number_format((float)$this->vBCST, 2, ".", "")));
                	//$N23 = $N08->appendChild($dom->createElement('vICMSST',     number_format((float)$this->vICMSST, 2, ".", "")));
                } elseif (funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) > 2 && funcoesGerais::retornarVersaoNFe(0,null,NFe::$_tipo_nota) < 4) {
                    //Na Vers�o 2.0 o nome dos campos vBCST e vICMSST foram trocados para vBCSTRET e vICMSSTRet
                    $_xml_ordem["N26"] = ['vBCSTRET'=>number_format((float)$this->vBCST, 2, ".", "")];
                    $_xml_ordem["N23"] = ['vICMSSTRet'=>number_format((float)$this->vICMSST, 2, ".", "")];

                    //$N26 = $N08->appendChild($dom->createElement('vBCSTRet',       number_format((float)$this->vBCST, 2, ".", "")));
                    //$N23 = $N08->appendChild($dom->createElement('vICMSSTRet',     number_format((float)$this->vICMSST, 2, ".", "")));
                } else {
                    if(($GLOBALS['_VERSAO_NT'] & 2048) != 0) {
                        $_xml_ordem["N26"] = ['vBCSTRet'=>number_format((float)$this->vBCSTRet, 2, ".", "")];
                        $_xml_ordem["N26a"] = ['pST'=>number_format((float)$this->pST, 2, ".", "")];
                        $_xml_ordem["N26b"] = ['vICMSSubstituto'=>number_format((float)$this->vICMSSubstituto, 2, ".", "")];
                        $_xml_ordem["N27"] = ['vICMSSTRet'=>number_format((float)$this->vICMSSTRet, 2, ".", "")];

                        /*$N26 = $N08->appendChild($dom->createElement('vBCSTRet', number_format((float)$this->vBCSTRet, 2, ".", "")));
                        $N26a = $N08->appendChild($dom->createElement('pST', number_format((float)$this->pST, 2, ".", "")));
                        $N26b = $N08->appendChild($dom->createElement('vICMSSubstituto', number_format((float)$this->vICMSSubstituto, 2, ".", "")));
                        $N27 = $N08->appendChild($dom->createElement('vICMSSTRet', number_format((float)$this->vICMSSTRet, 2, ".", "")));*/

                        if ($this->comb == true) {
                            $_xml_ordem["N31 "] = ['vBCSTDest'=>number_format((float)$this->vBCSTDest, 2, ".", "")];
                            $_xml_ordem["N32"] = ['vICMSSTDest'=>number_format((float)$this->vICMSSTDest, 2, ".", "")];
                            /*$N31 = $N08->appendChild($dom->createElement('vBCSTDest', number_format((float)$this->vBCSTDest, 2, ".", "")));
                            $N32 = $N08->appendChild($dom->createElement('vICMSSTDest', number_format((float)$this->vICMSSTDest, 2, ".", "")));*/
                        }
                    }
                    if(($GLOBALS['_VERSAO_NT'] & 8192) != 0) {
                        if(!isset($_xml_ordem["N27"])) {
                            $_xml_ordem["N26"] = ['vBCSTRet'=>number_format((float)$this->vBCSTRet, 2, ".", "")];
                            $_xml_ordem["N26a"] = ['pST'=>number_format((float)$this->pST, 2, ".", "")];
                            $_xml_ordem["N26b"] = ['vICMSSubstituto'=>number_format((float)$this->vICMSSubstituto, 2, ".", "")];
                            $_xml_ordem["N27"] = ['vICMSSTRet'=>number_format((float)$this->vICMSSTRet, 2, ".", "")];
                            /*$N26 = $N08->appendChild($dom->createElement('vBCSTRet',number_format((float)$this->vBCSTRet,2,".","")));
                            $N26a = $N08->appendChild($dom->createElement('pST',number_format((float)$this->pST,2,".","")));
                            $N26b = $N08->appendChild($dom->createElement('vICMSSubstituto',number_format((float)$this->vICMSSubstituto,2,".","")));
                            $N27 = $N08->appendChild($dom->createElement('vICMSSTRet',number_format((float)$this->vICMSSTRet,2,".","")));*/
                        }

                        $this->vBCFCPST = $this->vBCSTRet;
                        // repetido para que as tags Ret fiquem juntas, caso contrario
                        // � retornado um erro de XSD por ter tag Efet no meio
                        if(isset($this->pFCPST) && $this->pFCPST > 0) {
                            $_xml_ordem["N27a"] = ['vBCFCPSTRet' => number_format((float)$this->vBCFCPST, 2, ".", "")];
                            $_xml_ordem["N27b"] = ['pFCPSTRet' => number_format((float)$this->pFCPST, 2, ".", "")];
                            /**
                             * Clientes que n�o possuem o campo VFCP preenchido o sistema calculava,
                             * Ao mudarmos a regra passou a gerar um problema para o GP, ent�o mantivemos a regra anterior.
                             */
                            if ((float)$this->vFCP > 0) {
                                $this->vFCPSTRet = (float)$this->vFCP;
                            } elseif ($this->vFCPST > 0) {
                                $this->vFCPSTRet = (float)$this->vFCPST;
                            }
                            //$N27d = $N08->appendChild($dom->createElement('vFCPSTRet',       number_format($this->vFCPSTRet, 2, ".", "")));
                            $_xml_ordem["N27d"] = ['vFCPSTRet'=>number_format((float)$this->vFCPSTRet, 2, ".", "")];
                            /*$N27a = $N08->appendChild($dom->createElement('vBCFCPSTRet', number_format((float)$this->vBCFCPST, 2, ".", "")));
                            $N27b = $N08->appendChild($dom->createElement('pFCPSTRet', number_format((float)$this->pFCPST, 2, ".", "")));
                            //$_valor_fcpst = $this->vBCFCPST * ($this->pFCPST / 100);
                            $N27d = $N08->appendChild($dom->createElement('vFCPSTRet',       number_format((float)$this->vFCP, 2, ".", "")));*/
                            // evita montar 2x
                            unset($this->pFCPST);
                        }
                    }

                    //Quando os parametros l� em cima est�o habilitados ele preenchia duas vezes o vBCFCPSTRet
                    //colocando bloco de fcp aqui para montar na ordem as tags, se n�o estiver na ordem da erro de XSD
                    if(($GLOBALS['_VERSAO_NT'] & 8192) == 0 && (($GLOBALS['_VERSAO_NT'] & 2048) == 0) ) {
                        if (isset($this->pFCPST) && $this->pFCPST > 0) {
                            $this->vBCST = 0;
                            $_xml_ordem["N27a"] = ['vBCFCPSTRet' => number_format((float)$this->vBCFCPST, 2, ".", "")];
                            $_xml_ordem["N27b"] = ['pFCPSTRet' => number_format((float)$this->pFCPST, 2, ".", "")];

                            /**
                             * Clientes que n�o possuem o campo VFCP preenchido o sistema calculava,
                             * Ao mudarmos a regra passou a gerar um problema para o GP, ent�o mantivemos a regra anterior.
                             */
                            if ((float)$this->vFCP > 0) {
                                $this->vFCPSTRet = (float)$this->vFCP;
                            } elseif ($this->vFCPST > 0) {
                                $this->vFCPSTRet = (float)$this->vFCPST;
                            }
                            //$N27d = $N08->appendChild($dom->createElement('vFCPSTRet',       number_format($this->vFCPSTRet, 2, ".", "")));
                            $_xml_ordem["N27d"] = ['vFCPSTRet'=>number_format((float)$this->vFCPSTRet, 2, ".", "")];
                            /*$N27a = $N08->appendChild($dom->createElement('vBCFCPSTRet', number_format((float)$this->vBCFCPST, 2, ".", "")));
                            $N27b = $N08->appendChild($dom->createElement('pFCPSTRet', number_format((float)$this->pFCPST, 2, ".", "")));
                            //$_valor_fcpst = $this->vBCFCPST * ($this->pFCPST / 100);
                            $N27d = $N08->appendChild($dom->createElement('vFCPSTRet',       number_format((float)$this->vFCP, 2, ".", "")));*/
                            unset($this->pFCPST);
                        }
                    }

                    if(($GLOBALS['_VERSAO_NT'] & 2) != 0) {
                        $_xml_ordem["N34"] = ['pRedBCEfet' => number_format((float)$this->pRedBCEfet, 4, ".", "")];
                        $_xml_ordem["N35"] = ['vBCEfet' => number_format((float)$this->vBCEfet, 2, ".", "")];
                        $_xml_ordem["N36"] = ['pICMSEfet' => number_format((float)$this->pICMSEfet, 2, ".", "")];
                        $_xml_ordem["N37"] = ['vICMSEfet' => number_format((float)$this->vICMSEfet, 2, ".", "")];

                        /*$N34 = $N08->appendChild($dom->createElement('pRedBCEfet', number_format((float)$this->pRedBCEfet, 2, ".", "")));
                        $N35 = $N08->appendChild($dom->createElement('vBCEfet', number_format((float)$this->vBCEfet, 2, ".", "")));
                        $N36 = $N08->appendChild($dom->createElement('pICMSEfet', number_format((float)$this->pICMSEfet, 2, ".", "")));
                        $N37 = $N08->appendChild($dom->createElement('vICMSEfet', number_format((float)$this->vICMSEfet, 2, ".", "")));*/
                    }
                }

                if(isset($this->pFCPST) && $this->pFCPST > 0) {
                    $_xml_ordem["N27a"] = ['vBCFCPSTRet'=>number_format((float)$this->vBCFCPST, 2, ".", "")];
                    $_xml_ordem["N27b"] = ['pFCPSTRet'=>number_format((float)$this->pFCPST, 2, ".", "")];

                    //$N27a = $N08->appendChild($dom->createElement('vBCFCPSTRet',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    //$N27b = $N08->appendChild($dom->createElement('pFCPSTRet',       number_format((float)$this->pFCPST, 2, ".", "")));
                    //$_valor_fcpst = $this->vBCFCPST * ($this->pFCPST / 100);
                    $this->pFCPSTRet = (float)$this->pFCPST;
                    $this->vBCFCPSTRet= (float)$this->vBCFCPST;
                    /**
                     * Clientes que n�o possuem o campo VFCP preenchido o sistema calculava,
                     * Ao mudarmos a regra passou a gerar um problema para o GP, ent�o mantivemos a regra anterior.
                     */
                    if ((float)$this->vFCP > 0) {
                        $this->vFCPSTRet = (float)$this->vFCP;
                    } elseif ($this->vFCPST > 0) {
                        $this->vFCPSTRet = (float)$this->vFCPST;
                    }
                    //$N27d = $N08->appendChild($dom->createElement('vFCPSTRet',       number_format($this->vFCPSTRet, 2, ".", "")));
                    $_xml_ordem["N27d"] = ['vFCPSTRet'=>number_format((float)$this->vFCPSTRet, 2, ".", "")];
                }
                //Ajusto a ordem
                ksort($_xml_ordem);
                foreach ($_xml_ordem as $key => $value) {
                    $N = $N08->appendChild($dom->createElement(key($value), current($value)));
                }
                break;
            /**
             * NT2023001-1
             */
            case '02' :
            case '15' :
            case '53' :
            case '61' :
                $N08 = $N01->appendChild($dom->createElement('ICMS'.$this->CST));
                $N11 = $N08->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N08->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));

                /**
                 * ICMS monof�sico pr�prio
                 */
                //Quantidades
                if(!empty($this->qBCMono) && $this->qBCMono > 0){
                    $N08->appendChild($dom->createElement('qBCMono', number_format((float)$this->qBCMono, 4, ".", "")));
                }
                if(!empty($this->adRemICMS) && $this->adRemICMS > 0){
                    $N08->appendChild($dom->createElement('adRemICMS', number_format((float)$this->adRemICMS, 4, ".", "")));
                }
                if(!empty($this->vICMSMono) && $this->vICMSMono > 0){
                    $N08->appendChild($dom->createElement('vICMSMono', number_format((float)$this->vICMSMono, 2, ".", "")));
                }

                /**
                 * ICMS monof�sico sujeito a reten��o
                 */
                if(!empty($this->qBCMonoReten) && $this->qBCMonoReten > 0){
                    $N08->appendChild($dom->createElement('qBCMonoReten', number_format((float)$this->qBCMonoReten, 4, ".", "")));
                }
                if(!empty($this->adRemICMSReten) && $this->adRemICMSReten > 0){
                    $N08->appendChild($dom->createElement('adRemICMSReten', number_format((float)$this->adRemICMSReten, 4, ".", "")));
                }
                if(!empty($this->vICMSMonoReten) && $this->vICMSMonoReten > 0){
                    $N08->appendChild($dom->createElement('vICMSMonoReten', number_format((float)$this->vICMSMonoReten, 2, ".", "")));
                }

                /**
                 * ICMS monof�sico retido anteriormente
                 */
                //qBCMonoRet = Mesmo valor da tag qCom
                if(!empty($this->qBCMonoRet) && $this->qBCMonoRet > 0){
                    $N08->appendChild($dom->createElement('qBCMonoRet', number_format((float)$this->qBCMonoRet, 4, ".", "")));
                }
                //adRemICMSRet = Buscar do cadastro de mercadorai info estendida tipo 51
                if(!empty($this->adRemICMSRet) && $this->adRemICMSRet > 0){
                    $N08->appendChild($dom->createElement('adRemICMSRet', number_format((float)$this->adRemICMSRet, 4, ".", "")));
                }
                //vICMSMonoRet = qBCMonoRet x adRemICMSRet
                if(!empty($this->qBCMonoRet) && !empty($this->adRemICMSRet) ){
                    $N08->appendChild($dom->createElement('vICMSMonoRet', number_format((float)$this->vICMSMonoRet, 2, ".", "")));
                }

                if(!empty($this->vICMSMonoOp) && $this->vICMSMonoOp > 0){
                    $N08->appendChild($dom->createElement('vICMSMonoOp', number_format((float)$this->vICMSMonoOp, 2, ".", "")));
                }
                if(!empty($this->vICMSMonoDif) && $this->vICMSMonoDif > 0){
                    $N08->appendChild($dom->createElement('vICMSMonoDif', number_format((float)$this->vICMSMonoDif, 2, ".", "")));
                }

                //Montar pRedAdRem??? Ver com a J�ssica...
                break;
            case '70' :
                $N09 = $N01->appendChild($dom->createElement('ICMS70'));
                $N11 = $N09->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N09->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = $N09->appendChild($dom->createElement('modBC',       $this->modBC));
                $N14 = $N09->appendChild($dom->createElement('pRedBC',      number_format((float)$this->pRedBC, 4, ".", "")));
                $N15 = $N09->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $N16 = $N09->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
                $N17 = $N09->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")));

                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17a = $N09->appendChild($dom->createElement('vBCFCP',       number_format((float)$this->vBCFCP, 2, ".", "")));
                    $N17b = $N09->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N09->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }

                $N18 = $N09->appendChild($dom->createElement('modBCST',     $this->modBCST));
                $N19 = (isset($this->pMVAST))   ? $N09->appendChild($dom->createElement('pMVAST',      number_format((float)$this->pMVAST, 2, ".", "")))   : null;
                $N20 = (isset($this->pRedBCST)) ? $N09->appendChild($dom->createElement('pRedBCST',    number_format((float)$this->pRedBCST, 2, ".", ""))) : null;
                $N21 = $N09->appendChild($dom->createElement('vBCST',       number_format((float)$this->vBCST, 2, ".", "")));
                $N22 = $N09->appendChild($dom->createElement('pICMSST',     number_format((float)$this->pICMSST, 2, ".", "")));
                $N23 = $N09->appendChild($dom->createElement('vICMSST',     number_format((float)$this->vICMSST, 2, ".", "")));

                if(isset($this->pFCPST) && $this->pFCPST > 0) {
                    $N17a = $N09->appendChild($dom->createElement('vBCFCPST',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    $N17b = $N09->appendChild($dom->createElement('pFCPST',       number_format((float)$this->pFCPST, 2, ".", "")));
                    $_valor_fcpst = ($this->vBCFCPST * ($this->pFCPST / 100) - $this->vFCP);
                    $N17c = $N09->appendChild($dom->createElement('vFCPST',       number_format((float)$_valor_fcpst, 2, ".", "")));
                }

                if($this->vICMSDeson > 0){
                    $N17d = $N09->appendChild($dom->createElement('vICMSDeson',  number_format((float)$this->vICMSDeson, 2, ".", "")));
                    $N17e = $N09->appendChild($dom->createElement('motDesICMS',  $this->motDesICMS));
                    if($this->indDeduzDeson == '0' || $this->indDeduzDeson == '1'){
                        $N17f = $N09->appendChild($dom->createElement('indDeduzDeson', $this->indDeduzDeson));
                    }
                }

                /**
                 * NT20005110-5
                 * BIT
                 * Jun.2021
                 */
                if($this->vICMSSTDeson>0) {
                    $N33a = $N09->appendChild($dom->createElement('vICMSSTDeson',  number_format((float)$this->vICMSSTDeson, 2, ".", "")));
                    $N33b = $N09->appendChild($dom->createElement('motDesICMSST',  $this->motDesICMSST));
                }

                break;

            case '90' :
                $N10 = $N01->appendChild($dom->createElement('ICMS90'));
                $N11 = $N10->appendChild($dom->createElement('orig',        $this->orig));
                $N12 = $N10->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $N13 = $N10->appendChild($dom->createElement('modBC',       $this->modBC));
                $N15 = $N10->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $N14 = (isset($this->pRedBC)) ? $N10->appendChild($dom->createElement('pRedBC',      number_format((float)$this->pRedBC, 4, ".", ""))) : null;
                $N16 = $N10->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
                $N17 = $N10->appendChild($dom->createElement('vICMS',       number_format((float)$this->vICMS, 2, ".", "")));
                if(isset($this->pFCP) && $this->vFCP > 0) {
                    $N17a = $N10->appendChild($dom->createElement('vBCFCP',       number_format((float)$this->vBCFCP, 2, ".", "")));
                    $N17b = $N10->appendChild($dom->createElement('pFCP',       number_format((float)$this->pFCP, 2, ".", "")));
                    $N17c = $N10->appendChild($dom->createElement('vFCP',       number_format((float)$this->vFCP, 2, ".", "")));
                }
                // algumas tags est�o comentadas pois, ocasionavam erro na emiss�o de NFCe MT
                //$N18 = $N10->appendChild($dom->createElement('modBCST',     $this->modBCST));
                //$N18 = $N10->appendChild($dom->createElement('modBCST',     (trim($this->modBCST) === '') ? 0 : $this->modBCST));
                $N19 = (isset($this->pMVAST))   ? $N10->appendChild($dom->createElement('pMVAST',      number_format((float)$this->pMVAST, 2, ".", "")))   : null;
                $N20 = (isset($this->pRedBCST)) ? $N10->appendChild($dom->createElement('pRedBCST',    number_format((float)$this->pRedBCST, 2, ".", ""))) : null;
                //$N21 = $N10->appendChild($dom->createElement('vBCST',       number_format((float)$this->vBCST, 2, ".", "")));
               // $N22 = $N10->appendChild($dom->createElement('pICMSST',     number_format((float)$this->pICMSST, 2, ".", "")));
                //$N23 = $N10->appendChild($dom->createElement('vICMSST',     number_format((float)$this->vICMSST, 2, ".", "")));

                if(isset($this->pFCPST) && $this->vICMSST > 0) {
                    $N17a = $N10->appendChild($dom->createElement('vBCFCPST',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    $N17b = $N10->appendChild($dom->createElement('pFCPST',       number_format((float)$this->pFCPST, 2, ".", "")));
                    $_valor_fcpst = ($this->vBCFCPST * ($this->pFCPST / 100)-$this->vFCP);
                    $N17c = $N10->appendChild($dom->createElement('vFCPST',       number_format((float)$_valor_fcpst, 2, ".", "")));
                }

                /**
                 * NT20005110-5
                 * BIT
                 * Jun.2021
                 */
                if($this->vICMSSTDeson>0) {
                    $N33a = $N10->appendChild($dom->createElement('vICMSSTDeson',  number_format((float)$this->vICMSSTDeson, 2, ".", "")));
                    $N33b = $N10->appendChild($dom->createElement('motDesICMSST',  $this->motDesICMSST));
                    if($this->indDeduzDeson == '0' || $this->indDeduzDeson == '1'){
                        $N33c = $N10->appendChild($dom->createElement('indDeduzDeson', $this->indDeduzDeson));
                    }
                }

                break;
            case '102' :
            case '300' :
            case '400' :
            case '500' :
               	$N10 = $N01->appendChild($dom->createElement('ICMSSN'. (($this->CST=='300' || $this->CST=='400') ? '102' : $this->CST)));
				$N11 = $N10->appendChild($dom->createElement('orig',        $this->orig));
				$N12 = $N10->appendChild($dom->createElement('CSOSN',         sprintf("%03d", $this->CST)));
                if(isset($this->pFCPST) && $this->pFCPST > 0) {
                    $N17b = $N10->appendChild($dom->createElement('pFCPST',       number_format((float)$this->pFCPST, 2, ".", "")));
                    $_valor_fcpst = $this->vBCFCPST * ($this->pFCPST / 100);
                    $N17c = $N10->appendChild($dom->createElement('vFCPST',       number_format((float)$_valor_fcpst, 2, ".", "")));
                    $N21 = $N10->appendChild($dom->createElement('vBCFCPSTRet',       number_format((float)$this->vBCFCPST, 2, ".", "")));
                    $N17c = $N10->appendChild($dom->createElement('pST',           number_format((float)$this->pFCPST, 2, ".", "")));
                }
                if(($GLOBALS['_VERSAO_NT'] & 2048) != 0 && $this->CST == '500' && !isset($N27)) {
                    if(!isset($N26)) {
                        $N26 = $N10->appendChild($dom->createElement('vBCSTRet',number_format((float)$this->vBCSTRet,2,".","")));
                    }
                    if(!isset($N26a)&&!isset($N17c)) {
                        $N26a = $N10->appendChild($dom->createElement('pST',number_format((float)$this->pST,2,".","")));
                    }
                    if(!isset($N26b)) {
                        $N26b = $N10->appendChild($dom->createElement('vICMSSubstituto',number_format((float)$this->vICMSSubstituto,2,".","")));
                    }
                    $N27 = $N10->appendChild($dom->createElement('vICMSSTRet', number_format((float)$this->vICMSSTRet, 2, ".", "")));
                }
                if(($GLOBALS['_VERSAO_NT'] & 2) != 0 && $this->CST == '500') {
                    $N34 = $N10->appendChild($dom->createElement('pRedBCEfet', number_format((float)$this->pRedBCEfet, 4, ".", "")));
                    $N35 = $N10->appendChild($dom->createElement('vBCEfet', number_format((float)$this->vBCEfet, 2, ".", "")));
                    $N36 = $N10->appendChild($dom->createElement('pICMSEfet', number_format((float)$this->pICMSEfet, 2, ".", "")));
                    $N37 = $N10->appendChild($dom->createElement('vICMSEfet', number_format((float)$this->vICMSEfet, 2, ".", "")));
                }
                /*if(($GLOBALS['_VERSAO_NT'] & 2) != 0) {
                    $N34 = $N10->appendChild($dom->createElement('pRedBCEfet', number_format((float)$this->pRedBCEfet, 2, ".", "")));
                    $N35 = $N10->appendChild($dom->createElement('vBCEfet', number_format((float)$this->vBCEfet, 2, ".", "")));
                    $N36 = $N10->appendChild($dom->createElement('pICMSEfet', number_format((float)$this->pICMSEfet, 2, ".", "")));
                    $N37 = $N10->appendChild($dom->createElement('vICMSEfet', number_format((float)$this->vICMSEfet, 2, ".", "")));
                }*/

			    break;
        } // fim switch

        return $N01;
    }

}


//ICMSUFDest
class ICMSUFDest {

    var $vBCUFDest;     // NA03 - Valor da BC do ICMS na UF de destino
    var $pFCPUFDest;    // NA05 - Percentual do ICMS relativo ao Fundo de Combate � Pobreza (FCP) na UF de destino
    var $pICMSUFDest;   // NA07 - Al�quota interna da UF de destino
    var $pICMSInter;    // NA09 - Al�quota interestadual das UF envolvidas
    var $pICMSInterPart;// NA11 - Percentual provis�rio de partilha do ICMS Interestadual
    var $vFCPUFDest;    // NA13 - Valor do ICMS relativo ao Fundo de Combate � Pobreza (FCP) da UF de destino
    var $vICMSUFDest;   // NA15 - Valor do ICMS Interestadual para a UF de destino
    var $vICMSUFRemet;  // NA17 - Valor do ICMS Interestadual para a UF do remetente

    function __construct() {
    }

    function get_xml($dom) {
        $NA01 = $dom->appendChild($dom->createElement('ICMSUFDest'));

        $NA03 = $NA01->appendChild($dom->createElement('vBCUFDest',      number_format((float)$this->vBCUFDest, 2, ".", "")));
        if($this->vFCPUFDest > 0) {

            $_valor_BCFCPUFDest = $this->vBCUFDest;
            $NA03A = $NA01->appendChild($dom->createElement('vBCFCPUFDest',     number_format((float)$_valor_BCFCPUFDest, 2, ".", "")));
        }
        $NA05 = $NA01->appendChild($dom->createElement('pFCPUFDest',     number_format((float)$this->pFCPUFDest, 2, ".", "")));
        $NA07 = $NA01->appendChild($dom->createElement('pICMSUFDest',    number_format((float)$this->pICMSUFDest, 2, ".", "")));
        $NA09 = $NA01->appendChild($dom->createElement('pICMSInter',     number_format((float)$this->pICMSInter, 2, ".", "")));
        $NA11 = $NA01->appendChild($dom->createElement('pICMSInterPart', number_format((float)$this->pICMSInterPart, 2, ".", "")));

        $NA13 = $NA01->appendChild($dom->createElement('vFCPUFDest',     number_format((float)$this->vFCPUFDest, 2, ".", "")));
        $NA15 = $NA01->appendChild($dom->createElement('vICMSUFDest',    number_format((float)$this->vICMSUFDest, 2, ".", "")));
        $NA17 = $NA01->appendChild($dom->createElement('vICMSUFRemet',   number_format((float)$this->vICMSUFRemet, 2, ".", "")));
        return $NA01;
    }

}


// O01
class IPI {

    var $cIEnq;     // O02 - classe de IPI para cigarros e bebidas
    var $CNPJProd;  // O03 - CNPJ do produtor quando diferente do emitente
    var $cSelo;     // O04 - c�digo do selo de controle do IPI
    var $qSelo;     // O05 - quantidade de selo de controle
    var $cEnq;      // O06 - c�digo de enquadramento legal do IPI
    var $CST;       // O09 - c�digo da situa��o tribut�ria do IPI
    var $vBC;       // O10 - valor da BC do IPI
    var $qUnid;     // O11 - quantidade total na unidade padr�o para tributa��o
    var $vUnid;     // O12 - valor por unidade tribut�vel
    var $pIPI;      // O13 - al�quota do IPI
    var $vIPI;      // O14 - valor do IPI

    function __construct() {
    }

    function get_xml($dom) {

        $O01 = $dom->appendChild($dom->createElement('IPI'));
        $O02 = (!empty($this->cIEnq))    ? $O01->appendChild($dom->createElement('cIEnq',       $this->cIEnq))      : null;
        $O03 = (!empty($this->CNPJProd)) ? $O01->appendChild($dom->createElement('CNPJProd',    sprintf("%014s", $this->CNPJProd)))   : null;
        $O04 = (!empty($this->cSelo))    ? $O01->appendChild($dom->createElement('cSelo',       $this->cSelo))      : null;
        $O05 = (isset($this->qSelo))    ? $O01->appendChild($dom->createElement('qSelo',       $this->qSelo))      : null;
        $O06 = $O01->appendChild($dom->createElement('cEnq',        $this->cEnq));

        switch ($this->CST) {

            case '00' :
            case '49' :
            case '50' :
            case '99' :
                // O07 - grupo do CST 00,49,50 e 99
                $O07 = $O01->appendChild($dom->createElement('IPITrib'));
                $O09 = $O07->appendChild($dom->createElement('CST',     sprintf("%02d", $this->CST)));
                if (isset($this->vBC) && isset($this->pIPI)) {
                    $O10 = $O07->appendChild($dom->createElement('vBC',     number_format((float)$this->vBC, 2, ".", "")));
                    $O13 = $O07->appendChild($dom->createElement('pIPI',    number_format((float)$this->pIPI, 2, ".", "")));
                } else {
                    $O11 = $O07->appendChild($dom->createElement('qUnid',   number_format((float)$this->qUnid, 4, ".", "")));
                    $O12 = $O07->appendChild($dom->createElement('vUnid',   number_format((float)$this->vUnid, 4, ".", "")));
                }
                $O14 = $O07->appendChild($dom->createElement('vIPI',    number_format((float)$this->vIPI, 2, ".", "")));
                break;

            case '01' :
            case '02' :
            case '03' :
            case '04' :
            case '05' :
            case '51' :
            case '52' :
            case '53' :
            case '54' :
            case '55' :
                // O08 - grupo do CST 01,02,03,04,05,51,52,53,54 e 55
                $O08 = $O01->appendChild($dom->createElement('IPINT'));
                $O09 = $O08->appendChild($dom->createElement('CST',     sprintf("%02d", $this->CST)));
                break;
        }

        return $O01;
    }

}

// P01
class II {

    var $vBC;       // P02 - valor da BC do imposto de importa��o
    var $vDespAdu;  // P03 - valor das despesas aduaneiras
    var $vII;       // P04 - valor do imposto de importa��o
    var $vIOF;      // P05 - valor do imposto sobre opera��es financeiras

    function __construct() {
    }

    function get_xml($dom) {
        $P01 = $dom->appendChild($dom->createElement('II'));
        $P02 = $P01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
        $P03 = $P01->appendChild($dom->createElement('vDespAdu',    number_format((float)$this->vDespAdu, 2, ".", "")));
        $P04 = $P01->appendChild($dom->createElement('vII',         number_format((float)$this->vII, 2, ".", "")));
        $P05 = $P01->appendChild($dom->createElement('vIOF',        number_format((float)$this->vIOF, 2, ".", "")));
        return $P01;
    }

}

// Q01
class PIS {

    var $CST;       // Q06 - c�digo de situa��o tribut�ria do PIS
    var $vBC;       // Q07 - valor da BC do PIS
    var $pPIS;      // Q08 - al�quota do PIS
    var $vPIS;      // Q09 - valor do PIS
    var $qBCProd;   // Q10 - quantidade vendida
    var $vAliqProd; // Q11 - al�quota do PIS (em reais)

    function __construct() {
    }

    function get_xml($dom) {

        $Q01 = $dom->appendChild($dom->createElement('PIS'));

        switch ($this->CST) {

            case '01' :
            case '02' :
                $Q02 = $Q01->appendChild($dom->createElement('PISAliq'));
                $Q06 = $Q02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $Q07 = $Q02->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $Q08 = $Q02->appendChild($dom->createElement('pPIS',        number_format((float)$this->pPIS, 4, ".", "")));
                $Q09 = $Q02->appendChild($dom->createElement('vPIS',        number_format((float)$this->vPIS, 2, ".", "")));
                break;

            case '03' :
                $Q03 = $Q01->appendChild($dom->createElement('PISQtde'));
                $Q06 = $Q03->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $Q10 = $Q03->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                $Q11 = $Q03->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                $Q09 = $Q03->appendChild($dom->createElement('vPIS',        number_format((float)$this->vPIS, 2, ".", "")));
                break;

            case '04' :
            case '05' :
            case '06' :
            case '07' :
            case '08' :
            case '09' :
                $Q04 = $Q01->appendChild($dom->createElement('PISNT'));
                $Q06 = $Q04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                break;
            case '75' :
                if($_SESSION['flg_devolucao_usa_regra_especifica'] == 1
                    && ($_SESSION['cst_pis_dev_cupom'] == 0 || $_SESSION['cst_pis_dev_cupom'] = -1)) {
                    $Q05 = $Q01->appendChild($dom->createElement('PISOutr'));
                    $Q06 = $Q05->appendChild($dom->createElement('CST', $this->CST));
                } else {
                    $Q05 = $Q01->appendChild($dom->createElement('PISOutr'));
                    $Q06 = $Q05->appendChild($dom->createElement('CST',         sprintf("%02d", "99")));
                }

                if (isset($this->vBC) && $this->vBC > 0 && isset($this->pPIS) && $this->pPIS > 0) {
                    $Q07 = $Q05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                    $Q08 = $Q05->appendChild($dom->createElement('pPIS',        number_format((float)$this->pPIS, 4, ".", "")));
                } else {
                    $Q10 = $Q05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                    $Q11 = $Q05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                }
                $Q09 = $Q05->appendChild($dom->createElement('vPIS',        number_format((float)$this->vPIS, 2, ".", "")));
                break;

            case '49' :
                $Q05 = $Q01->appendChild($dom->createElement('PISOutr'));
                $Q06 = $Q05->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $Q07 = $Q05->appendChild($dom->createElement('vBC',         number_format(0.00, 2, ".", "")));
                $Q08 = $Q05->appendChild($dom->createElement('pPIS',        number_format(0.00, 4, ".", "")));
                $Q09 = $Q05->appendChild($dom->createElement('vPIS',         number_format((float)$this->vPIS, 2, ".", "")));
                break;
            case '50' :
            case '51' :
            case '52' :
            case '53' :
            case '54' :
            case '55' :
            case '56' :
            case '60' :
            case '61' :
            case '63' :
            case '64' :
            case '65' :
            case '66' :
            case '67' :
            case '70' :
            case '71' :
            case '72' :
            case '73' :
            case '74' :
            case '98' :
            case '99' :
                $Q05 = $Q01->appendChild($dom->createElement('PISOutr'));
                $Q06 = $Q05->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                if (isset($this->vBC) && isset($this->pPIS)) {
                    $Q07 = $Q05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                    $Q08 = $Q05->appendChild($dom->createElement('pPIS',        number_format((float)$this->pPIS, 4, ".", "")));
                } else {
                    $Q10 = $Q05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                    $Q11 = $Q05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                }
                $Q09 = $Q05->appendChild($dom->createElement('vPIS',        number_format((float)$this->vPIS, 2, ".", "")));
                break;

        } // fim switch

        return $Q01;
    }

}

/**
 * SQM-1831
 * GRUPO UB - Imposto de IS, IBS, CBS
 */

class IS {

    var $CSTIS;        // UB02 - c�digo de situa��o tribut�ria do Imposto Seletivo
    var $cClassTribIS; // UB03 - C�digo de Classifica��o Tribut�ria do Imposto Seletivo
    var $vBCIS;        // UB05 - Base de Calculo do Imposto Seletivo
    var $pIS;          // UB06 - Aliquota do Imposto Seletivo
    var $pISEspec;     // UB07 - Aliquota especifica do Imposto Seletivo
    var $uTrib;        // UB09 - Unidade de Medida Tributavel
    var $qTrib;        // UB10 - Quantidade Tributavel
    var $vIS;          // UB11 - Valor do Imposto Seletivo

    function __construct() {
    }

    function get_xml($dom) {

        $UB01 = $dom->appendChild($dom->createElement('IS'));
        $UB02 = !empty($this->CSTIS) ? $UB01->appendChild($dom->createElement('CSTIS', $this->CSTIS)) : null;
        $UB03 = !empty($this->cClassTribIS) ? $UB01->appendChild($dom->createElement('cClassTribIS', $this->cClassTribIS)) : null;
        $UB05 = !empty($this->vBCIS) ? $UB01->appendChild($dom->createElement('vBCIS', number_format((float)$this->vBCIS, 2, ".", ""))) : null;
        $UB06 = !empty($this->pIS) ? $UB01->appendChild($dom->createElement('pIS', number_format((float)$this->pIS, 4,".", ""))) : null;
        $UB07 = !empty($this->pISEspec) ? $UB01->appendChild($dom->createElement('pISEspec', number_format((float)$this->pISEspec, 4, ".", ""))) : null;
        $UB09 = !empty($this->uTrib) ? $UB01->appendChild($dom->createElement('uTrib', $this->uTrib)) : null;
        $UB10 = !empty($this->qTrib) ? $UB01->appendChild($dom->createElement('qTrib', $this->qTrib)) : null;
        $UB11 = !empty($this->vIS) ? $UB01->appendChild($dom->createElement('vIS', number_format((float)$this->vIS, 2, ".", ""))) : null;

        return $UB01;
    }

}

//W31
class ISTot {

    var $vIS;        // W33 - Total do imposto seletivo

    function __construct() {
    }

    function get_xml($dom) {

        $W31 = $dom->appendChild($dom->createElement('ISTot'));
        $W33 = $W31->appendChild($dom->createElement('vIS', number_format((float)$this->vIS, 2, ".", "")));

        return $W31;
    }

}

//UB01
class IBSCBS {

    var $CST;                       // UB13 - C�digo de situa��o tribut�ria do IBS/CBS
    var $cClassTrib;                // UB14 - C�digo de Classifica��o Tribut�ria do IBS
    var $vBC;                       // UB16 - Base de Calculo do IBS/CBS
    var $pIBSUF;                    // UB18 - Al�quota do IBS de compet�ncia das UF
    var $pDifUF;                    // UB22 - Percentual do diferimento da UF
    var $vDifUF;                    // UB23 - Valor do diferimento da UF
    var $pRedAliqUF;                // UB27 - Percentual da redu��o de al�quota do cClassTrib da UF
    var $pAliqEfetUF;               // UB28 - Al�quota Efetiva do IBS de compet�ncia das UF que ser� aplicada a Base de C�lculo
    var $vIBSUF;                    // UB35 - Valor do IBS de compet�ncia da UF
    var $pIBSMun;                   // UB37 - Al�quota do IBS de compet�ncia do Munic�pio
    var $pDifMun;                   // UB41 - Percentual do diferimento do Munic�pio
    var $vDifMun;                   // UB42 - Valor do diferimento do Munic�pio
    var $pRedAliqMun;               // UB46 - Percentual da redu��o de al�quota do cClassTrib do Munic�pio
    var $pAliqEfetMun;              // UB47 - Al�quota Efetiva do IBS de compet�ncia do Munic�pio que ser� aplicada a Base de C�lculo
    var $vIBSMun;                   // UB54 - Valor do IBS de compet�ncia do Munic�pio
    var $pCBS;                      // UB56 - Al�quota da CBS
    var $pDifCBS;                   // UB60 - Percentual do diferimento do CBS
    var $vDifCBS;                   // UB61 - Valor do diferimento do CBS
    var $pRedAliqCBS;               // UB65 - Percentual da redu��o de al�quota do cClassTrib do CBS
    var $pAliqEfetCBS;              // UB66 - Al�quota Efetiva do CBS que ser� aplicada a Base de C�lculo
    var $vCBS;                      // UB67 - Valor da CBS
    var $cCredPresIBS;              // UB74 - C�digo de Classifica��o do Cr�dito Presumido do IBS
    var $pCredPresIBS;              // UB75 - Percentual do Cr�dito Presumido do IBS
    var $vCredPresIBS;              // UB76 - Valor do Cr�dito Presumido do IBS
    var $vCredPresCondSusIBS;       // UB77 - Valor do Cr�dito Presumido em condi��o suspensiva do IBS
    var $cCredPresCBS;              // UB79 - C�digo de Classifica��o do Cr�dito Presumido do CBS
    var $pCredPresCBS;              // UB80 - Percentual do Cr�dito Presumido do CBS
    var $vCredPresCBS;              // UB81 - Valor do Cr�dito Presumido do CBS
    var $vCredPresCondSusCBS;       // UB82 - Valor do Cr�dito Presumido em condi��o suspensiva do CBS

    var $CSTReg;                    // UB69 - C�digo de Situa��o Tribut�ria do IBS/CBS
    var $cClassTribReg;             // UB70 - C�digo de Classifica��o Tribut�ria do IBS/CBS
    var $pAliqEfetRegIBSUF;         // UB71 - Valor da al�quota do IBS da UF
    var $vTribRegIBSUF;             // UB72 - Valor do tributo do IBS da UF
    var $pAliqEfetRegIBSMun;        // UB72a - Valor da al�quota do IBS do Munic�pio
    var $vTribRegIBSMun;            // UB72b - Valor do tributo do IBS do Munic�pio
    var $pAliqEfetRegCBS;           // UB72c - Valor da al�quota do CBS
    var $vTribRegCBS;               // UB72d - Valor do tributo do CBS
    var $vIBS;                      // UB54a - Valor do IBS (soma de vIBSUF e vIBSMun).

    function __construct() {
    }

    function get_xml($dom) {

        $UB12 = $dom->appendChild($dom->createElement('IBSCBS'));
        $UB13 = !empty($this->CST) ? $UB12->appendChild($dom->createElement('CST', $this->CST)) : null;
        $UB14 = !empty($this->cClassTrib) ? $UB12->appendChild($dom->createElement('cClassTrib', $this->cClassTrib)) : null;

        if($this->vBC!=null && $this->pIBSUF!=null && $this->pIBSMun!=null){
            $UB15 = $UB12->appendChild($dom->createElement('gIBSCBS'));
            $UB16 = $UB15->appendChild($dom->createElement('vBC', number_format((float)$this->vBC, 2, ".", "")));
            $UB17 = $UB15->appendChild($dom->createElement('gIBSUF'));
            $UB18 = $UB17->appendChild($dom->createElement('pIBSUF', number_format((float)$this->pIBSUF, 4, ".", "")));

            if($this->pDifUF!=null){
                $UB21 = $UB17->appendChild($dom->createElement('gDif'));
                $UB22 = $UB21->appendChild($dom->createElement('pDif', number_format((float)$this->pDifUF, 4, ".", "")));
                $UB23 = $UB21->appendChild($dom->createElement('vDif', number_format((float)$this->vDifUF, 2, ".", "")));
            }

            if($this->pRedAliqUF!=null){
                $UB26 = $UB17->appendChild($dom->createElement('gRed'));
                $UB27 = $UB26->appendChild($dom->createElement('pRedAliq', number_format((float)$this->pRedAliqUF, 4, ".", "")));
                $UB28 = $UB26->appendChild($dom->createElement('pAliqEfet', number_format((float)$this->pAliqEfetUF, 4, ".", "")));
            }

            $UB35 = $UB17->appendChild($dom->createElement('vIBSUF', number_format((float)$this->vIBSUF, 2, ".", "")));
            $UB36 = $UB15->appendChild($dom->createElement('gIBSMun'));
            $UB37 = $UB36->appendChild($dom->createElement('pIBSMun', number_format((float)$this->pIBSMun, 4, ".", "")));

            if($this->pDifMun!=null){
                $UB40 = $UB36->appendChild($dom->createElement('gDif'));
                $UB41 = $UB40->appendChild($dom->createElement('pDif', number_format((float)$this->pDifMun, 4, ".", "")));
                $UB42 = $UB40->appendChild($dom->createElement('vDif', number_format((float)$this->vDifMun, 2, ".", "")));
            }

            if($this->pRedAliqMun!=null){
                $UB45 = $UB36->appendChild($dom->createElement('gRed'));
                $UB46 = $UB45->appendChild($dom->createElement('pRedAliq', number_format((float)$this->pRedAliqMun, 4, ".", "")));
                $UB47 = $UB45->appendChild($dom->createElement('pAliqEfet', number_format((float)$this->pAliqEfetMun, 4, ".", "")));
            }

            $UB54 = $UB36->appendChild($dom->createElement('vIBSMun', number_format((float)$this->vIBSMun, 2, ".", "")));
            $UB54a = $UB15->appendChild($dom->createElement('vIBS', number_format((float)$this->vIBS, 2, ".", "")));

        }

        if($this->vBC!=null && $this->pCBS!=null){
            $UB55 = $UB15->appendChild($dom->createElement('gCBS'));
            $UB56 = $UB55->appendChild($dom->createElement('pCBS', number_format((float)$this->pCBS, 4, ".", "")));

            if($this->pDifCBS!=null){
                $UB59 = $UB55->appendChild($dom->createElement('gDif'));
                $UB60 = $UB59->appendChild($dom->createElement('pDif', number_format((float)$this->pDifCBS, 4, ".", "")));
                $UB61 = $UB59->appendChild($dom->createElement('vDif', number_format((float)$this->vDifCBS, 2, ".", "")));
            }

            if($this->pRedAliqCBS!=null){
                $UB64 = $UB55->appendChild($dom->createElement('gRed'));
                $UB65 = $UB64->appendChild($dom->createElement('pRedAliq', number_format((float)$this->pRedAliqCBS, 4, ".", "")));
                $UB66 = $UB64->appendChild($dom->createElement('pAliqEfet', number_format((float)$this->pAliqEfetCBS, 4, ".", "")));
            }

            $UB67 = $UB55->appendChild($dom->createElement('vCBS', number_format((float)$this->vCBS, 2, ".", "")));
        }

        if($this->CSTReg!=null && $this->cClassTribReg!=null){
            $UB68 = $UB15->appendChild($dom->createElement('gTribRegular'));
            $UB69 = $UB68->appendChild($dom->createElement('CSTReg', $this->CSTReg));
            $UB70 = $UB68->appendChild($dom->createElement('cClassTribReg', $this->cClassTribReg));
            $UB71 = $UB68->appendChild($dom->createElement('pAliqEfetRegIBSUF', number_format((float)$this->pAliqEfetRegIBSUF, 4, ".", "")));
            $UB72 = $UB68->appendChild($dom->createElement('vTribRegIBSUF', number_format((float)$this->vTribRegIBSUF, 2, ".", "")));
            $UB72a = $UB68->appendChild($dom->createElement('pAliqEfetRegIBSMun', number_format((float)$this->pAliqEfetRegIBSMun, 4, ".", "")));
            $UB72b = $UB68->appendChild($dom->createElement('vTribRegIBSMun', number_format((float)$this->vTribRegIBSMun, 2, ".", "")));
            $UB72c = $UB68->appendChild($dom->createElement('pAliqEfetRegCBS', number_format((float)$this->pAliqEfetRegCBS, 4, ".", "")));
            $UB72d = $UB68->appendChild($dom->createElement('vTribRegCBS', number_format((float)$this->vTribRegCBS, 2, ".", "")));
        }

        if($this->cCredPresIBS!=null && $this->pCredPresIBS!=null){
            $UB73 = $UB15->appendChild($dom->createElement('gIBSCredPres'));
            $UB74 = $UB73->appendChild($dom->createElement('cCredPres', $this->cCredPresIBS));
            $UB75 = $UB73->appendChild($dom->createElement('pCredPres', number_format((float)$this->pCredPresIBS, 4, ".", "")));
            $UB76 = $UB73->appendChild($dom->createElement('vCredPres', number_format((float)$this->vCredPresIBS, 2, ".", "")));
            $UB77 = $UB73->appendChild($dom->createElement('vCredPresCondSus', number_format((float)$this->vCredPresCondSusIBS, 2, ".", "")));
        }

        if($this->cCredPresCBS!=null && $this->pCredPresCBS!=null){
            $UB78 = $UB15->appendChild($dom->createElement('gCBSCredPres'));
            $UB79 = $UB78->appendChild($dom->createElement('cCredPres', $this->cCredPresCBS));
            $UB80 = $UB78->appendChild($dom->createElement('pCredPres', number_format((float)$this->pCredPresCBS, 4, ".", "")));
            $UB81 = $UB78->appendChild($dom->createElement('vCredPres', number_format((float)$this->vCredPresCBS, 2, ".", "")));
            $UB82 = $UB78->appendChild($dom->createElement('vCredPresCondSus', number_format((float)$this->vCredPresCondSusCBS, 2, ".", "")));
        }

        return $UB12;
    }

}

//W34
class IBSCBSTot {

    var $vBCIBSCBS;             // W35 - Valor total da BC do IBS e da CBS
    var $vDifUF;                // W38 - Valor total do diferimento da UF
    var $vDevTribUF;            // W39 - Valor total de devolu��o de tributos da UF
    var $vIBSUF;                // W41 - Valor total do IBS da UF
    var $vDifMun;               // W43 - Valor total do diferimento do Municipio
    var $vDevTribMun;           // W39 - Valor total de devolu��o de tributos do Municipio
    var $vIBSMun;               // W41 - Valor total do IBS do Municipio
    var $vIBS;                  // W47 - Valor total do IBS
    var $vCredPresIBS;          // W48 - Valor total do cr�dito presumido
    var $vCredPresCondSusIBS;   // W49 - Valor total do cr�dito presumido em condi��o suspensiva
    var $vDifCBS;               // W53 - Valor total do diferimento do CBS
    var $vDevTribCBS;           // W54 - Valor total de devolu��o de tributos do CBS
    var $vCBS;                  // W56 - Valor total do CBS


    function __construct() {
    }

    function get_xml($dom) {

        $W34 = $dom->appendChild($dom->createElement('IBSCBSTot'));
        $W35 = $W34->appendChild($dom->createElement('vBCIBSCBS', number_format((float)$this->vBCIBSCBS, 2, ".", "")));
        $W36 = $W34->appendChild($dom->createElement('gIBS'));
        $W37 = $W36->appendChild($dom->createElement('gIBSUF'));
        $W38 = $W37->appendChild($dom->createElement('vDif', number_format((float)$this->vDifUF, 2, ".", "")));
        $W39 = $W37->appendChild($dom->createElement('vDevTrib', number_format((float)$this->vDevTribUF, 2, ".", "")));
        $W41 = $W37->appendChild($dom->createElement('vIBSUF',number_format((float) $this->vIBSUF, 2, ".", "")));
        $W42 = $W36->appendChild($dom->createElement('gIBSMun'));
        $W43 = $W42->appendChild($dom->createElement('vDif', number_format((float)$this->vDifMun, 2, ".", "")));
        $W44 = $W42->appendChild($dom->createElement('vDevTrib', number_format((float)$this->vDevTribMun, 2, ".", "")));
        $W46 = $W42->appendChild($dom->createElement('vIBSMun', number_format((float)$this->vIBSMun, 2, ".", "")));
        $W47 = $W36->appendChild($dom->createElement('vIBS', number_format((float)$this->vIBS, 2, ".", "")));
        $W48 = $W36->appendChild($dom->createElement('vCredPres', number_format((float)$this->vCredPresIBS, 2, ".", "")));
        $W49 = $W36->appendChild($dom->createElement('vCredPresCondSus', number_format((float)$this->vCredPresCondSusIBS, 2, ".", "")));
        $W50 = $W34->appendChild($dom->createElement('gCBS'));
        $W53 = $W50->appendChild($dom->createElement('vDif', number_format((float)$this->vDifCBS, 2, ".", "")));
        $W54 = $W50->appendChild($dom->createElement('vDevTrib', number_format((float)$this->vDevTribCBS, 2, ".", "")));
        $W56 = $W50->appendChild($dom->createElement('vCBS', number_format((float)$this->vCBS, 2, ".", "")));
        $W56a = $W50->appendChild($dom->createElement('vCredPres', number_format((float)$this->vCredPresCBS, 2, ".", "")));
        $W56b = $W50->appendChild($dom->createElement('vCredPresCondSus', number_format((float)$this->vCredPresCondSusCBS, 2, ".", "")));

        return $W34;
    }

}

class vNFTot {

    var $vNFTot;        // W60 - Valor total da NF-e com IBS / CBS / IS

    function __construct() {
    }

    function get_xml($dom) {

        $W60 = $dom->createElement('vNFTot', number_format((float)$this->vNFTot, 2, ".", ""));

        return $W60;
    }

}

// R01
class PISST {

    var $vBC;       // R02 - valor da BC do PIS
    var $pPIS;      // R03 - al�quota do PIS
    var $qBCProd;   // R04 - quantidade vendida
    var $vAliqProd; // R05 - al�quota do PIS (em reais)
    var $vPIS;      // R06 - valor do PIS

    function __construct() {
    }

    function get_xml($dom) {
        $R01 = $dom->appendChild($dom->createElement('PISST'));
        if (isset($this->vBC) && $this->vBC > 0 && isset($this->pPIS) && $this->pPIS > 0) {
            $R02 = $R01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
            $R03 = $R01->appendChild($dom->createElement('pPIS',        number_format((float)$this->pPIS, 4, ".", "")));
        } else {
            $R04 = $R01->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
            $R05 = $R01->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
        }
        $R06 = $R01->appendChild($dom->createElement('vPIS',        number_format((float)$this->vPIS, 2, ".", "")));
        return $R01;
    }

}

// S01
class COFINS {

    var $CST;       // S06 - c�digo de situa��o tribut�ria do COFINS
    var $vBC;       // S07 - valor da BC do COFINS
    var $pCOFINS;   // S08 - al�quota do COFINS (em percentual)
    var $qBCProd;   // S09 - quantidade vendida
    var $vAliqProd; // S10 - al�quota do COFINS (em reais)
    var $vCOFINS;   // S11 - valor do COFINS

    function __construct() {
    }

    function get_xml($dom) {
        $S01 = $dom->appendChild($dom->createElement('COFINS'));

        switch ($this->CST) {

            case '01' :
            case '02' :
                $S02 = $S01->appendChild($dom->createElement('COFINSAliq'));
                $S06 = $S02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $S07 = $S02->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                $S08 = $S02->appendChild($dom->createElement('pCOFINS',     number_format((float)$this->pCOFINS, 4, ".", "")));
                $S11 = $S02->appendChild($dom->createElement('vCOFINS',     number_format((float)$this->vCOFINS, 2, ".", "")));
                break;

            case '03' :
                $S03 = $S01->appendChild($dom->createElement('COFINSQtde'));
                $S06 = $S03->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $S09 = $S03->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                $S10 = $S03->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                $S11 = $S03->appendChild($dom->createElement('vCOFINS',     number_format((float)$this->vCOFINS, 2, ".", "")));
                break;

            case '04' :
            case '05' :
            case '06' :
            case '07' :
            case '08' :
            case '09' :
                $S04 = $S01->appendChild($dom->createElement('COFINSNT'));
                $S06 = $S04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                break;
            case '75' :
                if($_SESSION['flg_devolucao_usa_regra_especifica'] == 1
                    && ($_SESSION['cst_cofins_dev_cupom'] == 0 || $_SESSION['cst_cofins_dev_cupom'] = -1)) {
                    $S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
                    $S06 = $S05->appendChild($dom->createElement('CST', $this->CST));
                } else {
                    $S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
                    $S06 = $S05->appendChild($dom->createElement('CST', sprintf("%02d", "99")));
                }
                if (isset($this->vBC) && $this->vBC > 0 && isset($this->pPIS) && $this->pPIS > 0) {
                    $S07 = $S05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                    $S08 = $S05->appendChild($dom->createElement('pCOFINS',        number_format((float)$this->pCOFINS, 4, ".", "")));
                } else {
                    $S10 = $S05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                    $S11 = $S05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                }
                $S09 = $S05->appendChild($dom->createElement('vCOFINS',        number_format((float)$this->vCOFINS, 2, ".", "")));
                break;

            case '49' :
                $S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
                $S06 = $S05->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                $S07 = $S05->appendChild($dom->createElement('vBC',         number_format(0.00, 2, ".", "")));
                $S08 = $S05->appendChild($dom->createElement('pCOFINS',     number_format(0.00, 4, ".", "")));
                $S11 = $S05->appendChild($dom->createElement('vCOFINS',     number_format((float)$this->vCOFINS, 2, ".", "")));
                break;
            case '50' :
            case '51' :
            case '52' :
            case '53' :
            case '54' :
            case '55' :
            case '56' :
            case '60' :
            case '61' :
            case '61' :
            case '63' :
            case '64' :
            case '65' :
            case '66' :
            case '67' :
            case '70' :
            case '71' :
            case '72' :
            case '73' :
            case '74' :
            case '98' :
            case '99' :
                $S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
                $S06 = $S05->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
                if (isset($this->vBC) && isset($this->pCOFINS)) {
                    $S07 = $S05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
                    $S08 = $S05->appendChild($dom->createElement('pCOFINS',     number_format((float)$this->pCOFINS, 4, ".", "")));
                } else {
                    $S09 = $S05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
                    $S10 = $S05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
                }
                $S11 = $S05->appendChild($dom->createElement('vCOFINS',     number_format((float)$this->vCOFINS, 2, ".", "")));
                break;

        } // fim switch

        return $S01;
    }

}

// T01
class COFINSST {

    var $vBC;       // T02 - valor da BC do COFINS
    var $pCOFINS;   // T03 - al�quota do COFINS (em percentual)
    var $qBCProd;   // T04 - quantidade vendida
    var $vAliqProd; // T05 - al�quota do COFINS (em reias)
    var $vCOFINS;   // T06 - valor do COFINS

    function __construct() {
    }

    function get_xml($dom) {
        $T01 = $dom->appendChild($dom->createElement('COFINSST'));
        if (isset($this->vBC) && $this->vBC > 0 && isset($this->pCOFINS) && $this->pCOFINS > 0) {
            $T02 = $T01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
            $T03 = $T01->appendChild($dom->createElement('pCOFINS',     number_format((float)$this->pCOFINS, 4, ".", "")));
        } else {
            $T04 = $T01->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
            $T05 = $T01->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
        }
        $T06 = $T01->appendChild($dom->createElement('vCOFINS',     number_format((float)$this->vCOFINS, 2, ".", "")));
        return $T01;
    }

}

// U01
class ISSQN {

    var $vBC;       // U02 - valor da BC do ISSQN
    var $vAliq;     // U03 - al�quota do ISSQN
    var $vISSQN;    // U04 - valor do ISSQN
    var $cMunFG;    // U05 - c�digo do munic�pio do fato gerador do ISSQN
    var $cListServ; // U06 - c�digo da lista de servi�os
    var $vDeducao;		// U07 - valor dedu��o para redu��o da Base de C�lculo
    var $vOutro;		// U08 - valor outras reten��es
    var $vDescIncond;	// U09 - valor desconto incondicionado
    var $vISSRet;		// U11 - valor reten��o ISS
    var $indISS;		// U12 - indicador da exigibilidade do ISS
    var $cServico;		// U13 - codigo do servi�o prestado dentro do munic�pio
	var $cMun;			// U14 - c�digo do Munic�pio de incid�ncia do imposto
	var $cPais;			// U15 - c�digo do Pa�s onde o servi�o foi prestado
	var $nProcesso;		// U16 - n�mero de processo judicial ou administrativo de suspens�o da exigibilidade (informar s� quando o indISS for 6 ou 7)
	var $indIncentivo;	// U17 - indicador de incentivo Fiscal

    function __construct() {
    }

    function get_xml($dom) {
        $U01 = $dom->appendChild($dom->createElement('ISSQN'));
        $U02 = $U01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
        $U03 = $U01->appendChild($dom->createElement('vAliq',       number_format((float)$this->vAliq, 2, ".", "")));
        $U04 = $U01->appendChild($dom->createElement('vISSQN',      number_format((float)$this->vISSQN, 2, ".", "")));
        $U05 = $U01->appendChild($dom->createElement('cMunFG',      $this->cMunFG));
        /* cListServ com m�scara '99.99' a partir da vers�o 3.10 */
        $U06 = $U01->appendChild($dom->createElement('cListServ',   substr(sprintf("%04d", $this->cListServ), 0, 2).".".substr(sprintf("%04d", $this->cListServ), 2, 4)));
        $U07 = (floatval($this->vDeducao)>0.00) ? $U01->appendChild($dom->createElement('vDeducao', number_format((float)$this->vDeducao, 2, ".", ""))) : null;
        $U08 = (floatval($this->vOutro)>0.00) ? $U01->appendChild($dom->createElement('vOutro', number_format((float)$this->vOutro, 2, ".", ""))) : null;
        $U09 = (floatval($this->vDescIncond)>0.00) ? $U01->appendChild($dom->createElement('vDescIncond', number_format((float)$this->vDescIncond, 2, ".", ""))) : null;
        /* Vers�o NFe 3.10 */
        $U11 = (strtoupper($this->vISSRet) != 'FALSE' ? $U01->appendChild($dom->createElement('vISSRet', number_format((float)$this->vISSRet, 2, ".", ""))) : null);
        $U12 = (!empty($this->indISS) ? $U01->appendChild($dom->createElement('indISS',	$this->indISS)) : 1); //Obrigat�rio
        $U13 = (!empty($this->cServico) ? $U01->appendChild($dom->createElement('cServico',	$this->cServico)) : null);
        $U14 = (!empty($this->cMun) ? $U01->appendChild($dom->createElement('cMun',	$this->cMun)) : null);
        if(!empty($this->cPais) && $this->cPais > 0) {
            $this->cPais = str_pad($this->cPais,4, "0", STR_PAD_LEFT);
        }
        $U15 = (!empty($this->cPais) ? $U01->appendChild($dom->createElement('cPais',	$this->cPais)) : null);
        $U16 = (!empty($this->nProcesso) ? $U01->appendChild($dom->createElement('nProcesso',	$this->nProcesso)) : null);
        $U17 = ($this->indIncentivo == 'S' ? $U01->appendChild($dom->createElement('indIncentivo',	'1')) : $U01->appendChild($dom->createElement('indIncentivo', '2'))); //Obrigat�rio
        /*vers�o 2.0 (retirado na vers�o 3.10)*/
        //$U07 = $U01->appendChild($dom->createElement('cSitTrib',   $this->cSitTrib));
        return $U01;
    }

}

// X33
class lacres {

    var $nLacre;    // X33 - grupo de lacres

    function __construct() {
    }

    function get_xml($dom) {
        $X33 = $dom->appendChild($dom->createElement('lacres'));
        $X34 = $X33->appendChild($dom->createElement('nLacre', $this->nLacre));
        return $X33;
    }

}



/* NIVEL 5 ********************************************************************/

// I25
class adi {

    var $nAdicao;       // I26 - n�mero da adi��o
    var $nSeqAdic;      // I27 - n�mero sequencial do item dentro da adi��o
    var $cFabricante;   // I28 - c�digo do fabricante estrangeiro
    var $vDescDI;       // I29 - valor do desconto do item da DI - adi��o
    //VERS�O 2.0
    var $xPed;			// I30 - N�mero do pedido de compra
    var $nItemPed;		// I31 - Item do Pedido de Compra

    function __construct() {
    }

    function get_xml($dom) {
        $I25 = $dom->appendChild($dom->createElement('adi'));
        $I26 = $I25->appendChild($dom->createElement('nAdicao',     $this->nAdicao));
        $I27 = $I25->appendChild($dom->createElement('nSeqAdic',    $this->nSeqAdic));
        $I28 = $I25->appendChild($dom->createElement('cFabricante', $this->cFabricante));
        $I29 = (isset($this->vDescDI)) ? $I25->appendChild($dom->createElement('vDescDI',     number_format((float)$this->vDescDI, 2, ".", ""))) : null;
        $I30 = $I25->appendChild($dom->createElement('xPed', $this->xPed));
        $I31 = $I25->appendChild($dom->createElement('nItemPed', $this->nItemPed));
        return $I25;
    }

}

// L105
class CIDE {

    var $qBCprod;   // L106 - BC da CIDE
    var $vAliqProd; // L107 - valor da al�quota da CIDE
    var $vCIDE;     // L108 - valor da CIDE

    function __construct() {
    }

    function get_xml($dom) {
        $L105 = $dom->appendChild($dom->createElement('CIDE'));
        $L106 = $L105->appendChild($dom->createElement('qBCprod',   $this->qBCprod));
        $L107 = $L105->appendChild($dom->createElement('vAliqProd', $this->vAliqProd));
        $L108 = $L105->appendChild($dom->createElement('vCIDE',     $this->vCIDE));
        return $L105;
    }
}

// L109
class ICMSComb {

    var $vBCIMCS;   // L110 - BC do ICMS
    var $vICMS;     // L111 - valor do ICMS
    var $vBCICMSST; // L112 - BC do ICMS ST retido
    var $vICMSST;   // L113 - valor do ICMS ST retido

    function __construct() {
    }

    function get_xml($dom) {
        $L109 = $dom->appendChild($dom->createElement('ICMSComb'));
        $L110 = $L109->appendChild($dom->createElement('vBCIMCS',   $this->vBCICMS));
        $L111 = $L109->appendChild($dom->createElement('vICMS',     $this->vICMS));
        $L112 = $L109->appendChild($dom->createElement('vBCICMSST', $this->vBCICMSST));
        $L113 = $L109->appendChild($dom->createElement('vICMSST',   $this->vICMSST));
        return $L109;
    }
}

// L114
class ICMSInter {

    var $vBCICMSSTDest; // L115 - BC do ICMS ST da UF de destino
    var $vICMSSTDest;   // L116 - valor do ICMS ST da UF de destino

    function __construct() {
    }

    function get_xml($dom) {
        $L114 = $dom->appendChild($dom->createElement('ICMSInter'));
        $L115 = $L114->appendChild($dom->createElement('vBCICMSSTDest', $this->vBCICMSSTDest));
        $L116 = $L114->appendChild($dom->createElement('vICMSSTDest',   $this->vICMSSTDest));
        return $L114;
    }
}

// L117
class ICMSCons {

    var $vBCICMSSTCons; // L118 - BC do ICMS ST da UF de consumo
    var $vICMSSTCons;   // L119 - valor do ICMS ST da UF de consumo
    var $UFcons;        // L120 - sigla da UF de consumo

    function __construct() {
    }

    function get_xml($dom) {
        $L117 = $dom->appendChild($dom->createElement('ICMSCons'));
        $L118 = $L114->appendChild($dom->createElement('vBCICMSSTCons', $this->vBCICMSSTCons));
        $L119 = $L114->appendChild($dom->createElement('vICMSSTCons',   $this->vICMSSTCons));
        $L120 = $L114->appendChild($dom->createElement('UFcons',        $this->UFcons));
        return $L117;
    }
}

//ZD
class infRespTec {

    var $CNPJ;      // ZD02 - CNPJ da Software House
    var $xContato;     // ZD04 - Nome da pessoa a ser contatada da Software House
    var $email;       // ZD05 - email da Software House
    var $fone;       // ZD06 - fone da Software House
    var $idCSRT;     // ZD08 - Identificador CSRT da Software House
    var $hashCSRT;     // ZD09 - Hash do CSRT da Software House

    function __construct() {
        $this->CNPJ = null;
        $this->xContato     = null;
        $this->email     = null;
        $this->fone      = null;
        $this->idCSRT       = null;
        $this->hashCSRT       = null;
    }

    function get_xml($dom) {
        $ZD01 = $dom->appendChild($dom->createElement('infRespTec'));

        $ZD02 = (!empty($this->CNPJ)) ? $ZD01->appendChild($dom->createElement('CNPJ',   $this->CNPJ)) : null;
        $ZD04 = (!empty($this->xContato)) ? $ZD01->appendChild($dom->createElement('xContato',   $this->xContato)) : null;
        $ZD05 = (!empty($this->email)) ? $ZD01->appendChild($dom->createElement('email',   $this->email)) : null;
        $ZD06 = (!empty($this->fone)) ? $ZD01->appendChild($dom->createElement('fone',   $this->fone)) : null;
        $ZD06 = (!empty($this->idCSRT)) ? $ZD01->appendChild($dom->createElement('idCSRT',   $this->idCSRT)) : null;
        $ZD08 = (!empty($this->hashCSRT)) ? $ZD01->appendChild($dom->createElement('hashCSRT',   $this->hashCSRT)) : null;

        return $ZD01;
    }

}

// A01
/**
 * Classe que trata a tag infCFe
 * @author fernando.silva
 *
 */
class infCFe extends infNFe {

	var $versaoDadosEnt;// A03 - Vers�o do leiaute do arquivo de dados do AC


	function __construct() {
		parent::__construct();
		$this->versao       = str_pad($GLOBALS["_VERSAO_CFE"], 4, "0.00", STR_PAD_LEFT);
		$this->ide          = new ideCF;
		$this->emit         = new emitCF;
		$this->dest         = new destCF;
		$this->total        = new totalCF;
		$this->pag          = array();

	}

	/**
	 * M�todo respons�vel por verificar se existe o arquivo de configura��o para o modo laborat�rio do SAT
	 * @return boolean
	 */
	public static function verificarSatLab() {
		$_dir = getcwd();
		if(file_exists($_dir.'/sat_lab.conf') && $GLOBALS["_SAT_LAB"]["ABERTO"] == false) {
			$GLOBALS["_SAT_LAB"]["ABERTO"] = true;
			$_bf = fopen($_dir.'/sat_lab.conf',"r");
			while(!feof($_bf)) {
				$_dados = fgets($_bf);
				if(empty($_dados)) {
					continue;
				}
				$_arrDados = explode('=',$_dados);
				$_key = trim($_arrDados[0]);
				$GLOBALS["_SAT_LAB"][$_key] = trim($_arrDados[1]);
			}
			fclose($_bf);
		}
		return true;
	}

	function get_xml($dom) {
		$A01 = $dom->appendChild($dom->createElement('infCFe'));
		$A02 = $A01->appendChild($dom->createAttribute('versaoDadosEnt'));
		$A02->appendChild($dom->createTextNode($this->versaoDadosEnt));

		$this->ide->verNFe = $this->versao;
		$B01 = $A01->appendChild($this->ide->get_xml($dom));
		$C01 = $A01->appendChild($this->emit->get_xml($dom));

		$E01 = $A01->appendChild($this->dest->get_xml($dom));

		$G01 = (is_object($this->entrega))  ? $A01->appendChild($this->entrega->get_xml($dom))  : null;

		$detalhe = null;
		for ($i=0; $i<count((array)$this->det); $i++) {
			$detalhe = $this->det[$i]->get_xml($dom);
			if (!is_null($detalhe)) {
				$H01 = $A01->appendChild($detalhe);
			}
		}

		$W01 = $A01->appendChild($this->total->get_xml($dom));

		$pag = null;
		$WA01 = $dom->appendChild($dom->createElement('pgto'));
		for ($i=0; $i<count((array)$this->pag); $i++) {
			$pag = $this->pag[$i]->get_xml($dom);
			if (!is_null($pag)) {
				$WA02 = $WA01->appendChild($pag);
			}
		}
		$A01->appendChild($WA01);

		$Z01 = (is_object($this->infAdic))  ? $A01->appendChild($this->infAdic->get_xml($dom))  : null;

		return $A01;
	}

}

class ideCF extends ide{

	//Vari�veis exclusivas para o SAT
	var $CNPJ; //B11
	var $signAC; //B12
	var $numeroCaixa; //B14

	function __construct() {
		parent::__construct();
		$this->mod      = 59;               // CFe
	}

	function get_xml($dom) {

		infCFe::verificarSatLab();

		if(!empty($GLOBALS["_SAT_LAB"]["IDE_CNPJ"])) {
			$this->CNPJ = $GLOBALS["_SAT_LAB"]["IDE_CNPJ"];
		}else{
			$this->CNPJ = '50245869000174'; //CNPJ da Software House, no caso Zanthus
		}

		if(!empty($GLOBALS["_SAT_LAB"]["IDE_SIGNAC"])) {
			$this->signAC = $GLOBALS["_SAT_LAB"]["IDE_SIGNAC"];
		}

		$B01 = $dom->appendChild($dom->createElement('ide'));
		$B11 = $B01->appendChild($dom->createElement('CNPJ',     $this->CNPJ));
		$B12 = $B01->appendChild($dom->createElement('signAC',     $this->signAC));
		$B14 = $B01->appendChild($dom->createElement('numeroCaixa',   $this->numeroCaixa));

		return $B01;
	}

}

// C01
class emitCF extends emit {

	var $CNPJ;      			// C02 - CNPJ do emitente
	var $IE;       				 // C12 - IE
	var $IM;        			// C13 - Inscri��o Municipal
	var $cRegTribISSQN = 1;      // C15 - Regime especial de tributa��o do ISSQN
	var $indRatISSQN = 'N';		// C16 - Indicador de rateio do desconto

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {

		infCFe::verificarSatLab();

		if(!empty($GLOBALS["_SAT_LAB"]["EMIT_CNPJ"])) {
			$this->CNPJ = $GLOBALS["_SAT_LAB"]["EMIT_CNPJ"];
		}

		if(!empty($GLOBALS["_SAT_LAB"]["IDE_IE"])) {
		    $this->IE = $GLOBALS["_SAT_LAB"]["IDE_IE"];
		}

		if(!empty($GLOBALS["_SAT_LAB"]["IDE_IM"])) {
			$this->IM = $GLOBALS["_SAT_LAB"]["IDE_IM"];
		}

		$C01 = $dom->appendChild($dom->createElement('emit'));
		$C02 = $C01->appendChild($dom->createElement('CNPJ', sprintf("%014s", $this->CNPJ)));
        //MF-e exige que complete com zeros a esquerda
		if ($this->IE != 'ISENTO' && $this->IE > 0) {
            $C12 = $C01->appendChild($dom->createElement('IE', str_pad($this->IE, 12, "0", STR_PAD_LEFT)));
        } else {
            $C12 = $C01->appendChild($dom->createElement('IE', $this->IE));
        }

		if(!empty($this->IM)) {
			$C13 = $C01->appendChild($dom->createElement('IM',        $this->IM));
		}
		$C15 = $C01->appendChild($dom->createElement('cRegTribISSQN',    $this->cRegTribISSQN));
		$C16 = $C01->appendChild($dom->createElement('indRatISSQN',    $this->indRatISSQN));

		return $C01;
	}

}


// E01
class destCF extends dest {

	var $CNPJ;      // E02 - CNPJ do destinat�rio
	var $CPF;       // E03 - CPF do destinat�rio
	var $xNome;     // E04 - raz�o social ou nome do emitente

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$E01  = $dom->appendChild($dom->createElement('dest'));

		if (!empty($this->CPF)) {
			$E02  = $E01->appendChild($dom->createElement('CPF',       $this->CPF));
		}

		if (!empty($this->CNPJ)) {
			$E03  = $E01->appendChild($dom->createElement('CNPJ',       $this->CNPJ));
		}

		if (!empty($this->xNome)) {
			$E04  = $E01->appendChild($dom->createElement('xNome',       $this->xNome));
		}

		return $E01;
	}
}

// W01
class totalCF extends total {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
	    //$W01
		return $dom->appendChild($dom->createElement('total'));
	}

}

// I01
class prodCF extends prod {

	var $cProd;     // I02 - c�digo do produto ou servi�o
	var $cEAN;      // I03 - GTIN (Global Trade Item Number)do produto
	var $xProd;     // I04 - descri��o do produto ou servi�o
	var $NCM;       // I05 - c�digo NCM
	var $CEST;		// I05c- c�digo CEST (C�d. Especificador da Substitui��o Tribut�ria)
    var $indEscala;	// I05f- indEscala parametro para indicar informa��es do CEST
	var $CFOP;      // I06 - c�digo fiscal de opera��es e presta��es
	var $uCom;      // I07 - unidade comercial
	var $qCom;      // I08 - quantidade comercial
	var $vUnCom;    // I09- valor unit�rio de comercializa��o
	var $indRegra = 'A';  // I11 - Regra de c�lculo o tipo A � fixo, se trabalhasse com combustivel teria que ser tipo T
	var $vDesc;     // I12 - Valor do Desconto do item
	var $vOutro;    // I13 - Outras desesas acess�rias sobre item
	var $obsFiscoDet;   // I17 - Grupo do campo de uso livre do Fisco
	var $xCampoDet;    // I18 - Identifica��o do campo
	var $xTextoDet;      // I19 - Conte�do do campo


	function __construct() {
		parent::__construct();
		$this->obsFiscoDet = new obsFiscoDet;
	}

	function get_xml($dom) {
		$I01  = $dom->appendChild($dom->createElement('prod'));
		$I02  = $I01->appendChild($dom->createElement('cProd',       $this->cProd));
		$I03  = (!empty($this->cEAN))     ? $I01->appendChild($dom->createElement('cEAN',        $this->cEAN))     : null;
		$I04  = $I01->appendChild($dom->createElement('xProd',       $this->xProd));
		$I05  = (!empty($this->NCM) && (int) $this->NCM > 0)     ? $I01->appendChild($dom->createElement('NCM',     $this->NCM))     : null;
		//A partir da vers�o 8 a tag CEST entra no XML.
        if((int)$GLOBALS["_VERSAO_CFE"] >= 8){
            $I05c = (!empty($this->CEST) && (int) $this->CEST > 0) ? $I01->appendChild($dom->createElement('CEST', (string) funcoesGerais::str_alinha($this->CEST, 7, DIREITA, true, '0'))) : null;
            $I05f = (!empty($this->indEscala)) ? $I01->appendChild($dom->createElement('indEscala', $this->indEscala)) : null;
        }
        $I06  = $I01->appendChild($dom->createElement('CFOP',        $this->CFOP));
		$I07  = $I01->appendChild($dom->createElement('uCom',        strtolower($this->uCom)));
		$I08  = $I01->appendChild($dom->createElement('qCom',        number_format((float)$this->qCom, 4, ".", "")));
		$I09  = $I01->appendChild($dom->createElement('vUnCom',      number_format((float)$this->vUnCom, 3, ".", "")));
		$I11  = $I01->appendChild($dom->createElement('indRegra',    $this->indRegra));
		$I12  = (floatval( number_format((float)$this->vDesc, 2, ".", "")) > 0.00)   ? $I01->appendChild($dom->createElement('vDesc',  number_format((float)$this->vDesc, 2, ".", "")))   : null;
		$I13 = (floatval(number_format((float)$this->vOutro, 2, ".", "")) > 0.00) ? $I01->appendChild($dom->createElement('vOutro',   number_format((float)$this->vOutro, 2, ".", "")))  : null;

        /**
         * As vers�es 0.06 e 0.07 da Cfe colocam o campo CEST aqui na observa��o do fisco.
         * As vers�es superiores inserem a tag CEST diretamente no XML.
         */
        if((int)$GLOBALS["_VERSAO_CFE"] < 8){
            if ($this->CEST) {
                $this->obsFiscoDet->xCampoDet = "Cod. CEST";
                $this->obsFiscoDet->xTextoDet = (string)funcoesGerais::str_alinha($this->CEST, 7, DIREITA, true, '0');
                $I17 = $I01->appendChild($this->obsFiscoDet->get_xml($dom));
            }
        }

        if($this->codanp){
            $this->obsFiscoDet->xCampoDet = "Cod. ANP";
            $this->obsFiscoDet->xTextoDet = $this->codanp;
            $I17 = $I01->appendChild($this->obsFiscoDet->get_xml($dom));
        }

		return $I01;
    }

}

/**
 * Grupo do campo de uso livre do Fisco
 * @author marcelo.junior
 *
 */
class obsFiscoDet {

    var $xCampoDet;     // I18 - Identifica��o do campo
    var $xTextoDet;     // I19 - Conte�do do campo

    function __construct() {

		}

    function get_xml($dom) {
        $I17 = $dom->appendChild($dom->createElement('obsFiscoDet'));
        $I17->setAttribute('xCampoDet',$this->xCampoDet);
        $I19 = $I17->appendChild($dom->createElement('xTextoDet', $this->xTextoDet));
        return $I17;
	}

}

class detCF extends det {

	function __construct() {
		parent::__construct();
		$this->prod         = new prodCF;
		$this->imposto      = new impostoCF;
		$this->infAdProd    = null;
	}

	function get_xml($dom) {
		if (empty($this->nItem)) {
			return null;
		}
		$H01 = $dom->appendChild($dom->createElement('det'));
		$H02 = $H01->appendChild($dom->createAttribute('nItem'));
		$H02->appendChild($dom->createTextNode($this->nItem));
		$I01 = $H01->appendChild($this->prod->get_xml($dom));
		$M01 = $H01->appendChild($this->imposto->get_xml($dom));
		return $H01;
	}

}


// N01
class ICMSCF extends ICMS {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {

		$N01 = $dom->appendChild($dom->createElement('ICMS'));

		switch ($this->CST) {

			case '00' :
			case '20' :
			case '90' :
				$N02 = $N01->appendChild($dom->createElement('ICMS00'));
				$N11 = $N02->appendChild($dom->createElement('Orig',        (empty($this->Orig)?0:$this->Orig)));
				$N12 = $N02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				$N16 = $N02->appendChild($dom->createElement('pICMS',       number_format((float)$this->pICMS, 2, ".", "")));
				break;

			case '40' :
			case '41' :
			case '50' :
			case '60' :
				$N06 = $N01->appendChild($dom->createElement('ICMS40'));
				$N11 = $N06->appendChild($dom->createElement('Orig',        (empty($this->Orig)?0:$this->Orig)));
				$N12 = $N06->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				break;
			case '102' :
			case '300' :
            case '400' :
			case '500' :
				$N10 = $N01->appendChild($dom->createElement('ICMSSN102'));
				$N11 = $N10->appendChild($dom->createElement('Orig',        $this->Orig));
				$N12 = $N10->appendChild($dom->createElement('CSOSN',         sprintf("%03d", $this->CST)));
				break;

		} // fim switch

		return $N01;
	}

}


class PISCF extends PIS {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {

		$Q01 = $dom->appendChild($dom->createElement('PIS'));

		switch ($this->CST) {

			case '01' :
			case '02' :
            case '05' :
				$Q02 = $Q01->appendChild($dom->createElement('PISAliq'));
				$Q06 = $Q02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				$Q07 = $Q02->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
				$Q08 = $Q02->appendChild($dom->createElement('pPIS',        number_format((float)($this->pPIS/100), 4, ".", "")));
				break;

			case '03' :
				$Q03 = $Q01->appendChild($dom->createElement('PISQtde'));
				$Q06 = $Q03->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				$Q10 = $Q03->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
				$Q11 = $Q03->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
				break;

			case '04' :
			case '06' :
			case '07' :
			case '08' :
			case '09' :
				$Q04 = $Q01->appendChild($dom->createElement('PISNT'));
				$Q06 = $Q04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				break;

			case '49' :
				$Q04 = $Q01->appendChild($dom->createElement('PISSN'));
				$Q06 = $Q04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				break;

            case '99' :
				$Q05 = $Q01->appendChild($dom->createElement('PISOutr'));
				$Q06 = $Q05->appendChild($dom->createElement('CST',         sprintf("%02d", '99')));
				if (isset($this->vBC) && isset($this->pPIS)) {
					$Q07 = $Q05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
					$Q08 = $Q05->appendChild($dom->createElement('pPIS',        number_format((float)($this->pPIS/100), 4, ".", "")));
				} else {
					$Q10 = $Q05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
					$Q11 = $Q05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
				}
				break;

		} // fim switch

		return $Q01;
	}

}



// R01
class PISSTCF extends PISST {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$R01 = $dom->appendChild($dom->createElement('PISST'));
		if (isset($this->vBC) && $this->vBC > 0 && isset($this->pPIS) && $this->pPIS > 0) {
			$R02 = $R01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
			$R03 = $R01->appendChild($dom->createElement('pPIS',        number_format((float)($this->pPIS/100), 4, ".", "")));
		} else {
			$R04 = $R01->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
			$R05 = $R01->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
		}
		return $R01;
	}

}

// S01
class COFINSCF extends COFINS {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$S01 = $dom->appendChild($dom->createElement('COFINS'));

		switch ($this->CST) {

			case '01' :
			case '02' :
            case '05' :
				$S02 = $S01->appendChild($dom->createElement('COFINSAliq'));
				$S06 = $S02->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				$S07 = $S02->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
				$S08 = $S02->appendChild($dom->createElement('pCOFINS',     number_format((float)($this->pCOFINS/100), 4, ".", "")));
				break;

			case '03' :
				$S03 = $S01->appendChild($dom->createElement('COFINSQtde'));
				$S06 = $S03->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				$S09 = $S03->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
				$S10 = $S03->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
				break;

			case '04' :
			case '06' :
			case '07' :
			case '08' :
			case '09' :
				$S04 = $S01->appendChild($dom->createElement('COFINSNT'));
				$S06 = $S04->appendChild($dom->createElement('CST',         sprintf("%02d", $this->CST)));
				break;

			case '75' :
				$S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
				$S06 = $S05->appendChild($dom->createElement('CST',         sprintf("%02d", "99")));
				if (isset($this->vBC) && $this->vBC > 0 && isset($this->pPIS) && $this->pPIS > 0) {
					$S07 = $S05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
					$S08 = $S05->appendChild($dom->createElement('pCOFINS',        number_format((float)($this->pCOFINS/100), 4, ".", "")));
				} else {
					$S10 = $S05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
					$S11 = $S05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
				}

				break;
            case '99' :
				$S05 = $S01->appendChild($dom->createElement('COFINSOutr'));
				$S06 = $S05->appendChild($dom->createElement('CST',         sprintf("%02d", '99')));
				if (isset($this->vBC) && isset($this->pCOFINS)) {
					$S07 = $S05->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
					$S08 = $S05->appendChild($dom->createElement('pCOFINS',     number_format((float)($this->pCOFINS/100), 4, ".", "")));
				} else {
					$S09 = $S05->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
					$S10 = $S05->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
				}

				break;

		} // fim switch

		return $S01;
	}

}

// T01
class COFINSSTCF extends COFINSST {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$T01 = $dom->appendChild($dom->createElement('COFINSST'));
		if (isset($this->vBC) && $this->vBC > 0 && isset($this->pCOFINS) && $this->pCOFINS > 0) {
			$T02 = $T01->appendChild($dom->createElement('vBC',         number_format((float)$this->vBC, 2, ".", "")));
			$T03 = $T01->appendChild($dom->createElement('pCOFINS',     number_format((float)($this->pCOFINS/100), 4, ".", "")));
		} else {
			$T04 = $T01->appendChild($dom->createElement('qBCProd',     number_format((float)$this->qBCProd, 4, ".", "")));
			$T05 = $T01->appendChild($dom->createElement('vAliqProd',   number_format((float)$this->vAliqProd, 4, ".", "")));
		}
		return $T01;
	}

}


// G01
class entregaCF extends entrega {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$G01  = $dom->appendChild($dom->createElement('entrega'));
		$G03  = $G01->appendChild($dom->createElement('xLgr',       str_pad($this->xLgr, 3, "...")));
		$G04  = $G01->appendChild($dom->createElement('nro',        "{$this->nro}"));
		$G05  = (!empty($this->xCpl)) ? $G01->appendChild($dom->createElement('xCpl',       $this->xCpl)) : '';
		$G06  = $G01->appendChild($dom->createElement('xBairro',    $this->xBairro));
		$G08  = $G01->appendChild($dom->createElement('xMun',       $this->xMun));
		$G09  = $G01->appendChild($dom->createElement('UF',         $this->UF));
		return $G01;
	}

}

//YA01 Grupo de Formas de Pagamento
class pagCF extends pag {
	/**
	 * Forma de pagamento
	 *
	 01=Dinheiro
		02=Cheque
		03=Cart�o de Cr�dito
		04=Cart�o de D�bito
		05=Cr�dito Loja
		10=Vale Alimenta��o
		11=Vale Refei��o
		12=Vale Presente
		13=Vale Combust�vel
        17=PIX
		99=Outros
	 * @var string
	 */
	/**
     * Por hora n�o gravaremos no banco.
     */
	public $cod_credenciadora;
	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		//Se o valor do pagamento estiver vazio cai fora.
		if (empty($this->vPag)) {
			return null;
		}
		$WA02  = $dom->appendChild($dom->createElement('MP'));
		$WA03  = $WA02->appendChild($dom->createElement('cMP', sprintf("%02s", $this->tPag)));
		$WA04  = $WA02->appendChild($dom->createElement('vMP', $this->vPag));
		if ((int) $this->cod_credenciadora > 0) {
            $WA05 = $WA02->appendChild($dom->createElement('cAdmC', sprintf("%03s", $this->cod_credenciadora)));
        }

        /*if ( ($_card = $this->card->get_xml($dom)) !== null) {
            $YA05  = $WA02->appendChild($_card);
        }*/
		return $WA02;
	}

}

class impostoCF extends imposto {

	function __construct() {
		parent::__construct();
	}

	function get_xml($dom) {
		$M01 = $dom->appendChild($dom->createElement('imposto'));
		//Adicionamos o novo campo de Total de tributa��o.

		$M02 = (!empty($this->vTotTrib)) ? $M01->appendChild($dom->createElement('vItem12741',   number_format((float)$this->vTotTrib, 2, ".", ""))) : null;

		$N01 = (is_object($this->ICMS)) ?$M01->appendChild($this->ICMS->get_xml($dom)) : null;
		$U01 = (is_object($this->ISSQN)) ? $M01->appendChild($this->ISSQN->get_xml($dom)) : null;
		$O01 = (is_object($this->IPI)) ? $M01->appendChild($this->IPI->get_xml($dom)) : null;
		$P01 = (is_object($this->II)) ? $M01->appendChild($this->II->get_xml($dom)) : null;
		$Q01 = (is_object($this->PIS)) ?$M01->appendChild($this->PIS->get_xml($dom)) : null;
		$R01 = (is_object($this->PISST)) ? $M01->appendChild($this->PISST->get_xml($dom)) : null;
		$S01 = (is_object($this->COFINS)) ? $M01->appendChild($this->COFINS->get_xml($dom)) : null;
		$T01 = (is_object($this->COFINSST)) ? $M01->appendChild($this->COFINSST->get_xml($dom)) : null;
		return $M01;
	}

}

