<?php
/**
 * Este arquivo � parte do projeto NFePHP - Nota Fiscal eletr�nica em PHP.
 *
 * Este programa � um software livre: voc� pode redistribuir e/ou modific�-lo
 * sob os termos da Licen�a P�blica Geral GNU como � publicada pela Funda��o
 * para o Software Livre, na vers�o 3 da licen�a, ou qualquer vers�o posterior.
 * e/ou
 * sob os termos da Licen�a P�blica Geral Menor GNU (LGPL) como � publicada pela
 * Funda��o para o Software Livre, na vers�o 3 da licen�a, ou qualquer vers�o posterior.
 *
 * Este programa � distribu�do na esperan�a que ser� �til, mas SEM NENHUMA
 * GARANTIA; nem mesmo a garantia expl�cita definida por qualquer VALOR COMERCIAL
 * ou de ADEQUA��O PARA UM PROP�SITO EM PARTICULAR,
 * veja a Licen�a P�blica Geral GNU para mais detalhes.
 *
 * Voc� deve ter recebido uma c�pia da Licen�a Publica GNU e da
 * Licen�a P�blica Geral Menor GNU (LGPL) junto com este programa.
 * Caso contr�rio consulte
 * <http://www.fsfla.org/svnwiki/trad/GPLv3>
 * ou
 * <http://www.fsfla.org/svnwiki/trad/LGPLv3>.
 *
 * @category  NFePHP
 * @package   NFePHP
 * @name      DanfceNFePHP.class.php
 * @copyright 2009-2013 &copy; NFePHP
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL v.3
 *            http://www.gnu.org/licenses/lgpl.html GNU/LGPL v.3
 * @version   GIT: 1.11
 * @link      http://www.nfephp.org/
 * @author    Roberto Spadim <roberto at spadim dot com dot br>
 *
 *
 * CONTRIBUIDORES (por ordem alfabetica):
 *            Roberto L. Machado <linux dot rlm at gmail dot com>
 *            Mario Almeida <mario at grupopmz dot com dot br>
 *
 */

//define o caminho base da instala��o do sistema
if (!defined('PATH_ROOT')) {
    define('PATH_ROOT', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR);
}

//ajuste do tempo limite de resposta do processo
set_time_limit(600);

//classes utilizadas
require_once(funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/mpdf/mpdf.php');
//require_once(funcoesGerais::retornarCaminhoAbsolutoManager() .'PDF/fpdf/fpdf.php');


require_once (funcoesGerais::retornarCaminhoAbsolutoManager() .  'plugin/qrcode/qrcode.class.php');
require_once (funcoesGerais::retornarCaminhoAbsolutoManager() . 'nfephp/tags/pre-review/libs/CommonNFePHP.class.php');
require_once (funcoesGerais::retornarCaminhoAbsolutoManager() . 'nfephp/tags/pre-review/libs/DocumentoNFePHP.interface.php');

/**
 * Classe DanfceNFePHP
 * Objetivo - impress�o de NFC-e em uma unica pagina (bobina)
 */
class DanfeNFCeNFePHP extends CommonNFePHP implements DocumentoNFePHP
{
    //publicas
    public $idToken;
    public $emitToken;
    public $papel;
    public $_eh_pdf = true;

    //privadas
    protected $xml; // string XML NFe
    protected $formatoChave="#### #### #### #### #### #### #### #### #### #### ####";
    protected $debugMode=0; //ativa ou desativa o modo de debug
    protected $nfeProc;
    protected $nfe;
    protected $infNFe;
    protected $ide;
    protected $enderDest;
    protected $ICMSTot;
    protected $imposto;
    protected $emit;
    protected $enderEmit;
    protected $det;
    protected $pag;
    protected $dest;
    protected $mPDF;
    protected $html;
    protected $imgQRCode;

    protected $urlConsulta = null;
    protected $info_impresssao;

    //ALTNFE-1
    protected $_versao_nfe;
    protected $vTroco;

    public $_imprimir_cod_lido = false;

    //PARAMETROS SAT
    /*array(
        '1'=> array(
            '12'=> array('chave'=>'','QR'=>'http://www.sefaznet.ac.gov.br/nfe/NFe.jsp?opc=3'),
            '13'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://sistemas.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),
            '21'=> array('chave'=>'','QR'=>'http://www.nfe.ma.gov.br/portal/consultarNFCe.jsp'),
            '51'=> array('chave'=>'http://www.sefaz.mt.gov.br/nfce/consultanfce',
            			 'QR'=>'http://www.sefaz.mt.gov.br/nfce/consultanfce'),
            '24'=> array('chave'=>'','QR'=>'http://www.nfe.rn.gov.br/portal/consultarNFCe.jsp'),
            '43'=> array('chave'=>'','QR'=>'https://www.sefaz.rs.gov.br/NFCE/NFCE-COM.aspx'),
            '28'=> array('chave'=>'','QR'=>'http://www.nfe.se.gov.br/portal/consultarNFCe.jsp')
        ),
        '2' => array(
            '12'=> array('chave'=>'','QR'=>'http://hml.sefaznet.ac.gov.br'),
            '13'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://homnfce.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),
            '35'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://homnfce.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),

            '21'=> array('chave'=>'','QR'=>'http://www.hom.nfe.ma.gov.br/portal/consultarNFCe.jsp'),
            '51'=> array('chave'=>'http://homologacao.sefaz.mt.gov.br/nfce/consultanfce',
            			 'QR'=>'http://homologacao.sefaz.mt.gov.br/nfce/consultanfce'),
            '24'=> array('chave'=>'','QR'=>'http://www.hom.nfe.rn.gov.br/portal/consultarNFCe.jsp'),
            '43'=> array('chave'=>'','QR'=>'https://www.sefaz.rs.gov.br/NFCE/NFCE-COM.aspx'),
            '28'=> array('chave'=>'','QR'=>'http://www.hom.nfe.se.gov.br/portal/consultarNFCe.jsp')
        ));*/

    /**
     * Pega as urls do xml da nfcs.
     * @param array $_url
     */
    public function setURLChave($_url) {
    	$this->urlConsulta = $_url;
    }

    /**
     *
     * @param type $docXML
     * @param type $sPathLogo
     * @param type $mododebug
     * @param type $idToken
     * @param type $Token
     */
    public function __construct($docXML = '', $sPathLogo = '', $mododebug = 0, $idToken = '', $emitToken = '')
    {
        if (is_numeric($mododebug)) {
            $this->debugMode = $mododebug;
        }
/*        if ($this->debugMode) {
            //ativar modo debug
            //Quem defini isso � o defines o class_bd
            //error_reporting(E_ALL);
            //ini_set('display_errors', 'On');
        } else {
            //desativar modo debug
            //error_reporting(0);
            //Quem defini isso � o defines o class_bd
            //ini_set('display_errors', 'Off');
        }*/
        $this->papel = array(80, 'one-page');

        $this->xml          = utf8_encode($docXML);
        $this->logomarca    = $sPathLogo;
        if (!empty($this->xml)) {
            $this->dom = new DomDocument;
            $this->dom->loadXML($this->xml);
            $this->nfeProc    = $this->dom->getElementsByTagName("nfeProc")->item(0);
            $this->nfe        = $this->dom->getElementsByTagName("NFe")->item(0);
            $this->infNFe     = $this->dom->getElementsByTagName("infNFe")->item(0);
            $this->ide        = $this->dom->getElementsByTagName("ide")->item(0);
            $this->emit       = $this->dom->getElementsByTagName("emit")->item(0);
            $this->enderEmit  = $this->dom->getElementsByTagName("enderEmit")->item(0);
            $this->det        = $this->dom->getElementsByTagName("det");
            $this->dest       = $this->dom->getElementsByTagName("dest")->item(0);
            $this->_versao_nfe = (float) $this->infNFe->getAttribute("versao");
            if($this->_versao_nfe >= 4) {
                $this->pag        = $this->dom->getElementsByTagName("detPag");
                $this->vTroco     = $this->dom->getElementsByTagName("vTroco")->item(0);
            }else{
                $this->pag        = $this->dom->getElementsByTagName("pag");
            }
            $this->imposto    = $this->dom->getElementsByTagName("imposto")->item(0);
            $this->ICMSTot    = $this->dom->getElementsByTagName("ICMSTot")->item(0);
        }
        $this->idToken = $idToken;
        $this->emitToken = $emitToken;

    } //fim __construct

    public function getIdToken()
    {
        return $this->idToken;
    }

    public function setIdToken($str)
    {
        $this->idToken = $str;
    }

    public function getEmitToken()
    {
        return $this->emitToken;
    }

    public function setEmitToken($str)
    {
        $this->emitToken = $str;
    }

    public function getPapel()
    {
        return $this->papel;
    }

    public function setPapel($aPap)
    {
        $this->papel = $aPap;
    }

    public function simpleConsistencyCheck()
    {
        if (1 == 2 || $this->xml == null || $this->infNFe == null || $this->ide == null) {
            return false;
        }
        return true;
    } //fim simpleConsistencyCheck

    /**
     *
     * @param type $orientacao
     * @param type $papel
     * @param type $logoAlign
     * @return type
     */
    public function monta ($orientacao = '', $papel = array(80, 'one-page'), $logoAlign = 'C', $detalhes = false, $_info_impressao = null, $_somar_desc_nfce = null) {
        $this->info_impresssao = $_info_impressao;
        return $this->montaDANFE($detalhes, $_somar_desc_nfce);
    }//fim monta

    /**
     *
     * @param type $nome
     * @param type $destino
     * @param type $printer
     * @return type
     */
    public function printDocument($nome = '', $destino = 'I', $printer = '')
    {
        return $this->printDANFE($nome, $destino, $printer);
    }//fim printDocument

    /**
     * o objetivo desta fun��o � ler o XML e gerar o DANFE com auxilio de convers�o HTML-PDF
     * @param bool|type $detalhes
     * @return type
     */
    public function montaDANFE($detalhes = false, $_somar_desc_nfce = null)
    {
        //DADOS DA NF
        $nProt = $this->__simpleGetValue($this->nfeProc, "nProt");
        $dhRecbto  = $this->__simpleGetValue($this->nfeProc, "dhRecbto");
        $digVal = $this->__simpleGetValue($this->nfe, "DigestValue");
        $chNFe = str_replace('NFe', '', $this->infNFe->getAttribute("Id"));
        $this->_versao_nfe = (float) $this->infNFe->getAttribute("versao");
        $tpAmb = $this->__simpleGetValue($this->ide, 'tpAmb');
        $cUF = $this->__simpleGetValue($this->ide, 'cUF');
        $nNF = $this->__simpleGetValue($this->ide, 'nNF');
        $serieNF = str_pad($this->__simpleGetValue($this->ide, "serie"), 3, "0", STR_PAD_LEFT);
        $dhEmi = $this->__simpleGetValue($this->ide, "dhEmi");
        $vTotTrib = $this->__simpleGetValue($this->ICMSTot, "vTotTrib");
        $vProd = $this->__simpleGetValue($this->ICMSTot, "vProd");
        $vNF = $this->__simpleGetValue($this->ICMSTot, "vNF");
        $vOutros = $this->__simpleGetValue($this->ICMSTot, "vOutro");
        $vDesc  = $this->__simpleGetValue($this->ICMSTot, "vDesc");
        $vICMS = $this->__simpleGetValue($this->ICMSTot, "vICMS");
        $qtdItens = $this->det->length;
        $_qrcode2 = '';
        if(($GLOBALS["_VERSAO_NT"] & 8) > 0) {
            $_qrcode2 = '2';
        }
        $urlChave = $this->urlConsulta["URLAcesso{$_qrcode2}"]; //$this->urlConsulta[$tpAmb][$cUF]['chave'];
        $urlQR    = $this->urlConsulta['URLQRCodeAcesso'];//$this->urlConsulta[$tpAmb][$cUF]['QR'];
        $_tpEmis =  $this->__simpleGetValue($this->ide, 'tpEmis');

        //Se for conting�ncia segundo o manual deve obrigatoriamente imprimir o detalhe.
        if ((int) $_tpEmis === 9) {
        	$detalhes = true;
        }

        //DADOS DO EMITENTE
        $emitRazao  = $this->__simpleGetValue($this->emit, "xNome");
        $emitCnpj   = $this->__simpleGetValue($this->emit, "CNPJ");
        $emitCnpj   = $this->__format($emitCnpj, "##.###.###/####-##");
        $emitIE     = $this->__simpleGetValue($this->emit, "IE");
        $emitFone = $this->__simpleGetValue($this->enderEmit, "fone");
        $foneLen = strlen($emitFone);
        if ($foneLen>0) {
            $fone2 = substr($emitFone, 0, $foneLen-4);
            $fone1 = substr($emitFone, 0, $foneLen-8);
            $emitFone = '('.$fone1.') '.substr($fone2, -4).'-'.substr($emitFone, -4);
        } else {
            $emitFone = '';
        }
        $emitLgr = $this->__simpleGetValue($this->enderEmit, "xLgr");
        $emitNro = $this->__simpleGetValue($this->enderEmit, "nro");
        $emitCpl = $this->__simpleGetValue($this->enderEmit, "xCpl", " - ");
        $emitBairro = $this->__simpleGetValue($this->enderEmit, "xBairro");
        $emitCEP = $this->__format($this->__simpleGetValue($this->enderEmit, "CEP"), "#####-###");
        $emitMun = $this->__simpleGetValue($this->enderEmit, "xMun");
        $emitUF = $this->__simpleGetValue($this->enderEmit, "UF");

        //pag
        $tPagNome = '';
        $pagHtml = $this->pagamento($this->pag, $tPagNome);

        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';

        //IMPOSTOS
        $impHtml = "<table width=\"100%\">\n";
       	if ($vNF !== $vProd) {
	        $impHtml .= "<tr>\n";
	        $impHtml .= "<td align=\"left\">".htmlspecialchars('VALOR PRODUTOS',null,"UTF-8")."</td>\n";
	        $impHtml .= "<td align=\"right\">". $_sigla_moeda .number_format($vProd, 2, ',', '.')."</td>\n";
	        $impHtml .= "</tr>\n";
       	}
       	if ($vOutros > 0) {
	        $impHtml .= "<tr>\n";
	        $impHtml .= "<td align=\"left\">" . utf8_encode("ACR�SCIMO") . "</td>\n";
	        $impHtml .= "<td align=\"right\">". $_sigla_moeda . number_format($vOutros, 2, ',', '.')."</td>\n";
	        $impHtml .= "</tr>\n";
       	}
       	if ($vDesc > 0) {
	        $impHtml .= "<tr>\n";
	        $impHtml .= "<td align=\"left\">DESCONTOS</td>\n";
	        $impHtml .= "<td align=\"right\">". $_sigla_moeda .number_format($vDesc, 2, ',', '.')."</td>\n";
	        $impHtml .= "</tr>\n";
       	}

        /**
         * ML-2951
         * BIT
         * Jan.2024
         */
        $_frete = (float)trim($this->__simpleGetValue($this->ICMSTot, "vFrete"));
        if(!empty($_frete)) {
            $impHtml .= "<tr>\n";
            $impHtml .= "<td align=\"left\">FRETE TOTAL</td>\n";
            $impHtml .= "<td align=\"right\">". $_sigla_moeda .number_format($_frete, 2, ',', '.')."</td>\n";
            $impHtml .= "</tr>\n";
        }

        $impHtml .= "<tr>\n";
        $impHtml .= "<td align='left'>VALOR TOTAL</td>\n";
        $impHtml .= "<td align='right'>". $_sigla_moeda . number_format($vNF, 2, ',', '.')."</td>\n";
        $impHtml .= "</tr>\n";
        $impHtml .= "</table>\n";

        //necess�rio para QRCode
        $cDest  = '';
        if (isset($this->dest)) {
            $considEstrangeiro = !empty($this->dest->getElementsByTagName("idEstrangeiro")->item(0)->nodeValue)
                    ? $this->dest->getElementsByTagName("idEstrangeiro")->item(0)->nodeValue
                    : '';
            $consCPF = !empty($this->dest->getElementsByTagName("CPF")->item(0)->nodeValue)
                    ? $this->dest->getElementsByTagName("CPF")->item(0)->nodeValue
                    : '';
            $consCNPJ = !empty($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue)
                    ? $this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue
                    : '';
            if (empty($cDest)) {
                $cDest = "Consumidor N�o Identifcado";
            }
            $cDest = trim($cDest);
            $cDest = $consCPF.$consCNPJ.$considEstrangeiro; //documentos do consumidor
        }

        //DADOS PARA QRCODE
        $idToken = empty($this->idToken) ? '000001' : $this->idToken;

        $this->imgQRCode = $this->makeQRCode(
            $chNFe,
            $urlQR,
            $tpAmb,
            $cDest,
            $dhEmi,
            $vNF,
            $vICMS,
            $digVal,
            $idToken,
            $Token
        );

        //FORMATA��O DOS CAMPOS
        $numNF = "NFCe ".$this->__format($nNF, "###.###.###");
        $tsHora = $this->__convertTime($dhEmi);
        $tsProt = $this->__convertTime($dhRecbto);
        $valorProdutos = number_format($vProd, 2, ",", ".");
        $valorTotal = number_format($vNF, 2, ",", ".");

        //DADOS DA LOJA
        $_empresa	= new Empresa($GLOBALS['_MASTER']);
        $_empresa->Buscar($this->info_impresssao['cod_loja']);
        $_complemento_cabecalho = $_empresa->getComplemento_cabecalho_fiscal();

        //CABE�ALHO
        $this->html = "";
        $this->html .= "<html>\n";
        $this->html .= "<head>\n";
        $this->html .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
        $this->html .= "<style>";
        $this->html .= "body {";
        $this->html .= "    font-family: Times New Roman;";
        $this->html .= "    font-size: 8pt;";
        $this->html .= "}";
        $this->html .= "h5, p {";
        $this->html .= "    margin: 0pt;";
        $this->html .= "}";
        $this->html .= "table.items {";
        $this->html .= "    font-size: 8pt;";
        $this->html .= "    border-collapse: collapse;";
        $this->html .= "    border: 3px solid #880000;";
        $this->html .= "}";
        $this->html .= "td {";
        $this->html .= "    font-size: 7pt;";
        $this->html .= "    vertical-align: top;";
        $this->html .= "    text-align: center;";
        $this->html .= "}";
        $this->html .= "table thead td {";
        $this->html .= "    background-color: #EEEEEE;";
        $this->html .= "    text-align: center;";
        $this->html .= "}";
        $this->html .= "table tfoot td { background-color: #AAFFEE;";
        $this->html .= "    text-align: center;";
        $this->html .= "}";
        $this->html .= ".barcode {";
        $this->html .= "    padding: 1.5mm;";
        $this->html .= "    margin: 0;";
        $this->html .= "    vertical-align: top;";
        $this->html .= "    color: #000000;";
        $this->html .= "}";
        $this->html .= ".barcodecell {";
        $this->html .= "    text-align: center;";
        $this->html .= "    vertical-align: middle;";
        $this->html .= "    padding: 0;";
        $this->html .= "}";
        $this->html .= ".menor { font-size: 7pt; text-align: center; }";
        $this->html .= "</style>\n";
        $this->html .= "</head>\n";
        $this->html .= "<body>\n";
        $this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td colspan=\"2\"><h2><i>NFC-e</i></h2><br>";//<img src=\"../images/logo.png\" width=\"82\" ></td>\n";
        if (!empty($this->logomarca)) {
	       $this->html .= " <img src=\"{$this->logomarca}\" width=\"82\" height=\"82\">";
        } else {
     		 $this->html .= " <div  width=\"82\" height=\"82\">";
        }
        $this->html .= "</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "<tr>\n";

        $_infoCodLoja = (!empty($this->info_impresssao['cod_loja']) && ((int)$this->info_impresssao['regra_especial_icms']&2048)>0) ? funcoesGerais::str_alinha($this->info_impresssao['cod_loja'],5,DIREITA,false,"0")." - " : '';
        $this->html .= "<td colspan=\"3\">".htmlspecialchars($_infoCodLoja . $emitRazao,null,"UTF-8")."<br>CNPJ:$emitCnpj I.E.:$emitIE<br>".
                htmlspecialchars($emitLgr . ", " . $emitNro,null,"UTF-8"). "<br>".
                htmlspecialchars($emitCpl,null,"UTF-8") . "<br>".
                htmlspecialchars($emitBairro . ", " . $emitMun . ", " . $emitUF,null,"UTF-8") . "<br>CEP: $emitCEP $emitFone". "<br>".
                htmlspecialchars($_complemento_cabecalho, null,"UTF-8") . "</td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td colspan=\"3\" class=\"menor\">".
                htmlspecialchars("DANFE NFC-E Nota Fiscal Eletr�nica para Consumidor Final",null,"UTF-8")."</td>\n";
        $this->html .= "</tr>\n";
        if ($tpAmb == 1) {
            $this->html .= "<tr>\n";
            $this->html .= "<td colspan=\"3\" class=\"menor\"><b>".
                    htmlspecialchars("NFC-e n�o permite aproveitamento de cr�dito de ICMS",null,"UTF-8")."<b></td>\n";
            $this->html .= "</tr>\n";
        } else {
            $this->html .= "<tr>\n";
            $this->html .= "<td colspan=\"3\" class=\"menor\">NFC-e Emitida em Ambiente de Testes</td>\n";
            $this->html .= "</tr>\n";
            $this->html .= "<tr>\n";
            $this->html .= "<td colspan=\"3\" ><b>SEM VALOR FISCAL</b></td>\n";
            $this->html .= "</tr>\n";
        }

        //Se for tipo 9 significa que foi emitida em conting�ncia e segundo a especifica��o t�cnica dever� ter uma mensagem.
        if ((int)$_tpEmis === 9) {
	        $this->html .= "<tr>\n";
	        $this->html .= "<td colspan=\"3\" class=\"menor\">" . utf8_encode("EMITIDA EM CONTING�NCIA") . "</td>\n";
	        $this->html .= "</tr>\n";
        }


        $this->html .= "</table>\n";

            //BLOCO DE DETALHES
        //Segundo a Val�ria, na impress�o do manager precisa ter os itens.
        //if ($detalhes) {
            //ITENS
            $this->html .= $this->itens($this->det, $_somar_desc_nfce);

        //}

        //TOTAIS DA NF
        $this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td align=\"left\">QTDADE TOTAL DE ITENS</td>\n";
        $this->html .= "<td align=\"right\">$qtdItens</td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "<tr>\n";
        $this->html .= "</table>\n";

        //IMPOSTOS
        $this->html .= $impHtml;

        $this->html .= $pagHtml;

        $this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td align=\"left\">" . utf8_encode("Informa��o dos Tributos Incidentes<br>(Lei Federal 12.741/2012)") . " </td>\n";
        $this->html .= "<td align=\"right\">" . $_sigla_moeda . number_format($this->vTotTrib, 2, ',', '.')."</td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "</table>\n";

        //Se a mensagem n�o estiver vazia e for a VIA do cliente exibe a mensagem
		if (!$this->_via_estabelecimento) {
	        $infCpl      = $this->dom->getElementsByTagName("infAdic")->item(0);
    	    $infCpl      = substr($this->__simpleGetValue($infCpl, "infCpl"),1,-1);
            $infAdFisco   = $this->dom->getElementsByTagName("infAdic")->item(0);
            $infAdFisco   = $this->__simpleGetValue($infAdFisco, "infAdFisco");
            if (empty($infAdFisco)) {
                $infAdFisco = " Nao houve a arrecadacao para o FECP";
            }
            if(((int)$this->info_impresssao['regra_especial_icms']&8192)>0&&!empty($infCpl)){
                $infCpl = ucwords(strtolower($infCpl));
                $infCpl = $this->formatarInfCpl($infCpl);
            }
	        if (!empty($infCpl) ) {
		        $this->html .= "<table width=\"100%\">\n";
		        $this->html .= "<tr>\n";
		        $this->html .= "<td align=\"left\">" . utf8_encode("informa��es adicionais de interesse do contribuinte") . " </td>\n";
		        $this->html .= "</tr>\n";
		        $this->html .= "<tr>\n";
		        $this->html .= "<td>" . utf8_encode($infCpl) ."</td>\n";
		        $this->html .= "</tr>\n";
		        $this->html .= "</table>\n";
                if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                    $this->html .= "<tr>\n";
                    $this->html .= "<td>" . utf8_encode($infAdFisco) . "</td>\n";
                    $this->html .= "<tr>\n";
                }
	        }
		}

        //DADOS DA NOTA
        $this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td>".htmlspecialchars($numNF,null,"UTF-8")."</td>\n";
        $this->html .= "<td>" . utf8_encode("S�rie:") . " $serieNF</td>\n";
        $this->html .= "<td>".date('d/m/Y H:i:s', strtotime($dhEmi))."</td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "</table>\n";

        //CHAVE DE ACESSO
        $this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td  colspan=\"3\">Consulte pela Chave de Acesso em <a href=\"$urlChave\" >".
            "$urlChave</a></td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td  colspan=\"3\">Chave de Acesso<br>$chNFe</td>\n";
        $this->html .= "</tr>\n";
        $this->html .= "</table>\n";

         //CONSUMIDOR
        $this->html .= $this->consumidor($this->dest);

        if ((int)$_tpEmis === 9) {
            $this->html .= "<table width=\"100%\">\n";
            $this->html .= "<tr>\n";
            $this->html .= "<td colspan=\"3\" class=\"menor\">" . utf8_encode("EMITIDA EM CONTING�NCIA") . "</td>\n";
            $this->html .= "</tr>\n";
            $this->html .= "<tr>\n";
            $this->html .= "<td colspan=\"3\" class=\"menor\">" . utf8_encode("Pendente de autoriza��o") . "</td>\n";
            $this->html .= "</tr>\n";
            $this->html .= "</table>\n";
        }

        //
        $cMsg = $this->__simpleGetValue($this->nfeProc, "cMsg");
        $xMsg = $this->__simpleGetValue($this->nfeProc, "xMsg");

        if ((int)$cMsg == 200 && !empty($xMsg)) {
            $_arrXMSG = explode("|",$xMsg);
            $this->html .= "<table width=\"100%\">\n";
            foreach ($_arrXMSG as $_msg) {
                $this->html .= "<tr>\n";
                $this->html .= "<td  colspan=\"3\">{$_msg}</td>\n";
                $this->html .= "</tr>\n";
            }
            $this->html .= "</table>\n";
        }
		$this->html .= "<table width=\"100%\">\n";
        $this->html .= "<tr>\n";
        $this->html .= "<td  colspan=\"3\"><b>Consulta via leitor QR Code</b></td>\n";
        $this->html .= "</tr>\n";

        $this->html .= "<tr>\n";

        //Isso pq a imagem era apagada antes de imprimirmos
        if (!$this->_eh_pdf) {
	        $_img_qr_code = $this->base64_encode_image($this->imgQRCode,'png');
	        $this->html  .= '<td  colspan="3"><img src="' . $_img_qr_code . '"/></td>';
	        //Apaga o arquivo
	        unlink($this->imgQRCode);
        } else {
    	    $this->html .= "<td  colspan=\"3\"><img src=\"./".$this->imgQRCode."\" ></td>\n";
        }

        $this->html .= "</tr>\n";
        $this->html .= "</table>\n";
        if (!empty($nProt)) {
	        $this->html .= "<table width=\"100%\">\n";
	        $this->html .= "<tr>\n";
	        $this->html .= "<td>" . utf8_encode("Prot. Autoriza��o: ") . " $nProt - ".date('d/m/Y H:i:s', $tsProt)."</td>\n";
	        $this->html .= "</tr>\n";
	        $this->html .= "</table>\n";
        }
        $this->html .= "</body>\n</html>\n";
        return $chNFe;
    }//fim da fun��o montaDANFE

    public function formatarInfCpl($_infCpl) {
        $_padrao = '/Federal R\$ ([0-9,\.]+).*?Estadual R\$ ([0-9,\.]+).*?Municipal R\$ ([0-9,\.]+)/i';
        if (preg_match($_padrao, $_infCpl, $_matches)) {
            $_federal = $_matches[1];
            $_estadual = $_matches[2];
            $_municipal = $_matches[3];
            return 'FONTE: IBPT; Tributos Totais Incidentes (Lei Federal 12.741/2012) - Federal R$ ' . $_federal .
                ' Estadual R$ ' . $_estadual . ' Municipal R$ ' . $_municipal;
        }
        return $_infCpl;
    }

    protected function pagamento($pag, &$tPnome) {
        if (!isset($pag)) {
            return '';
        }
        //DADOS DE PAGAMENTO
        $oldtBand = '';
        $oldtPag = '';
        $pagHtml = "<table width=\"100%\">\n<tr>";
		$pagHtml .= "<td align=\"left\">FORMA DE PAGAMENTO</td>\n";
        $pagHtml .= "<td align=\"right\">VALOR PAGO</td>\n";
        $pagHtml .= "</tr>\n";

        /**
         * SEGDOCFIN-1
         * BIT
         * Out.2023
         */
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
        $_getDadosPagamento = $this->_obj_pai->getDadosPagamentos();
        if(is_object($this->_obj_pai)&&!empty($_getDadosPagamento)) {
            foreach($this->_obj_pai->getDadosPagamentos() as $_fin => $_pagto) {
                $pagHtml .= "<tr>\n";
                $pagHtml .= "<td align=\"left\">{$_fin} " . htmlspecialchars($_pagto['DESCRICAO'],null,"UTF-8") . "</td>\n";
                $pagHtml .= "<td align=\"right\">" . $_sigla_moeda . number_format($_pagto['VLR_RECEBIDO'],2,",",".") . "</td>\n";
                $pagHtml .= "</tr>\n";
                $_documentos = [];
                for($_idx=1;$_idx<=6;$_idx++) {
                    if(!empty($_pagto["DOC{$_idx}"])) {
                        $_documentos[] = $_pagto["LEGENDA{$_idx}"] . ":" . $_pagto["DOC{$_idx}"];
                    }
                }
                if(!empty($_documentos)) {
                    $pagHtml .= "<tr>\n";
                    $pagHtml .= "<td align='left'>" . implode(",",$_documentos) . "</td>";
                    $pagHtml .= "<td></td>";
                    $pagHtml .= "</tr>\n";
                }
            }
        } else {
            foreach($pag as $pagI) {
                $tPag = $this->__simpleGetValue($pagI,"tPag");
                $tPagNome = $this->tipoPag($tPag);
                $tPnome = $tPagNome;
                $vPag = number_format($this->__simpleGetValue($pagI,"vPag"),2,",",".");
                //$card = $pagI->getElementsByTagName("card")->item(0);
                //cart�o
//                if(isset($card)) {
//                    $cardCNPJ = $this->__simpleGetValue($card,"CNPJ");
//                    $tBand = $this->__simpleGetValue($card,"tBand");
//                    //$cAut = $this->__simpleGetValue($card, "cAut");
//                    $tBandNome = self::getCardName($tBand);
//                }
                //Quando tinha duas formas de pagamento cart�o n�o imprimia as duas linhas
                //if ($tPag != $oldtPag) {
                $pagHtml .= "<tr>\n";
                $pagHtml .= "<td align=\"left\">" . htmlspecialchars($tPagNome,null,"UTF-8") . "</td>\n";
                $pagHtml .= "<td align=\"right\">$vPag</td>\n";
                $pagHtml .= "</tr>\n";
                $oldtPag = $tPag;
                //}
//                if($cardCNPJ!=''&&$oldtBand!=$tBand) {
//                    $pagHtml .= "<tr>\n";
//                    $pagHtml .= "<td align=\"left\">" . htmlspecialchars($tBandNome,null,"UTF-8") . "</td>\n";
//                    $pagHtml .= "<td align=\"right\">" . $this->__format($cardCNPJ,"##.###.###/####-##") . "</td>\n";
//                    $pagHtml .= "</tr>\n";
//                    $oldtBand = $tBand;
//                }
            } //fim foreach
        }

        if($this->_versao_nfe >= 4) {
            $pagHtml .= "<tr>\n";
            $pagHtml .= "<td align=\"left\">".htmlspecialchars('Troco',null,"UTF-8")."</td>\n";
            $pagHtml .= "<td align=\"right\">".( !empty($this->vTroco->nodeValue) ? $_sigla_moeda . $this->vTroco->nodeValue : '' )."</td>\n";
            $pagHtml .= "</tr>\n";
        }


        $pagHtml .= "</table>\n";
        return $pagHtml;
    }

    protected static function getCardName($tBand)
    {
        switch ($tBand) {
            case '01':
                $tBandNome = 'VISA';
                break;
            case '02':
                $tBandNome = 'MASTERCARD';
                break;
            case '03':
                $tBandNome = 'AMERICAN EXPRESS';
                break;
            case '04':
                $tBandNome = 'SOROCRED';
                break;
            case '05':
                $tBandNome = 'DINERS CLUB';
                break;
            case '06':
                $tBandNome = 'ELO';
                break;
            case '07':
                $tBandNome = 'HIPERCARD';
                break;
            case '08':
                $tBandNome = 'AURA';
                break;
            case '09':
                $tBandNome = 'CABAL';
                break;
            case '10':
                $tBandNome = 'ALELO';
                break;
            case '11':
                $tBandNome = 'BANES CARD';
                break;
            case '12':
                $tBandNome = 'CALCARD';
                break;
            case '13':
                $tBandNome = 'CREDZ';
            break;
                case '14':
                $tBandNome = 'DISCOVER';
                break;
            case '15':
                $tBandNome = 'GOODCARD';
                break;
            case '16':
                $tBandNome = 'GREENCARD';
                break;
            case '17':
                $tBandNome = 'HIPER';
                break;
            case '18':
                $tBandNome = 'JCB';
                break;
            case '19':
                $tBandNome = 'MAIS';
                break;
            case '20':
                $tBandNome = 'MAXVAN';
                break;
            case '21':
                $tBandNome = 'POLICARD';
                break;
            case '22':
                $tBandNome = 'REDECOMPRAS';
                break;
            case '23':
                $tBandNome = 'SODEXO';
                break;
            case '24':
                $tBandNome = 'VALECARD';
                break;
            case '25':
                $tBandNome = 'VEROCHEQUE';
                break;
            case '26':
                $tBandNome = 'VR';
                break;
            case '27':
                $tBandNome = 'TICKET';
                break;
            case '99':
                $tBandNome = 'OUTROS';
                break;
            default:
                break;
        }
        return $tBandNome;
    }//fim getCardName

    protected function tipoPag($tPag)
    {
        switch ($tPag) {
            case '01':
                $tPagNome = 'Dinheiro';
                break;
            case '02':
                $tPagNome = 'Cheque';
                break;
            case '03':
                $tPagNome = 'Cart�o de Cr�dito';
                break;
            case '04':
                $tPagNome = 'Cart�o de D�bito';
                break;
            case '05':
                $tPagNome = 'Cr�dito Loja';
                break;
            case '10':
                $tPagNome = 'Vale Alimenta��o';
                break;
            case '11':
                $tPagNome = 'Vale Refei��o';
                break;
            case '12':
                $tPagNome = 'Vale Presente';
                break;
            case '13':
                $tPagNome = 'Vale Combust�vel';
                break;
            case '14':
                $tPagNome = 'Duplicata Mercantil';
                break;
            case '15':
                $tPagNome = 'Boleto Bancario';
                break;
            case '16':
                $tPagNome = 'Dep�sito Banc�rio';
                break;
            case '17':
                $tPagNome = 'Pagamento Instant�neo (PIX)';
                break;
            case '18':
                $tPagNome = 'Transfer�ncia Banc�ria, Carteira Digital';
                break;
            case '19':
                $tPagNome = 'Programa de fidelidade, Cashback, Cr�dito Virtual';
                break;
            case '99':
                $tPagNome = 'Outros';
        }
        return utf8_encode($tPagNome);
    }

    protected function itens($det, $_somar_desc_nfce = null)
    {
        if (!isset($det)) {
            return '';
        }

        $_imprimir_desc_acres_item = ($GLOBALS["_VERSAO_NT"] & 512) > 0;
        $_imprimir_valor_liquido_item = $_somar_desc_nfce == 'S';

        //ITENS
        //Ajusta a ordem caso esteja invertido.
		$nitem_ant  = null;
		$_no_fim    = true;
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
        foreach ($det as $detI) {
            $thisItem   = $detI;
            $prod       = $thisItem->getElementsByTagName("prod")->item(0);
            $nitem      = $thisItem->getAttribute("nItem");
            $infAdProd  = $thisItem->getElementsByTagName("infAdProd")->item(0)->nodeValue;

            //Se for menor, coloca no come�o, e vamos ordenar.
            if (!isset($nitem_ant) || $nitem_ant > $nitem) {
            	if (isset($nitem_ant)) {
            		$_no_fim = false;
            	}
            	$nitem_ant = $nitem;
            }
            //Se houver EAN no XML, uso ele na impress�o.
            $_valorProd = $this->__simpleGetValue($prod, "cEAN");
            if($this->_imprimir_cod_lido && !empty($_valorProd) && $_valorProd != 'SEM GTIN'){
                $prod->getElementsByTagName("cProd")->item(0)->nodeValue = $prod->getElementsByTagName("cEAN")->item(0)->nodeValue;
            }
            $cProd      = $this->__simpleGetValue($prod, "cProd");
            $xProd      = $this->__simpleGetValue($prod, "xProd");

            /**
             * BL-7410
             * Foi pedido no BL-7073 para retirar o "Pre�o De Por" da descri��o do produto e colocado nas informa��es adicionais.
             * Ent�o estamos extraindo essa informa��o para poder imprimir corretamente no item do cupom.
             */
            $_de_por = '';
            $_array_infAdProd = explode('|', $infAdProd);
            foreach($_array_infAdProd as $_info) {
                $_info = trim($_info);
                if(strpos($_info, 'DESC_PROMO:') !== false) {
                    $_de_por = trim(str_replace(['DESC_PROMO:', $xProd], '', $_info));
                } else {
                    $infAdProd = $_info;
                }
            }

            // Temos que tratar o as informa��es adicionais pois agora pode vir com outros valores al�m do FECP.
            if (empty($infAdProd)) {
                $infAdProd = " Nao houve a arrecadacao para o FECP";
            }

            $qCom       = number_format($this->__simpleGetValue($prod, "qCom"), 3, ",", ".");
            $uCom       = $this->__simpleGetValue($prod, "uCom");

            /**
             * ML-1407
             * BIT Software
             * 28.04.2020
             * Ajuste nas casas decimais
             */
            $_vUnCom = $this->__simpleGetValue($prod, "vUnCom");
            $_cd = defined('CD_PRECO_UNITARIO') ? CD_PRECO_UNITARIO : 2;
            $_cd = $_cd>4 ? 4 : $_cd;
            $vUnCom = number_format($_vUnCom, $_cd, ",", ".");
            if($GLOBALS['_DEBUG']) {
                funcoesGerais::GravaLog("[CD] cd={$_cd} vUnCom[f]={$_vUnCom} vUnCom={$this->__simpleGetValue($prod, "vUnCom")}",true,true);
            }

            // Valor Total
            $_vProd = (float)$this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desc_acres_item = '';
            $_desconto = (float)trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = (float)trim($this->__simpleGetValue($prod, "vOutro"));
            if($_imprimir_desc_acres_item) {
                if (!empty($_desconto)) {
                    $_desc = number_format($_desconto, 2, ",", ".");
                    $_desc_acres_item.= "Desconto: {$_sigla_moeda}{$_desc} ";
                }
                if (!empty($_acrescimo)) {
                    $_acres = number_format($_acrescimo, 2, ",", ".");
                    $_desc_acres_item.= "Acrescimo: {$_sigla_moeda}{$_acres} ";
                }
            }


            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = $_vProd - $_desconto + $_acrescimo;
            }

            $_titulo =  "<tr>\n";
            $_titulo .=  "<td align=\"left\">".htmlspecialchars($nitem,null,"UTF-8")."</td>\n";
            $_titulo .=  "<td align=\"left\">".htmlspecialchars($cProd,null,"UTF-8")."</td>\n";
            $_titulo .=  "<td colspan = \"5\" align=\"left\">".htmlspecialchars($xProd,null,"UTF-8")."</td>\n";
            $_titulo .= "</tr>\n";
            $_titulo .= "<tr>\n";
            if(!empty($_de_por)) {
                $_titulo .= "<td colspan = \"3\" align=\"left\">" . htmlspecialchars($_de_por, null, "UTF-8") . "</td>\n";
            } else {
                $_titulo .= "<td colspan = \"3\">\n";
            }
            $_titulo .= "<td align=\"right\">$qCom</td>\n";
            $_titulo .= "<td align=\"right\">$uCom</td>\n";

            $_titulo .= "<td align=\"right\" width=\"60\" >" . $_sigla_moeda . htmlspecialchars($vUnCom, null, "UTF-8") . "</td>\n";
            $_titulo .= "<td align=\"right\" width=\"60\" >" . $_sigla_moeda . number_format($_vProd, 2, ",", ".") . "</td>\n";
            $_titulo .= "</tr>\n";

            if (!empty($_desc_acres_item)) {
                $_titulo .= "<tr>\n";
                $_titulo .= "<td colspan = \"7\" align=\"left\">" . htmlspecialchars($_desc_acres_item, null, "UTF-8") . "</td>\n";
                $_titulo .= "</tr>\n";
            }

            if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                $_titulo .= "<tr>\n";
                $_titulo .= "<td colspan = \"7\" align=\"center\">" . htmlspecialchars($infAdProd, null, "UTF-8") . "</td>\n";
                $_titulo .= "</tr>\n";
            }

            /**
             * ML-2951
             * BIT
             * Jan.2024
             */
            if(($GLOBALS["_VERSAO_NT"]&33554432)<=0) {
                $_frete = (float)trim($this->__simpleGetValue($prod, "vFrete"));
                if(!empty($_frete)) {
                    $_titulo .= "<tr>\n";
                    $_titulo .= "<td colspan=\"2\"></td>";
                    $_titulo .= "<td colspan=\"4\" align=\"left\">Frete</td>";
                    $_titulo .= "<td align=\"right\">" . $_sigla_moeda . number_format($_frete,2,",",".") . "</td>\n";
                    $_titulo .= "</tr>\n";
                }
            }

            //Pra acertar a ordena��o dos itens, caso esteja invertido.
            if ($_no_fim) {
	            $itensHtml .= $_titulo;
            } else {
            	$itensHtml = $_titulo . $itensHtml;
            }
        }
        $itensHtml = "<table width='100%'>\n" .
        			"<tr>\n".
        			"<td>#</td>\n".
        			"<td>".htmlspecialchars('CODIGO',null,"UTF-8")."</td>\n".
        			"<td>".htmlspecialchars('DESCRICAO',null,"UTF-8")."</td>\n".
        			"<td>QUANT.</td>\n".
        		    "<td>UN.</td>\n".
        			"<td>VL.UNIT.</td>\n".
        			"<td>VL.TOTAL</td>\n" .
        		    "</tr>\n" . $itensHtml;

        $itensHtml .= "</table>\n";
        return $itensHtml;
    }//fim itens

    protected function consumidor($dest)
    {
        //DADOS DO CONSUMIDOR
        if (!isset($dest)) {
            return '';
        }
        $enderDest = $dest->getElementsByTagName("enderDest")->item(0);
        $consNome = $this->__simpleGetValue($dest, "xNome");
        $consFone = $this->__simpleGetValue($dest, "fone");
        $foneLen = strlen($consFone);
        if ($foneLen > 0) {
            $fone2 = substr($consFone, 0, $foneLen-4);
            $fone1 = substr($consFone, 0, $foneLen-8);
            $consFone = '('.$fone1.') '.substr($fone2, -4).'-'.substr($consFone, -4);
        } else {
            $consFone = '';
        }
        $consLgr = $this->__simpleGetValue($enderDest, "xLgr");
        $consNro = $this->__simpleGetValue($enderDest, "nro");
        $consCpl = $this->__simpleGetValue($enderDest, "xCpl", " - ");
        $consBairro = $this->__simpleGetValue($enderDest, "xBairro");
        $consCEP = $this->__format($this->__simpleGetValue($enderDest, "CEP"));
        $consMun = $this->__simpleGetValue($enderDest, "xMun");
        $consUF = $this->__simpleGetValue($enderDest, "UF");
        $considEstrangeiro = $this->__simpleGetValue($dest, "idEstrangeiro");
        $consCPF = $this->__simpleGetValue($dest, "CPF");
        $consCNPJ = $this->__simpleGetValue($dest, "CNPJ");
        $consDoc = $consCPF.$consCNPJ.$considEstrangeiro; //documentos do consumidor

        $consHtml = '';
        if(empty($consDoc) || $consDoc == '99999999000191') {
            $consHtml .= "<table width='100%'>\n";
            $consHtml .= "<tr>\n<td>CONSUMIDOR NAO IDENTIFICADO</td>\n</tr>\n";
            $consHtml .= "</table>\n";
        }else{
            $consHtml .= "<table width='100%'>\n";
            $consHtml .= "<tr>\n<td>CONSUMIDOR</td>\n</tr>\n";
            $consHtml .= "<tr>\n<td>CNPJ/CPF/ID Estrangeiro : ".htmlspecialchars($consDoc,null,"UTF-8")."</td>\n</tr>\n";
            $consHtml .= "<tr>\n<td>".htmlspecialchars($consNome,null,"UTF-8")."</td>\n</tr>\n";
            if (!empty($consLgr) || (!empty($consBairro)) || (!empty($consMun)) ) {
                $consHtml .= "<tr>\n";
                $consHtml .= "<td>".htmlspecialchars($consLgr.", ".$consNro.$consCpl,null,"UTF-8")."<BR>\n".
                    htmlspecialchars($consBairro." - ".$consCEP,null,"UTF-8")."<BR>\n".
                    htmlspecialchars($consMun." - ".$consUF." "."Fone/Fax: ".$consFone,null,"UTF-8")."</td>\n";
                $consHtml .= "</tr>\n";
            }
            $consHtml .= "</table>\n";
        }
        return $consHtml;
    }//fim consumidor

    /**
     *
     * @param type $nome
     * @param type $destino
     * @return type
     */
    public function printDANFE($output = 'pdf', $nome = '', $destino = 'I', $_tipo_papel= null)
    {

        if ($output == 'pdf') {
            //montagem do pdf

            if (is_array($this->papel) && strtolower($this->papel[1])=='one-page') {
                $mpdf=new mPDF('', array($this->papel[0], 843.89));
                $mpdf->useCoreFontsOnly = true;
                $mpdf->ignore_invalid_utf8 = true;
                $mpdf->WriteHTML($this->html, 0, true, false);
                $this->papel=array($this->papel[0], $mpdf->y);
            }
            if($_tipo_papel == 'JT'){
                $this->mpdf = new mPDF('', 'A4', 0, '', 5, (595.28 / (72/25.4)) - 80, 5, 5, 0, 0, 'P');
            }
            else {
                $this->mpdf = new mPDF('', $this->papel, 0, '', 0, 0, 0, 0, 0, 'P');
            }

            $this->mpdf->ignore_invalid_utf8 = true;

            $this->mpdf->WriteHTML($this->html);
            if (is_file($this->imgQRCode)) {
                unlink($this->imgQRCode);
            }
            return $this->mpdf->Output($nome, $destino);

        } else {
            echo $this->html;
            if (is_file($this->imgQRCode)) {
                unlink($this->imgQRCode);
            }
        }
        return true;
    }//fim printDANFE


    /**
     * @param $filename
     * @param $filetype
     * @return string|void
     */
    protected function base64_encode_image($filename=null,$filetype='png') {
    	if($filename) {
    		$filename  = funcoesGerais::retornarCaminhoAbsolutoManager() . $filename;
    		$imgbinary = fread(fopen($filename, "r"), filesize($filename));
    		$imgbinary = str_replace(" ", "/", (trim(base64_encode($imgbinary))));
    		return 'data:image/' . $filetype . ';base64,' . $imgbinary ;
    	}
    }

    protected function makeQRCode(
        $chNFe,
        $url,
        $tpAmb,
        $cDest = '',
        $dhEmi = '',
        $vNF = '',
        $vICMS = '',
        $digVal = '',
        $idToken = '000001',
        $Token = ''
    ) {
        if(($GLOBALS["_VERSAO_NT"] & 134217728) > 0) {
            $_versao_qrcode = 3;
        } else {
            $_versao_qrcode = $this->getObjNFeZanthus()->aVerImpressao["IncluirQRCodeXMLNFCe"];
        }
       $seq = funcoesGerais::montarURLQrCodeNFCe($chNFe, $url, $tpAmb, $cDest, 
       											 $dhEmi, $vNF, $vICMS, $digVal, $idToken, $Token,$_versao_qrcode, $this->getObjNFeZanthus()->getrPrivkey());

       // echo $seq . "<br>";
        $imgQrCode = new QRcode($seq, 'M');
        $filename = $chNFe.date('YmdHis').'.png';
        $imgQrCode->displayPNG(200, array(255,255,255), array(0,0,0), $filename, 0);
        return $filename;

    }//fim makeQRCode
}//fim Classe

/**
 * Classe respons�vel por imprimir o comprovante do CFe pelo manager
 * @author fernando.silva
 *
 */
class DanfeSATPHP extends DanfeNFCeNFePHP {
	protected $vTotalTrib;
	/**
	 *
	 * @param type $docXML
	 * @param type $sPathLogo
	 * @param type $mododebug
	 * @param type $idToken
	 * @param type $Token
	 */
	public function __construct($docXML = '', $sPathLogo = '', $mododebug = 0, $idToken = '', $emitToken = '') {
		if (is_numeric($mododebug)) {
			$this->debugMode = $mododebug;
		}
        //Quem defini isso � o defines o class_bd
		/*if ($this->debugMode) {
			//ativar modo debug
			error_reporting(E_ALL);
			ini_set('display_errors', 'On');
		} else {
			//desativar modo debug
			error_reporting(0);
			ini_set('display_errors', 'Off');
		}*/
		$this->papel = array(80, 'one-page');

		$this->xml          = utf8_encode($docXML);
		$this->logomarca    = $sPathLogo;
		if (!empty($this->xml)) {
			$this->dom = new DomDocument;
			$this->dom->loadXML($this->xml);
			$this->nfe        = $this->dom->getElementsByTagName("CFe")->item(0);
			$this->infNFe     = $this->dom->getElementsByTagName("infCFe")->item(0);
            $this->infAdic    = $this->dom->getElementsByTagName("infAdic")->item(0);
			$this->ide        = $this->dom->getElementsByTagName("ide")->item(0);
			$this->emit       = $this->dom->getElementsByTagName("emit")->item(0);
			$this->enderEmit  = $this->dom->getElementsByTagName("enderEmit")->item(0);
			$this->det        = $this->dom->getElementsByTagName("det");
			$this->dest       = $this->dom->getElementsByTagName("dest")->item(0);
			$this->pag        = $this->dom->getElementsByTagName("MP");
			$this->imposto    = $this->dom->getElementsByTagName("imposto")->item(0);
			$this->ICMSTot    = $this->dom->getElementsByTagName("ICMSTot")->item(0);
		}
		$this->idToken = $idToken;
		$this->emitToken = $emitToken;

	} //fim __construct


	/**
	 * o objetivo desta fun��o � ler o XML e gerar o DANFE com auxilio de convers�o HTML-PDF
     * @param bool|type $detalhes
	 * @return type
	 */
	public function montaDANFE($detalhes = false, $_somar_desc_nfce = null)
	{
		//DADOS DA NF
		$nProt = $this->__simpleGetValue($this->nfeProc, "nProt");
		$dhRecbto  = $this->__simpleGetValue($this->nfeProc, "dhRecbto");
		$digVal = $this->__simpleGetValue($this->nfe, "DigestValue");
		//$chNFe = str_replace('CFe', '', $this->infNFe->getAttribute("Id"));

		//Dados de CFe cancelado, se houver
		$chCancNFe = str_replace('CFe', '', $this->infNFe->getAttribute("chCanc"));
		$dCancEmi = $this->__simpleGetValue($this->infNFe, "dEmi");
		$hCancEmi = $this->__simpleGetValue($this->infNFe, "hEmi");
		$dhCancEmi = substr($dCancEmi,0,4).'-'.substr($dCancEmi,4,2).'-'.substr($dCancEmi,6,2);
		$dhCancEmi .= 'T'.substr($hCancEmi,0,2).':'.substr($hCancEmi,2,2).':'.substr($hCancEmi,4,2).date("P",time());
		if(!empty($chCancNFe)) {
			$_cfe_cancelado = true;
		}else{
			$_cfe_cancelado = false;
		}


		//DADOS DO CFe
		$digVal = $this->__simpleGetValue($this->nfe, "DigestValue");
		$chNFe = str_replace('CFe', '', $this->infNFe->getAttribute("Id"));
		$tpAmb = $this->__simpleGetValue($this->ide, 'tpAmb');
		$cUF = $this->__simpleGetValue($this->ide, 'cUF');
		$nNF = $this->__simpleGetValue($this->ide, 'nCFe');
		$serieNF = str_pad($this->__simpleGetValue($this->ide, "nserieSAT"), 3, "0", STR_PAD_LEFT);

		$dEmi = $this->__simpleGetValue($this->ide, "dEmi");
		$hEmi = $this->__simpleGetValue($this->ide, "hEmi");
		$dhEmi = substr($dEmi,0,4).'-'.substr($dEmi,4,2).'-'.substr($dEmi,6,2);
		$dhEmi .= 'T'.substr($hEmi,0,2).':'.substr($hEmi,2,2).':'.substr($hEmi,4,2).date("P",time());

		$vProd = $this->__simpleGetValue($this->ICMSTot, "vProd");
		$vNF = $this->__simpleGetValue($this->nfe, "vCFe");
		$vOutros  = $this->__simpleGetValue($this->ICMSTot, "vOutro");
		$vDesc  = $this->__simpleGetValue($this->ICMSTot, "vDesc");
		$vICMS = $this->__simpleGetValue($this->ICMSTot, "vICMS");
		$vPIS = $this->__simpleGetValue($this->ICMSTot, "vPIS");
		$vCOFINS = $this->__simpleGetValue($this->ICMSTot, "vCOFINS");
		$vPISST = $this->__simpleGetValue($this->ICMSTot, "vPISST");
		$vCOFINSST = $this->__simpleGetValue($this->ICMSTot, "vCOFINSST");


		$qtdItens = $this->det->length;
		$urlQR    = $this->__simpleGetValue($this->ide, "assinaturaQRCODE");


		//DADOS DO EMITENTE
		$emitRazao  = $this->__simpleGetValue($this->emit, "xNome");
		$emitCnpj   = $this->__simpleGetValue($this->emit, "CNPJ");
		$emitCnpj   = $this->__format($emitCnpj, "##.###.###/####-##");
		$emitIE     = $this->__simpleGetValue($this->emit, "IE");
		$emitFone = $this->__simpleGetValue($this->enderEmit, "fone");
		$foneLen = strlen($emitFone);
		if ($foneLen>0) {
			$fone2 = substr($emitFone, 0, $foneLen-4);
			$fone1 = substr($emitFone, 0, $foneLen-8);
			$emitFone = '('.$fone1.') '.substr($fone2, -4).'-'.substr($emitFone, -4);
		} else {
			$emitFone = '';
		}
		$emitLgr = $this->__simpleGetValue($this->enderEmit, "xLgr");
		$emitNro = $this->__simpleGetValue($this->enderEmit, "nro");
		$emitCpl = $this->__simpleGetValue($this->enderEmit, "xCpl", " - ");
		$emitBairro = $this->__simpleGetValue($this->enderEmit, "xBairro");
		$emitCEP = $this->__format($this->__simpleGetValue($this->enderEmit, "CEP"), "#####-###");
		$emitMun = $this->__simpleGetValue($this->enderEmit, "xMun");
		$emitUF = $this->__simpleGetValue($this->enderEmit, "UF");

		//pag
		$tPagNome = '';
		$pagHtml = $this->pagamento($this->pag, $tPagNome);

        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';

		//IMPOSTOS
		$impHtml = "<table width=\"100%\">\n";
		if ($vNF !== $vProd) {
			$impHtml .= "<tr>\n";
			$impHtml .= "<td align=\"left\">".htmlspecialchars('VALOR PRODUTOS',null,"UTF-8")."</td>\n";
			$impHtml .= "<td align=\"right\">". $_sigla_moeda . number_format($vProd, 2, ',', '.')."</td>\n";
			$impHtml .= "</tr>\n";
		}
		if ($vOutros > 0) {
			$impHtml .= "<tr>\n";
			$impHtml .= "<td align=\"left\">" . utf8_encode("ACR�SCIMO") . "</td>\n";
			$impHtml .= "<td align=\"right\">". $_sigla_moeda . number_format($vOutros, 2, ',', '.')."</td>\n";
			$impHtml .= "</tr>\n";
		}
		if ($vDesc > 0) {
			$impHtml .= "<tr>\n";
			$impHtml .= "<td align=\"left\">DESCONTOS</td>\n";
			$impHtml .= "<td align=\"right\">". $_sigla_moeda . number_format($vDesc, 2, ',', '.')."</td>\n";
			$impHtml .= "</tr>\n";
		}

        /**
         * ML-2951
         * BIT
         * Jan.2024
         */
        $_frete = (float)trim($this->__simpleGetValue($this->ICMSTot, "vFrete"));
        if(!empty($_frete)) {
            $impHtml .= "<tr>\n";
            $impHtml .= "<td align=\"left\">FRETE TOTAL</td>\n";
            $impHtml .= "<td align=\"right\">". $_sigla_moeda .number_format($_frete, 2, ',', '.')."</td>\n";
            $impHtml .= "</tr>\n";
        }

		$impHtml .= "<tr>\n";
		$impHtml .= "<td align='left'>VALOR TOTAL</td>\n";
		$impHtml .= "<td align='right'>". $_sigla_moeda . number_format($vNF, 2, ',', '.')."</td>\n";
		$impHtml .= "</tr>\n";
		$impHtml .= "</table>\n";

		//necess�rio para QRCode
		$cDest  = '';
		if (isset($this->dest)) {
			$consCPF = !empty($this->dest->getElementsByTagName("CPF")->item(0)->nodeValue)
			? $this->dest->getElementsByTagName("CPF")->item(0)->nodeValue
			: '';
			$consCNPJ = !empty($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue)
			? $this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue
			: '';
			$cDest = $consCPF.$consCNPJ; //documentos do consumidor
		}

		//DADOS PARA QRCODE
		$idToken = empty($this->idToken) ? '000001' : $this->idToken;

		$this->imgQRCode = $chNFe .'|';
		$this->imgQRCode .= $dEmi . $hEmi . '|';
		$this->imgQRCode .= $vNF . '|';
		$this->imgQRCode .= (empty($consCPF)?$consCNPJ:$consCPF) . '|';
		$this->imgQRCode .= $this->__simpleGetValue($this->nfe, "assinaturaQRCODE");

		$this->imgQRCode = $this->makeQRCode2($this->imgQRCode);

		$barCode = $chNFe;

		//FORMATA��O DOS CAMPOS
		$numNF = "CFe ".$this->__format($nNF, "###.###.###");
		$tsHora = $this->__convertTime($hEmi);
		$tsProt = $this->__convertTime($dEmi);
		$valorProdutos = number_format($vProd, 2, ",", ".");
		$valorTotal = number_format($vNF, 2, ",", ".");

        //DADOS DA LOJA
        $_empresa	= new Empresa($GLOBALS['_MASTER']);
        $_empresa->setcod_loja($this->info_impresssao['cod_loja']);
        $_empresa->retornarCodigoUFLoja();
        $_ufLoja = $_empresa->getDes_sigla();
        $_empresa->Buscar($this->info_impresssao['cod_loja']);
        $_complemento_cabecalho = $_empresa->getComplemento_cabecalho_fiscal();

		//CABE�ALHO
		$this->html = "";
		$this->html .= "<html>\n";
		$this->html .= "<head>\n";
		$this->html .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
		$this->html .= "<style>";
		$this->html .= "body {";
		$this->html .= "    font-family: Times New Roman;";
		$this->html .= "    font-size: 8pt;";
		$this->html .= "    background: transparent url('imagens/bgbarcode.png') repeat-y scroll left top;";
		$this->html .= "}";
		$this->html .= "h5, p {";
		$this->html .= "    margin: 0pt;";
		$this->html .= "}";
		$this->html .= "table.items {";
		$this->html .= "    font-size: 8pt;";
		$this->html .= "    border-collapse: collapse;";
		$this->html .= "    border: 3px solid #880000;";
		$this->html .= "}";
		$this->html .= "td {";
		$this->html .= "    font-size: 7pt;";
		$this->html .= "    vertical-align: top;";
		$this->html .= "    text-align: center;";
		$this->html .= "}";
		$this->html .= "table thead td {";
		$this->html .= "    background-color: #EEEEEE;";
		$this->html .= "    text-align: center;";
		$this->html .= "}";
		$this->html .= "table tfoot td { background-color: #AAFFEE;";
		$this->html .= "    text-align: center;";
		$this->html .= "}";
		$this->html .= ".barcode {";
		$this->html .= "    padding: 1.5mm;";
		$this->html .= "    margin: 0;";
		$this->html .= "    vertical-align: top;";
		$this->html .= "    color: #000000;";
		$this->html .= "}";
		$this->html .= ".barcodecell {";
		$this->html .= "    text-align: center;";
		$this->html .= "    vertical-align: middle;";
		$this->html .= "    padding: 0;";
		$this->html .= "}";
		$this->html .= ".menor { font-size: 7pt; text-align: center; }";
		$this->html .= "</style>\n";
		$this->html .= "</head>\n";
		$this->html .= "<body>\n";
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td colspan=\"3\"><h2><i>CF-e</i></h2><br>";//<img src=\"../images/logo.png\" width=\"82\" ></td>\n";
		if (!empty($this->logomarca)) {
			$this->html .= " <img src=\"{$this->logomarca}\" width=\"82\" height=\"82\">";
		} else {
			$this->html .= " <div  width=\"82\" height=\"82\">";
		}
		$this->html .= "</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "<tr>\n";

        $_infoCodLoja = (!empty($this->info_impresssao['cod_loja']) && ((int)$this->info_impresssao['regra_especial_icms']&2048)>0) ? funcoesGerais::str_alinha($this->info_impresssao['cod_loja'],5,DIREITA,false,"0")." - " : '';
		$this->html .= "<td colspan=\"3\">".htmlspecialchars($_infoCodLoja . $emitRazao,null,"UTF-8")."<br>CNPJ:$emitCnpj I.E.:$emitIE<br>".
				htmlspecialchars($emitLgr . ", " . $emitNro,null,"UTF-8"). "<br>".
				htmlspecialchars($emitCpl,null,"UTF-8") . "<br>".
                htmlspecialchars($emitBairro . ", " . $emitMun . ", " . $emitUF,null,"UTF-8") . "<br>CEP: $emitCEP $emitFone". "<br>".
                htmlspecialchars($_complemento_cabecalho, null,"UTF-8") . "</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td colspan=\"3\" class=\"menor\">";

		if($_cfe_cancelado){
			$this->html .= "<b> Extrato No. {$nNF} <br>";
			$this->html .= "CUPOM FISCAL ELETRONICO - SAT CANCELAMENTO";
			$this->html .= "DADOS DO CUPOM FISCAL ELETRONICO DE CANCELAMENTO </b>";
			//
		} else {
			$this->html .= "<b> Extrato No. {$nNF} <br>";
			$this->html .= "CUPOM FISCAL ELETRONICO SAT <br> </b>";
		}

		$this->html .= "</td>\n";
		$this->html .= "</tr>\n";

		$this->html .= "</table>\n";

		//COD|DESC|QTD|UNIVL UN RS|(VL TR R$)*) VL ITEM R$
 		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td align=\"left\"># &nbsp; |COD &nbsp;|DESC &nbsp;|QTD &nbsp;|UNIVL UN RS &nbsp;|(VL TR R$)*) &nbsp;| VL ITEM R$</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "<tr>\n";
		$this->html .= "</table>\n";

		if(!$_cfe_cancelado){
			$this->vTotalTrib = 0;

			//BLOCO DE DETALHES

			if (isset($this->det)) {
				//ITENS
				$this->html .= $this->itens($this->det, $_somar_desc_nfce);
			}
			$this->vTotalTrib = funcoesGerais::ConverterParaNumero($this->vTotalTrib);
		}

		//TOTAIS DA NF
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td align=\"left\">QTDADE TOTAL DE ITENS</td>\n";
		$this->html .= "<td align=\"right\">$qtdItens</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "<tr>\n";
		$this->html .= "</table>\n";

		//IMPOSTOS
		$this->html .= $impHtml;

		$this->html .= $pagHtml;

		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td align=\"left\">" . utf8_encode("Informa��o dos Tributos Incidentes<br>(Lei Federal 12.741/2012)") . " </td>\n";
		$this->html .= "<td align=\"right\">" . $_sigla_moeda .number_format($this->vTotalTrib, 2, ',', '.')."</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "</table>\n";

		//CONSUMIDOR
		$this->html .= $this->consumidor($this->dest);


		//�rea V
		//BLOCO DE DETALHES
        if(!$_cfe_cancelado&&$this->info_impresssao['imprimir_tributos']=='S'&&((int)$this->info_impresssao['regra_especial_icms']&128)<=0) {
			$this->html .= "<table width=\"100%\">\n";
			$this->html .= "<tr>";
			$this->html .= "<td colspan=\"3\"> <b> OBSERVACOES DO CONTRIBUINTE </b> <br>
											   *Valor aproximado dos tributos do item <br>";
			$this->html .= $this->infAdic->nodeValue;
			$this->html .= "</tr> </td>";
			$this->html .= "</table>";
		}

		//DADOS DA NOTA
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>";
		$this->html .= "<td colspan=\"3\"> <b> SAT No.{$serieNF} </b> <br>".date('d/m/Y H:i:s', strtotime($dhEmi))."</td>";
		$this->html .= "</tr>";
		$this->html .= "</table>";




		//Se a mensagem n�o estiver vazia e for a VIA do cliente exibe a mensagem
		if (!$this->_via_estabelecimento) {
			$infCpl      = $this->dom->getElementsByTagName("infAdic")->item(0);
			$infCpl      = substr($this->__simpleGetValue($infCpl, "infCpl"),1,-1);
            $infAdFisco   = $this->dom->getElementsByTagName("infAdic")->item(0);
            $infAdFisco   = $this->__simpleGetValue($infCpl, "infAdFisco");
            if (empty($infAdFisco)) {
                $infAdFisco = " Nao houve a arrecadacao para o FECP";
            }
            if(((int)$this->info_impresssao['regra_especial_icms']&8192)>0&&!empty($infCpl)){
                $infCpl = ucwords(strtolower($infCpl));
                $infCpl = $this->formatarInfCpl($infCpl);
            }
			if (!empty($infCpl) ) {
				$this->html .= "<table width=\"100%\">\n";
				$this->html .= "<tr>\n";
				$this->html .= "<td>".utf8_encode("informa��es adicionais de interesse do contribuinte")."</td>\n";
				$this->html .= "</tr>\n";
				$this->html .= "<tr>\n";
				$this->html .= "<td>".utf8_encode($infCpl)."</td>\n";
				$this->html .= "<tr>\n";
                if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                    $this->html .= "<tr>\n";
                    $this->html .= "<td>" . utf8_encode($infAdFisco) . "</td>\n";
                    $this->html .= "<tr>\n";
                }
				$this->html .= "</table>\n";

			}
		}

		//DADOS DA NOTA
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td>".utf8_encode($numNF)."</td>\n";
		$this->html .= "<td>" . utf8_encode("S�rie:") . " $serieNF</td>\n";
        /**
         * BL-5646
         * BIT Software
         * 09.04.2018
         *
         */
		$this->html .= "<td>".date('d/m/Y H:i:s', strtotime($dhEmi))."</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "</table>\n";

		//CHAVE DE ACESSO
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td  colspan=\"3\">Chave de Acesso<br>$chNFe</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "</table>\n";

		//CONSUMIDOR
		$this->html .= $this->consumidor($this->dest);

        /**
         * SQA-1776
         * Conforme solicitado pelo Pedro Marques o c�digo de barras n�o � obrigat�rio no cupom Cfe
         * ent�o n�o vamos monta-lo quando for reimpress�o no manager ou envio por e-mail.
         */
        /*
		//CODIGO DE BARRAS
		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td>";
        if($chNFe <= 24){
            $this->html .= "<p>";
            $this->html .= "<img src=\"";
            $this->html .= "gerador_codigo_barras.php5?tipo=code128&tam=20&res=1&txt={$chNFe}&font=9&subtipo=&flgtxt=1";
            $this->html .= "\">";
        }else{
            $tamanho_string = strlen($chNFe);
            $_bloco1 = substr($chNFe,0,24);
            $_bloco2 = substr($chNFe,24,$tamanho_string);
            $this->html .= "<p>";
            $this->html .= "<img src=\"";
            $this->html .= "gerador_codigo_barras.php5?tipo=code128&tam=20&res=1&txt={$_bloco1}&font=9&subtipo=&flgtxt=1";
            $this->html .= "\">";
            $this->html .= "</p>";
            $this->html .= "<br>";
            $this->html .= "<p>";
            $this->html .= "<img src=\"";
            $this->html .= "gerador_codigo_barras.php5?tipo=code128&tam=20&res=1&txt={$_bloco2}&font=9&subtipo=&flgtxt=1";
            $this->html .= "\">";
            $this->html .= "</p>";
        }
		$this->html .= "</td>\n";
		$this->html .= "</tr>\n";
		$this->html .= "</table>\n";
        */


        //DADOS DO APLICATIVO

        if ($_ufLoja == "SP"){
            $_mensagem = "Consulte o QR Code pelo aplicativo 'De olho na nota', disponivel na AppStore (Apple) e PlayStore (Android)";
        }else if ($_ufLoja == "CE"){
            $_mensagem = "Consulte o QR Code pelo aplicativo 'Sua Nota Tem Valor', disponivel na AppStore (Apple) e PlayStore (Android)";
        }else{
            $_mensagem = "Consulta via leitor QR Code";
        }

		$this->html .= "<table width=\"100%\">\n";
		$this->html .= "<tr>\n";
		$this->html .= "<td  colspan=\"3\"><b>{$_mensagem}</b></td>\n";
		$this->html .= "</tr>\n";

		$this->html .= "<tr>\n";

        //
        $cMsg = $this->__simpleGetValue($this->nfeProc, "cMsg");
        $xMsg = $this->__simpleGetValue($this->nfeProc, "xMsg");

        if ((int)$cMsg == 200 && !empty($xMsg)) {
            $this->html .= "<table width=\"100%\">\n";
            $this->html .= "<tr>\n";
            $this->html .= "<td  colspan=\"3\">{$this->inserirTexto($xMsg, CENTRO)}</td>\n";
            $this->html .= "</tr>\n";
            $this->html .= "</table>\n";
        }

		//Isso pq a imagem era apagada antes de imprimirmos
		if (!$this->_eh_pdf) {
			$_img_qr_code = $this->base64_encode_image($this->imgQRCode,'png');
			$this->html  .= '<td  colspan="3"><img src="' . $_img_qr_code . '"/></td>';
			//Apaga o arquivo
			unlink($this->imgQRCode);
		} else {
			$this->html .= "<td  colspan=\"3\"><img src=\"./".$this->imgQRCode."\" width=\"100\" heigth=\"100\"></td>\n";
		}

		$this->html .= "</tr>\n";
		$this->html .= "</table>\n";
		$this->html .= "</body>\n</html>\n";
		return $chNFe;
	}//fim da fun��o montaDANFE

    public function formatarInfCpl($_infCpl) {
        $_padrao = '/Federal R\$ ([0-9,\.]+).*?Estadual R\$ ([0-9,\.]+).*?Municipal R\$ ([0-9,\.]+)/i';
        if (preg_match($_padrao, $_infCpl, $_matches)) {
            $_federal = $_matches[1];
            $_estadual = $_matches[2];
            $_municipal = $_matches[3];
            return 'FONTE: IBPT; Tributos Totais Incidentes (Lei Federal 12.741/2012) - Federal R$ ' . $_federal .
                ' Estadual R$ ' . $_estadual . ' Municipal R$ ' . $_municipal;
        }
        return $_infCpl;
    }

	protected function pagamento($pag, &$tPnome) {
		if (!isset($pag)) {
			return '';
		}
		//DADOS DE PAGAMENTO
		$oldtBand = '';
		$oldtPag = '';
		$pagHtml = "<table width=\"100%\">\n<tr>";
		$pagHtml .= "<td align=\"left\">FORMA DE PAGAMENTO</td>\n";
		$pagHtml .= "<td align=\"right\">VALOR PAGO</td>\n";
		$pagHtml .= "</tr>\n";
        /**
         * SEGDOCFIN-1
         * BIT
         * Out.2023
         */
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
        $_getDadosPagamentos = $this->_obj_pai->getDadosPagamentos();
        if(is_object($this->_obj_pai)&&!empty($_getDadosPagamentos)) {
            foreach($this->_obj_pai->getDadosPagamentos() as $_fin => $_pagto) {
                $pagHtml .= "<tr>\n";
                $pagHtml .= "<td align=\"left\">{$_fin} " . htmlspecialchars($_pagto['DESCRICAO'],null,"UTF-8") . "</td>\n";
                $pagHtml .= "<td align=\"right\">" . $_sigla_moeda . number_format($_pagto['VLR_RECEBIDO'],2,",",".") . "</td>\n";
                $pagHtml .= "</tr>\n";
                $_documentos = [];
                for($_idx=1;$_idx<=6;$_idx++) {
                    if(!empty($_pagto["DOC{$_idx}"])) {
                        $_documentos[] = $_pagto["LEGENDA{$_idx}"] . ":" . $_pagto["DOC{$_idx}"];
                    }
                }
                if(!empty($_documentos)) {
                    $pagHtml .= "<tr>\n";
                    $pagHtml .= "<td align='left'>" . implode(",",$_documentos) . "</td>";
                    $pagHtml .= "<td></td>";
                    $pagHtml .= "</tr>\n";
                }
            }
        } else {
            foreach($pag as $pagI) {
                $tPag = $this->__simpleGetValue($pagI,"cMP");
                $tPagNome = $this->tipoPag($tPag);
                $tPnome = $tPagNome;
                $vPag = number_format($this->__simpleGetValue($pagI,"vMP"),2,",",".");
                $vPag = $_sigla_moeda . (string)$vPag;
                //$card = $pagI->getElementsByTagName("card")->item(0);
                //cart�o
//                if(isset($card)) {
//                    $cardCNPJ = $this->__simpleGetValue($card,"CNPJ");
//                    $tBand = $this->__simpleGetValue($card,"tBand");
//                    //$cAut = $this->__simpleGetValue($card, "cAut");
//                    $tBandNome = self::getCardName($tBand);
//                }
                if($tPag!=$oldtPag) {
                    $pagHtml .= "<tr>\n";
                    $pagHtml .= "<td align=\"left\">" . htmlspecialchars($tPagNome,null,"UTF-8") . "</td>\n";
                    $pagHtml .= "<td align=\"right\">$vPag</td>\n";
                    $pagHtml .= "</tr>\n";
                    $oldtPag = $tPag;
                }
//                if($cardCNPJ!=''&&$oldtBand!=$tBand) {
//                    $pagHtml .= "<tr>\n";
//                    $pagHtml .= "<td align=\"left\">" . htmlspecialchars($tBandNome,null,"UTF-8") . "</td>\n";
//                    $pagHtml .= "<td align=\"right\">" . $this->__format($cardCNPJ,"##.###.###/####-##") . "</td>\n";
//                    $pagHtml .= "</tr>\n";
//                    $oldtBand = $tBand;
//                }
            } //fim foreach
        }
		$pagHtml .= "</table>\n";
		return $pagHtml;
	}

	/**
	 * Monta o QRCOde do SAT
	 * @see DanfeNFCeNFePHP::makeQRCode()
     * todo:: revisar (php 8.1) -> Totalmente diferente, alterado o nome e alteradas as chamadas..
	 */
	protected function makeQRCode2($_stringQRCode) {
		$imgQrCode = new QRcode($_stringQRCode, 'M');
		$filename = date('YmdHis').'.png';
		$imgQrCode->displayPNG(200, array(255,255,255), array(0,0,0), $filename, 0);
		return $filename;

	}//fim makeQRCode



	protected function itens($det, $_somar_desc_nfce = null)
	{
        if (!isset($det)) {
            return '';
        }

        $_imprimir_desc_acres_item = ($GLOBALS["_VERSAO_NT"] & 512) > 0;
        $_imprimir_valor_liquido_item = $_somar_desc_nfce == 'S';

		//ITENS
		//Ajusta a ordem caso esteja invertido.
		$nitem_ant  = null;
		$_no_fim    = true;
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
		foreach ($det as $detI) {
			$thisItem   = $detI;
			$prod       = $thisItem->getElementsByTagName("prod")->item(0);
			$vImposto 	= $thisItem->getElementsByTagName("imposto")->item(0);
			$_tributos = $this->__simpleGetValue($vImposto, "vItem12741");
			$nitem      = $thisItem->getAttribute("nItem");
			//Se for menor, coloca no come�o, e vamos ordenar.
			if (!isset($nitem_ant) || $nitem_ant > $nitem) {
				if (isset($nitem_ant)) {
					$_no_fim = false;
				}
				$nitem_ant = $nitem;
			}
            //Se houver EAN no XML, uso ele na impress�o.
            $_valorProd = $this->__simpleGetValue($prod, "cEAN");
            if($this->_imprimir_cod_lido && !empty($_valorProd) && $_valorProd != 'SEM GTIN'){
                $prod->getElementsByTagName("cProd")->item(0)->nodeValue = $prod->getElementsByTagName("cEAN")->item(0)->nodeValue;
            }
			$cProd      = $this->__simpleGetValue($prod, "cProd");
			$xProd      = $this->__simpleGetValue($prod, "xProd");

            /**
             * BL-7410
             * Foi pedido no BL-7073 para retirar o "Pre�o De Por" da descri��o do produto e colocado nas informa��es adicionais.
             * Ent�o estamos extraindo essa informa��o para poder imprimir corretamente no item do cupom.
             */
            $_de_por = '';
            $_array_infAdProd = explode('|', $infAdProd);
            foreach($_array_infAdProd as $_info) {
                $_info = trim($_info);
                if(strpos($_info, 'DESC_PROMO:') !== false) {
                    $_de_por = trim(str_replace(['DESC_PROMO:', $xProd], '', $_info));
                } else {
                    $infAdProd = $_info;
                }
            }

            // Temos que tratar o as informa��es adicionais pois agora pode vir com outros valores al�m do FECP.
            if (empty($infAdProd)) {
                $infAdProd = " Nao houve a arrecadacao para o FECP";
            }

			$qCom       = number_format($this->__simpleGetValue($prod, "qCom"), 3, ",", ".");
			$uCom       = $this->__simpleGetValue($prod, "uCom");
            $_tributos_formatado = number_format((float)$_tributos,2, ",",".");
			$vUnCom     = number_format($this->__simpleGetValue($prod, "vUnCom"), 2, ",", ".");

            // Valor Total
            $_vProd = (float)$this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desc_acres_item = '';
            $_desconto = (float)trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = (float)trim($this->__simpleGetValue($prod, "vOutro"));
            if($_imprimir_desc_acres_item) {
                if (!empty($_desconto)) {
                    $_desc = number_format($_desconto, 2, ",", ".");
                    $_desc_acres_item.= "Desconto: {$_sigla_moeda}{$_desc} ";
                }
                if (!empty($_acrescimo)) {
                    $_acres = number_format($_acrescimo, 2, ",", ".");
                    $_desc_acres_item.= "Acrescimo: {$_sigla_moeda}{$_acres} ";
                }
            }

            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = $_vProd - $_desconto + $_acrescimo;
            }

			$_titulo 	=  "<tr>\n";
			$_titulo 	.= "<td align=\"left\">".htmlspecialchars($nitem,null,"UTF-8")."</td>\n";
			$_titulo	.= "<td align=\"left\">".htmlspecialchars($cProd,null,"UTF-8")."</td>\n";
			$_titulo    .= "<td colspan = \"5\" align=\"left\">".htmlspecialchars($xProd,null,"UTF-8")."</td>\n";
			$_titulo	.= "</tr>\n";
            $_titulo    .= "<tr>\n";
            if(!empty($_de_por)) {
                $_titulo .= "<td colspan = \"3\" align=\"left\">" . htmlspecialchars($_de_por, null, "UTF-8") . "</td>\n";
            } else {
                $_titulo .= "<td colspan = \"3\">\n";
            }
			$_titulo	.= "<td align=\"right\">$qCom</td>\n";
            $_titulo    .= "<td align=\"right\">$uCom</td>\n";

            $vUnCom = $_sigla_moeda . $vUnCom;

            $_titulo    .= "<td align=\"right\" width=\"60\">$vUnCom</td>\n";
			$this->vTotalTrib += (float)$_tributos;
            $_titulo	.= "<td align=\"right\"> ({$_tributos_formatado})</td>\n";
			$_titulo	.= "<td align=\"right\" width=\"60\">". $_sigla_moeda . number_format($_vProd, 2, ",", ".") . "</td>\n";
			$_titulo	.= "</tr>\n";

            if (!empty($_desc_acres_item)) {
                $_titulo .= "<tr>\n";
                $_titulo .= "<td colspan = \"8\" align=\"left\">" . htmlspecialchars($_desc_acres_item, null, "UTF-8") . "</td>\n";
                $_titulo .= "</tr>\n";
            }

            if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                $_titulo .= "<tr>\n";
                $_titulo .= "<td colspan = \"8\" align=\"center\">" . htmlspecialchars($infAdProd, null, "UTF-8") . "</td>\n";
                $_titulo .= "</tr>\n";
            }

			//Pra acertar a ordena��o dos itens, caso esteja invertido.
			if ($_no_fim) {
				$itensHtml .= $_titulo;
			} else {
				$itensHtml = $_titulo . $itensHtml;
			}
		}
		$itensHtml = "<table width='100%'>\n" . $itensHtml . "</table>\n";

		return $itensHtml;
	}//fim itens


}