<?php
/**
 * Este arquivo � parte do projeto NFePHP - Nota Fiscal eletr�nica em PHP.
 *
 * Este programa � um software livre: voc� pode redistribuir e/ou modific�-lo
 * sob os termos da Licen�a P�blica Geral GNU como � publicada pela Funda��o
 * para o Software Livre, na vers�o 3 da licen�a, ou qualquer vers�o posterior.
 * e/ou
 * sob os termos da Licen�a P�blica Geral Menor GNU (LGPL) como � publicada pela
 * Funda��o para o Software Livre, na vers�o 3 da licen�a, ou qualquer vers�o posterior.
 *
 * Este programa � distribu�do na esperan�a que ser� �til, mas SEM NENHUMA
 * GARANTIA; nem mesmo a garantia expl�cita definida por qualquer VALOR COMERCIAL
 * ou de ADEQUA��O PARA UM PROP�SITO EM PARTICULAR,
 * veja a Licen�a P�blica Geral GNU para mais detalhes.
 *
 * Voc� deve ter recebido uma c�pia da Licen�a Publica GNU e da
 * Licen�a P�blica Geral Menor GNU (LGPL) junto com este programa.
 * Caso contr�rio consulte
 * <http://www.fsfla.org/svnwiki/trad/GPLv3>
 * ou
 * <http://www.fsfla.org/svnwiki/trad/LGPLv3>.
 *
 * @category  NFePHP
 * @package   NFePHP
 * @name      DanfceNFePHP.class.php
 * @copyright 2009-2013 &copy; NFePHP
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL v.3
 *            http://www.gnu.org/licenses/lgpl.html GNU/LGPL v.3
 * @version   GIT: 1.11
 * @link      http://www.nfephp.org/
 * @author    Roberto Spadim <roberto at spadim dot com dot br>
 *
 *
 * CONTRIBUIDORES (por ordem alfabetica):
 *            Roberto L. Machado <linux dot rlm at gmail dot com>
 *            Mario Almeida <mario at grupopmz dot com dot br>
 *
 */

//define o caminho base da instala��o do sistema
if (!defined('PATH_ROOT')) {
    define('PATH_ROOT', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR);
}

define("TRACO",1111);
//ajuste do tempo limite de resposta do processo
set_time_limit(600);

if (!funcoesGerais::managerOFFLine()) {
    require_once (funcoesGerais::retornarCaminhoAbsolutoManager() .  'plugin/qrcode/qrcode.class.php');
}
require_once (funcoesGerais::retornarCaminhoAbsolutoManager() . 'nfephp/tags/pre-review/libs/CommonNFePHP.class.php');
require_once (funcoesGerais::retornarCaminhoAbsolutoManager() . 'nfephp/tags/pre-review/libs/DocumentoNFePHP.interface.php');

/**
 * Classe DanfceNFePHP
 * Objetivo - impress�o de NFC-e em uma unica pagina (bobina)
 */
class DanfeTextoNFCeNFePHP extends CommonNFePHP implements DocumentoNFePHP
{
    //publicas
    public $idToken;
    public $emitToken;
    public $papel;
    public $_qtd_caracteres = 60;
    /**
     * Indica se tem consumidor ou n�o.
     * @var bool
     */
    protected $_sem_consumidor = false;

    //privadas
    protected $xml; // string XML NFe
    protected $formatoChave="#### #### #### #### #### #### #### #### #### #### ####";
    protected $debugMode=0; //ativa ou desativa o modo de debug
    protected $nfeProc;
    protected $nfe;
    protected $infNFe;
    protected $ide;
    protected $enderDest;
    protected $ICMSTot;
    protected $imposto;
    protected $emit;
    protected $enderEmit;
    protected $det;
    protected $pag;
    protected $dest;
    protected $mPDF;
    protected $_texto;
    protected $html;
    public $_via_estabelecimento = false;
    protected $imgQRCode;
    protected $urlConsulta = null;
    public $_imprimir_cod_lido = false;
    protected $qtdItens = 0;

    //Usado para o c�digo de barras do SAT
    protected $barCode;
    protected $info_impresssao;

    //ALTNFE-1
    protected $_versao_nfe;
    protected $vTroco;
    /*array(
        '1'=> array(
            '12'=> array('chave'=>'','QR'=>'http://www.sefaznet.ac.gov.br/nfe/NFe.jsp?opc=3'),
            '13'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://sistemas.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),
            '21'=> array('chave'=>'','QR'=>'http://www.nfe.ma.gov.br/portal/consultarNFCe.jsp'),
            '51'=> array('chave'=>'http://www.sefaz.mt.gov.br/nfce/consultanfce',
            			 'QR'=>'http://www.sefaz.mt.gov.br/nfce/consultanfce'),
            '24'=> array('chave'=>'','QR'=>'http://www.nfe.rn.gov.br/portal/consultarNFCe.jsp'),
            '43'=> array('chave'=>'','QR'=>'https://www.sefaz.rs.gov.br/NFCE/NFCE-COM.aspx'),
            '28'=> array('chave'=>'','QR'=>'http://www.nfe.se.gov.br/portal/consultarNFCe.jsp')
        ),
        '2' => array(
            '12'=> array('chave'=>'','QR'=>'http://hml.sefaznet.ac.gov.br'),
            '13'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://homnfce.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),
            '35'=> array(
                'chave'=>'http://sistemas.sefaz.am.gov.br/nfceweb/formConsulta.do',
                'QR'=>'http://homnfce.sefaz.am.gov.br/nfceweb/consultarNFCe.jsp'),

            '21'=> array('chave'=>'','QR'=>'http://www.hom.nfe.ma.gov.br/portal/consultarNFCe.jsp'),
            '51'=> array('chave'=>'http://homologacao.sefaz.mt.gov.br/nfce/consultanfce',
            			 'QR'=>'http://homologacao.sefaz.mt.gov.br/nfce/consultanfce'),
            '24'=> array('chave'=>'','QR'=>'http://www.hom.nfe.rn.gov.br/portal/consultarNFCe.jsp'),
            '43'=> array('chave'=>'','QR'=>'https://www.sefaz.rs.gov.br/NFCE/NFCE-COM.aspx'),
            '28'=> array('chave'=>'','QR'=>'http://www.hom.nfe.se.gov.br/portal/consultarNFCe.jsp')
        ));*/

    /**
     * Pega as urls do xml da nfcs.
     * @param array $_url
     */
    public function setURLChave($_url) {
        $this->urlConsulta = $_url;
    }


    /**
     *
     * @return DOMNode
     */
    public function getIde() {
        return $this->ide;
    }

    /**
     *
     * @return DOMNode
     */
    public function getICMSTot() {
        return $this->ICMSTot;
    }

    /**
     *
     * @return DOMNode
     */
    public function getNFe() {
        return $this->nfe;
    }
    /**
     *
     * @param type $docXML
     * @param type $sPathLogo
     * @param type $mododebug
     * @param type $idToken
     * @param type $Token
     */
    public function __construct($docXML = '', $sPathLogo = '', $mododebug = 0, $idToken = '', $emitToken = '')
    {
        if (is_numeric($mododebug)) {
            $this->debugMode = $mododebug;
        }
        if ($this->debugMode) {
            //ativar modo debug
            //Quem define isso � o defines
            //error_reporting(E_ALL);
            ini_set('display_errors', 'On');
        } else {
            //desativar modo debug
            //Quem define isso � o defines
            //error_reporting(0);
            ini_set('display_errors', 'Off');
        }
        $this->papel = array(80, 'one-page');
        $this->xml          = $docXML;
        $this->logomarca    = $sPathLogo;
        if (!empty($this->xml)) {
            $this->dom = new DomDocument;
            $_cont = 0;
            //Remove isso se tiver, pois n�o conseguia aplicar o parse no objeto pois entendia que continham dois xml.
            $this->xml = str_ireplace('<?xml version="1.0" encoding="utf-8"?>',"",$this->xml, $_cont);
            $_ret = $this->dom->loadXML($this->xml);
            if($_ret == false) {
                $this->xml = utf8_decode($this->xml);
                $_ret = $this->dom->loadXML($this->xml);
            }
            $this->nfeProc    = $this->dom->getElementsByTagName("nfeProc")->item(0);
            $this->nfe        = $this->dom->getElementsByTagName("NFe")->item(0);
            $this->infNFe     = $this->dom->getElementsByTagName("infNFe")->item(0);
            $this->ide        = $this->dom->getElementsByTagName("ide")->item(0);
            $this->emit       = $this->dom->getElementsByTagName("emit")->item(0);
            $this->enderEmit  = $this->dom->getElementsByTagName("enderEmit")->item(0);
            $this->det        = $this->dom->getElementsByTagName("det");
            $this->dest       = $this->dom->getElementsByTagName("dest")->item(0);
            $this->_versao_nfe = (float)$this->infNFe->getAttribute("versao");
            if($this->_versao_nfe >= 4) {
                $this->pag        = $this->dom->getElementsByTagName("detPag");
                $this->vTroco     = $this->dom->getElementsByTagName("vTroco")->item(0);
            }else{
                $this->pag        = $this->dom->getElementsByTagName("pag");
            }
            $this->imposto    = $this->dom->getElementsByTagName("imposto")->item(0);
            $this->ICMSTot    = $this->dom->getElementsByTagName("ICMSTot")->item(0);
        }
        $this->idToken = $idToken;
        $this->emitToken = $emitToken;
        $this->html = "";

    } //fim __construct

    public function getIdToken()
    {
        return $this->idToken;
    }

    public function setIdToken($str)
    {
        $this->idToken = $str;
    }

    public function getEmitToken()
    {
        return $this->emitToken;
    }

    public function setEmitToken($str)
    {
        $this->emitToken = $str;
    }

    public function getPapel()
    {
        return $this->papel;
    }

    public function setPapel($aPap)
    {
        $this->papel = $aPap;
    }

    public function simpleConsistencyCheck()
    {
        if (1 == 2 || $this->xml == null || $this->infNFe == null || $this->ide == null) {
            return false;
        }
        return true;
    } //fim simpleConsistencyCheck

    /**
     *
     * @param type $orientacao
     * @param type $papel
     * @param type $logoAlign
     * @return type
     */
    public function monta ($orientacao = '', $papel = array(80, 'one-page'), $logoAlign = 'C', $detalhes = false, $_info_impressao=null, $_somar_desc_nfce = null, $_dados_offline = null)
    {
        $this->info_impresssao = $_info_impressao;
        return $this->montaDANFE($detalhes, $_somar_desc_nfce, $_dados_offline);
    }//fim monta

    /**
     *
     * @param type $nome
     * @param type $destino
     * @param type $printer
     * @return type
     */
    public function printDocument($nome = '', $destino = 'I', $printer = '')
    {
        return $this->printDANFE($nome, $destino, $printer);
    }//fim printDocument

    /**
     * Este m�todo formatar� a sa�da
     * @param string $_texto
     * @param tipo
     * @return String
     */
    public function inserirTexto($_texto, $_tipo=CENTRO, $_sem_quebra = false,  $_destaque = false, $_divisao = true, $_descricao_inteira = false) {
        if($_descricao_inteira) {
            $_tamanho=strlen($_texto);
            $_cont=$this->_qtd_caracteres-1;
            $_tam=0;
            while($_tamanho>$_cont) {
                $_frase=substr($_texto, $_tam, $_cont);
                $_linha.=str_alinha($_frase, $_cont, ESQUERDA)."\n";
                $_tamanho=$_tamanho-strlen($_frase);
                $_tam+=$this->_qtd_caracteres-1;
            }
            $_frase=substr($_texto, $_tam);
            $_linha.=str_alinha($_frase, $_tamanho)."\n";
        } else {
            $_quebra="\n";
            if($_sem_quebra) {
                $_quebra="";
            }
            if($_texto===TRACO) {
                //Celso pediu pra colocar o tracejado at� o final.
                $_texto=str_repeat('-', $this->_qtd_caracteres);
            }

            $_colunas=$this->_qtd_caracteres;

            //BL-10288 - Desabilitando modo expandido
            $_destaque = false;
            if($_destaque) {
                //No modo expandido, para negritar, usa 2 colunas, por isso devemos quebrar em 2
                $_carac_destaque='!';
                //Se for PDV Mobile n�o faz sentido essa divis�o.
                if($_GET['origem']!=='PDVTM'&&$_divisao===true) {
                    $_colunas=($_colunas/2);
                }
            } else {
                $_carac_destaque='';
            }


            $_linha="";
            if(strlen($_texto)>$_colunas) {
                $_arr_palavras=explode(' ', $_texto);
                $_frase='';
                $_frase_atual='';
                $_palavra_antiga='';
                $_total_palavras=count((array)$_arr_palavras);
                if($_total_palavras>1) {
                    $_contador=0;
                    foreach($_arr_palavras as $_palavra) {
                        $_frase_atual=$_frase;
                        $_palavra_antiga=$_palavra;
                        $_frase.=$_palavra;
                        $_contador++;
                        if($_contador<$_total_palavras) {
                            $_frase.=' ';
                        }

                        if(strlen($_frase)>$_colunas) {
                            $_linha.=$_carac_destaque.funcoesGerais::str_alinha($_frase_atual, $_colunas, $_tipo, false, ' ')."{$_quebra}";
                            $_frase=$_palavra_antiga;
                            if($_contador<$_total_palavras) {
                                $_frase.=' ';
                            }
                        }
                    }
                    $_linha.=$_carac_destaque.funcoesGerais::str_alinha($_frase, $_colunas, $_tipo, false, ' ')."{$_quebra}";
                } else {
                    //Insere linhas com a quantidade de colunas estipulada.
                    $_qt_linhas=(int)(strlen($_texto)/$_colunas)+1;
                    for($_i=0; $_i<$_qt_linhas; $_i++) {
                        $_pos=$_i*$_colunas;
                        if($_i==$_qt_linhas-1) {
                            $_substr=substr($_texto, $_pos);
                        } else {
                            $_substr=substr($_texto, $_pos, $_colunas);
                        }

                        $_linha.=$_carac_destaque.funcoesGerais::str_alinha($_substr, $_colunas, $_tipo, false, ' ')."{$_quebra}";
                    }
                }

            } else {
                //Insere linhas com a quantidade de colunas estipulada.
                $_linha=$_carac_destaque.funcoesGerais::str_alinha($_texto, $_colunas, $_tipo, false, ' ')."{$_quebra}";
            }
        }
        return $_linha;
    }

    /**
     * M�todo para alinhar um texto a esquerda e outro a direita.
     * @param $_txt_esquerda
     * @param $_txt_direita
     * @param $_tam_linha
     */
    public function inserirTextoEsquerdaEDireita($_txt_esquerda, $_txt_direita, $_aproximidade = 0) {
        $this->_qtd_caracteres;

        $_qtd_colunas_vazia = $this->_qtd_caracteres - strlen($_txt_esquerda) - strlen($_txt_direita) - $_aproximidade;
        $_texto             = $_txt_esquerda. str_pad("", $_qtd_colunas_vazia) .$_txt_direita;

        return $this->inserirTexto($_texto);
    }

    /**
     * Retorna o destinatario
     * @return string
     */
    public function retornarDestinatario() {
        $cDest  = '';
        if (isset($this->dest)) {
            $considEstrangeiro = !empty($this->dest->getElementsByTagName("idEstrangeiro")->item(0)->nodeValue)
                ? $this->dest->getElementsByTagName("idEstrangeiro")->item(0)->nodeValue
                : '';
            $consCPF = !empty($this->dest->getElementsByTagName("CPF")->item(0)->nodeValue)
                ? $this->dest->getElementsByTagName("CPF")->item(0)->nodeValue
                : '';
            $consCNPJ = !empty($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue)
                ? $this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue
                : '';
            $cDest = $consCPF.$consCNPJ.$considEstrangeiro; //documentos do consumidor
            $cDest = trim($cDest);
            if (empty($cDest) || $cDest == '99999999000191') {
                $this->_sem_consumidor = true;
            }


        }
        return $cDest;
    }

    /**
     * o objetivo desta fun��o � ler o XML e gerar o DANFE com auxilio de convers�o HTML-PDF
     * @param type $detalhes
     * @return type
     */
    public function montaDANFE($detalhes = false, $_somar_desc_nfce = null, $_dados_offline = null)
    {
        $_num_tag = "";
        //Se for impress�o OFFLine precisar�
        if ($this->_via_estabelecimento) {
            $_num_tag = "2";
        }

        // criar um parametro pra tirar os espacos
        $tira_espaco = true;

        //DADOS DA NF
        $nProt = $this->__simpleGetValue($this->nfeProc, "nProt");
        $dhRecbto  = $this->__simpleGetValue($this->nfeProc, "dhRecbto");
        $digVal = $this->__simpleGetValue($this->nfe, "DigestValue");
        $chNFe = str_replace('NFe', '', $this->infNFe->getAttribute("Id"));
        $tpAmb = $this->__simpleGetValue($this->ide, 'tpAmb');
        $cUF = $this->__simpleGetValue($this->ide, 'cUF');
        $nNF = $this->__simpleGetValue($this->ide, 'nNF');
        $serieNF = str_pad($this->__simpleGetValue($this->ide, "serie"), 3, "0", STR_PAD_LEFT);
        $dhEmi = $this->__simpleGetValue($this->ide, "dhEmi");
        $vTotTrib = $this->__simpleGetValue($this->ICMSTot, "vTotTrib");
        $vTotTrib = funcoesGerais::ConverterParaNumero($vTotTrib);
        $vProd = $this->__simpleGetValue($this->ICMSTot, "vProd");
        $vNF = $this->__simpleGetValue($this->ICMSTot, "vNF");
        $vOutro  = $this->__simpleGetValue($this->ICMSTot, "vOutro");
        $vDesc  = $this->__simpleGetValue($this->ICMSTot, "vDesc");
        $vICMS = $this->__simpleGetValue($this->ICMSTot, "vICMS");
        $this->qtdItens = $this->det->length;
        $_qrcode2 = '';
        if(($GLOBALS["_VERSAO_NT"] & 8) > 0) {
            $_qrcode2 = '2';
        }
        $urlChave = $this->urlConsulta["URLAcesso{$_qrcode2}"]; //$this->urlConsulta[$tpAmb][$cUF]['chave'];
        $urlQR    = $this->urlConsulta['URLQRCodeAcesso'];//$this->urlConsulta[$tpAmb][$cUF]['QR'];


        $_tpEmis =  $this->__simpleGetValue($this->ide, 'tpEmis');

        //Se for conting�ncia segundo o manual deve obrigatoriamente imprimir o detalhe.
        if ((int) $_tpEmis === 9) {
            $detalhes = true;
        }

        //DADOS DO EMITENTE
        $emitRazao  = $this->__simpleGetValue($this->emit, "xNome");
        $emitCnpj   = $this->__simpleGetValue($this->emit, "CNPJ");
        $emitCnpj   = $this->__format($emitCnpj, "##.###.###/####-##");
        $emitIE     = $this->__simpleGetValue($this->emit, "IE");
        $emitFone = $this->__simpleGetValue($this->enderEmit, "fone");
        $foneLen = strlen($emitFone);
        if ($foneLen>0) {
            $fone2 = substr($emitFone, 0, $foneLen-4);
            $fone1 = substr($emitFone, 0, $foneLen-8);
            $emitFone = '('.$fone1.') '.substr($fone2, -4).'-'.substr($emitFone, -4);
        } else {
            $emitFone = '';
        }
        $emitLgr 	   = $this->__simpleGetValue($this->enderEmit, "xLgr");
        $emitNro 	   = $this->__simpleGetValue($this->enderEmit, "nro");
        $emitCpl 	   = $this->__simpleGetValue($this->enderEmit, "xCpl", " - ");
        $emitBairro    = $this->__simpleGetValue($this->enderEmit, "xBairro");
        $emitCEP 	   = $this->__format($this->__simpleGetValue($this->enderEmit, "CEP"), "#####-###");
        $emitMun 	   = $this->__simpleGetValue($this->enderEmit, "xMun");
        $emitUF        = $this->__simpleGetValue($this->enderEmit, "UF");
        $valorProdutos = number_format((float)$vProd, 2, ",", ".");
        $valorTotal    = number_format((float)$vNF, 2, ",", ".");
        $this->tam_tot = strlen($valorTotal);
        //pag
        $tPagNome = '';
        $pagHtml = $this->pagamento($this->pag, $tPagNome);

        $impHtml = '';

        //IMPOSTOS
        if ($vNF !== $vProd) {
			$impHtml .= $this->inserirTexto(funcoesGerais::str_alinha('Total produtos  ',20) .  'R$ ' . funcoesGerais::str_alinha($valorProdutos,strlen($valorProdutos),DIREITA), ESQUERDA);
        }
        if ($vOutro > 0 && (($GLOBALS["_VERSAO_NT"] & 512) <= 0 || ($GLOBALS["_VERSAO_NT"] & 32768) <= 0)) {
            $vOutro_format = number_format((float)$vOutro, 2, ',', '.');
	        $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha("Acrescimo",20). " R$ " . funcoesGerais::str_alinha($vOutro_format,strlen($vOutro_format),DIREITA), ESQUERDA);
        }
        if ($vDesc > 0 && (($GLOBALS["_VERSAO_NT"] & 512) <= 0 || ($GLOBALS["_VERSAO_NT"] & 32768) <= 0)) {
            $vDesc_format = number_format((float)$vDesc, 2, ',', '.');
	        $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha("Desconto",20).   "R$ " . funcoesGerais::str_alinha($vDesc_format,strlen($vDesc_format),DIREITA), ESQUERDA);
        }
        //$impHtml .= $this->inserirTexto("TOTAL R$ " . number_format((float)$vNF, 2, ',', '.'), ESQUERDA);

        /**
         * ML-2951
         * BIT
         * Jan.2024
         */
        $_frete = (float)trim($this->__simpleGetValue($this->ICMSTot, "vFrete"));
        if(!empty($_frete)) {
            $_vFrete = number_format((float)$_frete,2,",",".");
            $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha("Frete",20) . "R$ " . funcoesGerais::str_alinha($_vFrete,strlen($_vFrete),DIREITA), ESQUERDA);
        }

        //necess�rio para QRCode
        $cDest  = $this->retornarDestinatario();
        //DADOS PARA QRCODE, Isso vem de cima pra baixo.
        $idToken = empty($this->idToken) ? '000001' : $this->idToken;

        $this->imgQRCode = $this->makeQRCode(
            $chNFe,
            $urlQR,
            $tpAmb,
            $cDest,
            $dhEmi,
            $vNF,
            $vICMS,
            $digVal,
            $idToken,
            $Token
        );

        //FORMATA��O DOS CAMPOS
        $numNF = "NFCe ".$this->__format($nNF, "###.###.###");
        $tsHora = $this->__convertTime($dhEmi);
        $tsProt = $this->__convertTime($dhRecbto);

        //DADOS DA LOJA
        if (!funcoesGerais::managerOFFLine()) {
            $_empresa	= new Empresa($GLOBALS['_MASTER']);
            $_empresa->Buscar($GLOBALS['_eusuario']);
            $_complemento_cabecalho = $_empresa->getComplemento_cabecalho_fiscal();

        }else{
            $_empresa = simplexml_load_string($_dados_offline);
            if($_empresa===false) {
                $_xml_aux = utf8_encode($_dados_offline);
                $_empresa = simplexml_load_string($_xml_aux);
            }
            $_complemento_cabecalho = $_empresa->complemento_cabecalho_fiscal;
        }



        //CABE�ALHO
        $this->html .= "<TEXTO_ANTES{$_num_tag}><![CDATA[";

        /**
         * ML-1279
         * BIT Software
         * Caso seja definido no sistema, n�o imprimimos
         * os dados da empresa no cabe�alho (deve vir no logo)
         */
        if($GLOBALS['_suprime_cabecalho_fiscal']!==true) {
            //$this->html .= $this->inserirTexto("NFC-e"); //Retirado no ML-353
            $_infoCodLoja = (!empty($this->info_impresssao['cod_loja']) && ((int)$this->info_impresssao['regra_especial_icms']&2048)>0) ? funcoesGerais::str_alinha($this->info_impresssao['cod_loja'],5,DIREITA,false,"0")." - " : '';
            $this->html .= $this->inserirTexto("CNPJ:{$emitCnpj} " . $_infoCodLoja . $emitRazao);

            //BL-3363
            // $this->html .= $this->inserirTexto("CNPJ:{$emitCnpj}" /*. (!empty($emitIE) ? " I.E.: {$emitIE}" : "") . (!empty($emitFone) ? ", {$emitFone}" : "" )*/); //Retirado no ML-353
            $this->html .= $this->inserirTexto($emitLgr . ", " . $emitNro .
                (!empty($emitBairro) ? '-' . $emitBairro : "") .
                (!empty($emitMun) ? "-" . $emitMun : "") . ", " . $emitUF/*.$emitCEP.*/);
            if($this->info_impresssao['imprimir_ie_cabecalho_cupom']==="S") {
                $this->html .= $this->inserirTexto((!empty($emitIE) ? " I.E.: {$emitIE}" : ""));
            }
            if(!empty($emitCpl)) {
                $this->html .= $this->inserirTexto($emitCpl);
            }
            //$this->html .= $this->inserirTexto($emitBairro . ", " . $emitMun . ", " . $emitUF); //Retirado no ML-353
        }
        $this->html .= $this->inserirTexto($_complemento_cabecalho);
        $this->html .= $this->inserirTexto(TRACO);
        $this->html .= $this->inserirTexto("Documento Auxiliar Nota Fiscal de Consumidor Eletronica");
        //Se for tipo 9 significa que foi emitida em conting�ncia e segundo a especifica��o t�cnica dever� ter uma mensagem.
        if ((int)$_tpEmis === 9) {
            $this->html .= $this->inserirTexto("EMITIDA EM CONTINGENCIA",CENTRO,false, true);
            $this->html .= $this->inserirTexto("Pendente de autorizacao");
        }
        //$this->html .= $this->inserirTexto(TRACO);
        //$this->html .= $this->inserirTexto("Nao permite aproveitamento de credito de ICMS"); //Retirado no ML-353

        /*if ($tpAmb == 2) {
			$this->html .= $this->inserirTexto("NFC-e Emitida Ambiente de Homologacao-SEM VALOR FISCAL"); //Retirado no ML-353
        }*/
        $this->html .= $this->inserirTexto(TRACO);
        //BLOCO DE DETALHES
        if ($detalhes) {
            //ITENS
            $this->html .= $this->itens($this->det, $_somar_desc_nfce);
            $this->html .= $this->inserirTexto(TRACO);
        }

        //�rea IV
        $this->html .= $this->inserirTexto(funcoesGerais::str_alinha("Qtd. total de itens ",20) . funcoesGerais::str_alinha($this->qtdItens,$this->tam_tot + 3,DIREITA), ESQUERDA);
        if ($detalhes) {
            //IMPOSTOS
            $this->html .= $impHtml;
        }
        if (((int)$this->info_impresssao['regra_especial_icms']&16384)<=0) {
            $this->html .= $this->inserirTexto(funcoesGerais::str_alinha("Valor total ", 20) . "R$ " . funcoesGerais::str_alinha($valorTotal, $this->tam_tot, DIREITA), ESQUERDA, $tira_espaco);
        }
        //$this->html .= $this->inserirTexto(TRACO);
        if ($tira_espaco == false)
            $this->html .= $this->inserirTexto("");
        $this->html .= $pagHtml;
        $this->html .= $this->inserirTexto("");
        //$this->html .= $this->inserirTexto(TRACO);
        /*$this->html .= $this->inserirTexto($tPagNome);
        $this->html .= $this->inserirTexto("VALOR PAGO");
        $this->html .= $this->inserirTexto(number_format((float)$vNF, 2, ',', '.'));
        $this->html .= $this->inserirTexto("");*/

        //CHAVE DE ACESSO
        $this->html .= $this->inserirTexto("Consulte pela Chave de Acesso em",CENTRO);
        $this->html .= $this->inserirTexto($urlChave,CENTRO);
        //$this->html .= $this->inserirTexto("CHAVE DE ACESSO");  //Retirado no ML-353
        $this->html .= $this->inserirTexto($chNFe,CENTRO);
        //$this->html .= $this->inserirTexto(TRACO);
        /**
         * ML-1268
         * BIT Software
         * 25.09.2019
         * Caso seja definido criamos uma nova tag TEXTO_LADO
         * o qual depende do pdv informar na tag modelo_impressao
         */
        $_modelo_impressao = $GLOBALS['_modelo_impressao'];

        if($_modelo_impressao==1) {
            $this->html .= "]]></TEXTO_ANTES{$_num_tag}>";
            $this->html .= "<TEXTO_LADO{$_num_tag}><![CDATA[";
            $_qtd_carac_orig = $this->_qtd_caracteres;
            $this->_qtd_caracteres = (int) $this->_qtd_caracteres/2;
        } else {
            $this->html .= $this->inserirTexto("");
        }

        //CONSUMIDOR
        if ($tira_espaco == false)
            $this->html .= $this->inserirTexto("");
        if ($_modelo_impressao !=1) {
            $this->html .= $this->consumidor($this->dest);
        } else {
            $this->html .= $this->consumidor($this->dest, true, 1);
        }

        //DADOS DA NOTA
        if ($tira_espaco == false)
            $this->html .= $this->inserirTexto("");
        $this->html .= $this->inserirTexto(/*"Num: " .*/$numNF. " Serie {$serieNF} ".date('d/m/Y H:i:s', $tsHora), CENTRO);

        if ($this->_via_estabelecimento) {
            $this->html .= $this->inserirTexto("Via estabelecimento",CENTRO);
        } else {
            $this->html .= $this->inserirTexto("Via consumidor",CENTRO);
        }
        if ($tira_espaco == false)
            $this->html .= $this->inserirTexto("");

        //$this->html .= $this->inserirTexto(TRACO);
        //Se for tipo 9 significa que foi emitida em conting�ncia e segundo a especifica��o t�cnica dever� ter uma mensagem.
        if ((int)$_tpEmis === 9) {
            $this->html .= $this->inserirTexto("EMITIDA EM CONTINGENCIA",CENTRO,false, ($_modelo_impressao!=1));
            //BL-5277 H� um tamanho m�nimos de distancia que deve ser respeitado.
            $this->html .= $this->inserirTexto("Pendente de autorizacao",CENTRO,$tira_espaco);
        } else {
            //O Celso pediu pra nem enviar a tag caso n�o haja dado.
            if (!empty($nProt)) {
                $this->html .= $this->inserirTexto("Protocolo de autorizacao: {$nProt}");
                //SQA-1592 - Parametro adicionado para validar regra de quebra de linha.
                $_sem_quebra = ((int)$this->info_impresssao['regra_especial_icms']&4096)>0;
                //BL-5277 H� um tamanho m�nimos de distancia que deve ser respeitado.
                $this->html .= $this->inserirTexto("Data de autorizacao: " . date('d/m/Y H:i:s', $tsProt), CENTRO, $_sem_quebra);
            }
        }

        //$this->html .= $this->inserirTexto("Consulta via leitor QR Code",CENTRO,true);
        /**
         * ML-1268
         * BIT Software
         * 25.09.2019
         */
        if($_modelo_impressao==1) {
            $this->html .= "]]></TEXTO_LADO{$_num_tag}>";
            $this->_qtd_caracteres = $_qtd_carac_orig;
        } else {
            $this->html .= "]]></TEXTO_ANTES{$_num_tag}>";
        }
        $this->html .= "<QRCODE{$_num_tag}><![CDATA[";
        $this->html .= $this->imgQRCode;
        $this->html .= "]]></QRCODE{$_num_tag}>";
        $this->html .= "<TEXTO_DEPOIS{$_num_tag}><![CDATA[";

        // BL-7504 colocado xMsg para ser exibido depois, pois quando colocado na lateral do
        // qrcode, esta sendo cortado por limita��o de linhas
        if (!empty($nProt)) {
            $cMsg = $this->__simpleGetValue($this->nfeProc, "cMsg");
            $xMsg = $this->__simpleGetValue($this->nfeProc, "xMsg");
            if ((int)$cMsg == 200 && !empty($xMsg)) {
                $_arrXMSG = explode("|",$xMsg);
                foreach ($_arrXMSG as $_msg){
                    $this->html .= $this->inserirTexto($_msg, CENTRO);
                }
            }
        }

        //Segundo a Val�ria s� exibe quando existe valor
        if (!empty($vTotTrib) && $vTotTrib > 0) {
            $this->html .= $this->inserirTexto("Tributos Totais Incidentes (L.F. 12741/12) " . "R$ " . number_format((float)$vTotTrib, 2, ',', '.'));

        }


        //Infos complementares
        //Se a mensagem n�o estiver vazia e for a VIA do cliente exibe a mensagem
        if (!$this->_via_estabelecimento) {
            $infCpl      = $this->dom->getElementsByTagName("infAdic")->item(0);
            $infCpl      = substr($this->__simpleGetValue($infCpl, "infCpl"),1,-1);

            //ML-353
            $infCpl      = ucwords(strtolower($infCpl)); //Antes estava vindo tudo com letra mai�scula
            $infCpl      = str_replace("(l","(L",$infCpl); //S� um detalhe
            //BL-3363
            $infCpl      = trim($infCpl);

            $_arrCpl     = explode("##",$infCpl);

            // SQA-1572 - Regra adicionada para simplifica��o das informa��es dos impostos.
            if(((int)$this->info_impresssao['regra_especial_icms']&8192)>0){
                $_infCpl = $this->formatarInfCpl($infCpl);
                $this->html .= $this->inserirTexto($_infCpl);
            }
            //ML-353 - Teve que separar os tributos do resto dos complementos
            else if(count((array)$_arrCpl) == 2){
                if (!empty($_arrCpl[0]) ) {
                    $this->html .= $this->inserirTexto($_arrCpl[0]);
                }
                if (!empty($_arrCpl[1]) ) {
                    $this->html .= $this->inserirTexto($_arrCpl[1]);
                }
            } else if(!empty($infCpl)){
                $this->html .= $this->inserirTexto($infCpl);
            }
            if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                $infAdFisco = $this->dom->getElementsByTagName("infAdic")->item(0);
                $infAdFisco = substr($this->__simpleGetValue($infAdFisco, "infAdFisco"), 0, 17);
                if (!empty($infAdProd) || isset($infAdFisco)) {
                    $this->html .= $this->inserirTexto($infAdFisco,DIREITA,FALSE,FALSE,TRUE,TRUE);
                } else {
                    $this->html .= (String) $this->inserirTexto(" Nao houve a arrecadacao para o FECP",DIREITA,FALSE,FALSE,TRUE,TRUE);
                }
            }
        }

        /**
         * ML-353
         * Celso disse que n�o precisa dar quebra na �ltima linha.
         */
        $this->html = trim ($this->html);
        $this->html = trim ($this->html,"\n");

        $this->html .= "]]></TEXTO_DEPOIS{$_num_tag}>";

        return $chNFe;
    }//fim da fun��o montaDANFE

    public function formatarInfCpl($_infCpl) {
        $_padrao = '/Federal R\$ ([0-9,\.]+).*?Estadual R\$ ([0-9,\.]+).*?Municipal R\$ ([0-9,\.]+)/i';
        if (preg_match($_padrao, $_infCpl, $_matches)) {
            $_federal = $_matches[1];
            $_estadual = $_matches[2];
            $_municipal = $_matches[3];
            return 'FONTE: IBPT; Tributos Totais Incidentes (Lei Federal 12.741/2012) - Federal R$ ' . $_federal .
                ' Estadual R$ ' . $_estadual . ' Municipal R$ ' . $_municipal;
        }
        return $_infCpl;
    }

    protected function pagamento($pag, &$tPnome) {
        if(!isset($pag)) {
            return '';
        }
        //DADOS DE PAGAMENTO
        $oldtBand='';
        $oldtPag='';
        $pagHtml="";//$this->inserirTexto("");
        //$pagHtml .= $this->inserirTexto("PAGAMENTOS\n");

        $totalEPagamentoMesmoLinha = null;
        $tamanhoTotalEPagamentoMesmoLinha = null;
        if(((int)$this->info_impresssao['regra_especial_icms']&16384)>0) {
            $vNF = $this->__simpleGetValue($this->ICMSTot, "vNF");
            $totalEPagamentoMesmoLinha = "R$ " . number_format((float)$vNF, 2, ',', '.');
            $tamanhoTotalEPagamentoMesmoLinha = strlen($totalEPagamentoMesmoLinha);
        }

        /**
         * Fizemos isso por conta do php 5.6
         */
        $count_pag   = 0;
        $size_of_pag = $pag->length;

        foreach($pag as $pagI) {
            $count_pag++;
            $tPag=$this->__simpleGetValue($pagI, "tPag");
            $tPagNome=$this->tipoPag($tPag);
            $tPagNome=funcoesGerais::removerLatinCharacters($tPagNome);
            $tPnome=$tPagNome;
            $vPag=number_format((float)$this->__simpleGetValue($pagI, "vPag"), 2, ",", ".");
            //$card=$pagI->getElementsByTagName("card")->item(0);
            //cart�o
//            if(isset($card)) {
//                $cardCNPJ=$this->__simpleGetValue($card, "CNPJ");
//                $tBand=$this->__simpleGetValue($card, "tBand");
//                //$cAut = $this->__simpleGetValue($card, "cAut");
//                $tBandNome=self::getCardName($tBand);
//            }
            $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
            if (isset($totalEPagamentoMesmoLinha) && ($size_of_pag == $count_pag)) {
                $pagHtml .= $this->inserirTextoEsquerdaEDireita($tPagNome . ": " . $_sigla_moeda . $vPag, funcoesGerais::str_alinha("TOTAL ", $tamanhoTotalEPagamentoMesmoLinha) . $totalEPagamentoMesmoLinha);
            }else if (((int)$this->info_impresssao['regra_especial_icms']&16384)>0){
                $pagHtml .= $this->inserirTexto($tPagNome . ": " . $_sigla_moeda . $vPag, ESQUERDA);
            }

            if($pag->length===1) {
                $tPagNome="Forma de pagamento ".$tPagNome;
            }

            /** ML-353 - Retirado esse controle para imprimir todos, solicitado pela Val�ria * /
            if ($tPag != $oldtPag) {
            if ($pag->length > 1) {
            $pagHtml .= $this->inserirTextoEsquerdaEDireita($tPagNome, $vPag, 0);
            } else {
            $pagHtml .= $this->inserirTexto($tPagNome . ": " . $vPag);
            }
            $oldtPag = $tPag;
            }/**/
            if($pag->length>1 && ((int)$this->info_impresssao['regra_especial_icms']&16384)<=0) {
                $formaPgtos.=$this->inserirTextoEsquerdaEDireita($tPagNome, $_sigla_moeda.$vPag, 0);
            } else if (((int)$this->info_impresssao['regra_especial_icms']&16384)<=0) {
                $formaPgtos.=$this->inserirTexto($tPagNome.": ".$_sigla_moeda.$vPag);
            }
//            if($cardCNPJ!=''&&$oldtBand!=$tBand) {
//                if($pag->length>1) {
//                    $pagHtml.=$this->inserirTextoEsquerdaEDireita($tBandNome, $this->__format($cardCNPJ, "##.###.###/####-##"), 0);
//                } else {
//                    $pagHtml.=$this->inserirTexto($tBandNome.": ".$this->__format($cardCNPJ, "##.###.###/####-##"));
//                }
//                $oldtBand=$tBand;
//            }
        } //fim foreach

        if(($this->_versao_nfe >= 4)and($this->vTroco->nodeValue <> '')) {
            //$pagHtml.=$this->inserirTextoEsquerdaEDireita('Troco: ', $this->vTroco->nodeValue, 0);
            $pagHtml .= $this->inserirTexto(funcoesGerais::str_alinha('Troco ',20) .  'R$ ' . funcoesGerais::str_alinha($this->vTroco->nodeValue,strlen($this->vTroco->nodeValue),DIREITA), ESQUERDA);
        }
        /*
        if($pag->length>1) {
            $formaPgto  = $this->inserirTextoEsquerdaEDireita("Forma de pagamento", "VALOR PAGO", 0);
            $formaPgtos    .= $formaPgto;
        }
        */
        return $pagHtml.$formaPgtos;
    }

    protected static function getCardName($tBand)
    {
        switch ($tBand) {
            case '01':
                $tBandNome = 'VISA';
                break;
            case '02':
                $tBandNome = 'MASTERCARD';
                break;
            case '03':
                $tBandNome = 'AMERICAN EXPRESS';
                break;
            case '04':
                $tBandNome = 'SOROCRED';
                break;
            case '05':
                $tBandNome = 'DINERS CLUB';
                break;
            case '06':
                $tBandNome = 'ELO';
                break;
            case '07':
                $tBandNome = 'HIPERCARD';
                break;
            case '08':
                $tBandNome = 'AURA';
                break;
            case '09':
                $tBandNome = 'CABAL';
                break;
            case '10':
                $tBandNome = 'ALELO';
                break;
            case '11':
                $tBandNome = 'BANES CARD';
                break;
            case '12':
                $tBandNome = 'CALCARD';
                break;
            case '13':
                $tBandNome = 'CREDZ';
                break;
            case '14':
                $tBandNome = 'DISCOVER';
                break;
            case '15':
                $tBandNome = 'GOODCARD';
                break;
            case '16':
                $tBandNome = 'GREENCARD';
                break;
            case '17':
                $tBandNome = 'HIPER';
                break;
            case '18':
                $tBandNome = 'JCB';
                break;
            case '19':
                $tBandNome = 'MAIS';
                break;
            case '20':
                $tBandNome = 'MAXVAN';
                break;
            case '21':
                $tBandNome = 'POLICARD';
                break;
            case '22':
                $tBandNome = 'REDECOMPRAS';
                break;
            case '23':
                $tBandNome = 'SODEXO';
                break;
            case '24':
                $tBandNome = 'VALECARD';
                break;
            case '25':
                $tBandNome = 'VEROCHEQUE';
                break;
            case '26':
                $tBandNome = 'VR';
                break;
            case '27':
                $tBandNome = 'TICKET';
                break;
            case '99':
                $tBandNome = 'OUTROS';
                break;
            default:
                break;
        }
        return $tBandNome;
    }//fim getCardName

    protected function tipoPag($tPag)
    {
        //O acento na impressora DPP350 fica zuado ent�o removi
        switch ($tPag) {
            case '01':
                $tPagNome = 'Dinheiro';
                break;
            case '02':
                $tPagNome = 'Cheque';
                break;
            case '03':
                $tPagNome = 'Cartao de Credito';
                break;
            case '04':
                $tPagNome = 'Cartao de Debito';
                break;
            case '05':
                $tPagNome = 'Credito Loja';
                break;
            case '10':
                $tPagNome = 'Vale Alimentacao';
                break;
            case '11':
                $tPagNome = 'Vale Refeicao';
                break;
            case '12':
                $tPagNome = 'Vale Presente';
                break;
            case '13':
                $tPagNome = 'Vale Combustivel';
                break;
            case '99':
                $tPagNome = 'Outros';
        }
        return $tPagNome;
    }

    protected function itens($det, $_somar_desc_nfce = null)
    {
        if (!isset($det)) {
            return '';
        }

        /**
         * BL-7410
         * Aten��o: Isso aqui est� uma confus�o s�, estou tentando organizar o maximo poss�vel!!!!
         *
         * $GLOBALS["_VERSAO_NT"]: 512 - Ir� imprimir os descontos e acr�scimos do item.
         *
         * $_somar_desc_nfce - Ir� imprimir o total liquido no item.
         * Ex: Produto R$ 10,00 - Desconto R$ 5,00 + Acr�scimo R$ 2,00
         * Total Liquido: R$ 7,00
         *
         * "Pre�o De Por" - Antes vinha na descri��o da mercadoria no BL-7073, pediram para tirar ent�o foi colocado
         * nas informa��es adicionais do item, temos que extrair para formar novamente a descri��o correta.
         * OBS: Quando habilitado imprimir_danfe_nfce_1linha == S essa informa��o n�o aparece pois � pra ser reduzido
         *
         * De acordo com o tipo de impress�o (imprimir_danfe_nfce_1linha) os dados ser�o exibidos de forma diferente no cupom
         * Ex: (imprimir_danfe_nfce_1linha == N)
         * Temos mais espa�o pois existe uma descri��o completa da mercadoria e uma nova linha somente para os valores,
         * ent�o tentamos colocar os descontos e acrescimos nessa linha e quebramos caso n�o caiba.
         *
         * Ex: (imprimir_danfe_nfce_1linha == S)
         * Temos menos espa�o pois a mercadoria e os valores s�o impressos em uma unica linha,
         * ent�o temos colocar os descontos e acrescimos em uma nova linha e quebramos caso n�o caiba.
         */
        $_imprimir_desc_acres_item = ($GLOBALS["_VERSAO_NT"] & 512) > 0;
        $_imprimir_valor_liquido_item = $_somar_desc_nfce == 'S';

        //ITENS
        $itensHtml  = "";
        /*$_titulo    = funcoesGerais::str_alinha("#", 3,ESQUERDA,false,' ') ;
        $_titulo   .= funcoesGerais::str_alinha("CODIGO",14,ESQUERDA) . " ";
        $_titulo   .= funcoesGerais::str_alinha("DESCRICAO",26,ESQUERDA);
        //$itensHtml .= $this->inserirTexto($_titulo);
        $_titulo   .= funcoesGerais::str_alinha("QTD",7,DIREITA) . " ";
        $_titulo   .= funcoesGerais::str_alinha("UN.",3,ESQUERDA);
        $_titulo   .= funcoesGerais::str_alinha("VL.UNIT.",9,DIREITA) . " ";
        $_titulo   .= funcoesGerais::str_alinha("VL.TOTAL",10,DIREITA);
        */

        //Ajusta a ordem caso esteja invertido.
        $nitem_ant   = null;
        $_no_fim     = true;
        $_tamQtItens = strlen($this->qtdItens) + 1;
        $_tamCod     =  0;
        $_tamDesc    = 20;
        $_tamQtd	 = 0;
        $_tamVUni    = 0;
        $_tamUni     = 2;
        $_tamVTot    = 0;

        //BL-3363 Tentando pegar os tamanhos dos campos para alinhar.
        foreach ($det as $detI) {
            $thisItem   = $detI;
            $prod       = $thisItem->getElementsByTagName("prod")->item(0);
            //Se houver EAN no XML, uso ele na impress�o.
            $_valorProd = $this->__simpleGetValue($prod, "cEAN");
            $_seq = $thisItem->getAttribute("nItem");
            if($this->_imprimir_cod_lido) {
                if (!empty($_valorProd) && $_valorProd != 'SEM GTIN')  {
                    $prod->getElementsByTagName("cProd")->item(0)->nodeValue = $_valorProd;
                }
                /**
                 * O conceito veio do BL-7206
                 * Para que o PDV repasse essa informa��o inseri na tag nota, por�m para fazer isso preciso
                 * remov�-lo antes de aplicar o parser.
                 * Quando encontramos o c�digo lido e veio do PDV imprimimos ele.
                 */
                $_cod_prod = funcoesGerais::str_alinha($this->__simpleGetValue($prod, 'cProd'),17,DIREITA,true, "0");
                if (isset($GLOBALS['_objeto_complementar'])) {
                    try {
                        if (isset($GLOBALS['_objeto_complementar']->mercadorias[$_seq]) && !empty($GLOBALS['_objeto_complementar']->mercadorias[$_seq]->cod_lido)) {
                            $_cod_prod = $GLOBALS['_objeto_complementar']->mercadorias[$_seq]->cod_lido;
                            if (!empty($_cod_prod)) {
                                $prod->getElementsByTagName("cProd")->item(0)->nodeValue =  ltrim($_cod_prod,"0");
                            }
                        }
                    } catch (Exception $_e) {
                    }
                }
            }
            if ($_tamCod === 0 || strlen($this->__simpleGetValue($prod, "cProd")) > $_tamCod) {
                $_tamCod = strlen($this->__simpleGetValue($prod, "cProd"));
            }
            $qCom = funcoesGerais::ConverterParaNumero($this->__simpleGetValue($prod, "qCom"),3);
            $uCom = $this->__simpleGetValue($prod, "uCom");
            if ($uCom == "UN" || $uCom == "CX" ) {
                //Pode ser que esteja errado, ent�o se n�o for .000 � decimal ent�o deve mostrar
                if (($_pos = strpos($qCom,".000")) !== false) {
                    $qCom   = (int) $qCom;
                } else {
                    $qCom   = number_format((float)$qCom, 2, ",", ".");
                }
            } else {
                $qCom       = number_format((float)$qCom, 3, ",", ".");
            }
            if ($_tamQtd === 0 || strlen($qCom) > $_tamQtd) {
                $_tamQtd = strlen($qCom);
            }

            /**
             * ML-1407
             * BIT Software
             * 28.04.2020
             * Ajuste nas casas decimais
             */
            $_vUnCom = $this->__simpleGetValue($prod, "vUnCom");
            $_cd = defined('CD_PRECO_UNITARIO') ? CD_PRECO_UNITARIO : 2;
            $_cd = $_cd>4 ? 4 : $_cd;
            $vUnCom = number_format((float)$_vUnCom, $_cd, ",", ".");
            if($GLOBALS['_DEBUG']) {
                funcoesGerais::GravaLog("[CD] cd={$_cd} vUnCom[f]={$_vUnCom} vUnCom={$this->__simpleGetValue($prod, "vUnCom")}",true,true);
            }

            if ($_tamVUni === 0 || strlen($vUnCom) > $_tamVUni)  {
                $_tamVUni =  strlen($vUnCom);
            }

            // Valor Total
            $_vProd = (float)$this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desconto = (float)trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = (float)trim($this->__simpleGetValue($prod, "vOutro"));

            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = $_vProd - $_desconto + $_acrescimo;
            }
            $vProd = number_format((float)$_vProd, 2, ',', '.');
            if ($_tamVTot === 0 || strlen($vProd) > $_tamVTot){
                $_tamVTot = strlen($vProd);
            }
        }

        $_tamCod++;
        $_tamQtd++;
        $_tamVUni++;
        $_tamUni++;
        $_tamVTot++;
        $_tamTotal = $_tamQtItens + $_tamCod+$_tamDesc+$_tamQtd+$_tamVUni+$_tamUni+$_tamVTot;
        if ($_tamTotal > $this->_qtd_caracteres) {
            $_tamDesc = $_tamDesc + ($this->_qtd_caracteres - $_tamTotal);
        }
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
        foreach ($det as $detI) {
            $thisItem   = $detI;
            $prod       = $thisItem->getElementsByTagName("prod")->item(0);
            $nitem      = funcoesGerais::str_alinha($thisItem->getAttribute("nItem"),$_tamQtItens-1,DIREITA,true,($_tamQtItens > 1) ? '0' : ' ') . " ";
            $infAdProd  = $thisItem->getElementsByTagName("infAdProd")->item(0)->nodeValue;

            //Se for menor, coloca no come�o, e vamos ordenar.
            if (!isset($nitem_ant) || $nitem_ant > $nitem) {
                if (isset($nitem_ant)) {
                    $_no_fim = false;
                }
                $nitem_ant = $nitem;
            }
            $cProd      = $this->__simpleGetValue($prod, "cProd");
            $cProd      = funcoesGerais::removeZerosEsquerdaNumerosGrandes($cProd);
            if($this->info_impresssao['imprimir_danfe_nfce_1linha'] != "S" || ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0) {
                $cProd      = str_alinha($cProd, $_tamCod,ESQUERDA);
            }
            $xProd      = $this->__simpleGetValue($prod, "xProd");
            $xProd		= trim($xProd);

            /**
             * BL-7410
             * Foi pedido no BL-7073 para retirar o "Pre�o De Por" da descri��o do produto e colocado nas informa��es adicionais.
             * Ent�o estamos extraindo essa informa��o para poder imprimir corretamente no item do cupom.
             */
            $_de_por = '';
            $_array_infAdProd = explode('|', $infAdProd);
            foreach($_array_infAdProd as $_info) {
                $_info = trim($_info);
                if(strpos($_info, 'DESC_PROMO:') !== false) {
                    $_de_por = trim(str_replace(['DESC_PROMO:', $xProd], '', $_info)) . " ";
                } else {
                    $infAdProd = $_info;
                }
            }

            // Temos que tratar o as informa��es adicionais pois agora pode vir com outros valores al�m do FECP.
            if (empty($infAdProd)) {
                $infAdProd = " Nao houve a arrecadacao para o FECP";
            }

            $uCom = $this->__simpleGetValue($prod, "uCom");
            $qCom = funcoesGerais::ConverterParaNumero($this->__simpleGetValue($prod, "qCom"),3);
            if ($uCom == "UN" || $uCom == "CX" ) {
                //Pode ser que esteja errado, ent�o se n�o for .000 � decimal ent�o deve mostrar
                if (($_pos = strpos($qCom,".000")) !== false) {
                    $qCom   = (int) $qCom;
                } else {
                    $qCom   = number_format((float)$qCom, 2, ",", ".");
                }
            } else {
                $qCom       = number_format((float)$qCom, 3, ",", ".");
            }
            //Isso deve ficar abaixo da compara��o.

            /**
             * ML-1407
             * BIT Software
             * 28.04.2020
             * Ajuste nas casas decimais
            */
            $_vUnCom = $this->__simpleGetValue($prod, "vUnCom");
            $_cd = defined('CD_PRECO_UNITARIO') ? CD_PRECO_UNITARIO : 2;
            $_cd = $_cd>4 ? 4 : $_cd;
            if($GLOBALS['_DEBUG']) {
                funcoesGerais::GravaLog("[CD] cd={$_cd} vUnCom[f]={$_vUnCom} vUnCom={$this->__simpleGetValue($prod, "vUnCom")}",true,true);
            }

            // Valor Total
            $_vProd = (float)$this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desc_acres_item = '';
            $_desconto = (float)trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = (float)trim($this->__simpleGetValue($prod, "vOutro"));
            if($_imprimir_desc_acres_item) {
                if (!empty($_desconto)) {
                    $_desc = number_format((float)$_desconto, 2, ",", ".");
                    $_desc_acres_item.= "Desconto: {$_sigla_moeda}{$_desc} ";
                }
                if (!empty($_acrescimo)) {
                    $_acres = number_format((float)$_acrescimo, 2, ",", ".");
                    $_desc_acres_item.= "Acrescimo: {$_sigla_moeda}{$_acres} ";
                }
            }

            /**
             * ML-2951
             * BIT
             * Jan.2024
             */
            $_desc_frete_item = '';
            if(($GLOBALS["_VERSAO_NT"]&33554432)<=0) {
                $_frete = (float)trim($this->__simpleGetValue($prod, "vFrete"));
                if(!empty($_frete)) {
                    $_desc_frete_item = "Frete:              " . $_sigla_moeda . number_format((float)$_frete,2,',','.');
                }
            }

            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = $_vProd - $_desconto + $_acrescimo;
            }

            // Cest e Ncm
            $_cest_ncm_item = '';
            if($this->info_impresssao['imprimir_cest_ncm'] == "S") {
                $_cest = $this->__simpleGetValue($prod, "CEST");
                $_ncm = $this->__simpleGetValue($prod, "NCM");
                $_cest_ncm_item = "CEST: {$_cest} NCM: {$_ncm} ";
            }

            /**
             * ML-106
             * BL-4237
             * Conforme solicitado pelo Ronaldo e Bruno Neuman a descri��o dever� ser impressa
             * em uma linha separada da quantidade e valores, pois os clientes estavam reclamando
             * pelo fato da descri��o n�o aparecer completa.
             */
            if($this->info_impresssao['imprimir_danfe_nfce_1linha'] != "S" || ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0) {
                $uCom       = str_alinha($uCom, $_tamUni, DIREITA);
                $vUnCom     = str_alinha(number_format((float)$_vUnCom, $_cd, ",", "."), $_tamVUni, DIREITA);
                $vProd      = str_alinha(number_format((float)$_vProd, 2, ",", "."), $_tamVTot, DIREITA);
                if(((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0) {
                    $vUnCom = 'R$'. $vUnCom;
                    $vProd = 'R$'. $vProd;
                }
                $qCom		= str_alinha($qCom,$_tamQtd,DIREITA);

                /**
                 * BL-6063
                 * Quando � uma venda a partir de um pedido que vem preenchido o complemento_descricao_mercadoria tenho que respeitar o tamanho do campo,
                 * esse trecho cortava o final do complemento, se algu�m tiver que descomentar esse trecho refa�a
                 * o teste com os dados abaixo para n�o quebrar novamente.
                 * Tabela: zan_pedido_item (complemento_descricao_mercadoria = 'Part.:033/09 Fabr.:11/2009 Val.:11/2011')
                 */
                /*
                // Calculo a quantidade de caracteres
                $_tituloTam = strlen("{$nitem} {$cProd} ");
                $_caracteresSobrando = ($this->_qtd_caracteres - ($_tituloTam + 1));

                // Se tivar caracters sobrando eu coloco na descri��o do produto
                if($_caracteresSobrando > 0){
                    $xProd= funcoesGerais::str_alinha($xProd, $_caracteresSobrando, ESQUERDA);
                } else {
                    $xProd		= substr($xProd, 0,$_tamDesc);
                    $xProd      = str_alinha($xProd,$_tamDesc,ESQUERDA);
                }
                */
                $_titulo = "{$nitem} {$cProd} {$xProd}";
                $_titulo2 = "{$qCom} {$uCom} {$vUnCom} {$vProd}";
                //Pra acertar a ordena��o dos itens, caso esteja invertido.
                if($_no_fim) {
                    $itensHtml.= $this->inserirTexto($_titulo, ESQUERDA, false, false, true, true);

                    /**
                     * BL-7410
                     * Se precisar imprimir qualquer outra informa��o basta incluir na lista de textos abaixo:
                     */
                    $_textos = [
                        $_de_por,
                        $_desc_acres_item,
                        $_cest_ncm_item
                    ];
                    $itensHtml.= $this->otimizarLinhasTexto($_textos, $_titulo2, true);

                    if(!empty($_desc_frete_item)) {
                        $itensHtml .= $this->inserirTexto($_desc_frete_item,DIREITA);
                    }

                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml.=$this->inserirTexto($infAdProd);
                    }
                } else {
                    $itensHtml=$this->inserirTexto($_titulo, ESQUERDA, false, false, true, true).$this->inserirTexto($_titulo2, DIREITA).$itensHtml;
                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml.=$this->inserirTexto($infAdProd);
                    }
                }
            } else {
                $vUnCom = number_format((float)$_vUnCom, $_cd, ",", ".");
                $vProd = number_format((float)$_vProd, 2, ",", ".");

                /** Calculo a quantidade de caracteres */
                $_tituloTam = strlen("{$nitem} {$cProd} {$qCom} {$uCom} {$vUnCom} {$vProd}");
                $_caracteresSobrando = ($this->_qtd_caracteres - ($_tituloTam + 1));

                /** Se tivar caracters sobrando eu coloco na descri��o do produto */
                if($_caracteresSobrando > 0){
                    if(count((array)$xProd) < $_caracteresSobrando){
                        $_val_tam = $_caracteresSobrando - count((array)$xProd) +1;
                        $xProd = funcoesGerais::str_alinha($xProd, $_val_tam, ESQUERDA);
                    }
                    $xProd = substr($xProd, 0, $_caracteresSobrando);
                    $xProd = str_alinha($xProd,$_caracteresSobrando,ESQUERDA);
                    $_titulo  = "{$nitem} {$cProd} {$xProd} {$qCom} {$uCom} {$vUnCom} {$vProd}";
                }else{
                    $_titulo = "{$nitem} {$cProd} {$qCom} {$uCom} {$vUnCom} {$vProd}";
                }

                //Pra acertar a ordena��o dos itens, caso esteja invertido.
                if ($_no_fim) {
                    $itensHtml .= $this->inserirTexto(trim($_titulo),ESQUERDA);

                    /**
                     * BL-7410
                     * Se precisar imprimir qualquer outra informa��o basta incluir na lista de textos abaixo:
                     */
                    $_textos = [
                        $_de_por,
                        $_cest_ncm_item
                    ];
                    $itensHtml.= $this->otimizarLinhasTexto($_textos, $_desc_acres_item);

                    if(!empty($_desc_frete_item)) {
                        $itensHtml .= $this->inserirTexto($_desc_frete_item,DIREITA);
                    }

                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml.=$this->inserirTexto($infAdProd);
                    }
                } else {
                    $itensHtml = $this->inserirTexto(trim($_titulo),ESQUERDA) . $itensHtml;
                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml.=$this->inserirTexto($infAdProd);
                    }
                }
            }
        }

        //O titulo sempre no come�o
        //$_titulo    = "# Cod. Descr. Qtd. UN. Vl.Un. Vl.Tot.";
        $_titulo = funcoesGerais::str_alinha("# ",$_tamQtItens,DIREITA) .
            str_alinha("Cod", $_tamCod)  .
            str_alinha("Descricao",$_tamDesc) .
            str_alinha("Qt",$_tamQtd,DIREITA) .
            str_alinha("Un",$_tamUni,DIREITA) .
            str_alinha("Vlr",$_tamVUni,DIREITA) .
            str_alinha("Tot",$_tamVTot ,DIREITA);
        $itensHtml  = $this->inserirTexto($_titulo,ESQUERDA) . $itensHtml;

        return $itensHtml;
    }//fim itens

    /**
     * Validamos se o tamanho do novo texto
     * caber� na linha do texto atual
     *
     * @param $_novo_texto
     * @param $_texto
     */
    protected function tamanhoTextoValido($_novo_texto, $_texto) {
        return (strlen($_novo_texto) + (strlen($_texto)-1) < $this->_qtd_caracteres);
    }

    /**
     * Tentando otimizar a quantidade de linhas utilizadas na escrita do cupom
     *
     * @param array $_textos
     * @param string $_linha_inicial
     * @param string $_retorno
     * @param int $_primeiro_alinhamento
     * @return string
     */
    protected function otimizarLinhasTexto($_textos=[], $_linha_inicial='', $_primeiro_alinhamento_direita = false) {
        $_retorno = "";
        $_linha = "";
        $_total = count((array)$_textos)-1;
        $_alinhamento = $_primeiro_alinhamento_direita ? DIREITA : ESQUERDA;
        foreach ($_textos as $_index => $_texto) {
            if($this->tamanhoTextoValido("{$_linha} {$_texto}", $_linha_inicial)) {
                $_linha.= (empty($_linha) ? "" : " ") . $_texto;
            } else {
                if(!empty($_linha)) {
                    if($_primeiro_alinhamento_direita) {
                        $_linha = str_pad($_linha, ($this->_qtd_caracteres-strlen($_linha_inicial))," ",STR_PAD_RIGHT);
                        $_primeiro_alinhamento_direita = false;
                    }
                    $_retorno.= $this->inserirTexto($_linha . $_linha_inicial, $_alinhamento);
                } else {
                    $_retorno.= $this->inserirTexto($_linha_inicial, $_alinhamento);
                }
                $_alinhamento = ESQUERDA;
                $_linha_inicial = $_texto;
                $_linha = "";
            }
            // �ltimo la�o
            if($_total == $_index && (!empty($_linha) || !empty($_linha_inicial))) {
                if(!empty($_linha)) {
                    if($_primeiro_alinhamento_direita) {
                        $_linha = str_pad($_linha, ($this->_qtd_caracteres-strlen($_linha_inicial))," ",STR_PAD_RIGHT);
                        $_primeiro_alinhamento_direita = false;
                    }
                    $_retorno.= $this->inserirTexto($_linha . $_linha_inicial, $_alinhamento);
                } else {
                    $_retorno.= $this->inserirTexto($_linha_inicial, $_alinhamento);
                }
                $_alinhamento = ESQUERDA;
            }
        }
        return $_retorno;
    }

    protected function consumidor($dest, $_omitir = false, $_modelo_impressao = null)
    {
        //DADOS DO CONSUMIDOR
        if (empty($dest) || $this->_sem_consumidor) {
            if ($_modelo_impressao != 1) {
                return $this->inserirTexto("CONSUMIDOR NAO IDENTIFICADO", CENTRO, false, true);
            } else {
                return $this->inserirTexto("CONSUMIDOR NAO IDENTIFICADO", CENTRO, false, false);
            }
        }
        $enderDest = $dest->getElementsByTagName("enderDest")->item(0);
        $consNome = $this->__simpleGetValue($dest, "xNome");
        $consFone = $this->__simpleGetValue($dest, "fone");
        $foneLen = strlen($consFone);
        if ($foneLen > 0) {
            $fone2 = substr($consFone, 0, $foneLen-4);
            $fone1 = substr($consFone, 0, $foneLen-8);
            $consFone = '('.$fone1.') '.substr($fone2, -4).'-'.substr($consFone, -4);
        } else {
            $consFone = '';
        }
        $consLgr = $this->__simpleGetValue($enderDest, "xLgr");
        $consNro = $this->__simpleGetValue($enderDest, "nro");
        $consCpl = $this->__simpleGetValue($enderDest, "xCpl", " - ");
        $consBairro = $this->__simpleGetValue($enderDest, "xBairro");
        $consCEP = $this->__format($this->__simpleGetValue($enderDest, "CEP"));
        $consMun = $this->__simpleGetValue($enderDest, "xMun");
        $consUF = $this->__simpleGetValue($enderDest, "UF");
        $considEstrangeiro = $this->__simpleGetValue($dest, "idEstrangeiro");
        $consCPF = $this->__simpleGetValue($dest, "CPF");
        if (!empty($consCPF)) {
            $consCPF = funcoesGerais::formatarDado("CPF",$consCPF);
        }
        $consCNPJ = $this->__simpleGetValue($dest, "CNPJ");
        if (!empty($consCNPJ)) {
            $consCNPJ = funcoesGerais::formatarDado("CNPJ",$consCNPJ);
        }
        $consDoc = trim($consCPF.$consCNPJ.$considEstrangeiro); //documentos do consumidor

        if ($_omitir != true) {
            $consHtml .= $this->inserirTexto("CONSUMIDOR");
        }

        if ($_modelo_impressao !=1) {
            $consHtml .= $this->inserirTexto("CONSUMIDOR: " . $consDoc, CENTRO, false, true);
        } else {
            $consHtml .= $this->inserirTexto("CONSUMIDOR: " . $consDoc, CENTRO, false, false);
        }
        if (!empty($consNome) && $_omitir != true) {
            $consHtml .= $this->inserirTexto($consNome);
        }

        $_aux_consumidor =
            (!empty($consLgr) ? "" . $consLgr : "").
            (!empty($consNro) ? ", " . $consNro : "").
            (!empty($consCpl) ? " " . $consCpl : "") .
            (!empty($consBairro) ? "-" . $consBairro : "") .
            (!empty($consMun) ? "-" . $consMun : "") .
            (!empty($consUF) ? "(".$consUF.")" : "").
            (!empty($consCEP) ? "-" . $consCEP : "") .
            (!empty($consFone) ? "-{$consFone}" : "");
        //If apenas para n�o inserir linha em v�o
        if(!empty($_aux_consumidor)){
            $consHtml .= $this->inserirTexto($_aux_consumidor);
        }

        //$consHtml .= $this->inserirTexto("");
        return $consHtml;
    }//fim consumidor

    /**
     *
     * @param type $nome
     * @param type $destino
     * @return type
     */
    public function printDANFE($output = 'pdf', $nome = '', $destino = 'I')
    {
        return  "<XML>" .  $this->html . "</XML>";

    }//fim printDANFE


    /**
     * No de texto ele s� devolver� a sequencia.
     *
     * @param unknown_type $chNFe
     * @param unknown_type $url
     * @param unknown_type $tpAmb
     * @param unknown_type $cDest
     * @param unknown_type $dhEmi
     * @param unknown_type $vNF
     * @param unknown_type $vICMS
     * @param unknown_type $digVal
     * @param unknown_type $idToken
     * @param unknown_type $Token
     * @return mixed
     */
    protected function makeQRCode(
        $chNFe,
        $url,
        $tpAmb,
        $cDest = '',
        $dhEmi = '',
        $vNF = '',
        $vICMS = '',
        $digVal = '',
        $idToken = '000001',
        $Token = ''
    ) {
        if(($GLOBALS["_VERSAO_NT"] & 134217728) > 0) {
            $_versao_qrcode = 3;
        } else {
            $_versao_qrcode = $this->getObjNFeZanthus()->aVerImpressao["IncluirQRCodeXMLNFCe"];
        }
        $seq = funcoesGerais::montarURLQrCodeNFCe($chNFe, $url, $tpAmb, $cDest,
            $dhEmi, $vNF, $vICMS, $digVal, $idToken, $Token, $_versao_qrcode, $this->getObjNFeZanthus()->getrPrivkey());
        //funcoesGerais::GravaLog("depois " .$seq,true,true);

        return $seq;

    }//fim makeQRCode
}//fim Classe


/**
 * Classe DanfSATCFePHP
 * Objetivo - impress�o de SAT CF-e em uma unica pagina (bobina)
 */
class DanfeTextoSATCFePHP extends DanfeTextoNFCeNFePHP implements DocumentoNFePHP
{
    public function __construct($docXML = '', $sPathLogo = '', $mododebug = 0, $idToken = '', $emitToken = '') {
        if (is_numeric($mododebug)) {
            $this->debugMode = $mododebug;
        }
        //Quem defini isso � o defines o class_bd
        /*if ($this->debugMode) {
            //ativar modo debug
            error_reporting(E_ALL);
            ini_set('display_errors', 'On');
        } else {
            //desativar modo debug
            error_reporting(0);
            ini_set('display_errors', 'Off');
        }*/
        $this->papel = array(80, 'one-page');
        $this->xml          = $docXML;
        $this->logomarca    = $sPathLogo;
        if (!empty($this->xml)) {
            $this->dom = new DomDocument;
            $this->dom->loadXML($this->xml);
            $this->nfeProc    = $this->dom->getElementsByTagName("nfeProc")->item(0);
            if($this->dom->getElementsByTagName("CFeCanc")->item(0) != null) {
                $this->nfe        = $this->dom->getElementsByTagName("CFeCanc")->item(0);
            }else{
                $this->nfe        = $this->dom->getElementsByTagName("CFe")->item(0);
            }
            $this->infNFe     = $this->dom->getElementsByTagName("infCFe")->item(0);
            $this->ide        = $this->dom->getElementsByTagName("ide")->item(0);
            $this->emit       = $this->dom->getElementsByTagName("emit")->item(0);
            $this->enderEmit       = $this->dom->getElementsByTagName("enderEmit")->item(0);
            $this->det        = $this->dom->getElementsByTagName("det");
            $this->dest       = $this->dom->getElementsByTagName("dest")->item(0);
            $this->pag        = $this->dom->getElementsByTagName("MP");
            $this->imposto    = $this->dom->getElementsByTagName("imposto")->item(0);
            $this->ICMSTot    = $this->dom->getElementsByTagName("ICMSTot")->item(0);
        }
        $this->idToken = $idToken;
        $this->emitToken = $emitToken;
        $this->html = "";

    } //fim __construct

    /**
     * o objetivo desta fun��o � ler o XML e gerar o DANFE com auxilio de convers�o HTML-PDF
     * @param type $detalhes
     * @return type
     */
    public function montaDANFE($detalhes = false, $_somar_desc_nfce = null, $_dados_offline = null)
    {
        $_num_tag = "";

        //DADOS DA NF
        $nProt = $this->__simpleGetValue($this->nfeProc, "nProt");
        $dhRecbto = $this->__simpleGetValue($this->nfeProc, "dhRecbto");
        $digVal = $this->__simpleGetValue($this->nfe, "DigestValue");
        $chNFe = str_replace('CFe', '', $this->infNFe->getAttribute("Id"));

        //Dados de CFe cancelado, se houver
        $chCancNFe = str_replace('CFe', '', $this->infNFe->getAttribute("chCanc"));
        $dCancEmi = $this->__simpleGetValue($this->infNFe, "dEmi");
        $hCancEmi = $this->__simpleGetValue($this->infNFe, "hEmi");
        $dhCancEmi = substr($dCancEmi, 0, 4) . '-' . substr($dCancEmi, 4, 2) . '-' . substr($dCancEmi, 6, 2);
        $dhCancEmi .= 'T' . substr($hCancEmi, 0, 2) . ':' . substr($hCancEmi, 2, 2) . ':' . substr($hCancEmi, 4, 2) . date("P", time());
        if (!empty($chCancNFe)) {
            $_cfe_cancelado = true;
        } else {
            $_cfe_cancelado = false;
        }


        $tpAmb = $this->__simpleGetValue($this->ide, 'tpAmb');
        $cUF = $this->__simpleGetValue($this->ide, 'cUF');
        $nNF = $this->__simpleGetValue($this->ide, 'nCFe');
        $serieNF = str_pad($this->__simpleGetValue($this->ide, "nserieSAT"), 3, "0", STR_PAD_LEFT);
        $dEmi = $this->__simpleGetValue($this->ide, "dEmi");
        $hEmi = $this->__simpleGetValue($this->ide, "hEmi");
        $dhEmi = substr($dEmi, 0, 4) . '-' . substr($dEmi, 4, 2) . '-' . substr($dEmi, 6, 2);
        $dhEmi .= 'T' . substr($hEmi, 0, 2) . ':' . substr($hEmi, 2, 2) . ':' . substr($hEmi, 4, 2) . date("P", time());
        $vProd = $this->__simpleGetValue($this->ICMSTot, "vProd");
        $vNF = $this->__simpleGetValue($this->nfe, "vCFe");
        $vOutro = $this->__simpleGetValue($this->ICMSTot, "vOutro");
        $vDesc = $this->__simpleGetValue($this->ICMSTot, "vDesc");
        $vICMS = $this->__simpleGetValue($this->ICMSTot, "vICMS");
        $vPIS = $this->__simpleGetValue($this->ICMSTot, "vPIS");
        $vCOFINS = $this->__simpleGetValue($this->ICMSTot, "vCOFINS");
        $vPISST = $this->__simpleGetValue($this->ICMSTot, "vPISST");
        $vCOFINSST = $this->__simpleGetValue($this->ICMSTot, "vCOFINSST");

        $qtdItens = $this->det->length;
        $_qrcode2 = '';
        if (($GLOBALS["_VERSAO_NT"] & 8) > 0) {
            $_qrcode2 = '2';
        }
        $urlChave = $this->urlConsulta["URLAcesso{$_qrcode2}"]; //$this->urlConsulta[$tpAmb][$cUF]['chave'];
        $urlQR = $this->urlConsulta['URLQRCodeAcesso'];//$this->urlConsulta[$tpAmb][$cUF]['QR'];


        //DADOS DO EMITENTE
        $emiFantas = $this->__simpleGetValue($this->emit, "xFant");
        $emitRazao = $this->__simpleGetValue($this->emit, "xNome");
        $emitCnpj = $this->__simpleGetValue($this->emit, "CNPJ");
        $emitCnpj = $this->__format($emitCnpj, "##.###.###/####-##");
        $emitIE = $this->__simpleGetValue($this->emit, "IE");
        $emitFone = $this->__simpleGetValue($this->enderEmit, "fone");
        $foneLen = strlen($emitFone);
        if ($foneLen > 0) {
            $fone2 = substr($emitFone, 0, $foneLen - 4);
            $fone1 = substr($emitFone, 0, $foneLen - 8);
            $emitFone = '(' . $fone1 . ') ' . substr($fone2, -4) . '-' . substr($emitFone, -4);
        } else {
            $emitFone = '';
        }
        $emitLgr = $this->__simpleGetValue($this->enderEmit, "xLgr");
        $emitNro = $this->__simpleGetValue($this->enderEmit, "nro");
        $emitCpl = $this->__simpleGetValue($this->enderEmit, "xCpl", " - ");
        $emitBairro = $this->__simpleGetValue($this->enderEmit, "xBairro");
        $emitCEP = $this->__format($this->__simpleGetValue($this->enderEmit, "CEP"), "#####-###");
        $emitMun = $this->__simpleGetValue($this->enderEmit, "xMun");
        $emitUF = $this->__simpleGetValue($this->enderEmit, "UF");

        //pag
        $tPagNome = '';
        $pagHtml = $this->pagamento($this->pag, $tPagNome);

        $_caracteres_linha_destaque = $this->_qtd_caracteres / 2;

        if ($detalhes && !$_cfe_cancelado) {

            $_caracteres_linha_total_itens = strlen("R$ " . number_format((float)$vProd, 2, ',', '.'));
            $_caracteres_linha_outro = strlen("R$ " . number_format((float)$vOutro, 2, ',', '.'));
            $_caracteres_linha_desc = strlen("R$ " . number_format((float)$vDesc, 2, ',', '.'));

            //IMPOSTOS
            if ($vNF !== $vProd) {
                $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha('TOTAL ITENS', ($_caracteres_linha_destaque - $_caracteres_linha_total_itens)) . 'R$ ' . number_format((float)$vProd, 2, ',', '.'), ESQUERDA, false, true);
            }
            if ($vOutro > 0) {
                $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha("ACRESCIMO", ($_caracteres_linha_destaque - $_caracteres_linha_outro)) . "R$ " . number_format((float)$vOutro, 2, ',', '.'), ESQUERDA, false, true);
            }
            if ($vDesc > 0) {
                $impHtml .= $this->inserirTexto(funcoesGerais::str_alinha("DESCONTO", ($_caracteres_linha_destaque - $_caracteres_linha_desc)) . "R$ " . number_format((float)$vDesc, 2, ',', '.'), ESQUERDA, false, true);
            }

        }


        //necess�rio para QRCode
        $cDest = '';
        if (isset($this->dest)) {
            $consCPF = !empty($this->dest->getElementsByTagName("CPF")->item(0)->nodeValue)
                ? $this->dest->getElementsByTagName("CPF")->item(0)->nodeValue
                : '';
            $consCNPJ = !empty($this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue)
                ? $this->dest->getElementsByTagName("CNPJ")->item(0)->nodeValue
                : '';
            $cDest = $consCPF . $consCNPJ; //documentos do consumidor
            $cDest = trim($cDest);
            //Esse CNPJ fixo deve ser revisto...
            if (empty($cDest) || $cDest == '61.099.008/0001-41') {
                $this->_sem_consumidor = true;
            }
        }

        //DADOS PARA QRCODE, Isso vem de cima pra baixo.
        $idToken = empty($this->idToken) ? '000001' : $this->idToken;


        $this->imgQRCode = $chNFe . '|';
        if ($_cfe_cancelado) {
            $this->imgQRCode .= $dCancEmi . $hCancEmi . '|';
        } else {
            $this->imgQRCode .= $dEmi . $hEmi . '|';
        }
        $this->imgQRCode .= $vNF . '|';
        $this->imgQRCode .= (empty($consCPF) ? $consCNPJ : $consCPF) . '|';
        $this->imgQRCode .= $this->__simpleGetValue($this->nfe, "assinaturaQRCODE");

        $this->barCode = $chNFe;

        //FORMATA��O DOS CAMPOS
        $numNF = "CFe " . $this->__format($nNF, "###.###.###");
        if ($_cfe_cancelado) {
            $tsHora = $this->__convertTime($dhCancEmi);
        } else {
            $tsHora = $this->__convertTime($dhEmi);
        }
        $tsProt = $this->__convertTime($dhRecbto);
        $valorProdutos = number_format((float)$vProd, 2, ",", ".");
        $valorTotal = number_format((float)$vNF, 2, ",", ".");

        //DADOS DA LOJA
        $_empresa = simplexml_load_string($_dados_offline);
        if($_empresa===false) {
            $_xml_aux = utf8_encode($_dados_offline);
            $_empresa = simplexml_load_string($_xml_aux);
        }
        $_complemento_cabecalho = $_empresa->complemento_cabecalho_fiscal;

        //CABE�ALHO
        $this->html .= "<TEXTO_ANTES{$_num_tag}><![CDATA[";
        //$this->html .= $this->inserirTexto("NFC-e");
        if ($GLOBALS['_imprimir_nome_fantasia'] == true) {
            $this->html .= $this->inserirTexto($emiFantas);
        }

        $_infoCodLoja = (!empty($this->info_impresssao['cod_loja']) && ((int)$this->info_impresssao['regra_especial_icms']&2048)>0) ? funcoesGerais::str_alinha($this->info_impresssao['cod_loja'],5,DIREITA,false,"0")." - " : '';
        $this->html .= $this->inserirTexto($_infoCodLoja.$emitRazao);
        $this->html .= $this->inserirTexto("CNPJ: {$emitCnpj}" . " IE: {$emitIE}");
        $this->html .= $this->inserirTexto($emitLgr . ", " . $emitNro . " " . $emitCpl);
        $this->html .= $this->inserirTexto($emitBairro . ", " . $emitMun . ", " . $emitUF . " CEP: $emitCEP $emitFone");
        $this->html .= $this->inserirTexto($_complemento_cabecalho);
        $this->html .= $this->inserirTexto(TRACO);

        if ($_cfe_cancelado) {

            $this->html .= $this->inserirTexto("Extrato No. {$nNF}", CENTRO, false, true);
            $this->html .= $this->inserirTexto("CUPOM FISCAL ELETRONICO - SAT CANCELAMENTO", CENTRO, false, true);
            $this->html .= $this->inserirTexto(TRACO);
            $this->html .= $this->inserirTexto("DADOS DO CUPOM FISCAL ELETRONICO DE CANCELAMENTO", CENTRO, false, true);

        } else {

            $this->html .= $this->inserirTexto("Extrato No. {$nNF}", CENTRO, false, true);
            //$this->html .= $this->inserirTexto(TRACO);
            $this->html .= $this->inserirTexto("CUPOM FISCAL ELETRONICO SAT", CENTRO, false, true);
            $this->html .= $this->inserirTexto(TRACO);

        }

        /**
         * ML-1268
         * BIT Software
         * 25.09.2019
         * Caso seja definido criamos uma nova tag TEXTO_LADO
         * o qual depende do pdv informar na tag modelo_impressao
         */
        $_modelo_impressao = $GLOBALS['_modelo_impressao'];
        if($_modelo_impressao!=1) {
            //CONSUMIDOR
            $this->html .= $this->consumidor($this->dest);
        }

        if (!$_cfe_cancelado) {

            $this->vTotalTrib = 0;

            //BLOCO DE DETALHES
            if ($detalhes) {
                //ITENS
                $this->html .= $this->itens($this->det, $_somar_desc_nfce);
            }

            $this->html .= $this->inserirTexto(' ');

            $this->vTotalTrib = funcoesGerais::ConverterParaNumero($this->vTotalTrib);

            //�rea IV
            //$this->html .= $this->inserirTexto(funcoesGerais::str_alinha("QTD. TOTAL DE ITENS ",20) . $qtdItens, ESQUERDA);

            $this->html .= $pagHtml;
        }

        $this->html .= $impHtml;

        if(((int)$this->info_impresssao['regra_especial_icms']&16384) <= 0) {
            $_caracteres_linha_total = strlen("R$ " . number_format((float)$vNF, 2, ',', '.'));
            $this->html .= $this->inserirTexto(funcoesGerais::str_alinha("TOTAL ", ($_caracteres_linha_destaque - $_caracteres_linha_total)) . "R$ " . number_format((float)$vNF, 2, ',', '.'), DIREITA, false, true);
        }

        $this->html .= $this->inserirTexto(TRACO);


        //�rea V
        //BLOCO DE DETALHES
        /**
         * REDUCAOIMP-1
         * BIT
         * Fev.2024
         * Op��o para n�o gerar observa��es contribuinte
         */
        if(!$_cfe_cancelado&&$this->info_impresssao['imprimir_tributos']=='S'&&((int)$this->info_impresssao['regra_especial_icms']&128)<=0) {
            $this->html .= $this->inserirTexto("OBSERVACOES DO CONTRIBUINTE");
            $this->html .= $this->inserirTexto("*Valor aproximado dos tributos do item");
            $this->html .= $this->inserirTexto("Valor aproximado dos tributos deste cupom (Conforme Lei Federal 12.741/2012) R$(" . number_format((float)$this->vTotalTrib, 2, ',', '.') . ")");
            $this->html .= $this->inserirTexto(TRACO);
        }


        /**
         * Filipe Barros
         * LAYOUTCFE-4 - Imprimindo obsFisco
         */
        if (((int)$this->info_impresssao['regra_especial_icms']&8192)<=0) {
            foreach ($this->dom->getElementsByTagName("obsFisco") as $_obsFisco) {
                $_xcampo = $_obsFisco->getAttribute("xCampo");
                $_texto = $this->__simpleGetValue($_obsFisco, "xTexto");
                $this->html .= $this->inserirTexto("{$_xcampo} - {$_texto}");
            }
        }

        if($_modelo_impressao==1) {
            $this->html .= "]]></TEXTO_ANTES{$_num_tag}>";
            $this->html .= "<TEXTO_LADO{$_num_tag}><![CDATA[";
            $_qtd_carac_orig = $this->_qtd_caracteres;
            // Recebemos 56 colunas, estamos adicionando um caracter a mais para quebrar a chave corretamente.
            //SQA-1015 - Adicionado 3 caracteres para quebrar a mensagem do aplicativo corretamente
            $this->_qtd_caracteres = ((int) $this->_qtd_caracteres/2)+4;
            //CONSUMIDOR
            $this->html .= $this->consumidor($this->dest,true);
        }

        //DADOS DA NOTA
        $this->html .= $this->inserirTexto("SAT No. {$serieNF}", CENTRO, false, true);
        $_data = $_cfe_cancelado ? $dhCancEmi : $dhEmi;
        $this->html .= $this->inserirTexto(date('d/m/Y H:i:s', strtotime($_data)), CENTRO);
        //$this->html .= $this->inserirTexto(TRACO);

        //DADOS DO APLICATIVO
        if ($_empresa->endereco->uf == "SP"){
            $this->html .= $this->inserirTexto("Consulte o QR Code pelo aplicativo 'De olho na nota',");
            $this->html .= $this->inserirTexto("disponivel na AppStore (Apple) e PlayStore (Android)");
        }else if ($_empresa->endereco->uf == "CE"){
            $this->html .= $this->inserirTexto("Consulte o QR Code pelo aplicativo 'Sua Nota Tem Valor',");
            $this->html .= $this->inserirTexto("disponivel na AppStore (Apple) e PlayStore (Android)");
        }

        /**
         * REDUCAOIMP-1
         * BIT
         * Fev.2024
         * Op��o para imprimir a chave em uma linha somente
         */
        $_qtd_string_blocos = ($this->_qtd_caracteres/2)<28 ? 24 :44;
        if(((int)$this->info_impresssao['regra_especial_icms']&512)<=0) {
            $_total_string = strlen($this->barCode);
            $_destaque_barcode = true;
            if(($this->_qtd_caracteres/2)<=28) {
                $_destaque_barcode = false;
            }
            $_qtd_string_bloco_filho = 4;
            $_split_barcode = str_split($this->barCode,24);
            $j = 0;
            for($i = 0;$j<=$_total_string;$i++) {
                $_string_bloco = str_split($_split_barcode[$i],$_qtd_string_bloco_filho);
                $this->html .= $this->inserirTexto(implode(' ',$_string_bloco),CENTRO,false,$_destaque_barcode);
                $j += $_qtd_string_blocos;
            }
        } else {
            $this->html .= $this->inserirTexto($this->barCode,CENTRO,false,false);
        }

		if($_modelo_impressao==1) {
            $this->html .= "]]></TEXTO_LADO{$_num_tag}>";
            $this->_qtd_caracteres = $_qtd_carac_orig;
        } else {
            $this->html .= "]]></TEXTO_ANTES{$_num_tag}>";
        }
        $this->html .= "<QRCODE{$_num_tag}><![CDATA[";
        $this->html .= $this->imgQRCode;
        $this->html .= "]]></QRCODE{$_num_tag}>";
        if(((int)$this->info_impresssao['regra_especial_icms']&1024)<=0) {
            $this->html .= "<BARCODE{$_num_tag} BLOCO=\"{$_qtd_string_blocos}\"><![CDATA[{$this->barCode}]]></BARCODE{$_num_tag}>";
        }
        $this->html .= "<TEXTO_DEPOIS{$_num_tag}><![CDATA[";

        $infCpl      = $this->dom->getElementsByTagName("infAdic")->item(0);
        $infCpl      = substr($this->__simpleGetValue($infCpl, "infCpl"),1,-1);

        if (!empty($infCpl)&&((int)$this->info_impresssao['regra_especial_icms']&8192)<=0) {
            $this->html .= $this->inserirTexto($infCpl);
        }
        //SQA-1572 - Regra adicionada para simplifica��o das informa��es dos impostos.
        if (!empty($infCpl)&&((int)$this->info_impresssao['regra_especial_icms']&8192)>0){
            $infCpl = ucwords(strtolower($infCpl));
            $_infCpl = $this->formatarInfCpl($infCpl);
            $this->html .= $this->inserirTexto($_infCpl);
        }

        $this->html .= "]]></TEXTO_DEPOIS{$_num_tag}>";

        return $chNFe;
    }//fim da fun��o montaDANFE


    protected function pagamento($pag, &$tPnome) {
        if (!isset($pag)) {
            return '';
        }
        //DADOS DE PAGAMENTO
        $oldtBand = '';
        $oldtPag  = '';
        $pagHtml  = "";//$this->inserirTexto("");
        //$pagHtml .= $this->inserirTexto("PAGAMENTOS\n");

        $totalEPagamentoMesmoLinha = null;
        $tamanhoTotalEPagamentoMesmoLinha = null;
        if(((int)$this->info_impresssao['regra_especial_icms']&16384)>0) {
            $vNF = $this->__simpleGetValue($this->nfe, "vCFe");
            $totalEPagamentoMesmoLinha = "R$ " . number_format((float)$vNF, 2, ',', '.');
            $tamanhoTotalEPagamentoMesmoLinha = strlen($totalEPagamentoMesmoLinha);
        }

        /**
         * Fizemos isso por conta do php 5.6
         */
        $count_pag   = 0;
        $size_of_pag = $pag->length;

        foreach ($pag as $pagI) {
            $count_pag++;
            $tPag = $this->__simpleGetValue($pagI, "cMP");
            $tPagNome = $this->tipoPag($tPag);
            $tPnome = $tPagNome;
            $vPag = number_format((float)$this->__simpleGetValue($pagI, "vMP"), 2, ",", ".");
            //$card = $pagI->getElementsByTagName("card")->item(0);
            //cart�o
//            if (isset($card)) {
//                $cardCNPJ = $this->__simpleGetValue($card, "CNPJ");
//                $tBand    = $this->__simpleGetValue($card, "tBand");
//                //$cAut = $this->__simpleGetValue($card, "cAut");
//                $tBandNome = self::getCardName($tBand);
//            }
            $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
            if (isset($totalEPagamentoMesmoLinha) && ($size_of_pag == $count_pag)) {
                $pagHtml .= $this->inserirTextoEsquerdaEDireita($tPagNome . ": " . $_sigla_moeda . $vPag, funcoesGerais::str_alinha("TOTAL ", $tamanhoTotalEPagamentoMesmoLinha) . $totalEPagamentoMesmoLinha);
            }else{
                $pagHtml .= $this->inserirTexto($tPagNome . ": " . $_sigla_moeda . $vPag, ESQUERDA);
            }

//            if ($cardCNPJ != '') {
//                $pagHtml .= $this->inserirTexto($tBandNome . ": " . $this->__format($cardCNPJ, "##.###.###/####-##"));
//            }
        } //fim foreach

        return $pagHtml;
    }


    protected function consumidor($dest, $_omitir = false, $_modelo_impressao = null) {
        //DADOS DO CONSUMIDOR
        if ($this->_sem_consumidor) {
            $consHtml .= $this->inserirTexto("CONSUMIDOR NAO IDENTIFICADO");
            //$consHtml .= $this->inserirTexto(TRACO);
            return $consHtml;
        }

        $consCPF = $this->__simpleGetValue($dest, "CPF");
        $consCNPJ = $this->__simpleGetValue($dest, "CNPJ");
        if (!empty($consCPF)) {
            $consCPF = funcoesGerais::formatarDado("CPF",$consCPF);
        }
        if (!empty($consCNPJ)) {
            $consCNPJ = funcoesGerais::formatarDado("CNPJ",$consCNPJ);
        }

        $consDoc = $consCPF.$consCNPJ; //documentos do consumidor

        if(!empty($consDoc)) {
            $consHtml .= $this->inserirTexto("CNPJ/CPF do Consumidor: ".$consDoc);
            //$consHtml .= $this->inserirTexto(TRACO);
        }

        //$consHtml .= $this->inserirTexto("");
        return $consHtml;
    }//fim consumidor

    /**
     * POSTOF1-1
     * Quando � posto teremos valor unit�rio de 2 casas e de 3 ou 4 casas
     * por�m n�o quero mostrar na tela errado.
     */
    protected function checarCasasDecimais($_valor) {
        $_valor=number_format((float)$_valor, 4);
        $_contunuar=false;
        $_casas=4;
        do {
            if($_valor[strlen($_valor)-1]==="0") {
                $_valor=substr($_valor, 0, -1);
                $_continuar=true;
                $_casas--;
                //Duas casas � o limite.
                if($_casas===2) {
                    break;
                }
            } else {
                $_continuar=false;
            }
        } while($_continuar);
        return $_casas;
    }

    protected function itens($det, $_somar_desc_nfce = null) {
        if (!isset($det)) {
            return '';
        }

        $_imprimir_desc_acres_item = ($GLOBALS["_VERSAO_NT"] & 512) > 0;
        $_imprimir_valor_liquido_item = $_somar_desc_nfce == 'S';

        $nitem_ant = null;
        $_no_fim = true;
        $_tamCod = 0;
        $_tamDesc = 0;
        $_tamQtd = 0;
        $_tamVUni = 0;
        $_tamUni = 2;
        $_tamVTot = 0;
        $_tamTributo = 0;
        $_totalItensCupom = 0;

        foreach ($det as $detI){
            $_totalItensCupom++;
            $thisItem = $detI;
            $prod = $thisItem->getElementsByTagName("prod")->item(0);
            //Se houver EAN no XML, uso ele na impress�o.
            $_valorProd = $this->__simpleGetValue($prod, "cEAN");
            $_seq = $thisItem->getAttribute("nItem");
            if($this->_imprimir_cod_lido) {
                if (!empty($_valorProd) && $_valorProd != 'SEM GTIN')  {
                    $prod->getElementsByTagName("cProd")->item(0)->nodeValue = $_valorProd;
                }
                /**
                 * O conceito veio do BL-7206
                 * Para que o PDV repasse essa informa��o inseri na tag nota, por�m para fazer isso preciso
                 * remov�-lo antes de aplicar o parser.
                 * Quando encontramos o c�digo lido e veio do PDV imprimimos ele.
                 */
                $_cod_prod = funcoesGerais::str_alinha($this->__simpleGetValue($prod, 'cProd'),17,DIREITA,true, "0");
                if (isset($GLOBALS['_objeto_complementar'])) {
                    try {
                        if (isset($GLOBALS['_objeto_complementar']->mercadorias[$_seq]) && !empty($GLOBALS['_objeto_complementar']->mercadorias[$_seq]->cod_lido)) {
                            $_cod_prod = $GLOBALS['_objeto_complementar']->mercadorias[$_seq]->cod_lido;
                            if (!empty($_cod_prod)) {
                                $prod->getElementsByTagName("cProd")->item(0)->nodeValue =  ltrim($_cod_prod,"0");
                            }
                        }
                    } catch (Exception $_e) {
                    }
                }
            }
            if ($_tamCod === 0 || strlen($this->__simpleGetValue($prod, 'cProd')) > $_tamCod){
                $_tamCod = strlen($this->__simpleGetValue($prod, 'cProd'));
            }

            $uCom = $this->__simpleGetValue($prod, 'uCom');
            $qCom = funcoesGerais::ConverterParaNumero($this->__simpleGetValue($prod, 'qCom'));

            if ($uCom == 'UN' || $uCom = 'CX'){
                if (($_pos = strpos($qCom, '.000')) != false) {
                    $qCom = (int) $qCom;
                } else {
                    $qCom   = number_format((float)$qCom, 2, ",", ".");
                }
            } else {
                $qCom = number_format((float)$qCom, 3, ',','.');
            }

            if ($_tamQtd === 0 || strlen($qCom) > $_tamQtd) {
                $_tamQtd = strlen($qCom);
            }

            $vUnCom = number_format((float)$this->__simpleGetValue($prod, 'vUnCom'), 2, ',', '.');

            if ($_tamVUni === 0 || strlen($vUnCom) > $_tamVUni){
                $_tamVUni = strlen($vUnCom);
            }

            // Valor Total
            $_vProd = $this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desconto = trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = trim($this->__simpleGetValue($prod, "vOutro"));

            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = (float)$_vProd - (float)$_desconto + (float)$_acrescimo;
            }
            $vProd = number_format((float)$_vProd, 2, ',', '.');
            if ($_tamVTot === 0 || strlen($vProd) > $_tamVTot){
                $_tamVTot = strlen($vProd);
            }

            $_imposto = $thisItem->getElementsByTagName("imposto")->item(0);
            $_tributo = number_format((float)$this->__simpleGetValue($_imposto, "vItem12741"), 2, ',', '.');
            if (($_tamTributo === 0 || strlen($_tributo) > $_tamTributo) && $_tributo !== '0,00'){
                $_tamTributo = strlen($_tributo);
            }
        }

        $_tamQtItens = strlen($_totalItensCupom);
        $_tamCod++;
        $_tamQtd++;
        $_tamVUni++;
        $_tamVTot++;
        $_tamTributo++;

        /**
         * Tairo Miguel
         * BL-4237
         * Obs: Retirando da soma de caracters a '$_tamDesc' ele s� deve ser somado no final
         *      quando j� tivermos todos os tamanhos de caracteres, ai o que faltar para completar
         *      o n�mero de colunas nos colocamos para a descri��o
         */
        $_tamTotal = $_tamQtItens + $_tamCod + $_tamQtd + $_tamVUni + $_tamUni + $_tamVTot + $_tamTributo;
        if ($_tamTotal > $this->_qtd_caracteres){
            $_tamDesc = $_tamTotal - $this->_qtd_caracteres;
        }
        if ($_tamTributo > 0) {
            $_tamDesc = $_tamDesc - $_tamTributo;
            $_tamTributo++;
        }

        $_tamDesc = $this->_qtd_caracteres - ($_tamQtItens + $_tamCod);

        $nitem_ant  = null;
        //ITENS
        $itensHtml  = "";

        //Ajusta a ordem caso esteja invertido.
        $nitem_ant  = null;
        $_no_fim    = true;
        $_sigla_moeda = ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0 ? 'R$ ' : '';
        foreach ($det as $detI) {
            $thisItem   = $detI;
            $prod       = $thisItem->getElementsByTagName("prod")->item(0);
            if($this->info_impresssao['imprimir_danfe_nfce_1linha'] != "S" || ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0) {
                $nitem      = funcoesGerais::str_alinha($thisItem->getAttribute("nItem"), 4, ESQUERDA);
            }else{
                $nitem = funcoesGerais::str_alinha($thisItem->getAttribute("nItem"), 3, ESQUERDA);
            }
            if (!isset($nitem_ant) || $nitem_ant > $nitem) {
                if (isset($nitem_ant)) {
                    $_no_fim = false;
                }
                $nitem_ant = $nitem;
            }

            $cProd      = $this->__simpleGetValue($prod, "cProd");
            $cProd     = funcoesGerais::removeZerosEsquerdaNumerosGrandes($cProd);
            $xProd      = $this->__simpleGetValue($prod, "xProd");
            $xProd		= trim($xProd);
            $uCom       = $this->__simpleGetValue($prod, "uCom");
            $qCom       = funcoesGerais::ConverterParaNumero($this->__simpleGetValue($prod, "qCom"),3);
            if ($uCom == "UN" || $uCom == "CX" ) {
                //Pode ser que esteja errado, ent�o se n�o for .000 � decimal ent�o deve mostrar
                if (($_pos = strpos($qCom,".000")) !== false) {
                    $qCom   = (int) $qCom;
                } else {
                    $qCom   = number_format((float)$qCom, 2, ",", ".");
                }
            } else {
                $qCom       = number_format((float)$qCom, 3, ",", ".");
            }
            //POSTOF1-1 por causa do pre�o de combust�vel, precisaremos rever isso..
            $_num_casas_preco = $this->checarCasasDecimais($this->__simpleGetValue($prod, "vUnCom"));
            $vUnCom     = number_format((float)$this->__simpleGetValue($prod, "vUnCom"), $_num_casas_preco, ",", ".");

            // Valor Total
            $_vProd = $this->__simpleGetValue($prod, "vProd");

            // Descontos e Acr�scimos
            $_desc_acres_item = '';
            $_desconto = trim($this->__simpleGetValue($prod, "vDesc"));
            $_acrescimo = trim($this->__simpleGetValue($prod, "vOutro"));
            if($_imprimir_desc_acres_item) {
                if (!empty($_desconto)) {
                    $_desc = number_format((float)$_desconto, 2, ",", ".");
                    $_desc_acres_item.= "Desconto: {$_sigla_moeda}{$_desc} ";
                }
                if (!empty($_acrescimo)) {
                    $_acres = number_format((float)$_acrescimo, 2, ",", ".");
                    $_desc_acres_item.= "Acrescimo: {$_sigla_moeda}{$_acres} ";
                }
            }

            // Valor Total Liquido
            if($_imprimir_valor_liquido_item) {
                $_vProd = (float)$_vProd - (float)$_desconto + (float)$_acrescimo;
            }

            // Cest e Ncm
            $_cest_ncm_item = '';
            if($this->info_impresssao['imprimir_cest_ncm'] == "S") {
                $_cest = $this->__simpleGetValue($prod, "CEST");
                $_ncm = $this->__simpleGetValue($prod, "NCM");
                $_cest_ncm_item = "CEST: {$_cest} NCM: {$_ncm} ";
            }

            $_imposto = $thisItem->getElementsByTagName("imposto")->item(0);
            $_tributos = $this->__simpleGetValue($_imposto, "vItem12741");
            $this->vTotalTrib += (float)$_tributos;
            $_tributos_formatado = number_format((float)$_tributos,2,",",'.');

            if(floatval($_tributos) > 0){
                $_tributos = funcoesGerais::str_alinha('('.$_tributos_formatado.')', $_tamTributo);
            } else {
                $_tributos = funcoesGerais::str_alinha('()', $_tamTributo);
            }

            $qCom = funcoesGerais::str_alinha($qCom,$_tamQtd,DIREITA);

            /**
             * BL-4237
             * Conforme solicitado pelo Ronaldo e Bruno Neuman a descri��o dever� ser impressa
             * em uma linha separada da quantidade e valores, pois os clientes estavam reclamando
             * pelo fato da descri��o n�o aparecer completa.
             */
            $infAdProd = $this->dom->getElementsByTagName("infAdProd")->item(0);

            /**
             * BL-7410
             * Foi pedido no BL-7073 para retirar o "Pre�o De Por" da descri��o do produto e colocado nas informa��es adicionais.
             * Ent�o estamos extraindo essa informa��o para poder imprimir corretamente no item do cupom.
             */
            $_de_por = '';
            $_array_infAdProd = explode('|', $infAdProd);
            foreach($_array_infAdProd as $_info) {
                $_info = trim($_info);
                if(strpos($_info, 'DESC_PROMO:') !== false) {
                    $_de_por = trim(str_replace(['DESC_PROMO:', $xProd], '', $_info)) . " ";
                } else {
                    $infAdProd = $_info;
                }
            }

            if (empty($infAdProd)) {
                $infAdProd = " Nao houve a arrecadacao para o FECP";
            }

            if($this->info_impresssao['imprimir_danfe_nfce_1linha'] != "S" || ((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0){
                $cProd = funcoesGerais::str_alinha($cProd, $_tamCod, ESQUERDA);
                $uCom = funcoesGerais::str_alinha($uCom, $_tamUni, ESQUERDA);
                $_num_casas_preco = $this->checarCasasDecimais($this->__simpleGetValue($prod, "vUnCom"));
                $vUnCom = funcoesGerais::str_alinha(number_format((float)$this->__simpleGetValue($prod, "vUnCom"), $_num_casas_preco, ",", "."),$_tamVUni,DIREITA);
                $vProd = funcoesGerais::str_alinha(number_format((float)$_vProd, 2, ",", "."),$_tamVTot,DIREITA);
                if(((int)$this->info_impresssao['opcoes_impressao_nota']&1024)>0) {
                    $vUnCom = 'R$'. $vUnCom;
                    $vProd = 'R$'. $vProd;
                }
                $_titulo = "{$nitem} {$cProd} {$xProd}";
                $_titulo2 = "{$qCom} {$uCom} {$vUnCom} {$_tributos} {$vProd}";

                //Pra acertar a ordena��o dos itens, caso esteja invertido.
                if ($_no_fim) {
                    $itensHtml .= $this->inserirTexto($_titulo,ESQUERDA, false, false, true, true);

                    /**
                     * BL-7410
                     * Se precisar imprimir qualquer outra informa��o basta incluir na lista de textos abaixo:
                     */
                    $_textos = [
                        $_de_por,
                        $_desc_acres_item,
                        $_cest_ncm_item
                    ];
                    $itensHtml.= $this->otimizarLinhasTexto($_textos, $_titulo2, true);

                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml .= $this->inserirTexto($infAdProd, ESQUERDA, false, false, true, true);
                    }
                } else {
                    $itensHtml = $this->inserirTexto($_titulo,ESQUERDA, false, false, true, true) . $this->inserirTexto($_titulo2,DIREITA) . $itensHtml;
                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml .= $this->inserirTexto($infAdProd, ESQUERDA, false, false, true, true);
                    }
                }

            } else {
                $vProd = number_format((float)$_vProd, $_num_casas_preco, ",", ".");
                $_tituloTam = strlen("{$nitem} {$cProd} {$qCom} {$uCom} {$vUnCom} {$_tributos} {$vProd}");
                $_caracteresSobrando = ($this->_qtd_caracteres - ($_tituloTam + 1));
                if($_caracteresSobrando > 0){
                    $xProd = substr($xProd, 0, $_caracteresSobrando);
                    $xProd = str_alinha($xProd,$_caracteresSobrando,ESQUERDA);
                    $_titulo = "{$nitem} {$cProd} {$xProd} {$qCom} {$uCom} {$vUnCom} {$_tributos} {$vProd}";
                }else{
                    $_titulo = "{$nitem} {$cProd} {$qCom} {$uCom} {$vUnCom} {$_tributos} {$vProd}";
                }

                //Pra acertar a ordena��o dos itens, caso esteja invertido.
                if ($_no_fim) {
                    $itensHtml .= $this->inserirTexto(trim($_titulo),ESQUERDA);

                    /**
                     * BL-7410
                     * Se precisar imprimir qualquer outra informa��o basta incluir na lista de textos abaixo:
                     */
                    $_textos = [
                        $_de_por,
                        $_cest_ncm_item
                    ];
                    $itensHtml.= $this->otimizarLinhasTexto($_textos, $_desc_acres_item);

                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml .= $this->inserirTexto($infAdFisco, ESQUERDA, false, false, true, true);
                    }
                } else {
                    $itensHtml = $this->inserirTexto(trim($_titulo),ESQUERDA) . $itensHtml;
                    if (($GLOBALS["_VERSAO_NT"] & 128) > 0) {
                        $itensHtml .= $this->inserirTexto($infAdFisco, ESQUERDA, false, false, true, true);
                    }
                }
            }
        }

        $_titulo    = "#|COD|DESC|QTD|UN|VL UN R$|(VL TR R$)*|VL ITEM R$";
        $itensHtml  = $this->inserirTexto($_titulo,ESQUERDA) . $this->inserirTexto(TRACO) . $itensHtml;

        return $itensHtml;
    }//fim itens

}//fim Classe