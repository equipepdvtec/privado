<?php

/**
 *
 * Este script funciona via REST
 * Deve receber "sessao" e "mensagem"
 * "sessao" por enquanto n�o est� implementado, ent�o s� recebemos asterisco (*)
 * "mensagem" deve ser um JSON contendo "cod_loja", "cod_pdv", "tipo", "dados"
 *
 * O "tipo" vai ser usado para saber qual m�todo chamar ou qual a��o tomar, quando for implementada novas
 * funcionalidades � s� colocar no "switch ($_mensagemObj->tipo)" abaixo.

 * Os "dados" s�o basicamente os parametros usados para o determinado "tipo" passado
 *
 *
 * Exemplo de dados de envio:
 * url + a descri��o da sess�o abaixo
 * ?sessao=*&mensagem={"cod_loja":1,"cod_pdv":96,"tipo":"VersaoAplicativo","dados":{"retornar":"lista"}}
 *
 * O retorno segue o padr�o da chamada, � um JSON contendo:
 * "resultado": 0 (OK) ou 1 (NOK)
 * "mensagem": alguma mensagem de erro caso aconte�a
 * "cod_loja": a mesma passada no request
 * "cod_pdv":  o mesmo passado no request
 * "dados": Caso a funcionalidade (tipo) chamada tenha que retornar alguma informa��o esta pode usar
 * este parametro para retornar. Por padr�o isso retorna a mesma informa��o do request.
 *
 *

 */


$_lusuario 		= 99999; // Autorizador...

//Se for uma chamada do redirecionador � interno logo � sem HTTPS.
if($_SERVER["HTTP_REFERER"]==="saas_redirect") {
    $_SEMHTTPS = true;
}
$GLOBALS['_IS_MANAGER_PDV'] = true;

require_once("includes/header.inc");
require_once("classes/class_memcache_provider.inc");

if($_REQUEST["origem"] == 'PDVTM') {
    $_REQUEST["mensagem"] = base64_decode($_REQUEST["mensagem"]);
}

$_sessao		= $_REQUEST["sessao"];
$_mensagem		= $_REQUEST["mensagem"];
$_origem 		= $_REQUEST["origem"];

// se o jSon vier em formato errado, devolvo a mensagem pro PDV
try {
    if($_DEBUG) {
        funcoesGerais::GravaLog("JSON (REQUISI��O) :: {$_mensagem}", true, true);
    }
    $_mensagemObj 	= JSON::decode($_mensagem);

} catch (Exception $e) {
    $_retorno['resultado'] = '1';
    $_retorno['mensagem']  = $e->getMessage();
    $_erro = true;
}

if(!is_null($_mensagemObj)) {
    $_retorno = array(
        'resultado' => '0',
        'mensagem'  => '',
        'cod_loja'  => $_mensagemObj->cod_loja,
        'cod_pdv'   => $_mensagemObj->cod_pdv,
        'dados'     => $_mensagemObj->dados,
        'fn' 		=> $_mensagemObj->fn
    );
}

//-----------------------------------------------------------------
// Ainda n�o usamos a sess�o para nada, ent�o s� estamos verificando se come�a com *
if(!AMBIENTE_SAAS) {
    $_temp = substr($_sessao,0,1);
    if($_temp!=="*"){
        $_retorno['resultado'] = '1';
        $_retorno['mensagem']  = 'Sessao Invalida';
        $_erro = true;
    }
}
//-----------------------------------------------------------------
$_html_entities = true;
if($_erro) {
    $_retorno['mensagem'].=" | JSON :: {$_mensagem}";
} else {
    try {
        switch ($_mensagemObj->tipo) {
            case 'pegarInfoVersaoAtual':
                $_php_v = explode('.', phpversion());
                $_php = 'php_' . $_php_v[0] . '_' . $_php_v[1];

                /**
                 * BL-9815
                 *
                 * IMPORTANTE:
                 * N�o altere o nome da vari�vel abaixo, o gerador de vers�o utiliza ela ao processar o modulo AZZ.
                 */
                $_versao_modulo = (implode('_',$GLOBALS["_VERSAO_APP"]) . (!empty($GLOBALS["_VERSAO_RELEASE"]) ? $GLOBALS["_VERSAO_RELEASE"] : '') . '_' . $GLOBALS["_IDENTIFICADOR"]);

                /**
                 * SQA-964
                 * Contornando estrutura do instalador com modulo php8 em container.
                 * O caminho absoluto � o diret�rio dentro do container, por�m o PDV tenta acessar o diret�rio local.
                 * Haver� uma atividade de PDV pra for�ar o path_trab.
                 */
                $_path_trab = ($_php_v[0] >= 8 && funcoesGerais::isLinux()) ? "/Zanthus/Zeus/pdvJava/GERAL/SINCRO/WEB/moduloPHPPDV/" : funcoesGerais::retornarCaminhoAbsolutoManager();

                $_retorno['mensagem'] = 'Sucesso';
                $_retorno['dados'] = Array(
                    'sufixo_ambiente' => $_php,
                    'path_trab' => $_path_trab,
                    'versao_atual' => $_versao_modulo
                );
                break;
            default:
                $_retorno['resultado'] = '1';
                $_retorno['mensagem'] = 'Nenhum tipo encontrado';
                break;
        }
        //Como nem todos os m�todos est�o devidamente protegidos, melhor garantir...
    } catch(Exception $e) {
        $_erro = $e->getCode();

        // Tratando Retorno
        if($_retorno['resultado'] == "") {
            $_retorno['resultado'] = (empty($_erro) ? 1 : "{$_erro}");
            $_retorno['mensagem'] = "Erro: {$e->getMessage()}";
        }

        /**
         * Tratando Exce��o de Banco
         *
         * Aten��o: Como utilizaram tratamento de "exce��o" na forma "condicional" nos cases acima,
         * ent�o infelizmente tenho que repassar a exce��o "throw $e;" para cada m�todo que queria
         * ser validado se o banco est� off, somente assim consigo fazer o tratamento
         * num �nico ponto em comum.
         */
        if($_erro == 9000001) {
            $_retorno['off'] = 1;
        }
    }
}
ob_clean();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
if (is_array($_retorno) || is_object($_retorno)) {
    $_obj_json = JSON::encode((object)$_retorno, $_html_entities);
    if ($_obj_json === false) {
        funcoesGerais::GravaLog(" erro json " . json_last_error_msg(),true,true);
    }
} else {
    $_obj_json = $_retorno;
}

if($_DEBUG) {
    funcoesGerais::GravaLog("JSON (RETORNO) :: {$_obj_json}", true, true);
}

echo $_obj_json;
