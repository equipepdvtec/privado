<?php
/**
 * Created by PhpStorm.
 * User: eber.lincoln
 * O cliente Caedu usa o chama Fila Wyma
 * Se algum outro cliente precisar us�-lo funcinar�.
 * Vale lembrar que este processo usa um jar java
 *
 * Date: 15/03/2018
 * Time: 15:01
 */
$_caminho  = "java/";
$_comando = 'java -jar ' . $_caminho  . 'chamaFila.jar "' . $_REQUEST["IP"]  . '" "' .$_REQUEST["PDV"] . '" "' . $_REQUEST["LADO"] . '"' ;
exec($_comando,$_output);
//echo "retorno: " . var_export($_REQUEST,true). "<br>";
$_ret = $_output[0];
if (($_pos = strpos($_ret,"ERRO:")) !== false) {
    $_obj = new stdClass();
    $_obj->resultado = 1;
    $_obj->msg    = utf8_encode(substr($_ret,$_pos + 5));
} elseif (($_pos = strpos($_ret,"OK:")) !== false) {
    $_obj = new stdClass();
    $_obj->resultado = 3;
    $_obj->msg    = utf8_encode(substr($_ret,$_pos + 3));
}
$_obj_json = json_encode($_obj);
echo $_REQUEST['retorno'] . '(' .  $_obj_json . ')';
