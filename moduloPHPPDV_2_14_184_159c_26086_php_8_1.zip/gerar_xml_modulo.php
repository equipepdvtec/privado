<?php





$_INTERNO		= True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;

//N�o usar https para as integra��es dos clientes ao manager.
$_SEMHTTPS 	    = True;
$_SEMVALIDAR 	= True;
$_NOTEST 		= True;
$_FPDVDB		= true;

$_lusuario 		= 99999;
$_FPEDIDO 		= true;
$_TIMEOUT		= 3600;
$_cod_loja 		= 14;
$GLOBALS['_SQLLOJASAUT']    = $_cod_loja;
$GLOBALS['_eusuario']    	= $_cod_loja;
$GLOBALS['_IS_MANAGER_PDV'] = true;
$GLOBALS['_INCLUIR']		= false;
$_con 					    = $GLOBALS['_MASTER'];



require_once("includes/header.inc");

$_bf = fopen('modulo.xml',"w+");
fputs($_bf,'<arquivos>'."\r\n");
fclose($_bf);


function copiarRecursivo($_dir, $_raiz) {
	$_ponteiro  = opendir($_dir);
    $_array_ignore = array(
        'teste.php','.project','Logs','certificados','.projectOptions','sat_lab.conf','guard.xml'
    );

    if($_dir[strlen($_dir)-1] !=="/") {
        $_dir .= "/";
    }


	while ($_nome_itens = readdir($_ponteiro)) {
		if ($_nome_itens== "." || $_nome_itens == ".." || $_nome_itens[0] == "." || in_array($_nome_itens, $_array_ignore)) {
			continue;
		}
		$_destino = $_dir.$_nome_itens;
		if (!is_dir($_destino)) {
            $_bf = fopen('modulo.xml',"a+");
            $_destino = str_replace($_raiz.'/','',$_destino);
            fputs($_bf,"\t<arquivo>\r\n\t\t<![CDATA[".$_destino."]]>\r\n\t</arquivo>\r\n");
            fclose($_bf);
		} else {
			copiarRecursivo($_dir  . $_nome_itens . "", $_raiz);
		}
		//$_itens[] = $_nome_itens;
	}



	//return $_itens;
}



echo "vamos come�ar a listar<br>" ;
echo "Diret�rio base " . getcwd();

copiarRecursivo(getcwd(),getcwd() );

$_bf = fopen('modulo.xml',"a+");
fputs($_bf,'</arquivos>'."\r\n");
fclose($_bf);
//echo "<pre>". var_export(listar(getcwd()),true) . "</pre>";