<?php

/**
 *
 * Este script funciona via REST
 * Deve receber "sessao" e "mensagem"
 * "sessao" por enquanto n�o est� implementado, ent�o s� recebemos asterisco (*)
 * "mensagem" deve ser um JSON contendo "cod_loja", "cod_pdv", "tipo", "dados"
 *
 * O "tipo" vai ser usado para saber qual m�todo chamar ou qual a��o tomar, quando for implementada novas
 * funcionalidades � s� colocar no "switch ($_mensagemObj->tipo)" abaixo.

 * Os "dados" s�o basicamente os parametros usados para o determinado "tipo" passado
 *
 *
 * Exemplo de dados de envio:
 * url + a descri��o da sess�o abaixo
 * ?sessao=*&mensagem={"cod_loja":1,"cod_pdv":96,"tipo":"VersaoAplicativo","dados":{"retornar":"lista"}}
 *
 * O retorno segue o padr�o da chamada, � um JSON contendo:
 * "resultado": 0 (OK) ou 1 (NOK)
 * "mensagem": alguma mensagem de erro caso aconte�a
 * "cod_loja": a mesma passada no request
 * "cod_pdv":  o mesmo passado no request
 * "dados": Caso a funcionalidade (tipo) chamada tenha que retornar alguma informa��o esta pode usar
 * este parametro para retornar. Por padr�o isso retorna a mesma informa��o do request.
 *
 *

 */

$_INTERNO		= True;
$_INCLUIR       = True;
$_CONSULTA_WS   = True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;
$_SEMVALIDAR 	= True;
$_NOCERT        = True;
$_NOTEST 		= True;
$_lusuario 		= 99999; // Autorizador...
$_FPEDIDO 		= true;
/**
 * Tudo o que esta aqui deveria conseguir ser feito em 40 segundos
 * Caso precise de algum ponto especifico por favor tenha uma boa justificativa
 * e mude l�.
 */
$_TIMEOUT		= 40;
/*$_max_execution_time = ini_get('max_execution_time');
$_max_execution_time = (int)$_max_execution_time < 3600 ? 3600: $_max_execution_time;
$_TIMEOUT 		= $_max_execution_time;*/

//Tratamento de WebService
$_ACESSOWS      = true;

//Se for uma chamada do redirecionador � interno logo � sem HTTPS.
if($_SERVER["HTTP_REFERER"]==="saas_redirect") {
    $_SEMHTTPS = true;
}

//Volto para o diret�rio raiz para que tudo funcione.
chdir("../../");

/** Pega o post enviado pelo pdv e coloca no get para n�o mexer nos metodos que j� existe */
if(isset($_POST["mensagem"])) {
    $_GET = $_REQUEST;
}

require_once("includes/header.inc");
require_once("classes/class_funcoesgerais.inc");

if($_GET["origem"] == 'PDVTM') {
    $_GET["mensagem"] = base64_decode($_GET["mensagem"]);
}

$_sessao		= $_GET["sessao"];
$_mensagem		= $_GET["mensagem"];
$_origem 		= $_GET["origem"];

// se o jSon vier em formato errado, devolvo a mensagem pro PDV
try {
    if($_DEBUG) {
        funcoesGerais::GravaLog("JSON (REQUISI��O) :: {$_mensagem}", true, true);
    }
    //SQA- 5151 Ajuste para tratar m�todo POST
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        $_mensagemObj 	= JSON::decode($_mensagem);
    } else{
        $_bodyContent = file_get_contents('php://input');
        parse_str($_bodyContent, $_conteudoDecodificado);
        $_mensagemObj = JSON::decode($_conteudoDecodificado['mensagem']);
        $_sessao = !empty($_conteudoDecodificado['sessao']) ? $_conteudoDecodificado['sessao'] : $_sessao;
        $_origem = !empty($_conteudoDecodificado['origem']) ? $_conteudoDecodificado['origem'] : $_origem;
    }

} catch (Exception $e) {
    $_retorno['resultado'] = '1';
    $_retorno['mensagem']  = $e->getMessage();
    $_erro = true;
}

if(!is_null($_mensagemObj)) {
    $_retorno = array(
        'resultado' => '0',
        'mensagem'  => '',
        'cod_loja'  => $_mensagemObj->cod_loja,
        'cod_pdv'   => $_mensagemObj->cod_pdv,
        'dados'     => $_mensagemObj->dados,
        'fn' 		=> $_mensagemObj->fn
    );
}

//-----------------------------------------------------------------
// Ainda n�o usamos a sess�o para nada, ent�o s� estamos verificando se come�a com *
if(!AMBIENTE_SAAS) {
    $_temp = substr($_sessao,0,1);
    if($_temp!=="*"){
        $_retorno['resultado'] = '1';
        $_retorno['mensagem']  = 'Sessao Invalida';
        $_erro = true;
    }
}
//-----------------------------------------------------------------
$_html_entities = true;
if($_erro) {
    $_retorno['mensagem'].=" | JSON :: {$_mensagem}";
} else {
    try {
        switch ($_mensagemObj->tipo) {
            /**
             * INTVORTICE-13
             * BIT Software
             * 16.03.2020
             * Consulta do Cliente
             */
            case 'consultaCliente':
            case 'consultaClientePromoExterna':
            case 'ConsultaClientePromoExterna':
                $_integracaoPDV = new promocao_externa_pdv();
                $_html_entities = false;
                $_integracaoPDV->consultarCliente($_mensagemObj,$_retorno);
                break;
            case 'enviarCarrinhoPromocao':
                $_integracaoPDV = new promocao_externa_pdv();
                $_html_entities = false;
                $_integracaoPDV->enviarCarrinho($_mensagemObj, $_retorno);
                break;
            case 'confirmarCarrinhoPromocao':
                $_integracaoPDV = new promocao_externa_pdv();
                $_html_entities = false;
                $_integracaoPDV->confirmarCarrinho($_mensagemObj, $_retorno);
                break;
            case 'cancelarCarrinhoPromocao':
                $_integracaoPDV = new promocao_externa_pdv();
                $_html_entities = false;
                $_integracaoPDV->cancelarCarrinho($_mensagemObj, $_retorno);
                break;
            case 'consulta_status_funcionario':
                if (!empty($_mensagemObj->dados->cod_funcionario)) {
                    try {
                        $_usr = funcoesGerais::InstanciaClasse('usuario', $_MASTER);
                        $_checarFlgBloqueado = $_usr->checarFlgBloqueado($_mensagemObj->dados->cod_funcionario);

                        if (!empty($_checarFlgBloqueado)) {
                            $_liberacao_bloqueio = date('d-m-Y H:i:s');
                            if (!empty($_checarFlgBloqueado['TEMPO_BLOQUEIO_SENHA']) && !empty($_checarFlgBloqueado['DATA_BLOQUEIO_SENHA'])) {
                                $_liberacao_bloqueio = date('d-m-Y H:i:s', strtotime('+' . $_checarFlgBloqueado['TEMPO_BLOQUEIO_SENHA'] . ' minute', strtotime($_checarFlgBloqueado['DATA_BLOQUEIO_SENHA'])));
                            }

                            if ($_checarFlgBloqueado['FLG_BLOQUEADO'] != 'S' || strtotime(date('d-m-Y H:i:s')) >= strtotime($_liberacao_bloqueio)) {
                                $_res = true;
                                if ($_checarFlgBloqueado['FLG_BLOQUEADO'] == 'S') { // Passou porque deu o TEMPO
                                    $_res = $_usr->zerarCamposBloqueio($_mensagemObj->dados->cod_funcionario);
                                }

                                if ($_res) {
                                    $_liberacao_bloqueio_timestamp = funcoesGerais::dataToTimeStamp($_checarFlgBloqueado['DATA_BLOQUEIO_SENHA']);
                                    $_retorno['resultado'] = 0;
                                    $_retorno['mensagem'] = 'Usu�rio liberado';
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    $_retorno['dados']['bloqueado'] = '0';
                                    $_retorno['dados']['tempo_de_bloqueio_final'] = "{$_liberacao_bloqueio_timestamp}";
                                } else {
                                    $_retorno['resultado'] = 4;
                                    $_retorno['mensagem'] = "Erro ao atualizar(Zerar) dados do funcion�rio!";
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                }
                            } else {
                                $_disponibilidade_bloqueio = date('H:i:s', strtotime('+' . $_checarFlgBloqueado['TEMPO_BLOQUEIO_SENHA'] . ' minute', strtotime($_checarFlgBloqueado['DATA_BLOQUEIO_SENHA'])));
                                $_liberacao_bloqueio_timestamp = funcoesGerais::dataToTimeStamp($_liberacao_bloqueio);
                                $_retorno['resultado'] = 0;
                                $_retorno['mensagem'] = "Funcion�rio Bloqueado! Acesso liberado ap�s �s " . $_disponibilidade_bloqueio;
                                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                $_retorno['dados'] = Array();
                                $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                $_retorno['dados']['bloqueado'] = '1';
                                $_retorno['dados']['tempo_de_bloqueio_final'] = "{$_liberacao_bloqueio_timestamp}";
                            }
                        } else {
                            $_retorno['resultado'] = 2;
                            $_retorno['mensagem'] = "Funcion�rio n�o encontrado ou erro ao carregar dados do funcion�rio!";
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_retorno['dados'] = Array();
                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                        }

                    } catch (Exception $e) {
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                        $_retorno['dados'] = Array();
                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                        throw $e; // Repassando para tratar banco offline
                    }
                } else {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = "Cod. Funcion�rio n�o foi enviado pelo PDV ao Manager!";
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['dados'] = Array();
                    $_retorno['dados']['cod_funcionario'] = '';
                }
                $_retorno['mensagem'] = funcoesGerais::removerCaracteresEAcentos($_retorno['mensagem']);
                break;
            case 'valida_regras_senha':
                if (!empty($_mensagemObj->dados->cod_funcionario)) {
                    if (!empty($_mensagemObj->dados->senha)) {
                        try {
                            $_empresa = new Empresa($_MASTER);
                            $_info_loja = $_empresa->retornarInformacoesEmpresa($_mensagemObj->cod_loja, Array("PARAMETROS_KERNC"), false);
                            funcoesgerais::parametrizarKernz(Array($_info_loja), true);
                            $_decifrado = kernz_str_exec(51, 3, 0, 0, $_mensagemObj->dados->senha, Array());

                            if (!empty($_decifrado)) {
                                $_usr = funcoesGerais::InstanciaClasse('usuario', $_MASTER);
                                $_getLojaPerfil = $_usr->getLojaPerfil($_mensagemObj->dados->cod_funcionario);
                                if (!empty($_getLojaPerfil)) {
                                    $_getSenhaComplexa = $_usr->getSenhaComplexa($_getLojaPerfil);
                                    if (!empty($_getSenhaComplexa)) {
                                        $_msg = $_usr->checarSenhaComplexidade($_getSenhaComplexa, $_decifrado, null, 'valida_regras_senha');

                                        if (empty($_msg)) {
                                            $_retorno['resultado'] = 0;
                                            $_retorno['mensagem'] = 'Senha de acordo com a regra estabelecida';
                                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                            $_retorno['dados'] = Array();
                                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                        } else {
                                            $_retorno['resultado'] = 5;
                                            $_retorno['mensagem'] = $_msg;
                                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                            $_retorno['dados'] = Array();
                                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                        }
                                    } else {
                                        $_retorno['resultado'] = 4;
                                        $_retorno['mensagem'] = 'Erro na obten��o da regra de complexidade da senha!';
                                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                        $_retorno['dados'] = Array();
                                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    }
                                } else {
                                    $_retorno['resultado'] = 3;
                                    $_retorno['mensagem'] = 'Funcion�rio n�o encontrado ou erro na obten��o de loja(s) e/ou perfil(s) do funcion�rio!';
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                }
                            } else {
                                $_retorno['resultado'] = 2;
                                $_retorno['mensagem'] = 'Erro na descriptografia da senha pelo m�todo kernz_str_exec()!';
                                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                $_retorno['dados'] = Array();
                                $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                            }
                        } catch
                        (Exception $e) {
                            $_retorno['resultado'] = 1;
                            $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_retorno['dados'] = Array();
                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                            throw $e; // Repassando para tratar banco offline
                        }
                    } else {
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem'] = "Senha n�o foi enviada pelo PDV!";
                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                        $_retorno['dados'] = Array();
                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                    }
                } else {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = "Cod. Funcion�rio n�o foi enviado pelo PDV ao Manager!";
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['dados'] = Array();
                    $_retorno['dados']['cod_funcionario'] = '';
                }
                $_retorno['mensagem'] = funcoesGerais::removerCaracteresEAcentos($_retorno['mensagem']);
                break;
            case 'efetiva_nova_senha':
                if(!empty($_mensagemObj->dados->cod_funcionario)) {
                    if (!empty($_mensagemObj->dados->senha)) {
                        try {
                            $_empresa = new Empresa($_MASTER);
                            $_info_loja = $_empresa->retornarInformacoesEmpresa($_mensagemObj->cod_loja, Array("PARAMETROS_KERNC"), false);
                            funcoesgerais::parametrizarKernz(Array($_info_loja), true);
                            $_decifrado = kernz_str_exec(51, 3, 0, 0, $_mensagemObj->dados->senha, Array());

                            if (!empty($_decifrado)) {
                                $_usr = funcoesGerais::InstanciaClasse('usuario', $_MASTER);
                                $_res = $_usr->atualizarSenhaComplexa($_mensagemObj->dados->cod_funcionario, $_decifrado);

                                if ($_res) {
                                    $_res = $_usr->zerarCamposBloqueio($_mensagemObj->dados->cod_funcionario);

                                    if ($_res) {
//                                        $_retornaUsuario = $_usr->retornaUsuario($_POST["USUARIO"]);
                                        $_log = new LOGFILE($_MASTER);
                                        $_log->gravarLogFile("PDV", "TRO", 'comunicacao_pdv.php5', 'Trocar Senha', $_mensagemObj->dados->cod_funcionario);

                                        $_retorno['resultado'] = 0;
                                        $_retorno['mensagem'] = 'Senha atualizada com sucesso';
                                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                        $_retorno['dados'] = Array();
                                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    } else {
                                        $_retorno['resultado'] = 4;
                                        $_retorno['mensagem'] = "Erro ao atualizar(Zerar) dados do funcion�rio!";
                                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                        $_retorno['dados'] = Array();
                                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    }
                                } else {
                                    $_retorno['resultado'] = 3;
                                    $_retorno['mensagem'] = "Funcion�rio n�o encontrado ou erro na atualiza��o de dados do funcion�rio!";
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                }
                            } else {
                                $_retorno['resultado'] = 2;
                                $_retorno['mensagem'] = 'Erro na descriptografa��o da senha pelo m�todo kernz_str_exec()!';
                                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                $_retorno['dados'] = Array();
                                $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                            }
                        } catch
                        (Exception $e) {
                            $_retorno['resultado'] = 1;
                            $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_retorno['dados'] = Array();
                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                            throw $e; // Repassando para tratar banco offline
                        }
                    } else {
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem'] = "Senha n�o foi enviada pelo PDV!";
                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                        $_retorno['dados'] = Array();
                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                    }
                } else {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = "Cod. Funcion�rio n�o foi enviado pelo PDV ao Manager!";
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['dados'] = Array();
                    $_retorno['dados']['cod_funcionario'] = '';
                }
                $_retorno['mensagem'] = funcoesGerais::removerCaracteresEAcentos($_retorno['mensagem']);
                break;
            case 'bloqueio_funcionario':
                if(!empty($_mensagemObj->dados->cod_funcionario)) {
                    if($_mensagemObj->dados->bloqueado != 0 || $_mensagemObj->dados->bloqueado != 1) {
                        try {
                            $_usr = funcoesGerais::InstanciaClasse('usuario', $_MASTER);
                            if ($_mensagemObj->dados->bloqueado == 1) {
                                if (!empty($_mensagemObj->dados->tempo_de_bloqueio_final)) {
                                    $_getSenhaComplexa = $_usr->checarFlgBloqueado($_mensagemObj->dados->cod_funcionario);
                                    $_tempo_de_bloqueio_final = converte_data($_mensagemObj->dados->tempo_de_bloqueio_final, 'timestamp', "padrao");
                                    $_res = $_usr->bloquearUsuario($_mensagemObj->dados->cod_funcionario, $_tempo_de_bloqueio_final, $_getSenhaComplexa["LIMITE_TENTATIVAS_SENHA"], $_getSenhaComplexa["TEMPO_BLOQUEIO_SENHA"]);

                                    if ($_res) {
//                                                $_retornaUsuario = $_usr->retornaUsuario($_POST["USUARIO"]);
                                        $_log = new LOGFILE($_MASTER);
                                        $_log->gravarLogFile("PDV", "BLO", 'comunicacao_pdv.php5', 'Bloquear Funcion�rio', $_mensagemObj->dados->cod_funcionario);

                                        $_retorno['resultado'] = 0;
                                        $_retorno['mensagem'] = 'Usu�rio bloqueado com sucesso';
                                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                        $_retorno['dados'] = Array();
                                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    } else {
                                        $_retorno['resultado'] = 5;
                                        $_retorno['mensagem'] = "Funcion�rio n�o encontrado ou j� bloqueado ou erro na atualiza��o de dados do funcion�rio!";
                                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                        $_retorno['dados'] = Array();
                                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                    }
                                }
                            } elseif ($_mensagemObj->dados->bloqueado == 0) {
                                $_res = true;
                                $_res = $_usr->zerarCamposBloqueio($_mensagemObj->dados->cod_funcionario);

                                if ($_res) {
//                                        $_retornaUsuario = $_usr->retornaUsuario($_POST["USUARIO"]);
                                    $_log = new LOGFILE($_MASTER);
                                    $_log->gravarLogFile("PDV", "DBL", 'comunicacao_pdv.php5', 'Desbloquear Funcion�rio', $_mensagemObj->dados->cod_funcionario);

                                    $_retorno['resultado'] = 0;
                                    $_retorno['mensagem'] = 'Usu�rio desbloqueado com sucesso';
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                } else {
                                    $_retorno['resultado'] = 6;
                                    $_retorno['mensagem'] = "Erro ao atualizar(Zerar) dados do funcion�rio!";
                                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                                    $_retorno['dados'] = Array();
                                    $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                                }
                            }
                        } catch (Exception $e) {
                            $_retorno['resultado'] = '1';
                            $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_retorno['dados'] = Array();
                            $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                            throw $e; // Repassando para tratar banco offline
                        }
                    } else {
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem'] = "Status do bloqueio n�o foi enviado corretamente pelo PDV ao Manager!";
                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                        $_retorno['dados'] = Array();
                        $_retorno['dados']['cod_funcionario'] = $_mensagemObj->dados->cod_funcionario;
                    }
                } else {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = "Cod. Funcion�rio n�o foi enviado pelo PDV ao Manager!";
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['dados'] = Array();
                    $_retorno['dados']['cod_funcionario'] = '';
                }
                $_retorno['mensagem'] = funcoesGerais::removerCaracteresEAcentos($_retorno['mensagem']);
                break;
            case 'AtualizarContadores':
                try{
                    $_result = contadores_pdv::atualizarContadores($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                    if($_result === true){
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = 'Contadores atualizados com sucesso';
                    }else{
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = $_result;
                    }
                }catch (Exception $e){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'VersaoAplicativo':
                $_versao = new versao_pdv($GLOBALS['_MASTER']);
                $_retorno = $_versao->retornarInformacoesVersao($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                break;
            case 'VersaoAtuTemaInterf':
            case 'VersaoAtuTemaInterfJava':
                $_versao = new versao_pdv($GLOBALS['_MASTER']);
                $_mensagemObj->dados->tipoPacote='TEMAINTERF';
                if($_mensagemObj->tipo=="VersaoAtuTemaInterfJava"){
                    $_mensagemObj->dados->tipoPacote='TEMAINTERF_JAVA';
                }
                $_retorno = $_versao->retornarInformacoesVersao($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                break;
            case 'AtualizarAgendamentos':
                try{
                    $_ag = new agendamento_pdv($GLOBALS['_MASTER']);
                    $_result = $_ag->atualizaAgendamentosPDV($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);

                    if($_result === true){
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = 'Agendamento atualizado com sucesso';
                    }else{
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = $_result;
                    }
                }catch (Exception $e){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //Fun��o 12800 e 12801
            case 'ConsultaMercadoria':
                try{
                    $_mercadoria = new mercadoria($GLOBALS['_MASTER']);
                    $data = utf8_decode($_mensagemObj->dados);
                    $_dados = $_mercadoria->listarProdutosPDV($data, $_mensagemObj->loja, $_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem'] = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'ConsultaMercadoriaCaedu':
                try{
                    $_caedu = new caedu($GLOBALS['_MASTER']);
                    $_retorno = $_caedu->listarProdutosPDV($_mensagemObj->dados, $_mensagemObj->loja, $_mensagemObj->fn);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'retornarDadosVendasComJuros':
                try{
                    $_caedu = new caedu($GLOBALS['_MASTER']);
                    $_retorno = $_caedu->retornarDadosVendasComJuros($_mensagemObj->loja);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'retornarParametrosFaturaDigital':
                try{
                    $_caedu = new caedu($GLOBALS['_MASTER']);
                    $_retorno = $_caedu->retornarParametrosFaturaDigital($_mensagemObj->loja);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'retornarDadosChamaFilaCaedu':
                try{
                    $_caedu = new caedu($GLOBALS['_MASTER']);
                    $_retorno = $_caedu->retornarDadosChamaFila($_mensagemObj->cod_pdv, $_mensagemObj->loja);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * PC-60
             * Vale Troca Caedu
             */
            case 'retornarMotivosTrocaCaedu':
                try{
                    $_caedu = new caedu($GLOBALS['_MASTER']);
                    $_retorno = $_caedu->retornarMotivosTroca($_mensagemObj->loja);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_html_entities = false;
                break;
            //Fun��o 12802
            case 'ConsultaPedido':
                try{
                    $_pedido = funcoesGerais::InstanciaClasse('zan_pedido', $GLOBALS['_MASTER']);
                    $_dados = $_pedido->listarPedidosPDV($_mensagemObj->dados, $_mensagemObj->loja, $_mensagemObj->fn);
                    if (empty($_dados)) {
                        throw new Exception("Nenhum pedido foi encontrado com o termo pesquisado");
                    }
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem'] = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //Fun��o 12811
            case 'consultarPedidoPorOperador':
                try{
                    $_pedido = new zan_pedido($GLOBALS['_MASTER']);
                    $_dados = $_pedido->consultarPedidoPorOperador($_mensagemObj->operador, $_mensagemObj->loja, $_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem'] = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'ConsultarPedidoExterno':
            case 'ConsultaPedidoExterno':
                try {
                    $_tp = 7; // Magento -- Fixo???? ----
                    $_dados_pedido = new StdClass;
                    $_dados_pedido->tipo_pedido = $_tp;
                    $_pe = new controle_pedido_externo($GLOBALS['_MASTER'],$_dados_pedido);
                    $_dados = $_pe->listarPedidoExterno($_mensagemObj);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem'] = $_dados;
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                }
                break;
            //Fun��o 12803
            case 'ConsultaCliente':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente',$GLOBALS['_MASTER']);
                    $_dados = $_cliente->retornarClientePDV($_mensagemObj->dados, $_mensagemObj->loja, $_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem']  = $_dados;
                }catch(Exception $e) {
                    if($e->getCode()==500){
                        $_conf = new conf_interface_pdv($GLOBALS['_MASTER']);
                        $_dado_return = $_conf->getMensagemCadastroCliente($_mensagemObj->loja,$_mensagemObj->msgTermoFidelidade);
                        if(!empty($_dado_return)){
                            $_retorno = array_merge($_retorno,$_dado_return);
                        }
                    }
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    //erro tratado
                    if($e->getCode()==350){
                        $_retorno['fn'] = '10';
                        $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    }
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //Fun��o 12897
            case 'PegarTeclas':
                try{
                    $_teclas = new teclas_touch($GLOBALS['_MASTER']);
                    $_dados = $_teclas->pegarTeclas($_mensagemObj->dados, $_mensagemObj->loja, $_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem']  = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'ListaVoucher':
                try{
                    $_bonus = new controle_credito($GLOBALS['_MASTER']);
                    $_mensagemObj->dados->pdv = $_mensagemObj->cod_pdv;
                    $_dados = $_bonus->retornarBonusClientePDV($_mensagemObj->cod_loja, $_mensagemObj->dados);
                    if($_dados !== false) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = '';
                        $_retorno['dados'] = $_dados;
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['dados'] = '';
                        $_retorno['mensagem'] = 'Erro! O PDV n�o informou algum par�metro que o m�todo esperava. Verifique o log do Manager.';
                    }
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            // atualiza a Senha de Cliente atrav�s do PDV
            case 'CadastraSenha':
                try{
                    $_cli = new cliente($GLOBALS['_MASTER']);
                    $_retorno = $_cli->cadastrarSenhaCliente($_mensagemObj->cod_loja, $_mensagemObj->dados, $_mensagemObj->cod_pdv);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'ValidaDadosMercadoria': // Valida��o de consulta gen�rica, inicialmente apenas lote
                try {
                    $_mercadoria 		   = new mercadoria($GLOBALS['_MASTER']);
                    $_dados 			   = $_mercadoria->validarColetaDados($_mensagemObj->cod_loja,  $_mensagemObj->dados);
                    $_retorno['resultado'] = '0' ;
                    $_retorno['mensagem']  = '';
                    $_retorno['dados']     = $_dados;
                } catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    $_retorno['dados']     = $_dados;
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'TrataConvenio':
                try {
                    /**
                     * AJUSTEBS-3
                     * BIT Software
                     *
                     */
                    $_clienteConvenioSaldo =  funcoesGerais::InstanciaClasse('cliente_convenio',$GLOBALS['_MASTER']);//new cliente_convenio($GLOBALS['_MASTER']);
                    $_dados = $_clienteConvenioSaldo->retornarDadosClienteConvenioParaPDV( $_mensagemObj->cod_loja , $_mensagemObj->cod_pdv , $_mensagemObj->dados);

                    if($_dados !== false) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem']  = '';
                        $_retorno['dados']     = $_dados;
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['dados']     = '';
                        $_retorno['mensagem']  = 'Erro! O PDV n�o informou algum par�metro que o m�todo esperava. Verifique o log do Manager.';
                    }
                } catch(Exception $e) {
                    $_retorno['resultado']   = '1';
                    $_retorno['mensagem']    = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'BuscaCupom':
                try {
                    /**
                     * @var devolucao $_dev
                     */
                    $_dev = funcoesGerais::InstanciaClasse('devolucao',$GLOBALS['_MASTER']);
                    $_dados = $_dev->buscarCuponsTrocaPdv($_mensagemObj->cod_loja,  $_mensagemObj->dados, ($_mensagemObj->dados->cpfcnpj ? true : false));
                    if($_dados !== false) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = '';
                        $_retorno['dados'] = $_dados;
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['dados'] = '';
                        $_retorno['mensagem'] = 'Erro! O PDV n�o informou algum par�metro que o m�todo esperava. Verifique o log do Manager.';
                    }
                } catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    $_retorno['dados']     = $_dados;
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['mensagem'] = utf8_encode($_retorno['mensagem']);
                $_html_entities = false;
                break;
            case 'GeraDevolucao':
                try{
                    set_time_limit(27); //Por hora estamos colocando 27 para evitar problemas de duplicidade de trocas quando o pdv converter para offline (timeout padr�o do PDV est� 30 segundos, por isso deixamos 27 aqui)
                    if($_mensagemObj->dados->tipo_devol == 1) {
                        $_classe = 'troca';
                    }else{
                        $_classe = 'devolucao';
                    }
                    $_dev = funcoesGerais::InstanciaClasse($_classe,$GLOBALS['_MASTER']);
                    // Vai mandar a chave de transa��o chave_transacao (Atualizar na troca) - TROCASEMCV-1 15.10.2020
                    //
                    $_dados = $_dev->gerarDevolucaoPdv($_mensagemObj->cod_loja,  $_mensagemObj->dados);
                    if($_dados !== false) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = '';
                        $_retorno['dados'] = $_dados;
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['dados'] = '';
                        $_retorno['mensagem'] = 'Erro! O PDV n�o informou algum par�metro que o m�todo esperava. Verifique o log do Manager.';
                    }
                }catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    $_retorno['dados']     = $_dados;
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['mensagem'] = utf8_encode($_retorno['mensagem']);
                $_html_entities = false;
                break;
            case 'ultimaCompraFidelidade':
                $_fidelidade_historico = new fidelidade_historico($GLOBALS['_MASTER']);
                $_retorno 			   = $_fidelidade_historico->retornaUltimaCompra($_mensagemObj);
                break;
            case 'FidelizaConsultaCliente':
            case 'FidelizaConsultaVoucher':
                $_np 		= new netpoints($GLOBALS['_MASTER']);
                $_retorno 	= $_np->consultarWSNetpoints($_mensagemObj);
                break;
            case 'autenticarFuncionarioComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->autenticarFuncionarioComanda($_mensagemObj);
                break;
            case 'validarSupervisorComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->validarSupervisorComanda($_mensagemObj);
                break;
            case 'buscarComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->buscarComanda($_mensagemObj);
                break;
            case 'gravarComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->gravarComanda($_mensagemObj);
                break;
            case 'atualizaItemComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->atualizaItemComanda($_mensagemObj);
                break;
            case 'retornarSituacaoComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->retornarSituacaoComanda($_mensagemObj);
                break;
            case 'liberarComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->liberarComanda($_mensagemObj);
                break;
            case 'atualizarStatusComanda':
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_retorno 	= $_comanda->atualizarStatusComanda($_mensagemObj);
                break;
            case 'imprimirComanda':
                include_once("includes/defines.inc");
                registrarAutoload();
                register_shutdown_function('chamarAoDestruir');
                register_shutdown_function('pegarErroPHP');
                include_once("includes/bancodedados.inc");
                include_once("plugin/escpos/Escpos.php");
                header('Content-Type: application/json');
                header("Access-Control-Allow-Origin: *");
                header("Access-Control-Allow-Headers: Access-Control-Allow-Origin, Accept");
                $_comanda 	= new zan_comanda($GLOBALS['_MASTER']);
                $_dados = array_change_key_case((array)$_mensagemObj->dados,CASE_UPPER);
                $_comanda->setDadosSessao($_dados);
                $_retorno = $_comanda->imprimirComanda($_dados['COD_COMANDA'],'','',$_dados['TIMEOUT']);
                break;
            case 'confirmarItensComanda':
                include_once("includes/defines.inc");
                registrarAutoload();
                register_shutdown_function('chamarAoDestruir');
                register_shutdown_function('pegarErroPHP');
                include_once("includes/bancodedados.inc");
                include_once("plugin/escpos/Escpos.php");
                header('Content-Type: application/json');
                header("Access-Control-Allow-Origin: *");
                header("Access-Control-Allow-Headers: Access-Control-Allow-Origin, Accept");
                $_zan_comanda_item = new zan_comanda_item($GLOBALS['_MASTER']);
                $_dados = array_change_key_case((array)$_mensagemObj->dados,CASE_UPPER);
                $_zan_comanda_item->setDadosSessao($_dados);
                $_retorno = $_zan_comanda_item->confirmarItensComanda($_dados['COD_COMANDA'],$_dados['TIMEOUT']);
                break;
            case 'buscaDadosMercadoriaComanda':
                $_mercadoria = new mercadoria($GLOBALS['_MASTER']);
                $_retorno = $_mercadoria->consultaMercadoriaComanda($_mensagemObj->dados->loja, $_mensagemObj->dados->codMercadoria,$_mensagemObj->dados->registroPesavel);
                break;
            case 'ConsultaDetalhesCliente':
                $_cliente 	= new cliente($GLOBALS['_MASTER']);
                $_retorno	= $_cliente->ConsultaDetalhesClientePDV($_mensagemObj->dados, $_mensagemObj->loja);
                break;
            case 'ItemPremiadoListaCodPremiacao':
                $_promo		= new codigo_promocional($GLOBALS['_MASTER']);
                $_retorno	= $_promo->RetornarCuponsPDV($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados);
                break;
            case 'ConsultaPremiacao':
                $_premio = new premiacao($GLOBALS['_MASTER']);
                $_tipo_venda = $_mensagemObj->dados->tipo_venda;
                $_tipo_venda++; // Para o PDV o tipo de venda come�a do 0, precisamos incrementar para bater com o manager.
                $_retorno = $_premio->consultaPremiacao($_mensagemObj->dados->valor, $_tipo_venda, $_mensagemObj->cod_pdv, $_mensagemObj->dados->pdv_pesq, $_mensagemObj->dados->num_cupom,  $_mensagemObj->cod_loja, $_mensagemObj->dados->loja_pesq, $_mensagemObj->dados->cliente_venda, $_mensagemObj->fn);
                break;
            case 'cadastrarBiometria':

                $_biometria = new biometria($GLOBALS['_MASTER']);
                $_retorno = $_biometria->cadastrarDigital($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv,$_mensagemObj->dados->autorizador,  $_mensagemObj->dados->id, $_mensagemObj->dados->bio_tipo, $_mensagemObj->dados->sdk, $_mensagemObj->dados->dedos);
                break;
            // LOGINUNICO-18 BIT SOFTWARE 07.12.2015 - Recebimento da chamada do PDV
            case 'LoginUnico':
                // Decriptografar a senha enviada.
                if($_mensagemObj->dados->tipo_cripto!='1') {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = "Criptografia invalida";
                } elseif(!function_exists('kernz_str_exec')) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = "Kernz_str_exec n�o encontrada";
                } else {
                    // Antes precisamos assinar a chamada ao kernz
                    $_empresa	= new Empresa($GLOBALS['_MASTER']);
                    $_info_loja	= $_empresa->retornarInformacoesEmpresa($_mensagemObj->cod_loja,Array("PARAMETROS_KERNC"),false);
                    //Inicializa a tabela interna de "assinatura de bin�rios" que a biblioteca kernz mant�m.
                    $_res = kernz_exec(5,1,0,0,$_info_loja["PARAMETROS_KERNC"],Array());
                    if($_res!=0){
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem']  = "N�o foi poss�vel buscar os par�metros do KERNC. ({$_res})";
                        return false;
                    }
                    // Chamamos o Kernel para realizar a decriptografia (sic) da senha
                    // int kernz_exec( int grupo, int funcao, int param1, int param2 ,string param3 ,array param4 );
                    if(($_senha=kernz_str_exec(61,2,1,0,$_mensagemObj->dados->senha,array()))=='') {
                        $_retorno['resultado'] = 1;
                        $_retorno['mensagem']  = "Erro na chamada a Kernz_str_exec, n�o foi possivel decriptar a senha";
                    } else {
                        $_usuario   = new Usuario($GLOBALS['_MASTER']);
                        // Temos agora o login
                        $_retorno['dados'] = Array();
                        if($_usuario->Login($_mensagemObj->dados->cod_func,$_senha,$_mensagemObj->cod_loja,true)===false) {
                            $_retorno['resultado'] = 0;
                            $_erro_ldap = $_usuario->getMsg_login_unico();
                            if(is_array($_erro_ldap)) {
                                $_retorno['dados']['status'] = $_erro_ldap['erro']; // erro na autentica��o = 49
                                $_retorno['dados']['descricao'] = $_erro_ldap['mensagem_especifica']['descricao'];
                            } else {
                                $_retorno['dados']['status'] = 100;
                                $_retorno['dados']['descricao']  = "Erro ao validar o usu�rio {$_usuario->getMsg_login_unico()}";
                            }
                        } else {
                            $_retorno['resultado'] = 0;
                            $_retorno['mensagem']  = 'OK';
                            $_retorno['dados']['status'] = 0;
                            $_retorno['dados']['descricao'] = 'Login OK';
                        }
                    }
                }
                break;
            //Cadastrar cliente fun��o 12903
            case 'CadastrarCliente':
                try{
                    $GLOBALS["_CADASTRO_PDV_WS"] = true;
                    if(!empty($_mensagemObj->cod_loja)) {
                        $GLOBALS['_eusuario'] = $_mensagemObj->cod_loja;
                    }
                    $_dev = funcoesGerais::InstanciaClasse('cliente',$GLOBALS['_MASTER']);
                    $_retorno	= $_dev->cadastrarClientePdvTouch($_mensagemObj->dados,$_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem']  =$_retorno['mensagem'];
                    unset($GLOBALS["_CADASTRO_PDV_WS"]);
                }catch (Exception $e) {
                    $_retorno = Array();
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //BuscarCep fun��o 12904
            case 'BuscarCep':
                try{
                    $_cep= new busca_cep($GLOBALS['_MASTER'],0);
                    $_dados = $_cep->BuscarCepEnderecoVendassiPdvTouch($_mensagemObj->dados->_cep,$_mensagemObj->fn);
                    $_retorno['resultado'] = '3';
                    $_retorno['dado']  = $_dados;
                    $_retorno['mensagem']  ='';
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //Carrega UF fun��o 12905
            case 'CarregaUf':
                try{
                    $_dados = funcoesGerais::$_uf;
                    foreach ($_dados as $key => $value) {
                        $_teste.=",['".$value."','".$value."']";
                    }
                    $_retorno['resultado'] = '3';
                    $_retorno['dado']  ="[".substr($_teste,1)."]";
                    $_retorno['mensagem']  ='';
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            //Carrega Cidade fun��o 12906
            case 'CarregaCidade':
                try{
                    $_cidades=new municipio($GLOBALS['_MASTER']);
                    $_dados=$_cidades->listarCidadesPorEstadoPdvTouch($_mensagemObj->dados->_cidade);
                    $cont=0;
                    foreach($_dados as $key => $value) {
                        $_teste.=",['".$value['text']."','".$value['value']."']";
                        $cont++;
                    }
                    $_retorno['resultado'] = '3';
                    $_retorno['dado']  ="[".substr($_teste,1)."]";
                    $_retorno['mensagem']  ='';
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'CarregaPais':
                try{
                    $GLOBALS["_fnome"] = 'FRM_cliente';
                    $_pais = new pais($GLOBALS['_MASTER']);
                    $_dados = $_pais->retornarPaises();
                    $cont=0;
                    foreach($_dados as $key => $value) {
                        if($key==1058){
                            continue;
                        }
                        $value = trim(explode("-",$value)[1]);
                        $_paises.=",['".$value."','".$key."']";
                        $cont++;
                    }
                    $_retorno['resultado'] = '3';
                    $_retorno['dado']  ="[".substr($_paises,1)."]";
                    $_retorno['mensagem']  ='';
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'GetIP':
				if($_SERVER["HTTP_X_FORWARDED_FOR"] != '') {
                    $_ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
				} else {
					$_ip = $_SERVER["REMOTE_ADDR"];
				}
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = '';
				$_vp = new parametro_valor($GLOBALS['_MASTER']);
                $_a00mpc = $_vp->buscarParametroPorCodigoZanthus(0, 'A00MPC', $_mensagemObj->cod_loja);
                $_pegar_ip_requisicao_manager = (($_a00mpc & 1) > 0);
                if($_pegar_ip_requisicao_manager) {
                    $_retorno['dados']["ip"] = $_ip;
                } else {
                    // O pdv espera uma tag chamada ip, se mudarmos o nome da tag for�a ele a buscar da pr�pria placa.
                    $_retorno['dados']["pegar_ip_placa"] = $_ip;
                }
                break;
            // CONFIGREMOTA-39 - Upload de arquivo do PDV - BIT SOFTWARE 14.01.2016
            case 'uploadArquivo':
                $_emp = new empresa($GLOBALS['_MASTER']);
                $_cnpj = $_emp->retornarCNPJdaLoja($_mensagemObj->cod_loja);
                $_tipo = $_mensagemObj->tipo_arquivo;
                if(AMBIENTE_SAAS) {
                    $_path = funcoesGerais::retornarDiretorioComumSAAS();
                } else {
                    $_path = funcoesGerais::retornarValorParametro('path_comum_centralizado');
                }
                if(substr($_path,-1,1)!='/') {
                    $_path .= '/';
                }
                $_path .= strtr($_cnpj,Array('.'=>'','/'=>'','-'=>'')) . '/';
                //$_dir = "{$_path}{$_tipo}";
                $_ret = path_comum_centralizado::upload($_path,$_tipo,$_mensagemObj->cod_loja,false);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem']  = 'OK';
                $_retorno['dados']['status'] = ($_ret===false ? 9999 : 0);
                $_retorno['dados']['descricao'] = $_ret;
                break;
            case 'paf0203Lista':
                $_controle	= new controle_arquivos($GLOBALS['_MASTER']);
                $_retorno 	= $_controle->obterListaBlocoX($_mensagemObj,false);
                break;
            case 'pafEnviar':
                $_controle	= new controle_arquivos($GLOBALS['_MASTER']);
                $_retorno 	= $_controle->enviarArquivoSefaz($_mensagemObj);
                break;
            /**
             * BIT SOFTWARE
             * Projeto PRCODBARRA - PETZ
             * 24.05.2016
             * Fun��es para tratamento da comunica��o com o PDV
             * GCPXCB-14
             * BIT Software
             * 02.08.2017
             * Valida��o do limite de utiliza��o quando reutilizavel
             */
            case 'ConsultaVoucherPromo':
            case 'EmpenhaVoucherPromo':
            case 'DesempenhaVoucherPromo':
                // Faz a valida��o b�sica
                $_loja = $_mensagemObj->cod_loja;
                $_voucher = $_mensagemObj->dados->voucher;
                $_num_cgc = $_mensagemObj->dados->numcgc;
                $_cod_cli = $_mensagemObj->dados->codcli;
                $_vouc = new voucher_promocional($GLOBALS['_MASTER']);
                $_v_prod = new voucher_promocional_produto($GLOBALS['_MASTER']);
                //$_v_prod_rest = new voucher_promocional_produto_restrito($GLOBALS['_MASTER']);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem']  = '';
                $_retorno['dados'] = Array();

                if(!empty((string)$_cod_cli)) {
                    $_cliente = new cliente($GLOBALS['_MASTER']);
                    $_cliente->Buscar((string)$_cod_cli);
                    $_num_cgc = $_cliente->getnum_cgc();
                    unset($_cliente);
                }

                if($_mensagemObj->dados->tipo == 'EXT') {
                    /**
                     * #PEND-1714#
                     * Consultar o Cashback NEOS quando tem tratamento do carrinho;
                     */
                    if($_mensagemObj->dados->tipo_ext == '2'){
                        $_cbext = funcoesGerais::InstanciaClasse('integracao_cashbackcrmneos', $GLOBALS['_MASTER']);

                        $_retorno['dados']['status'] = 0;
                        $_retorno['dados']['descricao'] = null;
                        $_retorno['dados']['loja'] = $_mensagemObj->cod_loja;
                        $_retorno['dados']['voucher'] = $_voucher;
                        $_retorno['dados']['voucher_efetivo'] = $_voucher;

                        switch($_mensagemObj->tipo ) {
                            case 'ConsultaVoucherPromo':
                                $_cr = $_cbext->consultarSaldoDisponivelComTransacao(
                                    $_mensagemObj->cod_loja,
                                    $_mensagemObj->cod_pdv,
                                    $_num_cgc,
                                    $_mensagemObj->dados->carrinho
                                );
                                if ($_cr->erro === 0 || $_cr->erro === '0') {
                                    $_fin = new finalizadora($GLOBALS['_MASTER']);
                                    $_fcb = $_fin->retornarFinalizadorasCashBackExterno($_mensagemObj->cod_loja, $_cbext::tipo);
                                    $_retorno['dados']['porc_desc'] = 0;
                                    $_retorno['dados']['valor_desc'] = (float)(isset($_cr->cashback_maximo_aplicavel) ? $_cr->cashback_maximo_aplicavel : $_cr->saldo);
                                    $_retorno['dados']['data_ini'] = date('d-m-Y');
                                    $_retorno['dados']['data_fim'] = date('d-m-Y');
                                    $_retorno['dados']['uso_voucher'] = 1;
                                    $_retorno['dados']['tipo_desc'] = 2;
                                    $_retorno['dados']['valor_min_cup'] = 0;
                                    $_retorno['dados']['tipo_aplicacao'] = 1;
                                    $_retorno['dados']['valor_max_desc'] = (float)(isset($_cr->cashback_maximo_aplicavel) ? $_cr->cashback_maximo_aplicavel : $_cr->saldo);
                                    $_retorno['dados']['finalizadoras'] = [["codigo" => $_fcb[0]]];
                                    $_retorno['dados']['blacklist_produtos'] = $_cr->blacklist_produtos ? $_cr->blacklist_produtos : [];
                                    $_retorno['dados']['flags'] = 1;
                                } else {
                                    $_retorno['dados']['status'] = 1;
                                    $_retorno['dados']['descricao'] = "Cashback nao disponivel";
                                }
                                break;
                            case 'EmpenhaVoucherPromo':
                                $_rc = $_cbext->empenharCredito($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_num_cgc, $_voucher, (float)$_mensagemObj->dados->valor);
                                if($_rc->erro==0) {
                                    $_retorno['dados']['voucher'] = $_rc->id_definitivo;
                                }else{
                                    $_retorno['dados']['status'] = 1;
                                    $_retorno['dados']['descricao'] = 'Erro ao empenhar o cashback';
                                }
                                break;
                            case 'DesempenhaVoucherPromo':
                                $_rc = $_cbext->cancelarEmpenho($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_num_cgc, $_mensagemObj->dados->voucher_uuid);
                                if($_rc->erro!=0) {
                                    $_retorno['dados']['status'] = 1;
                                    $_retorno['dados']['descricao'] = 'Erro ao desempenhar o cashback';
                                }
                                break;
                            default:
                                $_retorno['dados']['status'] = 1;
                                $_retorno['dados']['descricao']  = "Cashback nao disponivel";
                                break;
                        }
                    }else{
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Cashback nao disponivel";
                    }
                }elseif(($_d_voucher=$_vouc->buscarVoucher($_loja,$_voucher,$_num_cgc,$_cod_cli))!==false) {
                    // Verificar se pode ser utilizado, se est� vencido
                    $_di = funcoesGerais::converte_data($_d_voucher['VALIDADE_INICIAL'],$GLOBALS['_MASTER']->getBDType(),'mktime');
                    $_df = funcoesGerais::converte_data($_d_voucher['VALIDADE_FINAL'],$GLOBALS['_MASTER']->getBDType(),'mktime');
                    $_hj = mktime(0,0,0,date("m"),date("d"),date("Y"));
                    if($_d_voucher['FLG_ATIVO']=='N') {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher n�o est� ativo.";
                    } elseif ($_d_voucher['ALERT'] !== null){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = $_d_voucher['ALERT'];
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '1' && empty($_cod_cli) && empty($_num_cgc) && $_mensagemObj->tipo=='ConsultaVoucherPromo'){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = 'O voucher � do tipo cliente favor informar um cliente';
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '1' && $_d_voucher['LIMITE_UTILIZADO_CLIENTE'] === false){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = 'O limite de utiliza��o deste cliente foi excedido';
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '2' && $_d_voucher['LIMITE_UTILIZADO_CLIENTE'] === false){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = 'O limite de utiliza��o deste cliente foi excedido';
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '2' && empty($_cod_cli) && empty($_num_cgc) && $_mensagemObj->tipo=='ConsultaVoucherPromo'){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = 'O voucher � do tipo cliente favor informar um cliente';
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '2' && $_d_voucher['FAIXA_DIAS_VALIDA']){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = "Voucher Est� fora do periodo de Utiliza��o";
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '1' && (int)$_d_voucher['FLG_UTILIZAVEL'] == 1){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = "O voucher � do tipo utiliza��o �nica por cliente";
                    } elseif ($_d_voucher['TIPO_COMPORTAMENTO'] === '2' && (int)$_d_voucher['FLG_UTILIZAVEL'] == 1){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = "O voucher � do tipo utiliza��o �nica por cliente";
                    } elseif (isset($_d_voucher["FAIXA_DIAS_VALIDA"]) && $_d_voucher['FAIXA_DIAS_VALIDA'] === false){
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao'] = "Voucher Est� fora do periodo de Utiliza��o";
                    } elseif($_d_voucher['FLG_STATUS']==2) {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = ($_d_voucher['TIPO_UTILIZACAO']==0) ? "Voucher atingiu o limite de utiliza��o." : "Voucher j� foi utilizado.";
                    } elseif($_d_voucher['FLG_STATUS']==3) {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher cancelado.";
                    } elseif($_d_voucher['FLG_STATUS']==1&&$_mensagemObj->tipo!='DesempenhaVoucherPromo') {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher j� est� empenhado em outra compra.";
                    } elseif($_d_voucher['FLG_STATUS']==0&&$_mensagemObj->tipo=='DesempenhaVoucherPromo') {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher n�o est� empenhado.";
                    } elseif($_di>$_hj) {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher ainda n�o pode ser utilizado. Data de inicio da validade " .date("d-m-Y",$_di);
                    } elseif($_df<$_hj) {
                        $_retorno['dados']['status'] = 1;
                        $_retorno['dados']['descricao']  = "Voucher vencido. Validade " . date("d-m-Y",$_df);
                    } else {
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem']  = 'OK';
                        $_retorno['dados']['status'] = 0;
                        $_retorno['dados']['descricao'] = null;
                        $_retorno['dados']['loja'] = $_loja;
                        //O c�digo de Voucher Alternativo repete e n�o pode ser utilizado para fins de baixa.
                        $_retorno['dados']['voucher']         = ($_voucher == $_d_voucher['COD_VOUCHER_ALTERNATIVO']) ? $_d_voucher['COD_VOUCHER_ALTERNATIVO'] : $_d_voucher['COD_VOUCHER'] ;
                        $_retorno['dados']['voucher_efetivo'] = $_d_voucher['COD_VOUCHER'];
                        switch($_mensagemObj->tipo) {
                            case 'ConsultaVoucherPromo':
                                $_retorno['dados']['porc_desc'] = ((int)$_d_voucher['TIPO_APLICACAO']==0 ? $_d_voucher['VALOR_APLICACAO'] : 0);
                                $_retorno['dados']['valor_desc'] = ((int)$_d_voucher['TIPO_APLICACAO']==1 ? $_d_voucher['VALOR_APLICACAO'] : 0);
                                $_retorno['dados']['data_ini'] = funcoesGerais::converte_data($_d_voucher['VALIDADE_INICIAL'],$GLOBALS['_MASTER']->getBDType(),'padrao');
                                $_retorno['dados']['data_fim'] = funcoesGerais::converte_data($_d_voucher['VALIDADE_FINAL'],$GLOBALS['_MASTER']->getBDType(),'padrao');
                                $_retorno['dados']['uso_voucher'] = (int)$_d_voucher['TIPO_UTILIZACAO'];
                                $_retorno['dados']['tipo_desc'] = (int)$_d_voucher['TIPO_DESCONTO'];
                                $_retorno['dados']['valor_min_cup'] = (int)$_d_voucher['MINIMO_VENDA'];
                                $_retorno['dados']['tipo_aplicacao'] = (int)$_d_voucher['TIPO_APLICACAO'];
                                $_retorno['dados']['valor_max_desc'] = (float)$_d_voucher['MAX_APLICACAO'];
                                $_retorno['dados']['finalizadoras'] = (array)$_d_voucher['COD_FINALIZADORA'];

                                //$_retorno['dados']['tipo_aplicacao_restrito'] = (int)$_d_voucher['TIPO_APLICACAO_RESTRITO'];
                                //utiliza��o do voucher "na compra", a flag "desconto acumulativo",
                                //quando marcado, tratar o bit com 0. Quando desmarcado, tratar o bit com 2
                                if((int)$_d_voucher['TIPO_DESCONTO'] === 0){
                                    $_flg = funcoesGerais::converteValorCombosToMSel($_d_voucher['FLAGS']);
                                    $_val = 2;
                                    foreach($_flg as $_vl){
                                        ($_vl !== 2) ? $_val+= $_vl : $_val-= 2;

                                    }
                                    $_retorno['dados']['flags']=(int)$_val;
                                }else{
                                    $_retorno['dados']['flags']=(int)$_d_voucher['FLAGS'];
                                }
                                $_retorno['dados']['texto_voucher_promocional'] = $_d_voucher['TEXTO_VOUCHER_PROMOCIONAL'];
                                //31 � o maximo de bit
                                //Mando somente os bits de tipo venda n�o permitidos para o voucher
                                $_retorno['dados']['tipos_venda'] = 0;
                                if ($_d_voucher['TIPO_VENDA'] !== null) {
                                    $_retorno['dados']['tipos_venda'] = (31 - (int)$_d_voucher['TIPO_VENDA']);
                                }
                                // produtos
                                if($_d_voucher['TIPO_DESCONTO']==1) {
                                    // Buscar os produtos do Voucher
                                    $_prods = $_v_prod->buscarTodosProdutos($_d_voucher['COD_VOUCHER'] ? $_d_voucher['COD_VOUCHER'] : $_d_voucher['cod_voucher'] );
                                    if(empty($_prods)) {
                                        $_retorno['dados']['status'] = 1;
                                        $_retorno['dados']['descricao'] = 'Nenhum produto cadastro, por�m Tipo de desconto=1(no produto)';
                                    } else {
                                        foreach($_prods as $_idx=>$_produto) {
                                            $_retorno['dados']['itens_promo'][$_idx]['cod_merc'] = $_produto['COD_PRODUTO'];
                                            $_retorno['dados']['itens_promo'][$_idx]['porc_desc'] = ((int)$_produto['TIPO_APLICACAO']==0 ? $_produto['VALOR_APLICACAO'] : 0);
                                            $_retorno['dados']['itens_promo'][$_idx]['valor_desc'] = ((int)$_produto['TIPO_APLICACAO']==1 ? $_produto['VALOR_APLICACAO'] : 0);
                                            $_retorno['dados']['itens_promo'][$_idx]['quant_max'] = $_produto['QTD_MAXIMA'];
                                            $_retorno['dados']['itens_promo'][$_idx]['valor_max_desc'] = (float)$_produto['MAX_APLICACAO'];
                                        }
                                    }
                                } else {
                                    $_retorno['dados']['itens_promo'] = null;
                                }
                                /*
                                 * Author; Bruno silva
                                 * Since: 27/11/2019
                                 * Description: Integra��o Produtos restritos para um voucher
                                 */
                                /*if($_d_voucher['TIPO_APLICACAO_RESTRITO'] == 9){
                                    $_prods_rest = $_v_prod_rest->buscarTodosProdutosRestritos($_d_voucher['COD_VOUCHER'] ? $_d_voucher['COD_VOUCHER'] : $_d_voucher['cod_voucher'] );
                                    if(empty($_prods_rest)){
                                        $_retorno['dados']['status'] = 1;
                                        $_retorno['dados']['descricao'] = 'Nenhum produto restrito cadastro.)';
                                    }else{
                                        foreach ($_prods_rest AS $_idx=>$_produto_restrito){
                                            $_retorno['dados']['items_promo_rest'][$_idx]['cod_voucher_restrito'] = $_d_voucher['COD_VOUCHER'];
                                            $_retorno['dados']['items_promo_rest'][$_idx]['cod_produto_voucher_restrito'] = (int)($_produto_restrito['COD_PRODUTO']);
                                            $_retorno['dados']['items_promo_rest'][$_idx]['tipo_aplicacao_voucher_restrito'] = (int)($_produto_restrito['TIPO_APLICACAO']);
                                        }
                                    }
                                }*/
                                //Chamada de altera��o de Status em Voucher na M38
                                $_vouc->alterarStatusVoucher($_d_voucher['COD_VOUCHER'] ? $_d_voucher['COD_VOUCHER'] : $_d_voucher['cod_voucher']);

                                break;
                            case 'EmpenhaVoucherPromo':
                                if($_vouc->empenharVoucher($_loja,$_voucher)==false) {
                                    $_retorno['dados']['status'] = 1;
                                    $_retorno['dados']['descricao'] = "Erro ao empenhar o voucher.";
                                }
                                break;
                            case 'DesempenhaVoucherPromo':
                                if($_vouc->desempenharVoucher($_loja,$_voucher)==false) {
                                    $_retorno['dados']['status'] = 1;
                                    $_retorno['dados']['descricao'] = "Erro ao desempenhar o voucher.";
                                }
                                break;
                        }
                    }
                } else {
                    $_retorno['dados']['status'] = 1;
                    $_retorno['dados']['descricao']  = "Erro na busca do voucher. Voucher n�o existe ou n�o pode ser utilizado nesta loja.";
                }
                break;
            case 'pingCurlManager':
                $_dados = json_decode($_mensagem, true);
                $_class = new curl_manager($GLOBALS['_MASTER']);
                $_retorno = $_class->retornarPing($_dados);
                break;
            case 'executarCurlManager':
                try {
                    $_dados = json_decode($_mensagem, true);
                    $_class = new curl_manager($GLOBALS['_MASTER']);
                    $_retorno = $_class->executarApi($_dados);
                    $_html_entities = false; //Deixando o mais puro poss�vel
                }
                catch (Exception $e){
                    $_code = $e->getCode();
                    $_mensagem = $e->getMessage();

                    //Tratamentos de erros
                    $_retorno['resultado'] = 1; //Erro
                    $_retorno['cod_loja'] = $_dados['cod_loja'];
                    $_retorno['cod_pdv'] = $_dados['cod_pdv'];
                    $_retorno['mensagem'] = "NOK";
                    $_retorno['dados'] = $_code.'/'.$_mensagem;
                }
                break;
            case 'listaVoucherPromo':
                try{
                    $_voucher_promocional = new voucher_promocional($GLOBALS['_MASTER']);
                    $_voucher = $_voucher_promocional->listarVoucherPromocional($_mensagemObj, $_mensagemObj->cod_loja, $_mensagemObj->cod_pdv);
                    $_retorno = Array();
                    $_retorno['resultado'] = '0';
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['mensagem']  = 'OK';
                    $_retorno['dados']['vouchers'] = $_voucher;
                    $_retorno = json_encode($_retorno);
                }catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro na busca do voucher ou n�o existe vouchers para esse cpf.';
                }
                break;
            case 'imprimirVoucherPromo':
                try{
                    $_voucher_promocional = new voucher_promocional($GLOBALS['_MASTER']);
                    $_impressao = $_voucher_promocional->imprimirVoucherPromocional($_mensagemObj);
                    $_retorno['resultado'] = 0;
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_retorno['mensagem']  = 'OK';
                    $_retorno['dados'] = $_impressao;
                    $_retorno = json_encode($_retorno);
                    funcoesGerais::GravaLog('VOUCHER RESPOSTA PDV', true,true);
                    funcoesGerais::GravaLog($_retorno, true,true);
                }catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                }
                break;
            case 'buscarUltimoCupom':
                try{
                    $_mov	= new movdb_1tra($GLOBALS['_MASTER']);
                    $_coo 	= $_mov->buscarUltimoCupom($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv);
                    $_retorno['resultado'] = 0;
                    $_retorno['dados']["coo"] = $_coo;
                    $_retorno['mensagem']  = 'OK';
                }catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                }
                break;
            case 'ListaDeEcfVirtual':
                $_pdv_sem_ecf = new pdv_sem_ecf($GLOBALS['_MASTER'],$_mensagemObj->cod_loja);
                $_resultado = $_pdv_sem_ecf->getTodosRegistros();
                if($_resultado===false){
                    $_retorno['resultado'] = '0';
                    $_retorno['dados']['status'] = 1;
                    $_retorno['dados']['descricao'] = 'Erro ao tentar resgatar os registros';
                    $_retorno['mensagem'] = 'Erro ao tentar resgatar os registros';
                }else{
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'Resgatado com sucesso';
                    $_retorno['dados'] = $_resultado;
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'InsereEcfVirtual':
                $_pdv_sem_ecf = new pdv_sem_ecf($GLOBALS['_MASTER'],$_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados->id_pdv);
                $_retorno = $_pdv_sem_ecf->inserePDV();
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'consultarPontosWS':
                /**
                 * @var controle_pontos $_controle_pontos
                 */
                $_controle_pontos=funcoesGerais::InstanciaClasse('controle_pontos', $GLOBALS['_MASTER']);
                $_flg_cliente     = (isset($_mensagemObj->dados->cod_cliente)&&!empty($_mensagemObj->dados->cod_cliente));
                $_cod_pesquisa    = ($_flg_cliente?$_mensagemObj->dados->cod_cliente:$_mensagemObj->dados->cpf_cnpj);
                $_controle_pontos->consultarPontosWS($_mensagemObj->cod_loja, $_cod_pesquisa, $_mensagemObj->dados->flg_somente_resgataveis, $_retorno, $_mensagemObj->cod_pdv, $_mensagemObj);
                break;
            case 'empenhaPontosWS':
            case 'cancelaEmpenhoPontosWS':
                /**
                 * @var controle_pontos $_controle_pontos
                 */
                $_controle_pontos=funcoesGerais::InstanciaClasse('controle_pontos', $GLOBALS['_MASTER']);
                $_flg_cliente=(isset($_mensagemObj->dados->cod_cliente)&&!empty($_mensagemObj->dados->cod_cliente));
                $_cod_pesquisa=($_flg_cliente?$_mensagemObj->dados->cod_cliente:$_mensagemObj->dados->cpf_cnpj);
                $_controle_pontos->{$_mensagemObj->tipo}($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_cod_pesquisa, $_retorno);
                break;
            /**
             * GCPXCB-11
             * BIT Software
             * 28.08.2017
             * Fun��es para controle de bonus para retirada de brindes
             */
            case 'consultarBonusWS':
                $_ctl_bonus = new controle_bonus($GLOBALS['_MASTER']);
                $_flg_cli = !empty($_mensagemObj->daods->cod_cliente);
                $_cod_cli = $_flg_cli ? $_mensagemObj->dados->cod_cliente : $_mensagemObj->dados->cpf_cnpj;
                $_retorno = $_ctl_bonus->consultarBonusCliente($_mensagemObj->cod_loja,$_cod_cli,$_flg_cli,$_mensagemObj->dados->flg_somente_resgataveis);
                break;
            case 'empenharBonusWS':
                $_ctl_bonus = new controle_bonus($GLOBALS['_MASTER']);
                $_retorno = $_ctl_bonus->empenharBonusWS($_mensagemObj->cod_loja,$_mensagemObj->cod_bonus,$_mensagemObj->cod_pdv);
                break;
            case 'cancelarEmpenhoBonusWS':
                $_ctl_bonus = new controle_bonus($GLOBALS['_MASTER']);
                $_retorno = $_ctl_bonus->cancelarEmpenhoBonusWS($_mensagemObj->cod_loja,$_mensagemObj->cod_bonus);
                break;
            // ML-370
            case 'ConsultarEstoquePAF':
                $_class_mercadoria = new mercadoria($GLOBALS['_MASTER']);
                $_retorno = $_class_mercadoria->consultarEstoquePAF($_mensagemObj);
                break;
            /**
             * POSTOF1-24
             * BIT SOFTWARE
             * 17.01.2017
             * Envio do cadastro de produtos para o CT-POSTO
             */
            case 'ListarProdutosComTipoCombustivel':
                $_merc = new mercadoria($GLOBALS['_MASTER']);
                $_lista = $_merc->buscarProdutosCombustiveis($_mensagemObj->cod_loja);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem']  = 'OK';
                $_retorno['dados'] = Array();
                if(is_array($_lista)) {
                    $_retorno['dados']['status'] = 0;
                    $_retorno['dados']['produtos'] = $_lista;
                } else {
                    $_retorno['dados']['status'] = ($_lista===false ? 9999 : 0);
                }
                break;

            /**
             * POSTOF1
             * Fabiano Nogueira
             * 24.02.2017
             * Envio do cadastro de frentistas para o CT-POSTO
             */
            case 'ListarRFIDcomNomeFrentista':
                $_func 	= new funcionario($GLOBALS['_MASTER']);
                $_lista = $_func->buscarRFIDFrentista($_mensagemObj->cod_loja);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem']  = 'OK';
                $_retorno['dados'] = Array();

                if(is_array($_lista)) {
                    $_retorno['dados']['status'] = 0;
                    $_retorno['dados']['frentistas'] = $_lista;
                } else {
                    $_retorno['dados']['status'] = ($_lista===false ? 9999 : 0);
                }
                break;
            /**
             * FRENTLOGPOS-1 Retorna o c�digo do frentista.
             * O Celso pediu pra replicar o m�todo, por conta da falta de padroniza��o do CTPOSTO.
             */
            case 'retornarOsRFIDsDoOperador':
                $_func 	= new funcionario($GLOBALS['_MASTER']);
                $_lista = $_func->buscarRFIDFrentista($_mensagemObj->cod_loja, $_mensagemObj->cod_funcionario);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem']  = 'OK';
                $_retorno['dados'] = Array();

                if(is_array($_lista)) {
                    $_retorno['dados']['status'] = 0;
                    $_retorno['dados']['frentistas'] = $_lista;
                } else {
                    $_retorno['dados']['status'] = ($_lista===false ? 9999 : 0);
                }
                break;
            case 'importarEncerrantes':
                $_enc 	  = new encerrante($GLOBALS['_MASTER']);
                //funcoesGerais::GravaLog("gerarEncerrantesRest \n " . var_export($_mensagemObj,true),true,true);

                $_retorno = $_enc->gerarEncerrantesRest($_mensagemObj->cod_loja, $_mensagemObj->dados);
                //$_lista = $_func->buscarRFIDFrentista($_mensagemObj->cod_loja);
                break;
            case 'ConsultarAtendimento':
                $_class_atendimento_item = new atendimento_item($GLOBALS['_MASTER']);
                $_retorno = $_class_atendimento_item->getAtendimento($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                break;
            case 'ConsultarPessoasAutorizadas':
                $_pessoa = new cliente_pessoa_autorizada($GLOBALS['_MASTER']);
                $_resultado = $_pessoa->consultarPessoasAutorizadas($_mensagemObj->dados->cod_cliente,$_mensagemObj->cod_loja);
                if($_resultado===false){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro ao buscar lista de pessoas';
                }else{
                    if(count((array)$_resultado) == 0) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Sem pessoas autorizadas';
                    }else{
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_resultado;
                    }

                }
                break;
            case 'consultarPremiacao1':
                $_premi = new premiacao($GLOBALS['_MASTER']);
                $_resultado = $_premi->consultarPremiacao1($_mensagemObj);
                if($_resultado===false){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'N�o foi contemplado';
                    $_retorno['dados'] = $_resultado;
                }else{
                    if(count((array)$_resultado) == 0) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'N�o foi contemplado';
                        $_retorno['dados'] = $_resultado;
                    }else{
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_resultado;
                    }
                }
                break;
            case 'validarAtualizacaoClientePdvTouch':
                try{
                    $_cliente = new cliente($GLOBALS['_MASTER']);
                    $_retorno = $_cliente->validarAtualizacaoClientePdvTouch($_mensagemObj->dados, $_mensagemObj->cod_loja, $_mensagemObj->fn);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'atualizarClientePdvTouch':
                try{
                    $_cliente = new cliente($GLOBALS['_MASTER']);
                    $_retorno = $_cliente->atualizarClientePdvTouch($_mensagemObj->dados, $_mensagemObj->cod_loja, $_mensagemObj->fn);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'validarPrimeiraCompraCartaoProprio':
                try{
                    $_cliente = new cliente($GLOBALS['_MASTER']);
                    $_retorno = $_cliente->validarPrimeiraCompraCartaoProprio($_mensagemObj->dados, $_mensagemObj->cod_loja, $_mensagemObj->fn);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'retornarDadosOfflineCaedu':
                try {
                    $_tef_offline = new transacao_tef_offline($GLOBALS['_MASTER']);
                    $_retorno = $_tef_offline->retornarTrasacaoTefOffline($_mensagemObj->cod_loja,$_mensagemObj->dados->modo ?: 0,$_mensagemObj->dados);
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            /**
             * base-4556
             * BIT
             * Nov.2024
             */
            case 'consultaStatusModoEspecial':
                try {
                    $_retorno_subtipo = true;
                    switch($_mensagemObj->dados->subtipo){
                        case 'reprocessamentoTEF':
                            $_tef_offline = new transacao_tef_offline($GLOBALS['_MASTER']);
                            $_retorno_subtipo = $_tef_offline->atualizarTabelaControleMirage($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                            break;
                        default:
                            throw new Exception('subtipo nao identificado');
                            break;
                    }
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    if($_retorno_subtipo){
                        $_retorno['dados'] = $_retorno_subtipo;
                    }
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'atualizarBaixaCargaLoja':
                try{
                    $_carga_pdv = new carga_pdv($GLOBALS['_MASTER']);
                    $_retorno = $_carga_pdv->atualizarBaixaCargaLoja($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'retornarPerguntasAutorizacao':
                try{
                    $_autorizacao_pergunta = new autorizacao_pergunta($GLOBALS['_MASTER']);
                    $_retorno = $_autorizacao_pergunta->retornarPerguntas($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados->cpf,4,3);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            case 'gravarRespostasAutorizacao':
                try{
                    $_autorizacao_resposta = new autorizacao_resposta($GLOBALS['_MASTER']);
                    $_retorno = $_autorizacao_resposta->gravarRespostas($_mensagemObj->cod_loja, $_mensagemObj->dados);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
            //Chamado toda vez que for necess�ria uma autoriza��o de pagamento com cashback beblue
            case 'pagamento-via-cashback-beblue':

                $entrada = json_decode($_mensagem, true);
                $cod_pdv = $entrada['cod_pdv'];
                $cod_loja = $entrada['cod_loja'];

                try {

                    $loja = new Empresa($GLOBALS['_MASTER']);
                    $loja->Buscar($cod_loja);
                    $beblueGateway = new beblue_gateway($loja);

                    $dados = $entrada['dados'];

                    $_retorno = $beblueGateway->registrarPagamentoViaCashback($dados, $cod_pdv);
                    $_retorno['cod_loja'] = $cod_loja;
                    $_retorno['cod_pdv'] = $cod_pdv;

                    if($GLOBALS['_DEBUG'] === true) {
                        funcoesGerais::GravaLog("=========================================================", true, true);
                        funcoesGerais::GravaLog("[BEBLUE - PAGAMENTO COM CASHBACK REALIZADO COM SUCESSO]", true, true);
                        funcoesGerais::GravaLog("=========================================================", true, true);
                    }

                }
                catch (Exception $e) {
                    $msg = $e->getMessage();
                    $utf2Iso = $e->utf2Iso;

                    if(isset($utf2Iso))
                        $msg = $utf2Iso($msg);

                    $code = $e->getCode();
                    $mensagem = $e->getMessage();

                    if(stripos($mensagem,'duplicado') !== false || stripos($mensagem,'repetido') !== false)
                        $_retorno['mensagem'] = "Pagamento Duplicado.";
                    else if($code == 400 && stripos($mensagem,'USER_NOT_AUTHENTICATED') !== false)
                        $_retorno['mensagem'] = "Falha na autentica��o ! CPF ou Senha incorretos ou usu�rio n�o cadastrado ou inativo ou bloqueado.";
                    else if($code == 400 && stripos($mensagem,'maximum amount should be') !== false)
                        $_retorno['mensagem'] = "Valor limite para pagamento com cashback excedido !";
                    else if($code == 412 && stripos($mensagem,'insuficiente') !== false)
                        $_retorno['mensagem'] = "Saldo insuficiente !";
                    else
                        $_retorno['mensagem'] = "Falha ao realizar o pagamento com resgate de cashback !";

                    $_retorno['resultado'] = 1; //Erro
                    $_retorno['cod_loja'] = $cod_loja;
                    $_retorno['cod_pdv'] = $cod_pdv;
                    $_retorno['dados'] = $msg;

                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("[BEBLUE - ERROR EM PAGAMENTO COM CASHBACK]", true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("Mensagem de Erro(Serializada): " . serialize($msg), true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);

                }

                break;

            //Cancelar Pagamento Espec�fico de uma Venda Espec�fica
            case 'cancelar-pagamento-beblue':

                $entrada = json_decode($_mensagem, true);
                $cod_loja = $entrada['cod_loja'];
                $cod_pdv = $entrada['cod_pdv'];

                try {


                    $saleId = $entrada['dados']['saleId'];
                    $pagamentoId = $entrada['dados']['paymentId'];

                    $loja = new Empresa($GLOBALS['_MASTER']);

                    $loja->Buscar($cod_loja);

                    $beblueGateway = new beblue_gateway($loja);

                    $venda = $beblueGateway->registrarCancelamentoPagamento($saleId, $pagamentoId);

                    $_retorno['cod_loja'] = $cod_loja;
                    $_retorno['cod_pdv'] = $cod_pdv;
                    $_retorno['mensagem'] = 'Cancelamento de pagamento registrado com sucesso';
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $venda;

                    if($GLOBALS['_DEBUG'] === true) {
                        funcoesGerais::GravaLog("=========================================================", true, true);
                        funcoesGerais::GravaLog("[BEBLUE - PAGAMENTO COM CASHBACK CANCELADO COM SUCESSO]", true, true);
                        funcoesGerais::GravaLog("=========================================================", true, true);
                    }

                }
                catch (Exception $e) {

                    $msg = $e->getMessage();
                    $utf2Iso = $e->utf2Iso;

                    if(isset($utf2Iso))
                        $msg = $utf2Iso($msg);

                    $_retorno['mensagem'] = "Falha ao registrar cancelamento de pagamento.";
                    $_retorno['resultado'] = 1; //Erro
                    $_retorno['dados'] = $msg;
                    $_retorno['cod_loja'] = $cod_loja;
                    $_retorno['cod_pdv'] = $cod_pdv;

                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("[BEBLUE - ERRO EM CANCELAMENTO DE PAGAMENTO COM CASHBACK]", true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("Mensagem de Erro(Serializada): " . serialize($msg), true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);
                }

                break;
            case 'cancelar-venda-beblue':
                try {
                    $entrada = json_decode($_mensagem, true);

                    $cod_loja = $entrada['cod_loja'];
                    $saleId = $entrada['dados']['saleId'];

                    $loja = new Empresa($GLOBALS['_MASTER']);

                    $loja->Buscar($cod_loja);

                    $beblueGateway = new beblue_gateway($loja);

                    $venda = $beblueGateway->registrarCancelamentoVenda($saleId);

                    $_retorno['mensagem'] = 'Cancelamento de venda registrado com sucesso';
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $venda;

                    if($GLOBALS['_DEBUG'] === true) {
                        funcoesGerais::GravaLog("=========================================================", true, true);
                        funcoesGerais::GravaLog("[BEBLUE - VENDA CANCELADA COM SUCESSO]", true, true);
                        funcoesGerais::GravaLog("=========================================================", true, true);
                    }

                }
                catch (Exception $e) {
                    $msg = $e->getMessage();
                    $utf2Iso = $e->utf2Iso;

                    if(isset($utf2Iso))
                        $msg = $utf2Iso($msg);

                    $_retorno['mensagem'] = "Falha ao registrar cancelamento da venda.";
                    $_retorno['resultado'] = 1; //Erro
                    $_retorno['dados'] = $msg;

                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("[BEBLUE - ERRO EM CANCELAMENTO DE VENDA]", true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);
                    funcoesGerais::GravaLog("Mensagem de Erro(Serializada): " . serialize($msg), true, true);
                    funcoesGerais::GravaLog("=========================================================", true, true);

                }

                break;
            case 'PesquisaSatisfacaoPDV':
                $_classe = new pesquisa_satisfacao_pdv($GLOBALS['_MASTER']);
                $_classe->setCOD_PDV($_mensagemObj->cod_pdv);
                $_classe->setCOD_LOJA($_mensagemObj->cod_loja);
                $_retorno = $_classe->PesquisaSatisfacaoPDV($_mensagemObj->dados);
                break;
            case 'TemMsgParaCliente':
                $_preAprovado = new cliente_comunicado($GLOBALS['_MASTER']);
                $_retorno['dados'] = [];

                /**
                 * WHITELIST-1
                 * BIT
                 * Mar.2022
                 */
                if($_mensagemObj->dados->modo_consulta==1) {
                    // Buscar novo padr�o de mensagens
                    $_res = $_preAprovado->consultarMensagensCliente($_mensagemObj->dados->cpf_cliente_venda);
                    if($_res!=false) {
                        if(!empty($_res['TXT_MENSAGEM'])) {
                            $_retorno['dados']['msg_cliente'] = $_res['TXT_MENSAGEM'];
                        } else{
                            $_retorno['dados']['msg_cliente'] = $_res['MENSAGEM'];
                        }
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem'] = 'OK';

                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Nenhuma mensagem para este CPF/CNPJ';
                        $_retorno['dados']['msg_cliente'] = '';

                    }
                } else if($_mensagemObj->dados->modo_consulta==2) {
                    $_html_entities = false;
                    $_integradores = [];
                    $_classe = new integracao_credsystem($GLOBALS['_MASTER']);
                    $_res_credsystem = $_classe->consultarPreCadastro($_mensagemObj);

                    if($_res_credsystem !== null) {
                        $_integradores['integradores'] = [$_res_credsystem];
                    }

                    if(count($_integradores) > 0) {
                        $_retorno['dados'] = $_integradores;
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem'] = 'OK';
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = utf8_encode('N�o foi poss�vel consultar a pr�-aprova��o do cliente.');
                    }
                    break;
                } else {
                    $_resultado = $_preAprovado->consultarCartaoPreAprovado($_mensagemObj->dados->cpf_cliente_venda);
                    if($_resultado!=false) {
                        if($_resultado['MENSAGEM']<>'') {
                            $_retorno['dados']['msg_cliente'] = $_resultado['MENSAGEM'];
                        } else {
                            $_retorno['dados']['msg_cliente'] = 'Parabens, voce tem um cartao pre aprovado.';
                        }
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem'] = 'OK';

                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Cpf n�o existe';
                        $_retorno['dados']['msg_cliente'] = '';
                    }
                }

                $_retorno['mensagem'] = utf8_encode($_retorno['mensagem']);
                $_retorno['dados']['msg_cliente'] = utf8_encode($_retorno['dados']['msg_cliente']);
                $_html_entities = false;

                break;
            /**
             * COOREPETE-3
             * BIT SOFTWARE
             * 25.09.2018
             * Valida o cupom informado (loja, pdv, coo, periodo)
             * E retorna se o mesmo j� foi utilizado ou n�o no
             * per�odo informado (em meses)
             */
            case 'ValidaCOOEmPeriodo':
                try{
                    $_mov	= new MestreCupom($GLOBALS['_MASTER']);
                    $_coo 	= $_mov->verificarRepeticaoCOO($_mensagemObj->cod_loja,$_mensagemObj->cod_pdv,$_mensagemObj->dados);
                    $_retorno['dados'] = Array();
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem']  = 'OK';
                    $_retorno['dados']['situacao'] = $_coo;
                } catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                }

                break;
            /**
             * PR-5
             * Bit software
             * JSC
             * 14.12.18
             * Realiza o pagamento via rappipay
             */
            case 'pagamento-via-cashback-rappi':
                $_rappi = new rappipay($GLOBALS['_MASTER']);
                $_retorno = $_rappi->registrarPagamento($_mensagemObj->cod_loja,$_mensagemObj->dados);
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                $_retorno['tipo'] = $_mensagemObj->tipo;
                $_retorno['dados']->paymentRef = $_mensagemObj->dados->paymentRef;
                break;
            /**
             * PR-5
             * Bit software
             * JSC
             * 14.12.18
             * Cancela um pagamento via rappipay
             */
            case 'cancelar-pagamento-rappi':
                $_rappi = new rappipay($GLOBALS['_MASTER']);
                $_retorno = $_rappi->registrarCancelamentoPagamento($_mensagemObj->dados);
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                $_retorno['tipo'] = $_mensagemObj->tipo;
                $_retorno['dados']->paymentRef = $_mensagemObj->dados->paymentRef;
                break;
            /**
             * Para o PDV acionar esse cara precisa estar com o par�metro A00LYH bit 1 ou 2 habilitado (a confirmar)
             * Para acessar promo��es externas, checar tamb�m o par�metro A00MFS (esse desce para o PDV apenas se XML config da integra��o estiver habilitado no cadastro de loja)
             */
            case 'ListaPromocoesCliente':
                $_html_entities = false;
                $_classe = new promocao_cliente($GLOBALS['_MASTER']);
                $_retorno = $_classe->ListaPromocoesCliente($_mensagemObj);
                if (isset($_retorno)) {
                    $_retorno["dados"]["mensagem"] = utf8_encode($_retorno["dados"]["mensagem"]);
                }
                break;
            /**
             * PR-20
             * BIT Software
             * 27.02.2019
             * Devolve a data/hora do servidor
             */
            case 'PegaDataHora':
                $_retorno['resultado'] = 0;
                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                $_dados = new StdClass;
                $_dados->data = date("dmY");
                $_dados->hora = date("Hi");
                $_retorno['dados'] = $_dados;
                break;
            /**
            //Exemplo que o PDV pode enviar ao Manager (ap�s conversa com Celso)
            {
                "cod_loja": 58,
                "cod_pdv": 238,
                "tipo": "autorizar-pagamento",
                "dados": {
                    "tipo": "3", //1 - Consulta sem validar valor, 2 - Consulta validando valor sem empenho, 3 - Consulta validando valor com empenho, 4 - Desempenho
                    "empenha_saldo": "1", //1 = aceita parcial
                    "valor": "20.00", //Valor a ser consultado/empenhado
                    "fin": "1", //Finalizadora
                    "cpf": "99999999999", //Chave de consulta
                    "plano": "",
                    "dt_operacao": "", //Data
                    "input_alfa": "", // Novo input para consulta al�m do CPF
                    "dja":"" //Pode vir quando o tipo = 4 (desempenho)
                }
            }

            //Exempo que o Manager pode retornar ao PDV (ap�s conversa com Celso)
            {
                "resultado": 0,
                "cod_loja": 51,
                "cod_pdv": 238,
                "dados": {
                    "dja": "412412asfaf23rfa", //Protocolo que aceita alfa de 40 caracateres
                    "nome_cliente": "Marcelo Jr",
                    "empenho": 0, //0 = empenhado com sucesso , 1 = n�o empenhado (Esse era utilizado apenas pela classe da bluesoft)
                    "valorEmpenho": "10.00", //Valor empenhado
                    "saldo":"0.00" //Saldo atualizado
                }
            }*/
            //PARA O PDV CONSULTAR ESSE M�TODO PRECISA TER O A00KLC al�m
            case 'autorizar-pagamento':
                try {
                    $_fin	=  funcoesGerais::InstanciaClasse('finalizadora', $GLOBALS['_MASTER']);
                    $_resultado 	= $_fin->consultarLimiteFinalizadora($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj->cod_pdv);
                    if($_resultado['resultado'] == '1') {
                        $_retorno['resultado'] = $_resultado['resultado'];
                        $_retorno['mensagem'] = $_resultado['mensagem'];
                    }else{

                        $_retorno['resultado'] = 0;
                        $_retorno['dados']->resultado = isset($_resultado['resultado']) ? $_resultado['resultado'] : (!is_array($_resultado) ? $_resultado : 0);
                        $_retorno['dados']->mensagem  = isset($_resultado['mensagem']) ? $_resultado['mensagem'] : 'OK';
                        $_retorno['dados']->saldo = $_resultado['saldo'];
                        $_retorno['dados']->cod_autorizacao = isset($_resultado['cod_autorizacao']) ? $_resultado['cod_autorizacao'] : null; //Parece que o PDV n�o est� pronto pra receber, Celso disse que usa a tag "dja" ali em baixo
                        if(isset($_resultado['empenho'])) {
                            $_retorno['dados']->empenho = $_resultado['empenho'];
                        }
                        /** BS, retorna o nome do cliente */
                        if(isset($_resultado['nome_cliente'])) {
                            $_retorno['dados']->nome_cliente = $_resultado['nome_cliente'];
                        }
                        
                        if(isset($_resultado['dja'])){
                            $_retorno['dados']->dja = $_resultado['dja']; //M02DJA / M04DJA
                        }

                        if(isset($_resultado['valorEmpenho'])){
                            $_retorno['dados']->valorEmpenho = $_resultado['valorEmpenho'];
                        }
                    }
                } catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    funcoesGerais::GravaLog("[autorizar-pagamento] Erro:: {$e->getMessage()}",true,true);
                }
                break;
            case 'consultarCreditoCliente':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS['_MASTER']);
                    $_resultado = $_cliente->consultarCreditoCliente($_mensagemObj->cod_loja,$_mensagemObj->dados);
                    $_retorno['resultado'] = isset($_resultado['resultado']) ? $_resultado['resultado'] : (!is_array($_resultado) ? $_resultado : 0);
                    $_retorno['mensagem']  = 'OK';
                    $_retorno['dados']->mensagem = $_resultado['mensagem'];
                } catch(Exception $e) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    funcoesGerais::GravaLog("[consultarCreditoCliente] Erro:: {$e->getMessage()}",true,true);
                }
                break;
            /**
             * ML-1055
             * BIT Software
             * 02.04.2019
             * Emiss�o de relat�rios gen�ricos
             */
            case 'emitirRelatorio':
                switch($_mensagemObj->dados->tipo) {
                    case 1: // Fechamento por operador
                        try {
                            $_fin = new finalizadora($GLOBALS['_MASTER']);
                            $_lista = $_fin->retornarResumoPorOperadorEFinalizadora($_mensagemObj->cod_loja, $_mensagemObj->dados->cod_operador, $_mensagemObj->dados->data, $_mensagemObj->dados->data);
                            if ($_lista === false) {
                                $_retorno['resultado'] = '1';
                                $_retorno['mensagem'] = 'Erro ao processar o relat�rio';
                            } else {
                                $_retorno['resultado'] = '0';
                                $_retorno['dados']->relatorio = $_lista;
                            }
                        } catch (Exception $ex) {
                            $_retorno['resultado'] = '1';
                            $_retorno['mensagem'] = $ex->getMessage();
                        }
                    break;
                    case 2: // Encerrantes
                        try {
                            $_encerrantes = funcoesGerais::InstanciaClasse('rel_encerrantes', $GLOBALS['_MASTER']);
                            $_relatorio = $_encerrantes->montarRelatorioPDV($_mensagemObj);

                            if ($_relatorio['resultado'] === true) {
                                $_retorno['resultado'] = '0';
                                $_retorno['dados']->relatorio = $_relatorio['dados'];
                            } else {
                                $_retorno['resultado'] = '1';
                                $_retorno['mensagem'] = $_relatorio['mensagem'];
                            }
                        } catch (Exception $e) {
                            $_retorno['resultado'] = '1';
                            $_retorno['mensagem'] = $e->getMessage();
                        }
                    break;
                    default: // Erro
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Nenhum tipo de relatorio encontrado';
                }
                break;
            /**
             * SUPERTROCO
             * Jakson Fischer
             * 11.11.2019
             * Consulta os dados no Super Troco
             */
            case 'enviarDoacaoTroco' :
                switch ($_mensagemObj->dados->tipo_doacao) {
                    case 3:
                        $_st = new troco_doacao($GLOBALS['_MASTER']);

                        $_mensagemObj->dados->pdv = $_mensagemObj->cod_pdv;
                        $_ret = $_st->autorizarDoacao($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj);
                        $_retorno['resultado'] = $_ret['resultado'];
                        $_retorno['mensagem'] = $_ret['mensagem'];
                        $_retorno['dados'] = json_decode($_ret['dados']);
                        $_html_entities = false;
                        break;
                    default:
                        $_st = new troco_doacao($GLOBALS['_MASTER']);
                        $_mensagemObj->dados->pdv = $_mensagemObj->cod_pdv;
                        $_ret = $_st->autorizarDoacao($_mensagemObj->cod_loja,$_mensagemObj->dados);
                        $_retorno['resultado'] = $_ret['resultado'];
                        $_retorno['mensagem'] = $_ret['mensagem'];
                        $_retorno['dados']->nsu = $_ret['nsu'];
                        $_retorno['dados']->comprovante = $_ret['comprovante']; // Definido com o Celso
                        $_retorno['nsu'] = $_ret['nsu'];
                        break;
                }
                break;
            case 'confirmarDoacaoTroco':
                switch ($_mensagemObj->dados->tipo_doacao) {
                    /**
                     * CHAINTT-18
                     * BIT SOFTWARE
                     * 22.04.2019
                     * Confirma uma doa��o de troco
                     * 05.06.2019
                     * Os dados a serem impressos
                     * ser�o enviados na tag dados->comprovante
                     */
                    case 1;
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem'] = 'OK | N�o existe confirma��o para esse tipo de doa��o!';
                        $_retorno['dados']->nsu = '';
                        $_retorno['dados']->comprovante = '';
                        $_retorno['nsu'] = '';
                        break;
                    /**
                     * SUPERTROCO-1
                     * Jakson Fischer
                     * 14.10.2019
                     * Fun��o respons�vel pelo envio
                     * dos dados para o Super Troco.
                     */
                    case 3:
                        $_st = new super_troco($GLOBALS['_MASTER']);
                        $_mensagemObj->dados->pdv = $_mensagemObj->platinum->supertroco->pdv;
                        $_ret = $_st->enviarCompraSuperTroco($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj);
                        if ($_ret === false || $_ret === null) {
                            $_retorno['resultado'] = '1';
                            $_retorno['mensagem'] = '';
                            $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_html_entities = false;
                        } else {
                            $_retorno['resultado'] = '0';
                            $_retorno['mensagem'] = '';
                            $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                            $_retorno['dados'] = $_ret->platinum->supertroco;
                            $_html_entities = false;
                        }
                        break;
                }
                break;
            /**
             * CHAINTTS-21
             * BIT SOFTWARE
             * 22.04.2019
             * Cancela uma doa��o de troco pelo NSU
             * 05.06.2019
             * Antes de efetivar o cancelamento ser�
             * feita uma busca no banco de dados pelo
             * NSU informado, caso n�o seja encontrado
             * o cancelamento � recusado.
             * Ap�s o cancelamento devolvemos o valor
             * da transa��o na tag dados->valor
             */
            case 'cancelarDoacaoTroco':
            case 'enviarCancelamentoDoacao':
                switch ($_mensagemObj->dados->tipo_doacao) {
                    /**
                     * SUPERTROCO
                     * Jakson Fischer
                     * 03.10.2019
                     * Fun��o para o cancelamento do
                     * Super Troco
                     */
                    case 3:
                        $_st = new super_troco($GLOBALS['_MASTER']);
                        $_mensagemObj->dados->pdv = $_mensagemObj->platinum->supertroco->pdv;
                        $_ret = $_st->fazerCancelamentoSuperTroco($_mensagemObj->cod_loja, $_mensagemObj->dados, $_mensagemObj);

                        if ($_ret === false || $_ret === null) {
                            $_retorno['resultado'] = '1';
                            $_retorno['mensagem'] = '';
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                            $_html_entities = false;
                        } else {
                            $_retorno['resultado'] = '0';
                            $_retorno['mensagem'] = '';
                            $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                            $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                            $_retorno['dados'] = $_ret->platinum->supertroco;
                            $_html_entities = false;
                        }
                        break;
                    default:
                        $_st = new troco_doacao($GLOBALS['_MASTER']);
                        $_ret = $_st->cancelarDoacaoPorNSU($_mensagemObj->cod_loja, $_mensagemObj->dados);
                        $_retorno['resultado'] = $_ret['resultado'];
                        $_retorno['mensagem'] = $_ret['mensagem'];
                        $_retorno['dados']->valor = $_ret['valor'];
                        break;
                }
                break;
            /**
             * base-9287
             * BIT
             * Dez.2024
             * Nova interface superTroco
             */
            case 'consultaSuperTrocoV4PreVenda':
                $_st = new super_troco($GLOBALS['_MASTER']);
                $_st->zSet('_versao4',true);
                $_mensagemObj->dados->tipo_doacao = 4;
                $_ret = $_st->fazerConsultaSuperTroco($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj);
                if(empty($_ret)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                } else {
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                    $_retorno['dados'] = $_ret->platinum->supertroco;
                }
                $_html_entities = false;
                break;
            case 'consultaSuperTrocoV4ConfirmaVenda':
                $_st = new super_troco($GLOBALS['_MASTER']);
                $_st->zSet('_versao4',true);
                $_mensagemObj->dados->tipo_doacao = 4;
                //$_mensagemObj->dados->pdv = $_mensagemObj->platinum->supertroco->pdv;
                $_ret = $_st->enviarCompraSuperTroco($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj);
                if ($_ret === false || $_ret === null) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_html_entities = false;
                } else {
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                    $_retorno['dados'] = $_ret->platinum->supertroco;
                    $_html_entities = false;
                }
                break;
            case 'consultaSuperTrocoV4Cancelamento':
                $_st = new super_troco($GLOBALS['_MASTER']);
                $_st->zSet('_versao4',true);
                $_mensagemObj->dados->tipo_doacao = 4;
                //$_mensagemObj->dados->pdv = $_mensagemObj->platinum->supertroco->pdv;
                $_ret = $_st->fazerCancelamentoSuperTroco($_mensagemObj->cod_loja, $_mensagemObj->dados, $_mensagemObj);
                if ($_ret === false || $_ret === null) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                    $_html_entities = false;
                } else {
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                    $_retorno['dados'] = $_ret->platinum->supertroco;
                    $_html_entities = false;
                }
                break;
            case 'consultaSuperTrocoV4Transacoes':
                $_mensagemObj->dados->pdv = $_mensagemObj->cod_pdv;
                $_st = new super_troco($GLOBALS['_MASTER']);
                $_st->zSet('_versao4',true);
                $_mensagemObj->dados->tipo_doacao = 4;
                $_stret = $_st->fazerConsultaSuperTroco($_mensagemObj->cod_loja,$_mensagemObj->dados,$_mensagemObj);
                if(empty($_stret)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja']= $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                } else {
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                    $_retorno['cod_pdv'] = $_ret->platinum->supertroco->pdv;
                    $_retorno['dados'] = $_ret->platinum->supertroco;
                }
                break;
            /**
             * DOTZAPI-2
             * Bit Software
             * 18.06.2019
             * Consulta o saldo do CPF informado
             */
            case 'consultarSaldoDotz':
                $_cpf = $_mensagemObj->dados->cpf;
                if(!empty($_cpf)) {
                    $_dotz = new integracao_dotz($GLOBALS['_MASTER']);
                    $_res = $_dotz->consultarSaldo($_mensagemObj->cod_loja,$_mensagemObj->dados);
                    if(empty($_res)) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Ocorreu um erro ao buscar o saldo';
                    } elseif(!empty($_res->erro)) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = $_res->mensagem;
                    } else {
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_res;
                    }
                } else {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'CPF N�o foi informado';
                }
                break;
            /**
             * VIAINTCRES-6
             * BIT Software
             * 26.08.2019
             * Cria��o do m�todo para integra�ao do PDV
             * com a Cresce Vendas
             * O PDV mandar� o json montado para envio
             */
            case 'consultaCarrinhoCresceVendas':
                $_json = $_mensagemObj->dados->conteudo;
                if(empty($_json)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Necess�rio informar o json da lista de compras';
                } else {
                    $_frete = new integracao_crescevendas($GLOBALS['_MASTER']);
                    $_frete->enviarListaInicial($_mensagemObj->cod_loja,$_json,$_retorno);
                }
                break;
            /**
             * PETENTREGA-13
             * BIT Software
             * 29.07.2019
             * Consulta frete conforme cliente informado
             */
            case 'consultarFreteCliente':
                $_dados = $_mensagemObj->dados;
                if(empty($_dados->chave)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Chave de busca n�o informada';
                } else {
                    $_retorno['resultado'] = '0';
                    $_frete = new frete($GLOBALS['_MASTER']);
                    $_frete->buscarFretePorCliente($_mensagemObj->cod_loja,$_dados->chave,$_dados->conteudo,$_dados->endereco_entrega,$_retorno);
                }
                break;
            case 'ConsultaConfigInterface':
                $_dados = $_mensagemObj->dados;
                $_perfil = new perfil_interface($GLOBALS['_MASTER']);
                $_retorno = $_perfil->ConfigInterface($_dados->cod_pdv,$_dados->loja);
                break;
            case 'validarVenda':
                $_integracao_delaware = new integracao_delaware($GLOBALS["_MASTER"]);
                $_ret = $_integracao_delaware->validarVendaPDV($_mensagemObj->cod_loja,$_mensagemObj->dados);
                $_retorno['resultado'] = $_ret["resultado"];
                $_retorno['mensagem'] = $_ret["mensagem"];
                $_retorno['dados'] = !empty($_ret["dados"])?$_ret["dados"]:"";
                break;
            /**
             * BIOCLIENTE-7
             * BIT Software
             * 07.04.2020
             * Consulta da biometria
             */
            case 'consultarBiometriaCliente':
                $_bio = new biometria_cliente($GLOBALS['_MASTER']);
                $_bio->buscarBiometria($_mensagemObj->dados->cpfcnpj,$_mensagemObj->cod_loja,$_retorno);
                break;
            /**
             * ML-1654, m�todo para consultar o pedido pela interface java
             */
            case 'ListaPedidosPagtoPendente':
                try{
                    /**
                     * @var  $_pedido zan_pedido
                    */
                    $_pedido = funcoesGerais::InstanciaClasse('zan_pedido',$GLOBALS['_MASTER']);
                    $_dados = $_pedido->listarPedidosPDV($_mensagemObj->dados, $_mensagemObj->cod_loja, 13168);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados']->pedidos = $_dados;
                    if(empty($_dados)) {
                        $_retorno['mensagem'] = 'Erro: Nenhum pedido encontrado com o termo pesquisado';
                    }
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * BASE-7619
             */
            case 'ListaComandasPagtoPendente':
                try{
                    /**
                     * @var  $_pedido zan_pedido
                     */
                    $_pedido = funcoesGerais::InstanciaClasse('zan_comanda',$GLOBALS['_MASTER']);
                    $_dados_retorno = $_pedido->listarComandasPDV($_mensagemObj->dados, $_mensagemObj->cod_loja, 11168);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = [
                        'pedidos' => $_dados_retorno,
                    ];
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * PROMOQTDE-9
             * BIT Software
             * 08.04.2020
             * Consulta Saldo promo��o
             */
            case 'consultaQtdDisponivelPromo':
                $_saldoCli = null;
                $_saldoLoja = null;
                $_retorno['resultado'] = 0;
                $_retorno['mensagem'] = 'OK';
                $_retorno['dados']->resultado = 0;
                $_retorno['dados']->qtd_disponivel = null;

                //PROMOAPP2-35 - Precisamos buscar a promo��o e entender qual o tipo dela
                $_novaPromo = new novapromocao($GLOBALS['_MASTER']);
                $_novaPromo->_joinsql = null;
                $_flags3 = $_novaPromo->BuscarCampo("FLAGS3", "CODPROMOCAO={$_mensagemObj->dados->cod_promocao}");
                if($_flags3 == false){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Problemas ao buscar dados da promo��o';
                    break;
                }

                //Controle de quantidade por cliente
                if(($_flags3 & 128) > 0) {
                    $_pc = new novapromocao_cliente($GLOBALS['_MASTER']);
                    $_saldoCli = $_pc->retornarSaldoClientePromocao($_mensagemObj->dados->cod_promocao,$_mensagemObj->dados->num_cgc,$_mensagemObj->cod_loja,$_retorno);
                    $_retorno['dados']->qtd_disponivel = $_saldoCli;
                }

                //Controle de quantidade por loja
                if(($_flags3 & 8) > 0) {
                    $_promoLoja = new promocao_loja($GLOBALS['_MASTER']);
                    $_saldoLoja = $_promoLoja->consultarSaldoPromocao($_mensagemObj->cod_loja,$_mensagemObj->dados->cod_promocao,$_retorno);
                    //PROMOAPP2-35 - Se os bits para controlar quantidade por loja e por cliente estiverem ativo consideramos o menor
                    if($_saldoLoja < $_saldoCli || ($_flags3 & 128) <= 0) {
                        $_retorno['dados']->qtd_disponivel = $_saldoLoja;
                    } else{
                        $_retorno['dados']->qtd_disponivel = $_saldoCli; //S� por garantia
                    }
                }
                break;
            case 'consultaListaQtdDisponivelPromo':
                $_saldoCli = null;
                $_saldoLoja = null;
                $_retorno['resultado'] = 0;
                $_retorno['mensagem'] = 'OK';

                $_novaPromo = new novapromocao($GLOBALS['_MASTER']);
                $_novaPromo->_joinsql = null;
                $_promos = Array();
                foreach ($_retorno['dados']->codigos as $key => $_cod_promocao) {
                    $_retorno['dados']->codigos[$key]->resultado = 0;
                    $_retorno['dados']->codigos[$key]->qtd_disponivel = null;
                    $_promos[] = $_cod_promocao->cod_promocao;
                }
                $_where = "CODPROMOCAO IN(".implode(",",$_promos).")";
                $_flags3 = $_novaPromo->BuscarCampoLista("CODPROMOCAO,FLAGS3", $_where);
                $_flags3_128 = Array();
                $_flags3_8 = Array();
                foreach ($_retorno['dados']->codigos as $key => $_codigo) {
                    foreach ($_flags3 as $_dados) {
                        if ($_codigo->cod_promocao == $_dados['CODPROMOCAO']) {
                            if ($_dados['FLAGS3'] == false) {
                                unset($_retorno['dados']->codigos[$key]->qtd_disponivel);
                                $_retorno['dados']->codigos[$key]->resultado = '1';
                                $_retorno['dados']->codigos[$key]->mensagem = 'Problemas ao buscar dados da promo��o';
                            }
                            if (($_dados['FLAGS3'] & 128) > 0) {
                                $_flags3_128[] = $_dados;
                            }
                            if (($_dados['FLAGS3'] & 8) > 0) {
                                $_flags3_8[] = $_dados;
                            }
                        }
                    }
                }
                //Controle de quantidade por cliente
                if (!empty($_flags3_128)) {
                    $_promo = Array();
                    foreach ($_retorno['dados']->codigos as $key => $_codigo) {
                        foreach ($_flags3_128 as $_dados) {
                            if ($_codigo->cod_promocao == $_dados['CODPROMOCAO']) {
                                $_retorno['dados']->codigos[$key]->qtd_disponivel = null;
                                $_promo[] = $_dados['CODPROMOCAO'];
                            }
                        }
                    }
                    $_pc = new novapromocao_cliente($GLOBALS['_MASTER']);
                    $_pc->retornarSaldoClientePromocaoLista($_promo,$_mensagemObj->dados->cpfcnpj_cliente,$_mensagemObj->cod_loja,$_retorno);
                }
                //Controle de quantidade por loja
                if (!empty($_flags3_8)) {
                    $_promo = Array();
                    foreach ($_flags3_8 as $_dados) {
                        $_promo[] = $_dados['CODPROMOCAO'];
                    }
                    $_promoLoja = new promocao_loja($GLOBALS['_MASTER']);
                    $_promoLoja->consultarSaldoPromocaoLista($_mensagemObj->cod_loja,$_promo,$_retorno);
                }
                break;
            case 'validaTokenPDV':
                $_token = new token();
                $_retorno_token = $_token->validarToken($_mensagemObj->cod_loja,$_mensagemObj->dados->token,$_mensagemObj->dados->tipo);
                if(!$_retorno_token){
                    if($_token->confirmarUtilizacao($_retorno_token["ID"],true,$_mensagemObj->cod_pdv)) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = 'Token validado';
                    }else{
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Problemas ao validar token';
                    }
                }else {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Token inv�lido';
                }
                break;
            /**
             * LISTADESC-1
             * Efetua o envio de Movimento zoombox
             */
            case 'ConsultaClienteFidelidade':
                switch ((int)$_mensagemObj->dados->tipo_fidelidade){
                    case 1: //ZOOMBOX
                        $_zoombox = new cliente_zoombox($GLOBALS['_MASTER']);
                        $_retorno = $_zoombox->consultarClienteZoombox($_mensagemObj);
                        break;
                    default:
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Tipo de fidelidade inexistente.';
                        break;
                }

                $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                break;
			/**
			 * BASE-9407
			 * Rodger Bittencourt
			 * 27/01/2025
			 * M�todo para enviar PIN (Email e SMS)
			 */
			case 'enviarPIN':
				$_codigo = $_mensagemObj->dados->codigo;
				$_tipo_envio = $_mensagemObj->dados->tipo_envio;
				$_telefone = $_mensagemObj->dados->telefone;
				$_email = $_mensagemObj->dados->email;
				$_cod_cliente = $_mensagemObj->dados->cod_cliente;

				// Verifica��o de presen�a dos campos
				if(empty($_codigo) || empty($_tipo_envio)){
					$_retorno['resultado'] = '1';
					$_retorno['mensagem'] = 'Erro: c�digo ou tipo de envio n�o informados';
					break;
				}

				// Envio por SMS
				if($_tipo_envio === 'sms'){
					if(empty($_telefone)) {
						$_retorno['resultado'] = '1';
						$_retorno['mensagem'] = 'Erro: telefone n�o foi informado';
					}

					$_fabrica_mecanismo_integracao = new sms_zenvia_service_factory();
					$_fabrica_mecanismo_integracao::$_tipo_envio = 'BON';
					$_fabrica_mecanismo_integracao::$_texto_sms = 'texto_bonus_sms';
					$_mecanismo_integracao = $_fabrica_mecanismo_integracao->getInstance();

					// 3 tentativas de envio
					for($i = 0; $i < 3; $i++) {
						$_resultado = $_mecanismo_integracao->sendSmsRequest($_telefone, $_codigo);
						if(!$_resultado['statusErro']) {
							break;
						}
					}

					$_retorno['resultado'] = '0';
					$_retorno['mensagem'] = 'SMS enviado com sucesso';
					if ($_resultado['statusErro']) {
						$_retorno['resultado'] = '1';
						$_retorno['mensagem'] = 'Erro: SMS n�o enviado ap�s 3 tentativas';
					}

					// Envio por Email
				} else if($_tipo_envio === 'email') {
					if(empty($_email)) {
						$_retorno['resultado'] = '1';
						$_retorno['mensagem'] = 'Erro: email n�o foi informado';
						break;
					}

					$_class_layout_email = new layout_email();
					$_email_layout = $_class_layout_email->retornarPrimeiroLayoutEmail(8);
					$_titulo = $_email_layout['ASSUNTO_EMAIL'];
					$_mensagem = str_replace('{COD_CONFIRMA_CADASTRO}', $_codigo, $_email_layout['TEXTO_EMAIL']);

					if(empty($_titulo) || empty($_mensagem)) {
						$_retorno['resultado'] = '1';
						$_retorno['mensagem'] = 'Erro: layout de email n�o configurado';
						break;
					}

					$_send_email = new email();
					// 3 tentativas de envio
					for($i = 0; $i < 3; $i++) {
						$_sent = $_send_email->EnviaEmailPear($_email, $_mensagem, $_titulo, null, array(), null, 'HTML');
						if($_sent) {
							break;
						}
					}

					$_retorno['resultado'] = '0';
					$_retorno['mensagem'] = 'Email enviado com sucesso';
					if(!$_sent) {
						$_retorno['resultado'] = '1';
						$_retorno['mensagem'] = 'Erro: Email n�o enviado ap�s 3 tentativas';
						break;
					}

					// Fallback
				} else {
					$_retorno['resultado'] = '1';
					$_retorno['mensagem'] = 'Erro: tipo de envio inv�lido';
					break;
				}

				break;
            /**
             * VENDABONUS-6
             * Fernando Silva
             * 10/02/2020
             * M�todo para enviar PIN via SMS
             * base-2144
             * BIT
             * Jul.2024
             */
            case 'enviarPINSMS':
                $_telefone = $_mensagemObj->dados->telefone;
                $_codigo = $_mensagemObj->dados->codigo;
                $_canal = $_mensagemObj->dados->canal_envio ?: 0; // 0 = Manager, 1 = Neos
                $_tipo = $_mensagemObj->dados->tipo;
                if(empty($_tipo)){
                    $_tipo = (int)funcoesGerais::retornarValorParametro('enviar_pin_sms');
                }
                if(!empty($_telefone)) {
                    /**
                     * base-8653
                     * BIT
                     * Nov.2024
                     * Inserido o tipo = 2
                     * o qual define que o envio ser� pela API de SMS
                     */
                    switch($_tipo) {
                        case 1:
                            $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                            $_resultado = [];
                            $_resultado['statusErro']  = $_neos->enviarPinSMS($_mensagemObj->cod_loja,$_telefone,$_codigo);
                            break;
                        case 2:
                            // API SMS
                            $_capi = new integracao_api_sms($GLOBALS['_MASTER']);
                            $_resultado = $_capi->enviarSMS($_mensagemObj->cod_loja,$_telefone,$_codigo);
                            break;
                        default:
                            $_fabrica_mecanismo_integracao = new sms_zenvia_service_factory();
                            $_fabrica_mecanismo_integracao::$_tipo_envio = 'BON';
                            $_fabrica_mecanismo_integracao::$_texto_sms = 'texto_bonus_sms';
                            $_mecanismo_integracao = $_fabrica_mecanismo_integracao->getInstance();
                            //Tentamos 3 vezes
                            for($i = 0;$i<3;$i++) {
                                $_resultado = $_mecanismo_integracao->sendSmsRequest($_telefone,$_codigo);
                                if($_resultado['statusErro']===false) {
                                    break;
                                }
                            }
                            break;
                    }
                    if ($_resultado['statusErro'] === false) {
                        $_retorno['resultado'] = '0';
                        $_retorno['mensagem'] = 'SMS enviado com sucesso';
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: SMS n�o enviado ap�s 3 tentativas';
                    }
                } else {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Telefone N�o foi informado';
                }
                break;
            /**
             * CADAPROD-17
             * Hist�ria 5
             * BIT Software
             * 12.02.2020
             * Interface para consulta de um produto_acesso com venda �nica
             */
            case 'verificarVendaUnica':
                $_pacesso = new produto_acesso($GLOBALS['_MASTER']);
                $_ret = $_pacesso->verificarSeEVendaUnica($_mensagemObj->dados->produto);
                if($_ret===false) {
                    // Erro no processo
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro ao executar a busca do c�digo de barras';
                } else {
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'OK';
                    $_retorno['dados']->resultado = 0;
                    $_retorno['dados']->venda_unica = $_ret;
                }
                break;// CADPROD-17
            case 'consultarEstoque':
                $_estoque = new est_produto_local($GLOBALS['_MASTER']);
                $_ret = $_estoque->consultarEstoque($_mensagemObj->cod_loja, $_mensagemObj->dados->codigo_produto, $_mensagemObj->dados->codigo_lido, $_mensagemObj->dados->quantidade_acumulada);
                $_retorno['resultado'] = $_ret['resultado'];
                $_retorno['mensagem'] = $_ret['mensagem'];
                $_retorno['dados']->resultado = $_ret['saldo'];
                break;
            case 'consultarClienteCadPremiado':
                $_dados = $_mensagemObj->dados;
                $_cpf = '';

                foreach ($_dados->perguntas_chaves as $_valor)
                {
                    $_cpf = $_valor->resposta;
                    continue;
                }

                if (empty($_dados))
                {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Nenhum dado enviado para processar';
                }
                else
                {
                    try
                    {
                        $_mov_dados_coleta = funcoesGerais::InstanciaClasse(
                            'mov_dados_coleta',
                            $GLOBALS['_MASTER']
                        );
                        $_buscar_cliente = $_mov_dados_coleta->buscarClienteCadPremiado(
                            $_cpf,
                            $_dados->cod_formulario
                        );

                        $_retorno = Array();
                        $_retorno['resultado'] = '0';
                        $_retorno['cod_loja'] = $_mensagemObj->cod_loja;
                        $_retorno['cod_pdv'] = $_mensagemObj->cod_pdv;
                        $_retorno['dados'] = [];

                        if (!empty($_buscar_cliente))
                        {
                            $_mov_dados_coleta_resp = funcoesGerais::InstanciaClasse(
                                'mov_dados_coleta_resp',
                                $GLOBALS['_MASTER']
                            );
                            $_cliente_respostas = $_mov_dados_coleta_resp->buscarRespostasCliente(
                                $_buscar_cliente['ID_CLIENTE'],
                                $_buscar_cliente['COD_LOJA'],
                                $_dados->cod_formulario
                            );
                            if (!empty($_cliente_respostas))
                            {
                                $_retorno['dados']['perguntas'] = [];
                                foreach ($_cliente_respostas as $_cod_pergunta => $_resposta)
                                {
                                    $_retorno['dados']['perguntas'][] = [
                                        'cod_pergunta' => $_cod_pergunta,
                                        'resposta' => $_resposta
                                    ];
                                }
                            }
                        }
                    }
                    catch (Exception $_exception)
                    {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Ocorreu um erro ao consultar o cliente: ' . $_exception->getMessage();
                        funcoesGerais::GravaLog(
                            '[COMUNICACAO_PDV][Linha ' . __LINE__ . '] Ocorreu um erro ao consultar o cliente: ' . $_exception->getMessage(),
                            true,
                            true
                        );
                    }
                }
                break;
            /**
             * AMEDIGITAL-1
             * BIT Software
             * Dez/2020
             * M�todos para integra��o com AME digital
             */
            case 'dispararQRCodePagamento':
                $_html_entities = false;
                $_ic = new integracao_callback($GLOBALS['_MASTER']);
                $_ret = $_ic->criarOrdemIntegrador($_mensagemObj->cod_loja,$_mensagem->cod_pdv,$_mensagemObj->dados);
                $_retorno['resultado'] = $_ret->resultado;
                if($_ret->resultado==0) {
                    $_retorno['dados']->resultado = 0;
                    $_retorno['dados']->conteudo_integrador = $_ret->conteudoIntegrador;
                } else {
                    $_retorno['mensagem'] = $_ret->mensagem;
                }
                break;
            case 'consultarStatusPagamento':
                $_ic = new integracao_callback($GLOBALS['_MASTER']);
                $_ret = !empty($_mensagemObj->dados->id) ? $_ic->Buscar([$_mensagemObj->dados->tipo,$_mensagemObj->dados->id]) : $_ic->bucarCallBackPorIdPDV($_mensagemObj->dados->tipo,$_mensagemObj->dados->id_pdv);
                if($_ret===false) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Transa��o de callBack n�o encontrada pelo id enviado';
                } else {
                    $_retorno['dados']->resultado = 0;
                    $_retorno['dados']->pendenteRespostaIntegrador = ($_ic->zGet('_status')==$_ic::PENDENTE);
                    $_retorno['dados']->nsu = $_ic->zGet('_cod_autorizacao');
                    $_retorno['dados']->conteudo_integrador = json_decode($_ic->zGet('_retorno'));
                }
                break;
            case 'cancelarPagamento':
                $_ic = new integracao_callback($GLOBALS['_MASTER']);
                $_ret = $_ic->cancelarPagamentoIntegrador($_mensagemObj->cod_loja,$_mensagem->cod_pdv,$_mensagemObj->dados);
                $_retorno['resultado'] = $_ret->resultado;
                if($_ret->resultado==0) {
                    $_retorno['dados']->resultado = 0;
                    $_retorno['dados']->conteudo_integrador = $_ret->conteudoIntegrador;
                } else {
                    $_retorno['mensagem'] = $_ret->mensagem;
                }
                break;
            case 'buscarUltimoNumeroZanthus':
                $_movdb = new movdb_1tra($GLOBALS['_MASTER']);
                $_ret = $_movdb->retornarUltimoNumeroZanthus($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv);
                if($_ret == false) {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = 'Consulta ultimo numero Zanthus: resposta sem numero Zanthus';
                } else {
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = 'OK';
                    $_retorno['dados']['numero_zanthus'] = $_ret['IDENTIFICADOR'];
                }
                break;
            case 'enviarFitaDetalhe':
                $_retorno['dados'] = []; // N�o preciso retornar os dados enviados.
                $_loja = $_mensagemObj->cod_loja;
                $_pdv = $_mensagemObj->cod_pdv;
                $_dta_movimento = $_mensagemObj->dados->data;
                $_num_operacao = $_mensagemObj->dados->coo;
                $_info1 = $_mensagemObj->dados->info1;
                $_info2 = $_mensagemObj->dados->info2;
                $_conteudo = $_mensagemObj->dados->conteudoComprimido;
                $_movdb = new movdb_1tra($GLOBALS['_MASTER']);
                $_ret = $_movdb->retornarDocumento($_num_operacao, $_dta_movimento, $_loja, $_pdv);
                if($_ret == false) {
                    $_ret = $_movdb->inserirDocumento($_loja, $_pdv, $_dta_movimento, $_num_operacao, $_info1, $_info2, $_conteudo);
                    if($_ret == true) {
                        $_retorno['resultado'] = 0;
                        $_retorno['mensagem'] = 'OK';
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Ocorreu um erro ao inserir o documento: ' . $_exception->getMessage();
                    }
                } else {
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = 'O documento j� foi inserido no banco de dados.';
                }
                break;
            case 'registrarCTIMP':
                $_ctimp = new ctimp($GLOBALS['_MASTER']);
                $_ret = $_ctimp->registrarCTIMP($_mensagemObj->cod_loja, $_mensagemObj->dados);
                $_retorno['resultado'] = (!$_ret) ? 1 : 0;
                $_retorno['mensagem'] = '';
                $_retorno['dados'] = [
                    'resultado' => (!$_ret) ? 1 : 0,
                    'mensagem' => (!$_ret) ? 'erro ao registrar o CTIMP' : '',
                    'dados' => $_mensagemObj->dados,
                ];
                break;
            case 'tratarRespostaCTIMP':
                $_ctimp = new ctimp($GLOBALS['_MASTER']);
                $_ret = $_ctimp->atualizarStatusImpressao($_mensagemObj->cod_loja,$_mensagemObj->dados);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem'] = '';
                $_retorno['dados'] = [
                    'resultado' => (!$_ret) ? 1 : 0,
                    'mensagem' => (!$_ret) ? 'erro ao atualizar o status do pedido ou item' : '',
                ];
                break;
            case 'pegarListaCTIMPs':
                $_ctimp = new ctimp($GLOBALS['_MASTER']);
                $_Lista_ctimp = $_ctimp->listarCtimpPDV($_mensagemObj->cod_loja);
                $_retorno['resultado'] = 0;
                $_retorno['mensagem'] = '';
                $_retorno['dados'] = [
                    'resultado' => (!$_Lista_ctimp) ? 1 : 0,
                    'lista' => $_Lista_ctimp,
                ];
                break;
            /**
             * CADCLIPDV-7
             * CADCLIPDV-8
             * BIT
             * Set.2021
             * NEW-443
             * BIT
             * Fev.2024
             * Novo tratamento
             */
            case 'solicitarCamposCadastro':
                if(!isset($_mensagemObj->dados->arquivo) && $_mensagemObj->dados->modo_consulta) {
                    switch($_mensagemObj->dados->modo_consulta) {
                        case 2:
                            $_classe = new integracao_credsystem($GLOBALS['_MASTER']);
                            $_res_credsystem = $_classe->retornarCamposObrigatorios($_mensagemObj);

                            if($_res_credsystem){
                                $_retorno['resultado']  = 0;
                                $_retorno['mensagem']   = '';
                                $_retorno['dados']      = [
                                    'resultado' => 0,
                                    'mensagem'  => 'OK',
                                    'campos'    => $_res_credsystem
                                ];
                            }else {
                                $_retorno['resultado']  = 1;
                                $_retorno['mensagem']   = '';
                                $_retorno['dados']      = [
                                    'resultado' => 1,
                                    'mensagem'  =>  utf8_encode("N�o foi poss�vel retornar os campos obrigat�rios dos integradores.")
                                ];
                            }
                            break;
                        default:
                            $_retorno['resultado']  = 1;
                            $_retorno['mensagem']   = '';
                            $_retorno['dados']      = [
                                'resultado' => 1,
                                'mensagem'  =>  utf8_encode("Campos obrigat�rios n�o dispon�veis")
                            ];
                    }
                } else {
                    $_json = null;
                    switch($_mensagemObj->dados->arquivo) {
                        case 10:
                            $_cliente_identificado = ($_mensagemObj->dados->cliente) ? true : false;

                            if($_cliente_identificado&&$_mensagemObj->dados->atualizacao!=1){
                                $_cliente_endereco = funcoesGerais::InstanciaClasse('cliente_endereco', $GLOBALS['_MASTER']);
                                $_json = $_cliente_endereco->geraSdfClienteEndereco();
                            } else {
                                $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS['_MASTER']);
                                $_json_aux = $_cliente->retornarCamposCliPDV();
                                $_json = json_decode($_json_aux);
                                if($_cliente_identificado&&$_mensagemObj->dados->atualizacao==1) {
                                    if($_cliente->Buscar($_mensagemObj->dados->cliente)) {
                                        foreach($_json as $_idx => $_campo) {
                                            if($_campo->campo=='NUM_CGC') {
                                                unset($_json[$_idx]);
                                            } else {
                                                $_campo->default = $_cliente->zGet('_' . strtolower($_campo->campo));
                                                switch($_campo->tipo){
                                                    case 'DATE':
                                                        $_campo->default = funcoesGerais::retornarNumeros(funcoesGerais::converte_data($_campo->default, $GLOBALS['_MASTER']->getBDType(), 'dmy', false, null));
                                                        break;
                                                    case 'TEL':
                                                        $_campo->default = funcoesGerais::retornarNumeros($_campo->default);
                                                        break;
                                                    default:
                                                        break;
                                                }
                                            }
                                        }
                                    }
                                    $_json = array_values($_json);
                                } else {
                                    $_chave_arquivo = 'arquivo10';
                                    $_retorno['dados']->$_chave_arquivo = $_cliente->geraSdfClienteFidelidade();
                                    $_retorno['dados']->retagcli = $_cliente->geraSdfClienteFidelidadeRetag();
                                }
                            }
                            $_retorno['dados']->resultado = empty($_json) ? 1 : 0;
                            $_retorno['dados']->mensagem = empty($_json) ? "Cadastro do arquivo nao encontrado" : "OK";
                            $_retorno['dados']->campos = empty($_json)?"":$_json;
                            break;
                        default:
                            $_retorno['dados']->resultado = 1;
                            $_retorno['dados']->mensagem = "Arquivo {$_mensagemObj->dados->arquivo} nao disponivel";
                    }
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = '';
                }
                break;
            case 'criarCadastro':
                $_dados = $_mensagemObj->dados->cadastro;
                $_campo_retorno = "chave";
                switch($_mensagemObj->dados->arquivo) {
                    case 10:
                        // Cadastrar o cliente
                        $_cli = funcoesGerais::InstanciaClasse('cliente', $_MASTER);
                        $_ret = $_cli->gravarClientePDV($_dados,$_mensagemObj->dados->operador,($_mensagemObj->dados->cliente) ? $_mensagemObj->dados->cliente : null, $_mensagemObj->cod_loja,($_mensagemObj->dados->atualizacao==1));
                        if($_ret['sucesso']) {
                            $_campo_retorno = "cod_cli";
                            $_retorno['resultado'] = 0;
                            $_ret['mensagem'] = '';
                        }
                        break;
                    default:
                        $_ret['sucesso'] = false;
                        $_ret['mensagem'] = "Arquivo {$_mensagemObj->dados->arquivo} n�o dispon�vel";
                }
                $_retorno['resultado'] = 0;
                $_retorno['mensagem'] = '';
                $_retorno['dados']->resultado = $_ret['sucesso'] ? 0: 1;
                $_retorno['dados']->mensagem = $_ret['mensagem'];
                if($_ret['chave']) {
                    $_retorno['dados']->{$_campo_retorno} = $_ret['chave'];
                }
                break;
            case 'consultaCredProm':
                $_loja = $_mensagemObj->cod_loja;
                $_pdv = $_mensagemObj->cod_pdv;
                $_dados = $_mensagemObj->dados;

                $_vale_credito = new vale_credito($GLOBALS['_MASTER']);

                $_retorno['resultado'] = '0';

                $_dados->cliente = $_vale_credito->verificaCodClienteCPF($_loja, $_dados->cliente);

                if($_dados->empenhar){
                    //Se for necessario empenhar, retornar um unico vale credito e empenhar
                    $_resultado = $_vale_credito->retornaMaiorSaldoDisponivel($_loja, $_pdv, $_dados);
                    if($_resultado !== false){
                        $_retorno['dados']->dados_vale_credito = $_resultado;
                    }else{
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro ao consultar ou empenhar o vale credito';
                    }
                }else {
                    $_retorno['dados']->dados_vale_credito = $_vale_credito->retornaSaldoValeCredito($_dados->cliente, $_loja, $_dados->categorias, $_dados->codigos_promocao);

                    foreach($_retorno['dados']->dados_vale_credito['det'] as $_key => $_val){
                        unset($_retorno['dados']->dados_vale_credito['det'][$_key]['vlr_vale_credito']);
                    }
                }
                break;
            case 'removeEmpenho':
                $_loja = $_mensagemObj->cod_loja;
                $_pdv = $_mensagemObj->cod_pdv;
                $_dados = $_mensagemObj->dados;

                $_retorno['resultado'] = '0';

                $_vale_credito = new vale_credito($GLOBALS['_MASTER']);
                $_dados->cliente = $_vale_credito->verificaCodClienteCPF($_loja, $_dados->cliente);

                $_vc_cpf = new vale_credito_cpf($GLOBALS['_MASTER']);
                $_vc_cpf->Zset('_cod_vale_credito', $_dados->id);
                $_vc_cpf->Zset('_cpf', $_dados->cliente);

                $_dados->cod_loja = $_loja;
                $_dados->num_pdv = $_pdv;
                $_resultado = $_vc_cpf->removeEmpenho($_dados);

                if($_resultado !== false){
                    $_retorno['dados']->dados_vale_credito = $_resultado;
                }else{
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro ao cancelar o empenho do vale credito';
                }
                break;
            case 'camposAceiteTermo':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS["_MASTER"]);
                    $_dados = $_cliente->getDadosClienteTermoFidelidade($_mensagemObj->dados);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem']  = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'aceiteTermoFidelidade':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS["_MASTER"]);
                    $_ret = $_cliente->atualizaTermoFidelidadePDV($_mensagemObj->loja,$_mensagemObj->dados);
                    if(is_array($_ret)){
                        $_retorno = array_merge($_retorno,$_ret);
                    }else {
                        $_retorno['resultado'] = ($_ret) ? '3' : '1';
                        $_retorno['mensagem'] = ($_ret) ? "" : "Falha ao atualizar termo";
                    }
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'consultaParaAceite':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS["_MASTER"]);
                    $_ret = $_cliente->atualizaTermoFidelidadePDV($_mensagemObj->cod_loja,$_mensagemObj->dados,true);
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = $_ret['msg'];
                    $_retorno['dados']->estado_atualizacao = $_ret['estado_atualizacao'];
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'consultaListaMCli':
                try{
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS["_MASTER"]);
                    $_ret = $_cliente->getListaBrindes($_mensagemObj->cod_loja,$_mensagemObj->dados->cliente);
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = $_ret['msg'];
                    $_retorno['dados']->mercadorias = $_ret['mercadorias'];
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /*
             * INTDOTZ-1
             * BIT
             * Mai.2022
             */
            case 'consultarClienteDotz':
                $_dotz = new integracao_dotz($_MASTER);
                $_dotz->consultarCliente($_mensagemObj->cod_loja,$_mensagemObj->dados->identificacao,$_retorno);
                break;
            case 'enviarOptInClienteDotz':
                $_dotz = new integracao_dotz($_MASTER);
                $_dotz->enviarOptin($_mensagemObj->cod_loja,$_mensagemObj->dados->identificacao,$_mensagemObj->dados->celular,$_retorno);
                break;
            /**
             * CASHBACKABERTO-1
             * BIT
             * Set.2022
             */
            case 'consultarSaldoCashback':
                switch($_mensagemObj->dados->tipo) {
                    case 1:
                        $_ca = new cashback_aberto($_MASTER);
                        $_resp = $_ca->consultarCliente($_mensagemObj->cod_loja,$_mensagemObj->dados->cpf_cnpj_cli,$_mensagemObj->dados->categorias);
                        $_retorno['resultado'] = 0;
                        if($_resp->sucesso) {
                            $_retorno['dados']->resultado = 0;
                            if($_resp->consultousaldo) {
                                $_retorno['dados']->saldo = $_resp->saldo;
                            }
                            $_retorno['dados']->consultou_saldo = $_resp->consultousaldo;
                        } else {
                            $_retorno['dados']->resultado = 1;
                            $_retorno['dados']->mensagem = $_resp->mensagem;
                        }
                        break;
                    default:
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Tipo informado � inv�lido';
                }
                break;

            case 'controleSeguro':
                /**
                 * A ideia aqui e poder agrupar as requisicoes por subtipo,
                 * Isso ajuda na otimiza��o e um c�digo mais limpo.
                 * Evita de ficar criando muitos m�todos no comunicacao_pdv.php5
                 */
                try {
                    $_seguro_pdv = new seguro_pdv($_MASTER);
                    $_retorno_funcao = $_seguro_pdv->tratarComunicacao($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados);
                    $_retorno['resultado'] = '0';
                    if(isset($_retorno_funcao["html_entities"])){
                        $_html_entities = $_retorno_funcao["html_entities"];
                        unset($_retorno_funcao["html_entities"]);
                    }
                    if($_retorno_funcao === false){
                        $_retorno_funcao = '1';
                    }
                    $_retorno['dados']->retorno = $_retorno_funcao;
                }catch(Exception $e){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * CRIPTSENHA-1
             * Rodilson
             * 09/09/2022 - Ult atualiz: 13/09/2022
             * Faz o cadastramento de nova senha ou altera a senha atual para o Cliente informado atraves do PDV .
             */
            case 'cadastrarSenhaCriptoCli':
                try{
                    $_cli = new autentica_cliente($GLOBALS['_MASTER']);
                    $_cli->cadastrarSenhaCriptoCli($_mensagemObj, $_retorno);
                }catch(Exception $e) {
                    $_retorno['resultado'] = !isset($_retorno['resultado']) ? '1' : $_retorno['resultado'];
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * CRIPTSENHA-1
             * Rodilson
             * 09/09/2022 - Ult atualiz: 13/09/2022
             * Retorna os dados para o Cliente consultado pelo PDV.
             */
            case 'consultarSenhaCriptoCli':
                try{
                    $_cli = new autentica_cliente($GLOBALS['_MASTER']);
                    $_cli->consultarSenhaCriptoCli($_mensagemObj, $_retorno);
                }catch(Exception $e) {
                    $_retorno['resultado'] = !isset($_retorno['resultado']) ? '1' : $_retorno['resultado'];
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * CRIPTSENHA-1
             * Rodilson
             * 09/09/2022 - Ult atualiz: 13/09/2022
             * Valida a senha do cliente informado no PDV e retorna status.
             */
            case 'validarSenhaCriptoCli':
                try{
                    $_cli = new autentica_cliente($GLOBALS['_MASTER']);
                    $_cli->validarSenhaCriptoCli($_mensagemObj, $_retorno);
                }catch(Exception $e) {
                    $_retorno['resultado'] = !isset($_retorno['resultado']) ? '1' : $_retorno['resultado'];
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * CRIPTSENHA-1
             * Rodilson
             * 16/09/2022 - Ult atualiz: 16/09/2022
             * Retorna a vers�o atual desta api para uso pelo PDV.
             * Retorna sucesso e a versaoAtual = 1.00
             * Solicitado pelo Celso/Marcelo Jr.
             */
            case 'retornarVersaoZanthusApiRest':
                try{
                    $_retorno['resultado']          = 0;
                    $_retorno['mensagem']           = 'OK';
                    $_retorno['dados']->versaoAtual = '1.00';
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'validaCupomCancelamento':
                //REEMULTIPAG-13
                //Verifica se o cupom informado e valido para cancelamento
                //Definicao inicial: Caso possuir reembolso/troca, nao considera disponivel
                $_devolucao = funcoesGerais::InstanciaClasse('devolucao', $_MASTER);
                try{
                    $_erro = $_devolucao->validaCupomCancelamento($_mensagemObj->dados->data, $_mensagemObj->dados->loja,$_mensagemObj->dados->pdv,$_mensagemObj->dados->cupom,$_mensagemObj->dados->cro);
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = '';
                    $_retorno['dados']->resultado = ($_erro) ? 1 : 0;
                    $_retorno['dados']->mensagem = $_erro;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * SAQUEMERG-18
             * Webservice para validar se o cliente � eleg�vel para o saque emergencial.
             * Caroline Mella
             * 22/03/2022
             *
             * Rev. Rodilson M. Federico
             * 12/2022
             *
             * Retorna "true" se o cliente � elegivel ou "false" nos demais casos.
             */
            case 'ConsultaElegivelSaque':
                $_cliente = new cliente_comunicado($GLOBALS['_MASTER']);
                $_ret = $_cliente->validarClienteElegivel($_mensagemObj->dados->cpf_cnpj);

                if($_ret === false) {
                    $_retorno['dados']->elegivel = false;
                    $_retorno['dados']->resultado = 1;
                } else {
                    $_retorno['dados']->elegivel = true;
                    $_retorno['dados']->resultado = 0;
                }
                break;
            /**
             * SAQUEMERG-21
             * Rodilson M. Federico
             * 11/2022 - Ult atualiz: 11/2022
             * Retorna os Saques e Estornos ocorridos nos �ltimos 7 dias para o CPF/CNPJ consultado pelo PDV.
             */
            case 'consultarSaquesEfetuados':
                $_cli = new mov_evento_cliente($GLOBALS['_MASTER']);
                $_cli->consultarSaquesEfetuados($_mensagemObj, $_retorno);
                break;
            case 'criarPedidoShellbox':
                try{
                    $_shellbox = funcoesGerais::InstanciaClasse('integracao_shellbox', $GLOBALS["_MASTER"]);
                    $_ret = $_shellbox->enviarPedido($_mensagemObj);
                    $_retorno['dados'] = $_ret;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'consultarPagamentoShellbox':
                try{
                    $_shellbox = funcoesGerais::InstanciaClasse('integracao_shellbox', $GLOBALS["_MASTER"]);
                    $_ret = $_shellbox->consultarPedido($_mensagemObj);
                    $_retorno['resultado'] = 0;
                    $_retorno['dados'] = $_ret;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'confirmarPagamentoShellbox':
                try{
                    $_shellbox = funcoesGerais::InstanciaClasse('integracao_shellbox', $GLOBALS["_MASTER"]);
                    $_ret = $_shellbox->confirmarPedido($_mensagemObj);
                    $_retorno['resultado'] = 0;
                    $_retorno['dados'] = $_ret;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'cancelarPedidoShellbox':
                try{
                    $_shellbox = funcoesGerais::InstanciaClasse('integracao_shellbox', $GLOBALS["_MASTER"]);
                    $_ret = $_shellbox->cancelarPedido($_mensagemObj);
                    $_retorno['resultado'] = 0;
                    $_retorno['dados'] = $_ret;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem']  = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'buscaDadosLoja':
                try{
                    $_loja = funcoesGerais::InstanciaClasse('empresa', $GLOBALS['_MASTER']);
                    $_dados_interface = $_loja->buscarDadosInterface($_mensagemObj->cod_loja);
                    if(!$_dados_interface) {
                        throw new Exception('Erro ao buscar os dados da loja para interface');
                    }
                    $_retorno['resultado'] = 0;
                    $_retorno['mensagem'] = 'OK';
                    $_retorno['dados'] = $_dados_interface;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * PROMOCONVEXT-1
             * Rodilson M. Federico
             * Set/2023
             * Consulta as API�s ativas para as promo��es Externas atrav�s do Manager que exijam a
             * identifica��o do cliente durante a venda (inicio) e devolve as informa��es obtidos ao PDV
             */
            case 'consultarClientePromocaoExtManager':
                try{
                    $_html_entities = false;
                    $_obj = new zm_promocoes_externas($GLOBALS['_MASTER']);
                    $_obj->consultarClientePromocoesExternas($_mensagemObj, $_retorno);
                } catch(Exception $e) {
                    $_retorno['resultado'] =  ($e->getCode() != 0) ? $e->getCode() : 1;
                    $_retorno['mensagem'] = 'Erro: ' . mb_convert_encoding($e->getMessage(), 'ISO-8859-1');
                    throw $e; // Repassando para tratar banco offline
                }
                break;

            /**
             * INTVASHKN-1
             * Rodilson M. Federico
             * Jun/2023
             * Consulta as promo��es Externas atrav�s do manager e devolve os descontos obtidos ao PDV
             */
            case 'consultarPromocaoExtManager':
                try{
                    $_html_entities = false;
                    $_obj = new zm_promocoes_externas($GLOBALS['_MASTER']);
                    $_obj->consultarPromocoesExternas($_mensagemObj, $_retorno);
                } catch(Exception $e) {
                    if ($_retorno['resultado'] == ''){
                        $_retorno['resultado'] =  ($e->getCode() != 0) ? $e->getCode() : 1;
                        $_retorno['mensagem'] = 'Erro: ' . mb_convert_encoding($e->getMessage(), 'ISO-8859-1');
                    }
                    throw $e; // Repassando para tratar banco offline
                }
                break;

            /**
             * INTVASHKN-1
             * Rodilson M. Federico
             * Jun/2023
             * Cancela o empenho/Bloqueio dos valores empenhados em cada API Externa atrav�s do manager.
             */
            case 'cancelarBloqPromocaoExtManager':
                try{
                    $_html_entities = false;
                    $_obj = new zm_promocoes_externas($GLOBALS['_MASTER']);
                    $_obj->cancelarPromocoesExternas($_mensagemObj, $_retorno);
                }catch(Exception $e) {
                    if ($_retorno['resultado'] == ''){
                        $_retorno['resultado'] =  ($e->getCode() != 0) ? $e->getCode() : 1;
                        $_retorno['mensagem'] = 'Erro: ' . mb_convert_encoding($e->getMessage(), 'ISO-8859-1');
                    }
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * INTEGRAMERCAFACIL-1
             * BIT
             * Nov.2023
             */
            case 'interacoesPromocaoExtManager':
                try {
                    $_html_entities = false;
                    $_obj = new zm_promocoes_externas($GLOBALS['_MASTER']);
                    $_obj->interacaoPromocaoExterna($_mensagemObj, $_retorno);
                } catch(Exception $e) {
                    if($_retorno['resultado']=='') {
                        $_retorno['resultado'] =  $e->getCode() ?: 1;
                        $_retorno['mensagem'] = 'Erro: ' . mb_convert_encoding($e->getMessage(), 'ISO-8859-1');
                    }
                    throw $e;
                }
                break;
            /**
             * BASE-4395
             * Mai.2024
             * Consulta o saldo dispon�vel para promo��o externa.
             * A princ�pio s� esta sendo utilizando pela OXMA
             */
            case 'consultaSaldoPromocaoExtManager':
                try {
                    $_html_entities = false;
                    $_obj = new zm_promocoes_externas($GLOBALS['_MASTER']);
                    $_obj->consultaSaldoPromocaoExtManager($_mensagemObj, $_retorno);
                }catch (Exception $e){
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                    throw $e;
                }
                break;
            case 'consultarTemplates':
                try{
                    $_template = funcoesGerais::InstanciaClasse('interface_pdv',$GLOBALS['_MASTER']);
                    $_dados = $_template->listarProjetos($_mensagemObj->loja, $_mensagemObj->fn,$_mensagemObj->dados->pdv,$_mensagemObj->dados->tipoInterface);
                    $_retorno['resultado'] = '3';
                    $_retorno['mensagem']  = $_dados;
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'gravarRespostaNPSInterface':
                try{
                    $_pesquisa = funcoesGerais::InstanciaClasse('pesquisa_satisfacao_pdv',$GLOBALS['_MASTER']);
                    $_ret_pesq = $_pesquisa->gravarRespostaInterface($_mensagemObj);
                    if($_ret_pesq) {
                        $_retorno['resultado'] = '3';
                    }else{
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro ao gravar resposta';
                    }
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            /**
             * CONTROLEFROTA-1
             * BIT
             * Jul.2023
             */
            case 'consultaVeiculosCliente':
                /**
                 * @var cliente_veiculo $_cv
                 */
                $_cv = funcoesGerais::InstanciaClasse('cliente_veiculo', $GLOBALS['_MASTER']);
                $_ret = $_cv->consultaVeiculosCliente($_mensagemObj->cod_loja,$_mensagemObj->dados->cpfcnpj);
                if($_ret->resultado==1) {
                    $_ret->veiculos = [];
                } elseif($_ret->resultado!=0) {
                    $_ret->veiculos = [];
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = $_ret->mensagem;
                }
                unset($_ret->resultado,$_ret->mensagem);
                $_retorno['dados'] = $_ret;
                break;
            /**
             * RESGATECARRINHO-1
             * BIT
             * Ago.2023
             */
            case 'PedsuspSuspendeVenda':
            case 'pedsuspsuspendevenda':
                try {
                    /**
                     * @var zan_pedido $_pedido
                     */
                    $_pedido = funcoesGerais::InstanciaClasse('zan_pedido', $GLOBALS['_MASTER']);
                    $_dados = $_pedido->inserirPedidoResgateCarrinho($_mensagemObj->dados, $_mensagemObj->cod_loja,$_mensagemObj->cod_pdv);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $_dados;
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            case 'PedsuspRecuperaOuPesquisaPedidos':
            case 'pedsusprecuperaoupesquisapedidos':
                try {
                    /**
                     * @var zan_pedido $_pedido
                     */
                    $_pedido = funcoesGerais::InstanciaClasse('zan_pedido', $GLOBALS['_MASTER']);
                    $_dados = $_pedido->recuperarPedidoResgateCarrinho($_mensagemObj->cod_loja,$_mensagemObj->dados->cpfcnpj,$_mensagemObj->cod_pdv);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $_dados;
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * ENVIAQRCODECLI-1
             * Grupo Pereira
             * Out.2023
             */
            case 'enviarNotificacaoCliente':
                try {
                    $_obj = new whatsapp_zenvia($GLOBALS['_MASTER']);
                    $_obj->enviarNotificacaoCliente($_mensagemObj, $_retorno);
                } catch (Exception $e) {
                    $_retorno['resultado'] = !isset($_retorno['resultado']) ? '1' : $_retorno['resultado'];
                    $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'buscarCadastroClienteSimplificado':
                try {
                    $_classe = new cliente_simplificado($GLOBALS['_MASTER']);
                    $_retorno = $_classe->buscarCamposCadastroCliente($_mensagemObj->cod_loja);
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * ARQUICFG-1
             * BIT
             * Jan.2024
             */
            case 'enviarPerfilCFG':
                try {
                    /**
                     * @var perfil_cfg_arquivo $_perfilcfg
                     */
                    $_perfilcfg = funcoesGerais::InstanciaClasse('perfil_cfg_arquivo', $GLOBALS['_MASTER']);
                    $_ret = $_perfilcfg->upLoadPerfil($_mensagemObj->cod_loja,$_mensagemObj->dados->arquivos);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $_ret;
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                    throw $e;
                }
                break;
            case 'consultarPerfilCFG':
                try {
                    /**
                     * @var perfil_cfg_arquivo $_perfilcfg
                     */
                    $_perfilcfg = funcoesGerais::InstanciaClasse('perfil_cfg_arquivo', $GLOBALS['_MASTER']);
                    $_ret = $_mensagemObj->dados->acao==0 ? $_perfilcfg->retornarVersaoAtualPerfil($_mensagemObj->cod_loja,$_mensagemObj->dados->perfilcfg,$_mensagemObj->dados->versaoAtual) : $_perfilcfg->downloadPerfil($_mensagemObj->cod_loja,$_mensagemObj->dados->perfilcfg,$_mensagemObj->dados->versaoDownload);
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $_ret;
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: ' . $e->getMessage();
                    throw $e;
                }
                break;
            case 'verificarPreCadastro':
                try {
                    $_par = funcoesGerais::retornarValorParametro('local_consulta_pre_cad_cli');
                    $_ret = false;
                    if(($_par&2)>0) {
                        // Vamos na Neos
                        $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                        $_ret = $_neos->verificarClienteFidelizado($_mensagemObj->cod_loja,$_mensagemObj->dados->cpfcnpj);
                    }
                    if($_ret===false&&(($_par&1)>0||empty($_par))) {
                        /**
                         * @var cliente_precadastro $_objpcad
                         */
                        $_objpcad = funcoesGerais::InstanciaClasse('cliente_precadastro',$GLOBALS['_MASTER']);
                        $_ret = $_objpcad->verificarPreCadastro($_mensagemObj->dados->cpfcnpj);
                    }
                    $_retorno['resultado'] = '0';
                    $_retorno['dados']->existe = $_ret!==false ? 'S' : 'N';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * BASE-3195
             * BIT
             * Mar.2024
             */
            case 'mensagemPosVenda':
                $_html_entities = false;
                $_objM = new exibicao_mensagem($GLOBALS['_MASTER']);
                $_retorno['dados'] = $_objM->responderEventoPDV(1,$_mensagemObj->cod_loja, $_mensagemObj->dados);
                break;
            /**
             * NEW-476
             * BIT
             * Mar.2024
             */
            case 'consultaMercadoriaPorDescricao':
                try {
                    $_mercadoria = new mercadoria($GLOBALS['_MASTER']);
                    $_termo = utf8_decode($_mensagemObj->dados->descricao);
                    $_dados = $_mercadoria->retornarListProdutosProDescricao($_mensagemObj->cod_loja, $_termo,$_mensagemObj->dados->tipovenda);
                    $_retorno['resultado'] = 0;
                    $_retorno['dados'] = ["resultado"=>$_dados];
                } catch(Exception $_e) {
                    $_retorno['resultado'] = $_e->getCode() ?: 1;
                    $_retorno['mensagem'] = $_e->getMessage();
                    throw $_e;
                }
                break;
            /**
             * NEW-401
             * BIT
             * Fev.2024
             */
            case 'CrmBonusApiInicio':
                $_metodo = 'iniciar';
            case 'CrmApiValidarPin':
                $_metodo = $_metodo ?: 'validarPin';
            case 'CrmApiReenviarPin':
                $_metodo = $_metodo ?: 'reenviarPin';
            case 'CrmApiBonusDisponivel':
                $_metodo = $_metodo ?: 'consultarBonusDisponivel';
            case 'CrmApiConsultaBonus':
                $_metodo = $_metodo ?: 'consultarBonus';
            case 'CrmApiCampanhaDisponivel':
                $_metodo = $_metodo ?: 'consultarCampanhaDisponivel';
            case 'CrmApiFinalizaCompra':
                $_metodo = $_metodo ?: 'finalizarCompra';
            case 'CrmApiEnviarVenda':
                $_metodo = $_metodo ?: 'enviarVenda';
            case 'CrmApiCancelarBonus':
                $_metodo = $_metodo ?: 'cancelarBonus';
                /**
                 * base-9894
                 * BIT
                 * Mar.2025
                 */
                $_crmb = $_mensagemObj->dados->versao_bonus==2 ? new integracao_crmbonus_v2() : new integracao_crmbonus();
                $_retorno['dados'] = $_crmb->{$_metodo}($_mensagemObj->cod_loja,$_mensagemObj->dados);
                break;
            case 'CrmApiConsultaProduto':
                /**
                 * base-9894
                 * BIT
                 * Mar.2025
                 */
                if($_mensagemObj->dados->versao_bonus==2) {
                    $_crmb = new integracao_crmbonus_v2();
                    $_retorno['dados'] = $_crmb->consultarProduto($_mensagemObj->cod_loja,$_mensagemObj->dados);
                } else {
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = 'm�todo n�o suportado na vers�o enviada';
                }
                break;
            case 'consulta-doc-externo':
                try {
                    $_finalizadora = funcoesGerais::InstanciaClasse('finalizadora', $GLOBALS['_MASTER']);
                    $_retorno_pdf = $_finalizadora->consultarDocExterno($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados);
                    $_retorno['resultado'] = $_retorno_pdf['resultado'] ?: 0;
                    $_retorno['mensagem'] = $_retorno_pdf['mensagem'] ?: '';
                    $_retorno['pdf'] = $_retorno_pdf["pdf"];
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * NEW-485
             * BIT
             * Mar.2024
             */
            case 'consultarEstoquePorProximidade':
                /**
                 * @var loja_distancia $_objldist
                 */
                $_objldist = funcoesGerais::InstanciaClasse('loja_distancia', $GLOBALS['_MASTER']);
                $_retorno['resultado'] = 0;
                $_retorno['dados'] = $_objldist->consultarEstoquePorProximidade($_mensagemObj->cod_loja,$_mensagemObj->dados);
                break;
            case 'consultaExtratoCredishop':
                try {
                    $_integracao_credishop = new integracao_credishop($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_integracao_credishop->consultarExtratoCartao($_mensagemObj->cod_loja, $_mensagemObj->dados);
                    $_retorno['resultado'] = '0';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            case 'executaPagamentoCredishop':
                try {
                    $_integracao_credishop = new integracao_credishop($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_integracao_credishop->executarPagamento($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados);
                    $_retorno['resultado'] = '0';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            case 'consultaCancelamentoCredishop':
                try {
                    $_integracao_credishop = new integracao_credishop($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_integracao_credishop->consultarPagamento($_mensagemObj->cod_loja, $_mensagemObj->dados);
                    $_retorno['resultado'] = '0';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            case 'executaCancelamentoCredishop':
                try {
                    $_integracao_credishop = new integracao_credishop($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_integracao_credishop->cancelarPagamento($_mensagemObj->cod_loja, $_mensagemObj->dados);
                    $_retorno['resultado'] = '0';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            case 'integracaoHorizon':
                try {
                    $_integracao_horizon = new integracao_horizon($GLOBALS['_MASTER']);
                    $_retorno['dados']->access_token = $_integracao_horizon->recuperaToken($_mensagemObj->dados->forcaToken, $_mensagemObj->dados->cod_loja);
                    $_retorno['dados']->cod_loja = $_mensagemObj->cod_loja;
                    $_retorno['dados']->forcaToken = $_mensagemObj->dados->forcaToken;
                    $_retorno['resultado'] = '0';
                } catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * base-6105
             * BIT
             * Jun.2024
             */
            case 'ConsultarClienteNEOS':
            case 'consultarClienteNEOS':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                /**
                 * base-9312
                 * BIT
                 * Nov.2024
                 * Teremos dois formatos aqui,
                 * o original de consulta
                 * e outro para envio de email/sms de cadastro
                 */
                if(property_exists($_mensagemObj->dados,"metodo_envio")!==false) {
                    if($_neos->enviarMensagemCliente($_mensagemObj->cod_loja,$_mensagemObj->dados)===false) {
                        $_retorno['dados']->resultado = 1;
                        $_retorno['dados']->mensagem = utf8_encode('O envio da mensagem pela Neos falhou. ' . $_neos->retornarMsgErro());
                    } else {
                        $_retorno['dados']->resultado = 0;
                        $_retorno['dados']->mensagem = "acionado com sucesso o envio pela Neos";
                    }
                } else {
                    if(($_dcli = $_neos->consultarCadastroCliente($_mensagemObj->cod_loja,$_mensagemObj->dados->cpfcnpj))===false) {
                        $_retorno['dados']->resultado = 1;
                        $_retorno['dados']->mensagem = utf8_encode('Erro ao consultar cliente na Neos');
                    } else {
                        $_retorno['dados'] = json::array_utf8_encode_recursive(json::array_utf8_decode_recursive($_dcli));
                        $_retorno['dados']->resultado = 0;
                    }
                }
                break;
            case 'AtualizarClienteNEOS':
            case 'atualizarClienteNEOS':
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if($_neos->atualizarCadastroCliente($_mensagemObj->cod_loja,$_mensagemObj->dados)===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('Erro ao cadastrar o cliente');
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = utf8_encode('Erro ao cadastrar o cliente');
                } else {
                    $_retorno['dados']->resultado = 0;
                }
                break;
            case 'ConsultarFidelidadeSimulacaoNEOS':
            case 'consultarFidelidadeSimulacaoNEOS':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if(($_dados_fidelidade = $_neos->consultarFidelidadeSimulacao($_mensagemObj->cod_loja,$_mensagemObj->dados))===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('Erro ao consultar dados da simula��o da fidelidade');
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = $_retorno['dados']->mensagem;
                } else {
                    $_retorno['dados'] = json::array_utf8_encode_recursive(json::array_utf8_decode_recursive($_dados_fidelidade));
                    $_retorno['dados']->resultado = 0;
                }
                break;
            case 'ConsultarFidelidadeBeneficiosNEOS':
            case 'consultarFidelidadeBeneficiosNEOS':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if(($_dados_fidelidade = $_neos->consultarFidelidadeBeneficios($_mensagemObj->cod_loja,$_mensagemObj->dados))===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('Erro ao consultar dados de benef�cios da fidelidade');
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = $_retorno['dados']->mensagem;
                } else {
                    $_retorno['dados'] = json::array_utf8_encode_recursive(json::array_utf8_decode_recursive($_dados_fidelidade));
                    $_retorno['dados']->resultado = 0;
                }
                break;
            case 'ResgatarBeneficioNEOS':
            case 'resgatarBeneficioNEOS':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if(($_dados_resgate = $_neos->resgatarBeneficio($_mensagemObj->cod_loja,$_mensagemObj->dados))===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('Erro ao resgatar benef�cio');
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = $_retorno['dados']->mensagem;
                } else {
                    $_retorno['dados'] = json::array_utf8_encode_recursive(json::array_utf8_decode_recursive($_dados_resgate));
                    $_retorno['dados']->resultado = 0;
                }
                break;
            case 'EstornarBeneficioNEOS':
            case 'estornarBeneficioNEOS':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if(($_dados_estorno = $_neos->estornarBeneficio($_mensagemObj->cod_loja,$_mensagemObj->dados))===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('Erro ao estornar benef�cio');
                    $_retorno['resultado'] = 1;
                    $_retorno['mensagem'] = $_retorno['dados']->mensagem;
                } else {
                    $_retorno['dados'] = json::array_utf8_encode_recursive(json::array_utf8_decode_recursive($_dados_estorno));
                }
                break;
            case 'CancelarTiers':
                try{
                    if(isset($_mensagemObj->dados->identificacao)){

                        $cod_loja  = $_mensagemObj->dados->cod_loja;
                        $identificacao  = $_mensagemObj->dados->identificacao;


                        $_ret = new integracao_petz($GLOBALS['_MASTER']);
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_ret->cancelarTier($cod_loja, $identificacao);
                    }
                }catch(Exception $e){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * base-9919
             * BIT
             * Fev.2025
             * Envio do pre-cadastro para clientes n�o cadastrados na Neos
             */
            case 'preCadastroClienteNeos':
                $_html_entities = false;
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_neos = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                if($_neos->preCadastroCliente($_mensagemObj->cod_loja,$_mensagemObj->dados)===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = utf8_encode('O envio da mensagem pela Neos falhou. ' . $_neos->retornarMsgErro());
                } else {
                    $_retorno['dados']->resultado = 0;
                    $_retorno['dados']->mensagem = "acionado com sucesso o envio pela Neos";
                }
                break;
            case 'AlocarTier':
                try{
                    if(isset($_mensagemObj->dados->cod_pedido)){
                        $_ret = new integracao_petz($GLOBALS['_MASTER']);
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_ret->alocarTier($_mensagemObj->dados->cod_pedido);
                    }
                }catch(Exception $e){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e;
                }
                break;
            /**
             * #NEW-681#
             */
            case 'AutorizaMercApiInicio':
                try {
                    /**
                     * BASE-5657
                     * VALIDA��O EXTERNA DE VENDA PETZ
                     */
                    if(!empty($_mensagemObj->dados->cod_cliente)){
                        $_ret = new integracao_petz($GLOBALS['_MASTER']);
                        //$_emp = new empresa($GLOBALS['_MASTER']);
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_ret->validarCompra($_mensagemObj->cod_loja, $_mensagemObj->dados);

                    }else{

                        $_ret = new integracao_vanguarda_vg($GLOBALS['_MASTER']);
                        $_retorno['resultado'] = '0';
                        $_retorno['dados'] = $_ret->autorizaMerc($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados);
                    }
                } catch(Exception $e) {

                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $e->getMessage();

                    throw $e;
                }
                break;
            case 'solicitaCodTransacaoNumes':
                $_emp = new empresa($GLOBALS['_MASTER']);
                $_xml = $_emp->retornarConfiguracaoXML($_mensagemObj->cod_loja,'dados_api');
                unset($_emp);
                if(empty($_xml)) {
                    if($GLOBALS['_DEBUG']) {
                        funcoesGerais::GravaLog("Loja {$_mensagemObj->cod_loja} n�o configurada para Numes",true,true);
                    }
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: Falha ao obter numero da transacao';
                } else {
                    $_oper = $_mensagemObj->dados->tipo_pdv==1 ? $_xml->op_mobile : $_xml->op_comum;
                    $_codigo_seq = new codigo($GLOBALS['_MASTER']);
                    $_codigo_seq->setcod_campo('NUT_MOV_REST');
                    $_codigo_seq->setcod_loja($_mensagemObj->cod_loja);
                    $_codigo_seq->setnome_tab_max_validacao('MOV_REST');
                    $_seq = $_codigo_seq->retornarCodigo();
                    unset($_codigo_seq);
                    $_num = str_pad($_xml->nut,4,'0',STR_PAD_LEFT) . $_oper . str_pad($_seq,10,'0',STR_PAD_LEFT);
                    $_retorno['dados']->resultado = '0';
                    $_retorno['dados']->numero_transacao = $_num;
                }
                break;
            /**
             * base-2284
             * BIT
             * Ago.2024
             */
            case 'cancelamentoNFCEsincrono':
                $_mov = new movdb($GLOBALS['_MASTER']);
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_retorno['dados']->resultado = 0;
                $_retorno['dados']->mensagem = 'Nota incluida no processo de cancelamento';
                if($_mov->gerarCancelamentoNFCEsincrono($_mensagemObj->cod_loja,$_mensagemObj->dados->id_nfe,$_mensagemObj->dados->cod_cliente)===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = 'Erro ao gerar o cancelamento da Nota';
                }
                break;

            case 'consultaStatusCancNF':
                $_mov = new movdb($GLOBALS['_MASTER']);
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_retorno['dados']->resultado = 0;
                $_retorno['dados']->mensagem = 'Nota cancelada com sucesso';
                if($_mov->consultaStatusCancelamento($_mensagemObj->cod_loja,$_mensagemObj->dados->id_nfe,$_mensagemObj->dados->cod_cliente)===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = 'Pendente de cancelamento';
                }
                break;

            case 'consultaClienteIZIO':
                try {
                    $_objIzi = new integracao_izio($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_objIzi->consultarPessoa($_mensagemObj->cod_loja, $_mensagemObj->dados);
                }catch (Exception $_ex){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_ex->getMessage();

                }
                break;
            case 'cadastraClienteIZIO':
                try {
                    $_objIzi = new integracao_izio($GLOBALS['_MASTER']);
                    $_retorno['dados'] = $_objIzi->inserirPessoaPDV($_mensagemObj->cod_loja, $_mensagemObj->dados);
                }catch (Exception $_ex){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = '';
                }
                break;
            case 'retornaConveniosCliente':
                try {
                    $_objConv = new cliente_convenio($GLOBALS['_MASTER']);
                    $_retorno['resultado'] = '0';
                    $_retConvenioCli = $_objConv->retornaConveniosCliente($_mensagemObj->dados->codcli, $_mensagemObj->dados->cpfcnpj, $_mensagemObj->dados->rne);
                    if(!$_retConvenioCli){throw  new Exception('Falha ao consultar as informacoes na tabela devido a falta de informacao');}
                    else{
                        $_retorno['dados'] = $_retConvenioCli;
                    }
                }catch (Exception $_ex){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_ex->getMessage();
                    $_retorno['dados'];

                }
                break;
            case 'validarCadastroCliente':
                try {
                    $_cliente = funcoesGerais::InstanciaClasse('cliente', $GLOBALS['_MASTER']);
                    $_validado = $_cliente->validarCadastroManager($_mensagemObj->dados);
                    if($_validado['resultado']){
                        throw new Exception($_validado['mensagem']);
                    }
                    $_retorno['resultado'] = '0';
                    $_retorno['dados'] = $_validado['dados'];
                }catch (Exception $_ex){
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_ex->getMessage();
                }
                break;
            /**
             * base-7176
             * BIT
             * Nov.2024
             */
            case 'emitirVoucherVasilhame':
                $_cvas = new vasilhame($GLOBALS['_MASTER']);
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'OK';
                $_cvas->emitirVoucherSobra($_mensagemObj->cod_loja,$_mensagemObj->dados,$_retorno);
                break;
            /**
             * base-2144
             * BIT
             * Jul.2024
             */
            case 'consultarPontosCRMNeos':
                $_cbext = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                $_cr = $_cbext->consultarSaldoDisponivel($_mensagemObj->cod_loja,$_mensagemObj->dados->pdv,$_mensagemObj->dados->cpf_cliente,$_mensagemObj->dados->celular_cliente);
                if($_cr->erro==0) {
                    $_fin = new finalizadora($GLOBALS['_MASTER']);
                    $_fcb = $_fin->retornarFinalizadorasCashBackExterno($_mensagemObj->cod_loja, $_cbext::tipo);
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['dados'] = [
                        'resultado' => '0',
                        "tipo" => "EXT",
                        "tipo_ext" => $_cbext::tipo,
                        "chave" => $_cr->transacao,
                        "bonus" => null,
                        "valor" => $_cr->saldo,
                        "valor_total" => $_cr->saldo,
                        "descricao" => empty($_param_text) ? "CASHBACK CRM NEOS" : $_param_text,
                        "cod_loja" => $_mensagemObj->cod_loja,
                        "data" => date('Y-m-d'),
                        "cod_finalizadora" => $_fcb[0],
                        "flg_permitir_parcial" => 1,
                        "permite_edicao" => $_cr->permite_edicao,
                        "percentual_maximo_compra" => $_cr->percentual_maximo_compra
                    ];
                } else {
                    $_retorno['resultado'] = '1';
                    $_retorno['dados'] = '';
                    $_retorno['mensagem'] = 'Erro! O PDV n�o informou algum par�metro que o m�todo esperava. Verifique o log do Manager.';
                }
                break;
            case 'empenharPontosCRMNeos':
                $_cbext = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                $_rc = $_cbext->empenharCredito($_mensagemObj->cod_loja,$_mensagemObj->dados->cod_pdv,$_mensagemObj->dados->cpf_cliente,null,$_mensagemObj->dados->valor_empenhar,$_mensagemObj->dados->celular_cliente);
                if($_rc->erro!=0) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro! o empenho no CRMNeos falhou';
                } else {
                    $_data = date("d-m-Y");
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = '';
                    $_retorno['dados'] = [
                        'resultado'=> '0',
                        'cod_pdv' => $_mensagemObj->dados->cod_pdv,
                        'data_validade' => $_data,
                        'data_emissao' => $_data,
                        'lancamento_uuid' => $_rc->id_definitivo,
                        'id_definitivo' => $_rc->id_definitivo,
                        'valor' => $_mensagemObj->dados->valor_empenhar
                    ];
                }
                break;
            case 'desempenharPontosCRMNeos':
                $_cbext = new integracao_cashbackcrmneos($GLOBALS['_MASTER']);
                $_rc = $_cbext->cancelarEmpenho($_mensagemObj->cod_loja,$_mensagemObj->dados->cod_pdv,$_mensagemObj->dados->cpf_cliente,$_mensagemObj->dados->lancamento_uuid,$_mensagemObj->dados->celular_cliente);
                if($_rc->erro!=0) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro! o cancelamento do empenho no CRMNeos falhou';
                } else {
                    $_data = date("d-m-Y");
                    $_retorno['dados'] = [
                        'resultado'=> '0',
                        'cod_pdv' => $_mensagemObj->dados->cod_pdv,
                        'data' => $_data,
                        'id_definitivo' => $_rc->id_definitivo,
                        'valor_desempenhado' => $_rc->valor_desempenhado,
                        'lancamento_uuid' => $_rc->lancamento_uuid
                    ];
                }
                break;
            case 'consultarSangria':
                /* datas devem ter o padr�o internacional YYYY-MM-DD */
                $_retorno['resultado'] = '0';
                $_retorno['mensagem'] = 'Consulta realizada com sucesso';

                if(empty($_mensagemObj->dados->data_inicio) || empty($_mensagemObj->dados->data_fim)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: dados data_inicio e data_fim s�o obrigat�rios';
                    break;
                }

                $_classe = new rel_sangrias($GLOBALS['_MASTER']);
                $_consulta = $_classe->consultarSangria($_mensagemObj->cod_loja, $_mensagemObj->cod_pdv, $_mensagemObj->dados->data_inicio, $_mensagemObj->dados->data_fim);

                if($_consulta->erro !=0) {
                    $_retorno['resultado'] = $_consulta->erro;
                    $_retorno['mensagem'] = $_consulta->mensagem;
                } else {
                    $_retorno['dados'] = new stdClass();
                    $_retorno['dados']->LST_SANGRIAS = $_consulta->dados;
                }

                break;
            /**
             * new-1524
             * BIT
             * Mai.2025
             */
            case 'propostasMeuCrediario':
                $_cl = new cliente($GLOBALS['_MASTER']);
                $_html_entities = false;
                $_json = [
                    'cliente' => $_mensagemObj->dados->codcli,
                    'cpfcnpj' => $_mensagemObj->dados->cpfcnpj,
                    'rne' => $_mensagemObj->dados->rne,
                    'pais' => $_mensagemObj->dados->cod_pais,
                    'encode' => false,
                    'loja' => $_mensagemObj->cod_loja,
                    'acao' => 'PDV',
                    'propostas' => $_mensagemObj->dados->propostas ?: [],
                    'contratos' => [],
                    'buscarContratos' => false,
                ];
                $_resposta = $_cl->consultarClienteMeuCrediarioAjax(json_encode($_json));
                if($_resposta->sucesso===false) {
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = $_resposta->mensagem;
                } else {
                    $_retorno['dados']->propostas = $_resposta->meucrediario->propostas ?: $_mensagemObj->dados->propostas ?: [];
                    $_retorno['dados']->limite = $_resposta->meucrediario->limite ?: [];
                }
                break;
            case 'atualizaTelefoneCliente':
               try{
                    $_cli = new cliente($GLOBALS['_MASTER']);
                    $_retorno = $_cli->atualizaTelefoneCliente($_mensagemObj->cod_loja, $_mensagemObj->dados, $_mensagemObj->cod_pdv);
                }catch(Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: '.$e->getMessage();
                    throw $e; // Repassando para tratar banco offline
                }
                break;
            case 'Empenha2ValeTroca':
                $_html_entities = false;

                try {
                    if (empty($_mensagemObj->cod_loja) || empty($_mensagemObj->dados->cpfcnpj) || empty($_mensagemObj->dados->voucher) || empty($_mensagemObj->dados->valor_empenhar) || empty($_mensagemObj->cod_pdv)) {
                        throw new Exception("Dados incompletos para processamento.");
                    }

                    $_cbext = new integracao_cashbackexterno($GLOBALS['_MASTER']);
                    $_rc = $_cbext->empenha2ValeTrocaCashbackExterno($_mensagemObj->cod_loja, $_mensagemObj->dados->cpfcnpj, $_mensagemObj->dados->voucher, $_mensagemObj->dados->valor_empenhar, $_mensagemObj->cod_pdv);

                    if ($_rc['resultado'] == 0) {
                        $_retorno['dados'] = array(
                            'valor_total' => empty($_rc['dados']['valor_total']) ? 0 : $_rc['dados']['valor_total'],
                            'empenhados' => empty($_rc['dados']['empenhados']) ? [] : $_rc['dados']['empenhados']
                        );
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = empty($_rc['mensagem']) ? 'Erro no processamento' : $_rc['mensagem'];
                    }
                } catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $e->getMessage();
                }
                break;
            case 'ContrataCategoriaCliente':
                $_html_entities = false;

                try {
                    if (empty($_mensagemObj->cod_loja)) {
                         throw new Exception("Campo loja vazio.");
                    }
                    
                    // petz n�o usa o rne em 01/12/2025
                    if ($_mensagemObj->dados->rne && empty($_mensagemObj->dados->cpfcnpj) && empty($_mensagemObj->dados->codcli)) {
                        throw new Exception("Impossivel validar via rne.");
                    }
                    
                    if (empty($_mensagemObj->dados->cpfcnpj) && empty($_mensagemObj->dados->codcli)) {
                        throw new Exception("Cpfcnpj ou codcli vazio.");
                    }
                    
                    if (empty($_mensagemObj->dados->codmerc)) {
                        throw new Exception("Codigo de mercadoria vazia.");
                    }
                    
                    //enviando dados para atualizaCategoriaCliente
                    $_dados = $_mensagemObj->dados;

                    $_cbext = new integracao_petz($GLOBALS['_MASTER']);
                    $_rc = $_cbext->atualizaCategoriaCliente($_mensagemObj->cod_loja, $_dados);

                    if ($_rc['resultado'] == 0) {
                        $_retorno['dados'] = array(
                            'messages' => !empty($_rc['messages']) ? $_rc['messages'] : [],
                            'beforeTier' => !empty($_rc['beforeTier']) ? $_rc['beforeTier'] : [],
                            'afterTier' => !empty($_rc['afterTier']) ? $_rc['afterTier'] : []
                        );
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = empty($_rc['mensagem']) ? 'Erro no processamento' : $_rc['mensagem'];
                    }
                } catch (Exception $_e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_e->getMessage();
                }
                break;
            case 'ConsultaEconomia':
                $_html_entities = false;

                try {
                    if (empty($_mensagemObj->cod_loja)) {
                         throw new Exception("Campo loja vazio.");
                    }
                    
                    // petz n�o usa o rne em 01/12/2025
                    if ($_mensagemObj->dados->rne && empty($_mensagemObj->dados->cpfcnpj) && empty($_mensagemObj->dados->codcli)) {
                        throw new Exception("Impossivel validar via rne.");
                    }
                    
                    if (empty($_mensagemObj->dados->cpfcnpj) && empty($_mensagemObj->dados->codcli)) {
                        throw new Exception("Cpfcnpj ou codcli vazio.");
                    }
                    
                    //enviando dados para consultaSaldoEconomizadoComClub
                    $_dados = $_mensagemObj->dados;
                    
                    $_cbext = new integracao_petz($GLOBALS['_MASTER']);
                    $_rc = $_cbext->consultaSaldoEconomizadoComClub($_mensagemObj->cod_loja, $_dados);

                    if ($_rc['resultado'] == 0) {
                        $_retorno['dados'] = array(
                            'tierInfo' => !empty($_rc['tierInfo']) ? $_rc['tierInfo'] : [],
                            'totalEarnings' => !empty($_rc['totalEarnings']) ? $_rc['totalEarnings'] : 0,
                            'benefits' => !empty($_rc['benefits']) ? $_rc['benefits'] : []
                        );
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = empty($_rc['mensagem']) ? 'Erro no processamento' : $_rc['mensagem'];
                    }
                } catch (Exception $_e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_e->getMessage();
                }
                break;
            case 'Cancela2EmpenhoValeTroca':
                $_html_entities = false;

                try {

                    if (empty($_mensagemObj->cod_loja) || empty($_mensagemObj->dados->voucher) || empty($_mensagemObj->dados->cod_transacao) || empty($_mensagemObj->cod_pdv ) || empty($_mensagemObj->dados->cpfcnpj)) {
                        throw new Exception("Dados incompletos para processamento.");
                    }

                    $_cbext = new integracao_cashbackexterno($GLOBALS['_MASTER']);
                    $_rc = $_cbext->cancela2ValeTrocaCashbackExterno($_mensagemObj->cod_loja, $_mensagemObj->dados->voucher, $_mensagemObj->dados->cod_transacao, $_mensagemObj->cod_pdv , $_mensagemObj->dados->cpfcnpj, $_mensagemObj->dados->lido);

                    if ($_rc['resultado'] == 0) {
                       $_retorno['mensagem'] = $_rc['mensagem'];
                    } else {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = empty($_rc['mensagem']) ? 'Erro no processamento' : $_rc['mensagem'];
                    }
                } catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $e->getMessage();
                }
                break;
            /**
             * PEND-1423
             * Marcos Bezerra
             * Out.2025
             */
            case 'consultarVendedoresPorLoja':
                $_html_entities = false;
                try {
                    $_funcs = new funcionario($GLOBALS['_MASTER']);
                    $_funcionarios = $_funcs->listarFuncionariosPorLoja($_mensagemObj->cod_loja);

                    if (empty($_funcionarios)) {
                       throw new Exception("Nenhum vendedor encontrado para a loja {$_mensagemObj->cod_loja}");
                    }

                    $_retorno= [
                        'resultado' => '0',
                        'mensagem' => '',
                        'dados' => [
                            'vendedores' => $_funcionarios,
                            'total' => is_array($_funcionarios) ? count($_funcionarios) : 0,
                        ]
                    ];
                } catch (Exception $_e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = $_e->getMessage();
                }
                break;
            case 'consultaListaPedidos':
                $_class = new zan_pedido($GLOBALS["_MASTER"]);
                $_lista = $_class->pedidosParaImpressaoPDV($_mensagemObj->cod_loja);
                if(!empty($_lista)){
                    $_retorno['dados'] = $_lista;
                }else{
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = "Falha ao consultar lista de pedidos";
                }
                break;
            case 'consultaPedidoParaImpressao':
                $_class = new zan_pedido($GLOBALS["_MASTER"]);
                $_impressao = $_class->impressaoPedidoPDV($_mensagemObj->cod_loja,$_mensagemObj->dados->num_pedido,$_mensagemObj->dados->colunas_impressora);
                if(!empty($_impressao)){
                    $_retorno['dados'] = $_impressao;
                }else{
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = 'Falha ao consultar pedido';
                }
                break;
            case 'informaPedidoImpresso':
                $_class = new zan_pedido($GLOBALS["_MASTER"]);
                if($_class->marcarPedidoImpresso($_mensagemObj->cod_loja,$_mensagemObj->dados->num_pedido)){
                    $_retorno['dados']->resultado = 0;
                }else{
                    $_retorno['dados']->resultado = 1;
                    $_retorno['dados']->mensagem = 'Falha ao atualizar pedido';
                }
                break;
            /**
             *
             */
            case 'consultaCarneJequiti':
                $_html_entities = false;

                try {

                    if (!isset($_mensagemObj->cod_loja) || empty($_mensagemObj->cod_loja) ) {
                        throw new Exception("C�digo da loja n�o informado!");
                    }
                    if (!isset($_mensagemObj->dados->numero_carne) || empty($_mensagemObj->dados->numero_carne) ) {
                        throw new Exception("N�mero do carn� n�o informado!");
                    }

                    $_jequiti = new integracao_jequiti($GLOBALS['_MASTER']);
                    $_dados_completos = isset($_mensagemObj->dados->numero_carne) ? $_mensagemObj->dados->dados_completos : false;
                    $_somente_pagaveis = isset($_mensagemObj->dados->somente_pagaveis) ? $_mensagemObj->dados->somente_pagaveis : true;
                    $_consulta = $_jequiti->consultaCarne($_mensagemObj->cod_loja, $_mensagemObj->dados->numero_carne,$_dados_completos, $_somente_pagaveis);
                    if($_consulta['resultado'] != 0) {
                        throw new Exception($_consulta['mensagem']);
                    }
                    $_retorno['dados'] = $_consulta['dados'];

                } catch (Exception $e) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = utf8_encode($e->getMessage());
                }
                break;
            /**
             * base-10461
             * BIT
             * Dez.2025
             */
            case 'enviarLinkPagamento':
                $_link = $_mensagemObj->dados->link ?: $_mensagemObj->dados->url;
                $_canal = $_mensagemObj->dados->canal==1 ? 'email' : ($_mensagemObj->dados->canal==2 ? 'sms' : 'email');
                $_telefone = $_mensagemObj->dados->telefone;
                $_email = $_mensagemObj->dados->email;
                // Verifica��o de presen�a dos campos
                if(empty($_link)||empty($_canal)) {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: link de pagamento e/ou canal n�o informados';
                    break;
                }
                // Envio por SMS
                if($_canal=='sms') {
                    if(empty($_telefone)) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: telefone n�o foi informado';
                    }
                    $_fabrica_mecanismo_integracao = new sms_zenvia_service_factory();
                    $_fabrica_mecanismo_integracao::$_texto_sms = $_link;
                    $_mecanismo_integracao = $_fabrica_mecanismo_integracao->getInstance();
                    $_mecanismo_integracao->setTextoSMS($_link);
                    // 3 tentativas de envio
                    for($i = 0; $i < 3; $i++) {
                        $_resultado = $_mecanismo_integracao->sendSmsRequest($_telefone,'');
                        if(!$_resultado['statusErro']) {
                            break;
                        }
                    }
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'SMS enviado com sucesso';
                    if ($_resultado['statusErro']) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: SMS n�o enviado ap�s 3 tentativas';
                    }
                // Envio por Email
                } elseif($_canal=='email') {
                    if(empty($_email)) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: email n�o foi informado';
                        break;
                    }
                    $_titulo = 'Link de pagamento';
                    $_mensagem = $_link;
                    $_send_email = new email();
                    // 3 tentativas de envio
                    for($i = 0; $i < 3; $i++) {
                        $_sent = $_send_email->EnviaEmailPear($_email, $_mensagem, $_titulo, null, array(), null, 'HTML');
                        if($_sent) {
                            break;
                        }
                    }
                    $_retorno['resultado'] = '0';
                    $_retorno['mensagem'] = 'Email enviado com sucesso';
                    if(!$_sent) {
                        $_retorno['resultado'] = '1';
                        $_retorno['mensagem'] = 'Erro: Email n�o enviado ap�s 3 tentativas';
                        break;
                    }
                // Fallback
                } else {
                    $_retorno['resultado'] = '1';
                    $_retorno['mensagem'] = 'Erro: canal inv�lido';
                    break;
                }
                break;
            default:
                $_retorno['resultado'] = '1';
                $_retorno['mensagem'] = 'Nenhum tipo encontrado';
                break;
        }

        //Como nem todos os m�todos est�o devidamente protegidos, melhor garantir...
    } catch(Exception $e) {
        $_erro = $e->getCode();

        // Tratando Retorno
        if($_retorno['resultado'] == "") {
            $_retorno['resultado'] = (empty($_erro) ? 1 : "{$_erro}");
            $_retorno['mensagem'] = "Erro: {$e->getMessage()}";
        }

        /**
         * Tratando Exce��o de Banco
         *
         * Aten��o: Como utilizaram tratamento de "exce��o" na forma "condicional" nos cases acima,
         * ent�o infelizmente tenho que repassar a exce��o "throw $e;" para cada m�todo que queria
         * ser validado se o banco est� off, somente assim consigo fazer o tratamento
         * num �nico ponto em comum.
         */
        if($_erro == 9000001) {
            $_retorno['off'] = 1;
        }
    }
}
ob_clean();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
if (is_array($_retorno) || is_object($_retorno)) {
    $_obj_json = JSON::encode((object)$_retorno, $_html_entities);
    if ($_obj_json === false) {
        funcoesGerais::GravaLog(" erro json " . json_last_error_msg() . "\nmsg: {$_mensagem} \nretorno: " . var_export($_retorno,true),true,true);
    }
} else {
    $_obj_json = $_retorno;
}

$_dados = (array)$_dados;
$_dados['dados'] = (array)$_dados['dados'];

//WEDOOF2-1 - Se o PDV enviar esse par�metro ent�o ele quer que fazemos um entities decode antes de retornar
if($_dados['dados']['res_html_entities_decode'] === true){
    $_obj_json = html_entity_decode($_obj_json);
}
//WEDOOF2-1 - Se o PDV enviar esse par�metro ent�o ele quer que fazemos um utf8 decode antes de retornar
if($_dados['dados']['utf8_decode'] === true) {
    $_obj_json = utf8_decode($_obj_json);
}

//Se for uma comunica��o Rest com PDV Tecla Mouse retorna o callback, PDV comum retorna somente o JSON
if($_origem == 'PDVTM') {
    echo $_GET['retorno'] . '(' .  $_obj_json . ')';
}else{
    echo $_obj_json;
}
if($_DEBUG) {
    funcoesGerais::GravaLog("JSON (ENVIO) :: {$_mensagem}", true, true);
    funcoesGerais::GravaLog("JSON (RETORNO) :: {$_obj_json}", true, true);
}
?>