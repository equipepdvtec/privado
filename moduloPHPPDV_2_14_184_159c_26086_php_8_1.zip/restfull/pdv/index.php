<?php
/**
 * Atalho para comunicacao_pdv.php5
 * Usado pelo m�dulo PDV (php -S) para acessar via index.php
 * 
 * Carrega o arquivo XML_EMPRESA.xml da pasta raiz do projeto
 * e disponibiliza as configura��es para o comunicacao_pdv.php5
 */
    date_default_timezone_set("America/Bahia");
    ini_set("date.timezone","America/Bahia");
    //Setando informa��es para pegar um problema de erro 500 na chamada do PDV>
    if (ini_get("error_log") == "") {
        ini_set("error_log", "./php_error.log");
    }
    ini_set("post_max_size","800M");
    ini_set("memory_limit","1024M");
    ini_set("error_reporting","E_ALL & ~E_DEPRECATED & ~E_STRICT & ~E_NOTICE & ~E_WARNING");
    ini_set("ignore_repeated_errors","On");
    ini_set("log_errors","On");
    ini_set('display_errors', "Off");
    ini_set('display_startup_errors', "Off");
    
    
    

	$GLOBALS['_IS_MANAGER_PDV'] = true;
	$GLOBALS['_INCLUIR']		= false;
	chdir("../../");
    // Carrega o NF_EMPRESA.XML da pasta raiz
    $_caminhoXML = '/Zanthus/Zeus/pdvJava/NF_EMPRESA.XML';

if (file_exists($_caminhoXML)) {
    $_xmlContent = file_get_contents($_caminhoXML);
    $_xmlEmpresa = simplexml_load_string($_xmlContent);
    
    // Disponibiliza o XML como global para o comunicacao_pdv.php5 usar
    $GLOBALS['_XML_EMPRESA'] = $_xmlEmpresa;
} else {
	$_msg = "AVISO: Arquivo NF_EMPRESA.XML n�o encontrado em {$_caminhoXML}";
	echo $_msg;
    // Se n�o encontrou o XML, registra aviso mas continua
    //error_log($_msg);
}


require ("restfull/pdv/comunicacao_pdv.php5");
